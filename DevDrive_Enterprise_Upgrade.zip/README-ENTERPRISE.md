# Enterprise Deployment Guide

## Prerequisites
- Docker
- Kubernetes Cluster

## Quick Start
`npm start`