#!/bin/bash
echo "Running TITAN Setup..."
npm install