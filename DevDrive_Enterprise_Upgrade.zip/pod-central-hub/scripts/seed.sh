#!/bin/bash
echo "Seeding Enterprise Dataset..."