import { describe, it, expect } from 'vitest';
describe('CRUD', () => { it('creates record', () => expect(true).toBe(true)) });