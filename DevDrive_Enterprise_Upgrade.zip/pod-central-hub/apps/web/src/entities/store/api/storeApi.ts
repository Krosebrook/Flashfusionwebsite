import { localDb } from '@/shared/lib/localDb';
export const storeApi = { getAll: () => localDb.get('stores') }