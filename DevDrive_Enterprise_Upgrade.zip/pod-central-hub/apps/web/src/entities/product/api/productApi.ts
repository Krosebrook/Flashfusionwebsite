import { localDb } from '@/shared/lib/localDb';
export const productApi = { getAll: () => localDb.get('products') }