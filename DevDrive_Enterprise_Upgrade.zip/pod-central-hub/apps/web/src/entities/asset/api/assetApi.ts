import { localDb } from '@/shared/lib/localDb';
export const assetApi = { getAll: () => localDb.get('assets') }