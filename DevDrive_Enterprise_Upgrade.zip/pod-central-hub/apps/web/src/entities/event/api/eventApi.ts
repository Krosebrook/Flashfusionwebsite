import { localDb } from '@/shared/lib/localDb';
export const eventApi = { getAll: () => localDb.get('events') }