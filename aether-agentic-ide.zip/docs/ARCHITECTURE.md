# Architecture Overview

## Overview
Aether Agentic IDE is a React-based Progressive Web App (PWA) for orchestrating Gemini agents.
- Source: `index.html` (PWA meta tags), `index.tsx` (React root).
- Confidence: HIGH

## Modules
1.  **Sidebar**: Navigation and Agent list (`components/Sidebar.tsx`).
2.  **ChatView**: Agent interaction interface (`components/ChatView.tsx`).
3.  **CanvasView**: Workflow/Node editor (`components/CanvasView.tsx`).
4.  **MetricsView**: Telemetry visualization (`components/MetricsView.tsx`).
5.  **Terminal**: API and System terminals (`components/ApiTerminal.tsx`, `components/SystemTerminal.tsx`).
6.  **Orchestration**: Agent management (`components/OrchestrationView.tsx`).
- Source: `App.tsx` routing/rendering logic.
- Confidence: HIGH

## Data Flow
> Status: UNKNOWN
> Action Required: Human Review. Diagram state flow between App.tsx, Contexts, and IndexedDB.
> Confidence: LOW

## Orchestration Pattern
> Status: UNKNOWN
> Action Required: Human Review. Document how agents communicate or chain tasks.
> Confidence: LOW

## Trust Boundaries
- User Input -> React Component -> `geminiService` -> External API.
- LocalStorage/IndexedDB -> React Component.
- Source: Code inspection of `ChatView.tsx` and `ApiKeysContext.tsx`.
- Confidence: MEDIUM

## Failure Modes
> Status: UNKNOWN
> Action Required: Human Review.
> Confidence: LOW
