# Documentation Policy

## 1. Scope
This policy governs the following assets:
- `docs/**`
- `ADR/**`
- `llms.txt`
- `llms-full.txt`
- `CHANGELOG.md`

## 2. Authority Model
- **Human Authority**: Developers and Maintainers have final say.
- **Documentation Authority Agent (DAA)**: Authorized to maintain the structure, consistency, and index files (`llms-full.txt`).

## 3. Provenance Rules
All structural changes or factual assertions in documentation must include a provenance footer or block:
- **Source**: File path, commit SHA, or external standard.
- **Locator**: Line number or specific section.
- **Confidence**: HIGH, MEDIUM, or LOW.
- **Last Verified**: YYYY-MM-DD.

If provenance cannot be established, the section must be marked:
> Status: UNKNOWN
> Action Required: Human Review
> Confidence: LOW

## 4. Incremental Updates
- The DAA must NOT rewrite entire files unless `DOC_REWRITE_APPROVED=true` is explicitly set in the task context.
- Updates should be append-only or surgical edits to specific sections.

## 5. Architecture Decision Records (ADR)
- ADRs are immutable once finalized.
- New decisions supersede old ones via new ADR files (e.g., `0002-new-decision.md`).

## 6. Automation & Kill Switch
- CI/CD pipelines automate the generation of `llms-full.txt`.
- **Kill Switch**: Set `DOC_AUTOMATION_ENABLED=false` in repository variables to disable auto-commits by the DAA.

## 7. Compliance Claims
- Do NOT make unfounded compliance claims (SOC2, HIPAA, ISO) without verified external audit evidence linked in `SECURITY.md`.
