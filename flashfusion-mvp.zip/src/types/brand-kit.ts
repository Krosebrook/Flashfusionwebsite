// FlashFusion MVP - Brand Kit Types
// Type-safe definitions for Claude API response

export interface BrandKitInput {
  description: string;
  audience: string;
  style: string;
}

export interface ColorPalette {
  primary: string;
  secondary: string;
  accent: string;
  neutral: string;
  background: string;
}

export interface LogoConcept {
  name: string;
  description: string;
  usage: string;
}

export interface FontPairing {
  name: string;
  role: "Headlines" | "Body Text";
  googleFont: string;
  rationale: string;
  sizes: string;
}

export interface MockupIdea {
  product: string;
  designConcept: string;
  placement: string;
}

export interface BrandVoice {
  tone: string;
  messaging: string;
  doWrite: string;
  dontWrite: string;
}

export interface BrandKit {
  colors: ColorPalette;
  colorRationale: string;
  logos: [LogoConcept, LogoConcept, LogoConcept];
  fonts: [FontPairing, FontPairing];
  mockups: MockupIdea[];
  brandVoice: BrandVoice;
  usageGuidelines: string;
}

// API response wrapper
export interface GenerateResponse {
  success: boolean;
  data?: BrandKit;
  error?: string;
}

// Validation helpers
export function isValidHexColor(color: string): boolean {
  return /^#[0-9A-Fa-f]{6}$/.test(color);
}

export function validateBrandKit(kit: unknown): kit is BrandKit {
  if (!kit || typeof kit !== "object") return false;
  
  const k = kit as Record<string, unknown>;
  
  // Check required top-level fields exist
  const requiredFields = ["colors", "logos", "fonts", "mockups", "brandVoice"];
  for (const field of requiredFields) {
    if (!(field in k)) return false;
  }
  
  // Validate colors
  const colors = k.colors as Record<string, unknown>;
  const colorKeys = ["primary", "secondary", "accent", "neutral", "background"];
  for (const key of colorKeys) {
    if (typeof colors[key] !== "string") return false;
  }
  
  // Validate logos array
  if (!Array.isArray(k.logos) || k.logos.length < 3) return false;
  
  // Validate fonts array
  if (!Array.isArray(k.fonts) || k.fonts.length < 2) return false;
  
  // Validate mockups array
  if (!Array.isArray(k.mockups) || k.mockups.length < 1) return false;
  
  return true;
}
