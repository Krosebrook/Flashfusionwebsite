// FlashFusion MVP - Checkout API Route
// POST /api/checkout - Creates Stripe checkout session

import { NextRequest, NextResponse } from "next/server";
import { createCheckoutSession } from "@/lib/stripe";

export async function POST(request: NextRequest) {
  try {
    // Parse request body
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, error: "Invalid JSON in request body" },
        { status: 400 }
      );
    }

    // Validate input
    if (!body || typeof body !== "object") {
      return NextResponse.json(
        { success: false, error: "Request body must be an object" },
        { status: 400 }
      );
    }

    const input = body as Record<string, unknown>;

    if (typeof input.brandKitId !== "string" || !input.brandKitId) {
      return NextResponse.json(
        { success: false, error: "brandKitId is required" },
        { status: 400 }
      );
    }

    // Get origin for redirect URLs
    const origin =
      request.headers.get("origin") ||
      process.env.NEXT_PUBLIC_APP_URL ||
      "http://localhost:3000";

    // Create checkout session
    const session = await createCheckoutSession({
      brandKitId: input.brandKitId,
      customerEmail:
        typeof input.email === "string" ? input.email : undefined,
      successUrl: `${origin}/generate?success=true`,
      cancelUrl: `${origin}/generate?canceled=true`,
    });

    return NextResponse.json({
      success: true,
      url: session.url,
      sessionId: session.sessionId,
    });
  } catch (error) {
    console.error("Checkout API error:", error);

    const message =
      error instanceof Error ? error.message : "Unknown error occurred";

    return NextResponse.json(
      { success: false, error: message },
      { status: 500 }
    );
  }
}

// Only allow POST
export async function GET() {
  return NextResponse.json(
    { success: false, error: "Method not allowed. Use POST." },
    { status: 405 }
  );
}
