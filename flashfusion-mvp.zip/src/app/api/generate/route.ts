// FlashFusion MVP - Generate API Route
// POST /api/generate - Creates brand kit via Claude

import { NextRequest, NextResponse } from "next/server";
import { generateBrandKit } from "@/lib/claude";
import { BrandKitInput } from "@/types/brand-kit";

// Rate limiting (simple in-memory, use Redis in production)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 5; // requests per window
const RATE_WINDOW = 60 * 1000; // 1 minute

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const record = rateLimitMap.get(ip);

  if (!record || record.resetAt < now) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW });
    return true;
  }

  if (record.count >= RATE_LIMIT) {
    return false;
  }

  record.count++;
  return true;
}

export async function POST(request: NextRequest) {
  try {
    // Get client IP for rate limiting
    const ip =
      request.headers.get("x-forwarded-for")?.split(",")[0] ||
      request.headers.get("x-real-ip") ||
      "unknown";

    // Rate limit check
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Rate limit exceeded. Fix: Wait 60 seconds. Retry: Yes, after cooldown.",
        },
        { status: 429 }
      );
    }

    // Parse request body
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, error: "Invalid JSON in request body" },
        { status: 400 }
      );
    }

    // Validate input structure
    if (!body || typeof body !== "object") {
      return NextResponse.json(
        { success: false, error: "Request body must be an object" },
        { status: 400 }
      );
    }

    const input = body as Record<string, unknown>;

    // Validate required fields
    if (
      typeof input.description !== "string" ||
      typeof input.audience !== "string" ||
      typeof input.style !== "string"
    ) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required fields: description, audience, style",
        },
        { status: 400 }
      );
    }

    // Sanitize input (basic XSS prevention)
    const sanitize = (str: string): string => {
      return str
        .replace(/[<>]/g, "") // Remove angle brackets
        .replace(/javascript:/gi, "") // Remove JS protocol
        .replace(/on\w+=/gi, "") // Remove event handlers
        .trim();
    };

    const sanitizedInput: BrandKitInput = {
      description: sanitize(input.description),
      audience: sanitize(input.audience),
      style: sanitize(input.style),
    };

    // Generate brand kit
    const brandKit = await generateBrandKit(sanitizedInput);

    // Generate a simple ID for the brand kit (for Stripe metadata)
    const brandKitId = `bk_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

    return NextResponse.json({
      success: true,
      data: brandKit,
      brandKitId,
    });
  } catch (error) {
    console.error("Generate API error:", error);

    const message =
      error instanceof Error ? error.message : "Unknown error occurred";

    // Don't expose internal errors
    const safeMessage = message.includes("API key")
      ? "Service configuration error. Please try again later."
      : message;

    return NextResponse.json(
      { success: false, error: safeMessage },
      { status: 500 }
    );
  }
}

// Only allow POST
export async function GET() {
  return NextResponse.json(
    { success: false, error: "Method not allowed. Use POST." },
    { status: 405 }
  );
}
