// FlashFusion MVP - Root Layout
import type { Metadata } from "next";
import { Space_Grotesk, DM_Sans } from "next/font/google";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "FlashFusion | Brand Kit Generator for POD Creators",
  description:
    "Generate a complete brand identity in 5 minutes. Colors, logo concepts, fonts, mockup ideas, and usage guidelines for your print-on-demand business.",
  keywords: ["brand kit", "POD", "print on demand", "branding", "logo", "design"],
  openGraph: {
    title: "FlashFusion | Brand Kit Generator",
    description: "Generate a complete brand identity in 5 minutes.",
    type: "website",
    url: "https://flashfusion.vercel.app",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${spaceGrotesk.variable} ${dmSans.variable}`}
    >
      <body className="font-body bg-gray-950 text-gray-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
