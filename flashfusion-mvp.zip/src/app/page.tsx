// FlashFusion MVP - Landing Page
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="flex-1 flex items-center justify-center px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          {/* Logo/Brand */}
          <div className="mb-8">
            <span className="text-5xl">⚡</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="gradient-text">Brand Kit</span>
            <br />
            <span className="text-white">in 5 Minutes</span>
          </h1>

          {/* Subheadline */}
          <p className="text-xl text-gray-400 mb-8 max-w-xl mx-auto">
            Generate a complete brand identity for your print-on-demand business.
            Colors, logo concepts, fonts, mockup ideas, and usage guidelines.
          </p>

          {/* CTA */}
          <Link
            href="/generate"
            className="inline-block px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 
                       text-white font-semibold text-lg rounded-lg
                       hover:from-indigo-500 hover:to-purple-500
                       transition-all duration-200 shadow-lg hover:shadow-indigo-500/25"
          >
            Generate Your Brand Kit →
          </Link>

          {/* Social Proof / Price */}
          <p className="mt-6 text-gray-500">
            Preview free • Download for $20
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gray-900/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-white text-center mb-12">
            What You Get
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl mb-4">🎨</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Color Palette
              </h3>
              <p className="text-gray-400 text-sm">
                5 harmonized colors with usage rationale and accessibility compliance
              </p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">✏️</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Logo Concepts
              </h3>
              <p className="text-gray-400 text-sm">
                3 detailed logo descriptions ready to hand to a designer
              </p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">🔤</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Font Pairings
              </h3>
              <p className="text-gray-400 text-sm">
                2 Google Font recommendations with sizing guidelines
              </p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">📦</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Mockup Ideas
              </h3>
              <p className="text-gray-400 text-sm">
                5 product-specific design concepts with placement details
              </p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Brand Voice
              </h3>
              <p className="text-gray-400 text-sm">
                Tone, tagline, and do/don&apos;t messaging examples
              </p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">📋</div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Usage Guide
              </h3>
              <p className="text-gray-400 text-sm">
                How to apply your brand consistently across all touchpoints
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-gray-800">
        <div className="max-w-4xl mx-auto text-center text-gray-500 text-sm">
          <p>
            Built by FlashFusion •{" "}
            <a href="mailto:support@flashfusion.app" className="hover:text-gray-400">
              Contact
            </a>
          </p>
        </div>
      </footer>
    </main>
  );
}
