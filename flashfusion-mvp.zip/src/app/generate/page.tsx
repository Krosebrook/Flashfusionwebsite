"use client";

// FlashFusion MVP - Generate Page
// Main wizard: Form → Generate → Preview → Purchase/Download

import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import BrandForm from "@/components/BrandForm";
import BrandPreview from "@/components/BrandPreview";
import { BrandKit, BrandKitInput } from "@/types/brand-kit";
import { generateBrandKitPDF, downloadPDF } from "@/lib/pdf";

type Step = "form" | "loading" | "preview" | "success";

export default function GeneratePage() {
  const searchParams = useSearchParams();

  const [step, setStep] = useState<Step>("form");
  const [brandKit, setBrandKit] = useState<BrandKit | null>(null);
  const [brandKitId, setBrandKitId] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [hasPaid, setHasPaid] = useState(false);

  // Check URL params for payment success/cancel
  useEffect(() => {
    const success = searchParams.get("success");
    const canceled = searchParams.get("canceled");

    if (success === "true") {
      setHasPaid(true);
      // Try to restore brand kit from sessionStorage
      const stored = sessionStorage.getItem("flashfusion_brandkit");
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          setBrandKit(parsed.brandKit);
          setBrandKitId(parsed.brandKitId);
          setStep("preview");
        } catch {
          // If parse fails, just show success message
          setStep("success");
        }
      }
    }

    if (canceled === "true") {
      setError("Payment was canceled. You can try again when ready.");
      // Restore preview if available
      const stored = sessionStorage.getItem("flashfusion_brandkit");
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          setBrandKit(parsed.brandKit);
          setBrandKitId(parsed.brandKitId);
          setStep("preview");
        } catch {
          setStep("form");
        }
      }
    }
  }, [searchParams]);

  const handleGenerate = async (input: BrandKitInput) => {
    setStep("loading");
    setError(null);

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to generate brand kit");
      }

      setBrandKit(data.data);
      setBrandKitId(data.brandKitId);

      // Store in sessionStorage for payment return
      sessionStorage.setItem(
        "flashfusion_brandkit",
        JSON.stringify({
          brandKit: data.data,
          brandKitId: data.brandKitId,
        })
      );

      setStep("preview");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
      setStep("form");
    }
  };

  const handlePurchase = async () => {
    if (!brandKitId) return;

    setIsPurchasing(true);
    setError(null);

    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brandKitId }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to create checkout session");
      }

      // Redirect to Stripe Checkout
      window.location.href = data.url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Checkout failed");
      setIsPurchasing(false);
    }
  };

  const handleDownload = () => {
    if (!brandKit) return;

    try {
      const pdfBlob = generateBrandKitPDF(brandKit);
      const filename = `flashfusion-brand-kit-${brandKitId || "draft"}.pdf`;
      downloadPDF(pdfBlob, filename);
    } catch (err) {
      setError("Failed to generate PDF. Please try again.");
    }
  };

  const handleReset = () => {
    setBrandKit(null);
    setBrandKitId("");
    setError(null);
    setHasPaid(false);
    setStep("form");
    sessionStorage.removeItem("flashfusion_brandkit");
    // Clear URL params
    window.history.replaceState({}, "", "/generate");
  };

  return (
    <main className="min-h-screen py-12 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Link href="/" className="inline-block mb-6 text-3xl">
            ⚡
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2">
            {step === "form" && "Create Your Brand Kit"}
            {step === "loading" && "Generating..."}
            {step === "preview" && "Your Brand Kit"}
            {step === "success" && "Success!"}
          </h1>
          <p className="text-gray-400">
            {step === "form" &&
              "Tell us about your business and we'll create a complete brand identity."}
            {step === "loading" &&
              "Our AI is crafting your unique brand identity..."}
            {step === "preview" && "Review your brand kit below."}
            {step === "success" && "Your brand kit is ready to download."}
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-8 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
            <p className="text-red-400 text-sm">{error}</p>
            <button
              onClick={() => setError(null)}
              className="text-red-300 text-sm underline mt-2"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Step: Form */}
        {step === "form" && (
          <BrandForm onSubmit={handleGenerate} isLoading={false} />
        )}

        {/* Step: Loading */}
        {step === "loading" && (
          <div className="text-center py-20">
            <div className="inline-block mb-6">
              <svg
                className="animate-spin h-12 w-12 text-indigo-500"
                viewBox="0 0 24 24"
                fill="none"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
            </div>
            <p className="text-gray-400">
              This usually takes 15-30 seconds...
            </p>
            <p className="text-gray-500 text-sm mt-2">
              Crafting colors, logos, fonts, and more.
            </p>
          </div>
        )}

        {/* Step: Preview */}
        {step === "preview" && brandKit && (
          <>
            <BrandPreview
              brandKit={brandKit}
              brandKitId={brandKitId}
              onDownload={handleDownload}
              onPurchase={handlePurchase}
              isPurchasing={isPurchasing}
              hasPaid={hasPaid}
            />

            <div className="text-center mt-8">
              <button
                onClick={handleReset}
                className="text-gray-500 hover:text-gray-400 text-sm underline"
              >
                Start Over with New Brand
              </button>
            </div>
          </>
        )}

        {/* Step: Success (fallback if brandKit not restored) */}
        {step === "success" && !brandKit && (
          <div className="text-center py-12">
            <div className="text-6xl mb-6">🎉</div>
            <h2 className="text-2xl font-bold text-white mb-4">
              Payment Successful!
            </h2>
            <p className="text-gray-400 mb-8">
              Your brand kit has been unlocked. If the download didn&apos;t start,
              please generate a new one.
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500"
            >
              Generate New Brand Kit
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
