"use client";

// FlashFusion MVP - Brand Form Component
// Collects user input for brand kit generation

import { useState } from "react";
import { BrandKitInput } from "@/types/brand-kit";

interface BrandFormProps {
  onSubmit: (input: BrandKitInput) => void;
  isLoading: boolean;
}

const STYLE_OPTIONS = [
  { value: "minimal", label: "Minimal & Clean", emoji: "✨" },
  { value: "bold", label: "Bold & Vibrant", emoji: "🔥" },
  { value: "playful", label: "Playful & Fun", emoji: "🎨" },
  { value: "luxury", label: "Luxury & Refined", emoji: "💎" },
  { value: "retro", label: "Retro & Vintage", emoji: "📻" },
  { value: "organic", label: "Natural & Organic", emoji: "🌿" },
];

export default function BrandForm({ onSubmit, isLoading }: BrandFormProps) {
  const [description, setDescription] = useState("");
  const [audience, setAudience] = useState("");
  const [style, setStyle] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!description || description.length < 20) {
      newErrors.description =
        "Please describe your business in at least 20 characters";
    }
    if (description.length > 1000) {
      newErrors.description = "Description must be under 1000 characters";
    }

    if (!audience || audience.length < 10) {
      newErrors.audience =
        "Please describe your target audience in at least 10 characters";
    }
    if (audience.length > 500) {
      newErrors.audience = "Audience must be under 500 characters";
    }

    if (!style) {
      newErrors.style = "Please select a style preference";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({ description, audience, style });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Business Description */}
      <div>
        <label
          htmlFor="description"
          className="block text-sm font-medium text-gray-200 mb-2"
        >
          Describe your business
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Example: I sell handmade jewelry inspired by ocean waves. Each piece is crafted from recycled silver and features unique textures that remind people of beach vacations."
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg 
                     text-gray-100 placeholder-gray-500
                     focus:ring-2 focus:ring-indigo-500 focus:border-transparent
                     transition-all duration-200"
          rows={4}
          maxLength={1000}
          disabled={isLoading}
        />
        <div className="flex justify-between mt-1">
          {errors.description && (
            <p className="text-red-400 text-sm">{errors.description}</p>
          )}
          <p className="text-gray-500 text-sm ml-auto">
            {description.length}/1000
          </p>
        </div>
      </div>

      {/* Target Audience */}
      <div>
        <label
          htmlFor="audience"
          className="block text-sm font-medium text-gray-200 mb-2"
        >
          Who is your target audience?
        </label>
        <textarea
          id="audience"
          value={audience}
          onChange={(e) => setAudience(e.target.value)}
          placeholder="Example: Women aged 25-45 who love travel and sustainable fashion. They shop on Etsy, follow beach lifestyle accounts on Instagram, and care about eco-friendly products."
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg 
                     text-gray-100 placeholder-gray-500
                     focus:ring-2 focus:ring-indigo-500 focus:border-transparent
                     transition-all duration-200"
          rows={3}
          maxLength={500}
          disabled={isLoading}
        />
        <div className="flex justify-between mt-1">
          {errors.audience && (
            <p className="text-red-400 text-sm">{errors.audience}</p>
          )}
          <p className="text-gray-500 text-sm ml-auto">
            {audience.length}/500
          </p>
        </div>
      </div>

      {/* Style Preference */}
      <div>
        <label className="block text-sm font-medium text-gray-200 mb-3">
          Choose your brand style
        </label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {STYLE_OPTIONS.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setStyle(option.value)}
              disabled={isLoading}
              className={`px-4 py-3 rounded-lg border-2 text-left transition-all duration-200
                ${
                  style === option.value
                    ? "border-indigo-500 bg-indigo-500/20 text-white"
                    : "border-gray-700 bg-gray-800 text-gray-300 hover:border-gray-600"
                }
                ${isLoading ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
              `}
            >
              <span className="text-xl mr-2">{option.emoji}</span>
              <span className="text-sm font-medium">{option.label}</span>
            </button>
          ))}
        </div>
        {errors.style && (
          <p className="text-red-400 text-sm mt-2">{errors.style}</p>
        )}
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={isLoading}
        className={`w-full py-4 px-6 rounded-lg font-semibold text-lg
          transition-all duration-200
          ${
            isLoading
              ? "bg-gray-700 text-gray-400 cursor-not-allowed"
              : "bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-500 hover:to-purple-500 shadow-lg hover:shadow-indigo-500/25"
          }
        `}
      >
        {isLoading ? (
          <span className="flex items-center justify-center gap-2">
            <svg
              className="animate-spin h-5 w-5"
              viewBox="0 0 24 24"
              fill="none"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
            Generating your brand kit...
          </span>
        ) : (
          "Generate Brand Kit ✨"
        )}
      </button>

      <p className="text-center text-gray-500 text-sm">
        Takes about 15-30 seconds. Preview is free, download is $20.
      </p>
    </form>
  );
}
