"use client";

// FlashFusion MVP - Brand Preview Component
// Displays generated brand kit with download/purchase options

import { BrandKit } from "@/types/brand-kit";

interface BrandPreviewProps {
  brandKit: BrandKit;
  brandKitId: string;
  onDownload: () => void;
  onPurchase: () => void;
  isPurchasing: boolean;
  hasPaid: boolean;
}

export default function BrandPreview({
  brandKit,
  brandKitId,
  onDownload,
  onPurchase,
  isPurchasing,
  hasPaid,
}: BrandPreviewProps) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-2">
          Your Brand Kit is Ready! 🎉
        </h2>
        <p className="text-gray-400">
          Preview your complete brand identity below
        </p>
      </div>

      {/* Color Palette */}
      <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          🎨 Color Palette
        </h3>
        <div className="flex flex-wrap gap-4 mb-4">
          {Object.entries(brandKit.colors).map(([name, color]) => (
            <div key={name} className="text-center">
              <div
                className="w-16 h-16 rounded-lg shadow-lg border border-gray-600"
                style={{ backgroundColor: color }}
              />
              <p className="text-xs text-gray-400 mt-2 capitalize">{name}</p>
              <p className="text-xs text-gray-500 font-mono">{color}</p>
            </div>
          ))}
        </div>
        {brandKit.colorRationale && (
          <p className="text-sm text-gray-400 italic">
            {brandKit.colorRationale}
          </p>
        )}
      </section>

      {/* Logo Concepts */}
      <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          ✏️ Logo Concepts
        </h3>
        <div className="space-y-4">
          {brandKit.logos.map((logo, index) => (
            <div
              key={index}
              className="bg-gray-900/50 rounded-lg p-4 border border-gray-700"
            >
              <h4 className="font-medium text-indigo-400 mb-2">{logo.name}</h4>
              <p className="text-sm text-gray-300 mb-2">{logo.description}</p>
              <p className="text-xs text-gray-500">📍 {logo.usage}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Typography */}
      <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          🔤 Typography
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          {brandKit.fonts.map((font, index) => (
            <div
              key={index}
              className="bg-gray-900/50 rounded-lg p-4 border border-gray-700"
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-white">{font.name}</h4>
                <span className="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded">
                  {font.role}
                </span>
              </div>
              <p className="text-sm text-gray-400 mb-2">{font.rationale}</p>
              <p className="text-xs text-gray-500">Sizes: {font.sizes}</p>
              <a
                href={`https://fonts.google.com/specimen/${font.googleFont}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-indigo-400 hover:text-indigo-300 mt-2 inline-block"
              >
                View on Google Fonts →
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* Product Mockups */}
      <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          📦 Product Mockup Ideas
        </h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {brandKit.mockups.map((mockup, index) => (
            <div
              key={index}
              className="bg-gray-900/50 rounded-lg p-4 border border-gray-700"
            >
              <h4 className="font-medium text-white mb-2">{mockup.product}</h4>
              <p className="text-sm text-gray-400 mb-2">
                {mockup.designConcept}
              </p>
              <p className="text-xs text-gray-500">📐 {mockup.placement}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Brand Voice */}
      <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          💬 Brand Voice
        </h3>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-400 mb-1">Tone:</p>
            <p className="text-white font-medium">{brandKit.brandVoice.tone}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Tagline:</p>
            <p className="text-xl text-indigo-400 font-semibold italic">
              "{brandKit.brandVoice.messaging}"
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
              <p className="text-green-400 text-sm font-medium mb-2">
                ✓ Do Write
              </p>
              <p className="text-gray-300 text-sm">
                {brandKit.brandVoice.doWrite}
              </p>
            </div>
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
              <p className="text-red-400 text-sm font-medium mb-2">
                ✗ Don't Write
              </p>
              <p className="text-gray-300 text-sm">
                {brandKit.brandVoice.dontWrite}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Usage Guidelines */}
      {brandKit.usageGuidelines && (
        <section className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            📋 Usage Guidelines
          </h3>
          <p className="text-gray-300">{brandKit.usageGuidelines}</p>
        </section>
      )}

      {/* Action Buttons */}
      <div className="bg-gradient-to-r from-indigo-900/50 to-purple-900/50 rounded-xl p-6 border border-indigo-500/30">
        <div className="text-center mb-4">
          <p className="text-gray-300 mb-2">
            {hasPaid
              ? "Thank you for your purchase! Download your brand kit."
              : "Like what you see? Download the full PDF brand kit."}
          </p>
          {!hasPaid && (
            <p className="text-2xl font-bold text-white">
              $20{" "}
              <span className="text-sm font-normal text-gray-400">
                one-time
              </span>
            </p>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          {hasPaid ? (
            <button
              onClick={onDownload}
              className="px-8 py-3 bg-gradient-to-r from-green-600 to-emerald-600 
                         text-white font-semibold rounded-lg
                         hover:from-green-500 hover:to-emerald-500
                         transition-all duration-200 shadow-lg"
            >
              Download PDF →
            </button>
          ) : (
            <>
              <button
                onClick={onPurchase}
                disabled={isPurchasing}
                className={`px-8 py-3 font-semibold rounded-lg transition-all duration-200
                  ${
                    isPurchasing
                      ? "bg-gray-700 text-gray-400 cursor-not-allowed"
                      : "bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-500 hover:to-purple-500 shadow-lg"
                  }
                `}
              >
                {isPurchasing ? "Redirecting to checkout..." : "Purchase & Download"}
              </button>
              <button
                onClick={onDownload}
                className="px-8 py-3 bg-gray-700 text-gray-300 font-semibold rounded-lg
                           hover:bg-gray-600 transition-all duration-200"
              >
                Preview PDF (Watermarked)
              </button>
            </>
          )}
        </div>

        <p className="text-center text-gray-500 text-sm mt-4">
          ID: {brandKitId}
        </p>
      </div>
    </div>
  );
}
