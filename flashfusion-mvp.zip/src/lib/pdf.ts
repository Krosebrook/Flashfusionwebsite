// FlashFusion MVP - PDF Generation
// Client-side PDF creation for brand kit download

import { jsPDF } from "jspdf";
import { BrandKit } from "@/types/brand-kit";

export function generateBrandKitPDF(brandKit: BrandKit): Blob {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;
  let yPos = margin;

  // Helper: Add heading
  const addHeading = (text: string, size: number = 16) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", "bold");
    doc.text(text, margin, yPos);
    yPos += size * 0.5;
  };

  // Helper: Add paragraph
  const addParagraph = (text: string, size: number = 11) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", "normal");
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, yPos);
    yPos += lines.length * size * 0.4 + 5;
  };

  // Helper: Add color swatch
  const addColorSwatch = (
    color: string,
    label: string,
    x: number,
    y: number
  ) => {
    // Draw colored rectangle
    doc.setFillColor(color);
    doc.rect(x, y, 25, 15, "F");

    // Draw border
    doc.setDrawColor(200, 200, 200);
    doc.rect(x, y, 25, 15, "S");

    // Add label
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(50, 50, 50);
    doc.text(label, x, y + 20);
    doc.text(color.toUpperCase(), x, y + 24);
  };

  // Helper: Check if need new page
  const checkNewPage = (needed: number) => {
    if (yPos + needed > pageHeight - margin) {
      doc.addPage();
      yPos = margin;
    }
  };

  // ===== PAGE 1: COVER =====
  doc.setFillColor(brandKit.colors.primary);
  doc.rect(0, 0, pageWidth, 80, "F");

  doc.setFontSize(32);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(255, 255, 255);
  doc.text("Brand Kit", pageWidth / 2, 45, { align: "center" });

  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text("by FlashFusion", pageWidth / 2, 58, { align: "center" });

  doc.setTextColor(50, 50, 50);
  yPos = 100;

  addHeading("Your Brand Identity", 20);
  yPos += 5;
  addParagraph(
    "This brand kit contains everything you need to maintain a consistent brand identity across all your print-on-demand products and marketing materials."
  );

  // ===== COLOR PALETTE =====
  yPos += 10;
  addHeading("Color Palette", 16);
  yPos += 5;

  const colorY = yPos;
  addColorSwatch(brandKit.colors.primary, "Primary", margin, colorY);
  addColorSwatch(brandKit.colors.secondary, "Secondary", margin + 35, colorY);
  addColorSwatch(brandKit.colors.accent, "Accent", margin + 70, colorY);
  addColorSwatch(brandKit.colors.neutral, "Neutral", margin + 105, colorY);
  addColorSwatch(
    brandKit.colors.background,
    "Background",
    margin + 140,
    colorY
  );

  yPos = colorY + 35;
  if (brandKit.colorRationale) {
    addParagraph(brandKit.colorRationale);
  }

  // ===== PAGE 2: LOGOS =====
  doc.addPage();
  yPos = margin;

  addHeading("Logo Concepts", 18);
  yPos += 5;

  brandKit.logos.forEach((logo, index) => {
    checkNewPage(40);
    addHeading(`${index + 1}. ${logo.name}`, 14);
    yPos += 2;
    addParagraph(`Description: ${logo.description}`);
    addParagraph(`Usage: ${logo.usage}`);
    yPos += 5;
  });

  // ===== TYPOGRAPHY =====
  checkNewPage(60);
  yPos += 10;
  addHeading("Typography", 18);
  yPos += 5;

  brandKit.fonts.forEach((font) => {
    checkNewPage(35);
    addHeading(`${font.name} — ${font.role}`, 14);
    yPos += 2;
    addParagraph(`Google Fonts: fonts.google.com/specimen/${font.googleFont}`);
    addParagraph(`Rationale: ${font.rationale}`);
    addParagraph(`Recommended sizes: ${font.sizes}`);
    yPos += 5;
  });

  // ===== PAGE 3: MOCKUPS =====
  doc.addPage();
  yPos = margin;

  addHeading("Product Mockup Ideas", 18);
  yPos += 5;

  brandKit.mockups.forEach((mockup, index) => {
    checkNewPage(35);
    addHeading(`${index + 1}. ${mockup.product}`, 14);
    yPos += 2;
    addParagraph(`Design: ${mockup.designConcept}`);
    addParagraph(`Placement: ${mockup.placement}`);
    yPos += 5;
  });

  // ===== BRAND VOICE =====
  checkNewPage(70);
  yPos += 10;
  addHeading("Brand Voice", 18);
  yPos += 5;

  addParagraph(`Tone: ${brandKit.brandVoice.tone}`);
  addParagraph(`Tagline: "${brandKit.brandVoice.messaging}"`);
  yPos += 3;
  addParagraph(`✓ Do write: ${brandKit.brandVoice.doWrite}`);
  addParagraph(`✗ Don't write: ${brandKit.brandVoice.dontWrite}`);

  // ===== USAGE GUIDELINES =====
  checkNewPage(50);
  yPos += 10;
  addHeading("Usage Guidelines", 18);
  yPos += 5;
  addParagraph(brandKit.usageGuidelines || "Use these assets consistently across all touchpoints.");

  // ===== FOOTER =====
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(150, 150, 150);
    doc.text(
      `Generated by FlashFusion — Page ${i} of ${totalPages}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: "center" }
    );
  }

  return doc.output("blob");
}

export function downloadPDF(blob: Blob, filename: string = "brand-kit.pdf") {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
