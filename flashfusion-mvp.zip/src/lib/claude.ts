// FlashFusion MVP - Claude API Integration
// Single-call brand kit generation (no Symphony of Roles complexity)

import Anthropic from "@anthropic-ai/sdk";
import { BrandKit, BrandKitInput, validateBrandKit } from "@/types/brand-kit";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

const BRAND_KIT_PROMPT = `You are a professional brand designer with 15 years of experience in print-on-demand and e-commerce branding. You specialize in creating cohesive brand identities that convert browsers into buyers.

TASK: Generate a complete brand kit for a print-on-demand business.

INPUT:
- Business description: {description}
- Target audience: {audience}  
- Style preference: {style}

OUTPUT REQUIREMENTS:
Return ONLY valid JSON (no markdown code blocks, no explanations before or after).

STRUCTURE:
{
  "colors": {
    "primary": "#XXXXXX",
    "secondary": "#XXXXXX",
    "accent": "#XXXXXX",
    "neutral": "#XXXXXX",
    "background": "#XXXXXX"
  },
  "colorRationale": "2 sentences explaining color psychology for this audience",
  
  "logos": [
    {
      "name": "Primary Logo",
      "description": "Detailed description: shape, symbolism, style (e.g., 'Circular badge with stylized cat silhouette, whiskers forming letter C, playful hand-drawn line art style')",
      "usage": "Use on: website header, product tags, social media profile"
    },
    {
      "name": "Secondary Logo",  
      "description": "Simplified version for small spaces",
      "usage": "Use on: favicons, app icons, small product labels"
    },
    {
      "name": "Logo Mark",
      "description": "Icon-only version (no text)",
      "usage": "Use on: social media posts, pattern backgrounds"
    }
  ],
  
  "fonts": [
    {
      "name": "Font Name Here",
      "role": "Headlines",
      "googleFont": "Font+Name+For+URL",
      "rationale": "Why this font matches the brand personality",
      "sizes": "48px headlines, 32px subheadings"
    },
    {
      "name": "Font Name Here",
      "role": "Body Text", 
      "googleFont": "Font+Name+For+URL",
      "rationale": "Readable, pairs well with headline font",
      "sizes": "16px body, 14px captions"
    }
  ],
  
  "mockups": [
    {
      "product": "T-Shirt",
      "designConcept": "Detailed description of design",
      "placement": "Front center, 8x10 inches"
    },
    {
      "product": "Mug",
      "designConcept": "...",
      "placement": "Wrap-around design"
    },
    {
      "product": "Poster", 
      "designConcept": "...",
      "placement": "11x17 inches"
    },
    {
      "product": "Sticker",
      "designConcept": "...",
      "placement": "Die-cut, 3x3 inches"
    },
    {
      "product": "Tote Bag",
      "designConcept": "...",
      "placement": "Front panel, 10x12 inches"
    }
  ],
  
  "brandVoice": {
    "tone": "3 adjectives (e.g., playful, authentic, bold)",
    "messaging": "Sample tagline that captures brand essence",
    "doWrite": "Example good copy: '...'",
    "dontWrite": "Example bad copy to avoid: '...'"
  },
  
  "usageGuidelines": "3-4 sentences: how to use this kit consistently across all touchpoints"
}

QUALITY STANDARDS:
- Colors: Must pass WCAG AA contrast for text
- Fonts: Must be available on Google Fonts (verify exact names)
- Logo descriptions: Detailed enough that a designer could sketch it
- Mockups: Specific product + design concept + exact placement
- Brand voice: Avoid generic words like "innovative" - be specific to THIS business`;

export async function generateBrandKit(input: BrandKitInput): Promise<BrandKit> {
  // Input validation
  if (!input.description || input.description.length < 10) {
    throw new Error("Business description must be at least 10 characters");
  }
  if (!input.audience || input.audience.length < 5) {
    throw new Error("Target audience must be at least 5 characters");
  }
  if (!input.style || input.style.length < 5) {
    throw new Error("Style preference must be at least 5 characters");
  }

  // Length limits (prevent token abuse)
  if (input.description.length > 1000) {
    throw new Error("Business description must be under 1000 characters");
  }
  if (input.audience.length > 500) {
    throw new Error("Target audience must be under 500 characters");
  }
  if (input.style.length > 500) {
    throw new Error("Style preference must be under 500 characters");
  }

  const prompt = BRAND_KIT_PROMPT
    .replace("{description}", input.description)
    .replace("{audience}", input.audience)
    .replace("{style}", input.style);

  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    // Extract text content
    const content = response.content[0];
    if (content.type !== "text") {
      throw new Error("Unexpected response type from Claude API");
    }

    // Parse JSON response
    let brandKit: unknown;
    try {
      // Clean potential markdown code blocks
      let jsonText = content.text.trim();
      if (jsonText.startsWith("```json")) {
        jsonText = jsonText.slice(7);
      }
      if (jsonText.startsWith("```")) {
        jsonText = jsonText.slice(3);
      }
      if (jsonText.endsWith("```")) {
        jsonText = jsonText.slice(0, -3);
      }
      brandKit = JSON.parse(jsonText.trim());
    } catch (parseError) {
      console.error("JSON parse error:", content.text);
      throw new Error("Failed to parse brand kit response as JSON");
    }

    // Validate structure
    if (!validateBrandKit(brandKit)) {
      console.error("Validation failed:", brandKit);
      throw new Error("Brand kit response failed validation");
    }

    return brandKit;
  } catch (error) {
    // Cause → Fix → Retry pattern
    if (error instanceof Anthropic.APIError) {
      if (error.status === 429) {
        throw new Error(
          "Rate limit exceeded. Fix: Wait 60 seconds. Retry: Yes, automatically."
        );
      }
      if (error.status === 401) {
        throw new Error(
          "API key invalid. Fix: Check ANTHROPIC_API_KEY in .env. Retry: After fixing key."
        );
      }
      throw new Error(`Claude API error (${error.status}): ${error.message}`);
    }
    throw error;
  }
}
