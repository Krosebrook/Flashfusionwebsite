// FlashFusion MVP - Stripe Integration
// Simple checkout flow for $20 brand kit unlock

import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is required");
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-12-18.acacia",
});

export interface CheckoutSessionInput {
  brandKitId: string;
  customerEmail?: string;
  successUrl: string;
  cancelUrl: string;
}

export async function createCheckoutSession(
  input: CheckoutSessionInput
): Promise<{ url: string; sessionId: string }> {
  // Input validation
  if (!input.brandKitId || input.brandKitId.length < 1) {
    throw new Error("Brand kit ID is required");
  }
  if (!input.successUrl || !input.cancelUrl) {
    throw new Error("Success and cancel URLs are required");
  }

  // Validate URLs are from allowed origins
  const allowedOrigins = [
    process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
    "https://flashfusion.vercel.app",
  ];

  const isValidUrl = (url: string) => {
    try {
      const parsed = new URL(url);
      return allowedOrigins.some((origin) => url.startsWith(origin));
    } catch {
      return false;
    }
  };

  if (!isValidUrl(input.successUrl) || !isValidUrl(input.cancelUrl)) {
    throw new Error("Invalid redirect URLs");
  }

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "FlashFusion Brand Kit",
              description:
                "Complete brand identity: colors, logo concepts, fonts, mockup ideas, and usage guidelines",
              images: ["https://flashfusion.vercel.app/brand-kit-preview.png"],
            },
            unit_amount: 2000, // $20.00 in cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${input.successUrl}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: input.cancelUrl,
      customer_email: input.customerEmail,
      metadata: {
        brandKitId: input.brandKitId,
      },
      // Collect billing address for fraud prevention
      billing_address_collection: "required",
      // Allow promotion codes for early testers
      allow_promotion_codes: true,
    });

    if (!session.url) {
      throw new Error("Failed to create checkout session URL");
    }

    return {
      url: session.url,
      sessionId: session.id,
    };
  } catch (error) {
    if (error instanceof Stripe.errors.StripeError) {
      // Cause → Fix → Retry pattern
      if (error.type === "StripeAuthenticationError") {
        throw new Error(
          "Stripe API key invalid. Fix: Check STRIPE_SECRET_KEY in .env. Retry: After fixing key."
        );
      }
      if (error.type === "StripeRateLimitError") {
        throw new Error(
          "Stripe rate limit. Fix: Wait 60 seconds. Retry: Yes, automatically."
        );
      }
      throw new Error(`Stripe error: ${error.message}`);
    }
    throw error;
  }
}

export async function verifyPayment(
  sessionId: string
): Promise<{ paid: boolean; brandKitId: string | null }> {
  if (!sessionId || sessionId.length < 10) {
    throw new Error("Invalid session ID");
  }

  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    return {
      paid: session.payment_status === "paid",
      brandKitId: (session.metadata?.brandKitId as string) || null,
    };
  } catch (error) {
    if (error instanceof Stripe.errors.StripeError) {
      throw new Error(`Failed to verify payment: ${error.message}`);
    }
    throw error;
  }
}
