# FlashFusion MVP

> Generate complete brand kits for POD creators in 5 minutes. $20/kit.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your API keys

# 3. Run development server
npm run dev

# 4. Open http://localhost:3000
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | ✅ | Claude API key from [console.anthropic.com](https://console.anthropic.com) |
| `STRIPE_SECRET_KEY` | ✅ | Stripe secret key from [dashboard.stripe.com](https://dashboard.stripe.com/apikeys) |
| `NEXT_PUBLIC_APP_URL` | ❌ | Your app URL (defaults to localhost:3000) |

## Deploy to Vercel

### Option 1: One-Click Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/flashfusion-mvp)

### Option 2: CLI Deploy

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard
# Project Settings → Environment Variables
```

### Post-Deploy Checklist

1. ✅ Set environment variables in Vercel dashboard
2. ✅ Update `NEXT_PUBLIC_APP_URL` to your Vercel URL
3. ✅ Test Stripe checkout flow with test card `4242 4242 4242 4242`
4. ✅ Verify PDF download works
5. ⚠️ When ready for production, switch `sk_test_` to `sk_live_`

## Tech Stack

- **Framework:** Next.js 15 (App Router)
- **Styling:** Tailwind CSS
- **AI:** Claude Sonnet 4.5 (Anthropic)
- **Payments:** Stripe Checkout
- **PDF:** jsPDF (client-side)
- **Deploy:** Vercel

## Project Structure

```
src/
├── app/
│   ├── page.tsx              # Landing page
│   ├── generate/
│   │   └── page.tsx          # Brand kit wizard
│   ├── api/
│   │   ├── generate/         # Claude API endpoint
│   │   └── checkout/         # Stripe checkout
│   ├── layout.tsx
│   └── globals.css
├── components/
│   ├── BrandForm.tsx         # User input form
│   └── BrandPreview.tsx      # Brand kit display
├── lib/
│   ├── claude.ts             # Claude API wrapper
│   ├── stripe.ts             # Stripe integration
│   └── pdf.ts                # PDF generation
└── types/
    └── brand-kit.ts          # TypeScript types
```

## User Flow

1. User describes their business, audience, style preference
2. Claude generates complete brand kit (colors, logos, fonts, mockups, voice)
3. User previews brand kit for free
4. User pays $20 via Stripe to download PDF

## Cost Estimate

| Service | Monthly Cost (at 100 kits/mo) |
|---------|-------------------------------|
| Claude API | ~$15 (0.15/call × 100) |
| Stripe | 2.9% + $0.30 per transaction |
| Vercel | $0 (Hobby tier) |
| **Total** | ~$15-20 |

## Local Development

```bash
# Type check
npm run type-check

# Lint
npm run lint

# Build
npm run build
```

## Stripe Test Cards

| Card | Result |
|------|--------|
| `4242 4242 4242 4242` | Successful payment |
| `4000 0000 0000 0002` | Declined |
| `4000 0025 0000 3155` | Requires 3D Secure |

Use any future date and any 3-digit CVC.

## License

MIT

---

Built with ⚡ by FlashFusion
