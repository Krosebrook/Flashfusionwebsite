#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

export PORT="${PORT:-3000}"
MODE="${RUN_MODE:-prod}"

if [[ "$MODE" != "prod" && "$MODE" != "dev" ]]; then
  echo "==> Invalid RUN_MODE='$MODE' (expected 'prod' or 'dev'). Falling back to 'prod'."
  MODE="prod"
fi

echo "==> Nexus POD (Replit) boot"
echo "==> Node: $(node -v)"
echo "==> NPM : $(npm -v)"
echo "==> RUN_MODE: $MODE"
echo "==> PORT: $PORT"

# Install deps if missing
if [[ ! -d "node_modules" ]]; then
  echo "==> Installing dependencies (npm install)..."
  npm install
else
  echo "==> Dependencies already present (node_modules/)."
fi

if [[ "$MODE" == "dev" ]]; then
  echo "==> Dev mode: Vite UI on :3000, API on :3001"
  export NODE_ENV="development"

  SERVER_PID=""
  cleanup() {
    if [[ -n "${SERVER_PID}" ]]; then
      echo "==> Stopping API dev server (pid=$SERVER_PID)"
      kill "$SERVER_PID" >/dev/null 2>&1 || true
    fi
  }
  trap cleanup EXIT INT TERM

  echo "==> Starting API (server) dev watcher..."
  npm -w server run dev &
  SERVER_PID=$!

  # Give the watcher a moment to compile and bind
  sleep 1

  echo "==> Starting Vite dev server on 0.0.0.0:3000 (proxy /api -> :3001)..."
  exec npm -w client run dev -- --host 0.0.0.0 --port 3000 --strictPort
fi

# Build if dist outputs are missing
NEED_BUILD=0
if [[ ! -f "server/dist/index.js" ]]; then
  NEED_BUILD=1
fi
if [[ ! -f "client/dist/index.html" ]]; then
  NEED_BUILD=1
fi

if [[ "${SKIP_BUILD:-0}" == "1" ]]; then
  echo "==> SKIP_BUILD=1; skipping build."
elif [[ "$NEED_BUILD" == "1" ]]; then
  echo "==> Building workspace (npm run build)..."
  npm run build
else
  echo "==> Build artifacts present; skipping build."
fi

echo "==> Starting production server..."
exec npm start
