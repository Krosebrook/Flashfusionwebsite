import { createHash } from "node:crypto";
import { readEnv } from "../utils/env.js";
import { logger } from "../utils/logger.js";

export type GeneratedDesign = {
  provider: "mock" | "openai";
  imageDataUrl: string;
};

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function svgToDataUrl(svg: string): string {
  const b64 = Buffer.from(svg, "utf-8").toString("base64");
  return `data:image/svg+xml;base64,${b64}`;
}

function clampText(s: string, max = 80): string {
  const trimmed = (s || "").trim();
  if (trimmed.length <= max) return trimmed;
  return trimmed.slice(0, max - 1) + "…";
}

function placeholderSvg(prompt: string): string {
  const seed = createHash("sha256").update(prompt || "nexus").digest("hex");
  const c1 = `#${seed.slice(0, 6)}`;
  const c2 = `#${seed.slice(6, 12)}`;
  const label = clampText(prompt || "Demo Design");
  const subtitle = "Nexus POD • Demo Mode";

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
    <filter id="noise">
      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch"/>
      <feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 .12 0"/>
    </filter>
  </defs>

  <rect width="1024" height="1024" fill="url(#g)"/>
  <rect width="1024" height="1024" filter="url(#noise)" opacity="0.25"/>
  <g font-family="Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif" fill="white">
    <text x="64" y="160" font-size="56" font-weight="700">${escapeXml(label)}</text>
    <text x="64" y="220" font-size="28" opacity="0.9">${escapeXml(subtitle)}</text>
  </g>
  <g opacity="0.15" fill="white">
    <circle cx="820" cy="220" r="140"/>
    <circle cx="760" cy="760" r="240"/>
    <rect x="120" y="640" width="320" height="72" rx="36"/>
  </g>
</svg>`;
}

function escapeXml(str: string): string {
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;")
    .replaceAll("'", "&apos;");
}

async function openAiGenerate(prompt: string): Promise<string> {
  const apiKey = readEnv("OPENAI_API_KEY", { warnIfMissing: false });
  if (!apiKey) throw new Error("OPENAI_API_KEY missing");

  const model = readEnv("OPENAI_IMAGE_MODEL", { warnIfMissing: false }) || "gpt-image-1";
  const size = readEnv("OPENAI_IMAGE_SIZE", { warnIfMissing: false }) || "1024x1024";

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);

  try {
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "authorization": `Bearer ${apiKey}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model,
        prompt,
        size,
        // Prefer base64 so the client can save offline easily.
        response_format: "b64_json"
      }),
      signal: controller.signal
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`OpenAI image generation failed: ${res.status} ${text.slice(0, 500)}`);
    }

    const data = await res.json() as any;
    const first = data?.data?.[0];

    if (first?.b64_json) return `data:image/png;base64,${first.b64_json}`;
    if (first?.url) return String(first.url);

    throw new Error("OpenAI response missing image data");
  } finally {
    clearTimeout(timeout);
  }
}

export async function generateDesign(prompt: string): Promise<GeneratedDesign> {
  const apiKey = readEnv("OPENAI_API_KEY", { warnIfMissing: false });

  if (!apiKey) {
    await delay(3000);
    return { provider: "mock", imageDataUrl: svgToDataUrl(placeholderSvg(prompt)) };
  }

  try {
    const imageDataUrl = await openAiGenerate(prompt);
    return { provider: "openai", imageDataUrl };
  } catch (err) {
    logger.warn("OpenAI generation failed; falling back to Demo Mode placeholder.", String(err));
    // Fall back quickly (no need to wait full 3 seconds).
    return { provider: "mock", imageDataUrl: svgToDataUrl(placeholderSvg(prompt)) };
  }
}
