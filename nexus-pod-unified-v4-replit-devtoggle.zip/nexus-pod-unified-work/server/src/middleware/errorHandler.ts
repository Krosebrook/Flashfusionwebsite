import type { ErrorRequestHandler } from "express";
import { logger } from "../utils/logger.js";

export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  const requestId = (req as any).requestId || "unknown";
  const status = typeof (err as any)?.status === "number" ? (err as any).status : 500;

  logger.error(`requestId=${requestId}`, err);

  res.status(status).json({
    error: status >= 500 ? "internal_error" : "request_error",
    message: status >= 500 ? "Unexpected server error" : (err as any)?.message || "Bad request",
    requestId
  });
};
