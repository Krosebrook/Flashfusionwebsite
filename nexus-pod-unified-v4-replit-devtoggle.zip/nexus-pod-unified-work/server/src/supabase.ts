import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { readEnv } from "./utils/env.js";
import { logger } from "./utils/logger.js";

let cached: SupabaseClient | null | undefined;

export function getSupabaseClient(): SupabaseClient | null {
  if (cached !== undefined) return cached;

  const url = readEnv("SUPABASE_URL");
  const key = readEnv("SUPABASE_KEY", { displayName: "SUPABASE_KEY (service key recommended server-side)" });

  if (!url || !key) {
    cached = null;
    logger.warn("Supabase not configured. Running without DB (Demo Mode for persistence).");
    return cached;
  }

  cached = createClient(url, key, {
    auth: { persistSession: false },
    global: { headers: { "X-Client-Info": "nexus-pod-server" } }
  });

  return cached;
}
