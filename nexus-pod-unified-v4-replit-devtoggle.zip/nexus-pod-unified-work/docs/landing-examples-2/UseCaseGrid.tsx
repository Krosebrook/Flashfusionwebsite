'use client';

import React, { useState } from 'react';

interface UseCase {
  id: string;
  title: string;
  description: string;
  icon?: string;
  image?: string;
  benefits: string[];
  ctaText?: string;
  ctaLink?: string;
}

interface UseCaseGridProps {
  title: string;
  subtitle?: string;
  useCases: UseCase[];
  layout?: 'grid' | 'tabs' | 'accordion';
  columns?: 2 | 3;
}

/**
 * UseCaseGrid - Industry/use case specific sections
 * 
 * Usage: 40% of SaaS sites tailor messaging by vertical (e.g., "For Marketing Teams", "For Developers").
 * Shows how product solves problems for different user types.
 * 
 * @param title - Section heading
 * @param subtitle - Supporting description
 * @param useCases - Array of use cases with title, description, benefits, and optional CTA
 * @param layout - Display style: grid (cards), tabs (tabbed interface), accordion (expandable)
 * @param columns - Number of columns for grid layout
 */
export default function UseCaseGrid({
  title,
  subtitle,
  useCases,
  layout = 'grid',
  columns = 3,
}: UseCaseGridProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [openAccordion, setOpenAccordion] = useState<number | null>(0);

  const renderGrid = () => (
    <div className={`use-case-grid columns-${columns}`}>
      {useCases.map((useCase, index) => (
        <div key={useCase.id} className="use-case-card">
          {useCase.icon && (
            <div className="use-case-icon">{useCase.icon}</div>
          )}
          {useCase.image && (
            <div className="use-case-image">
              <img src={useCase.image} alt={useCase.title} loading="lazy" />
            </div>
          )}
          <h3>{useCase.title}</h3>
          <p className="description">{useCase.description}</p>
          
          {useCase.benefits.length > 0 && (
            <ul className="benefits">
              {useCase.benefits.map((benefit, idx) => (
                <li key={idx}>{benefit}</li>
              ))}
            </ul>
          )}
          
          {useCase.ctaText && (
            <a href={useCase.ctaLink || '#'} className="use-case-cta">
              {useCase.ctaText} →
            </a>
          )}
        </div>
      ))}
    </div>
  );

  const renderTabs = () => {
    const activeUseCase = useCases[activeTab];
    
    return (
      <div className="tabs-layout">
        <div className="tab-navigation">
          {useCases.map((useCase, index) => (
            <button
              key={useCase.id}
              className={`tab-button ${index === activeTab ? 'active' : ''}`}
              onClick={() => setActiveTab(index)}
            >
              {useCase.icon && <span className="tab-icon">{useCase.icon}</span>}
              {useCase.title}
            </button>
          ))}
        </div>
        
        <div className="tab-content">
          {activeUseCase.image && (
            <div className="content-image">
              <img src={activeUseCase.image} alt={activeUseCase.title} />
            </div>
          )}
          <div className="content-text">
            <h3>{activeUseCase.title}</h3>
            <p className="description">{activeUseCase.description}</p>
            
            {activeUseCase.benefits.length > 0 && (
              <ul className="benefits">
                {activeUseCase.benefits.map((benefit, idx) => (
                  <li key={idx}>{benefit}</li>
                ))}
              </ul>
            )}
            
            {activeUseCase.ctaText && (
              <a href={activeUseCase.ctaLink || '#'} className="btn-primary">
                {activeUseCase.ctaText}
              </a>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderAccordion = () => (
    <div className="accordion-layout">
      {useCases.map((useCase, index) => (
        <div key={useCase.id} className="accordion-item">
          <button
            className={`accordion-header ${openAccordion === index ? 'active' : ''}`}
            onClick={() => setOpenAccordion(openAccordion === index ? null : index)}
            aria-expanded={openAccordion === index}
          >
            {useCase.icon && <span className="accordion-icon">{useCase.icon}</span>}
            <span className="accordion-title">{useCase.title}</span>
            <svg
              className="chevron"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
            >
              <path
                d="M5 7.5L10 12.5L15 7.5"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          
          <div className={`accordion-content ${openAccordion === index ? 'open' : ''}`}>
            {useCase.image && (
              <img src={useCase.image} alt={useCase.title} loading="lazy" />
            )}
            <p className="description">{useCase.description}</p>
            
            {useCase.benefits.length > 0 && (
              <ul className="benefits">
                {useCase.benefits.map((benefit, idx) => (
                  <li key={idx}>{benefit}</li>
                ))}
              </ul>
            )}
            
            {useCase.ctaText && (
              <a href={useCase.ctaLink || '#'} className="accordion-cta">
                {useCase.ctaText} →
              </a>
            )}
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="use-case-section">
      <div className="section-header">
        <h2>{title}</h2>
        {subtitle && <p className="subtitle">{subtitle}</p>}
      </div>

      {layout === 'grid' && renderGrid()}
      {layout === 'tabs' && renderTabs()}
      {layout === 'accordion' && renderAccordion()}

      <style jsx>{`
        .use-case-section {
          padding: 80px 20px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .section-header {
          text-align: center;
          margin-bottom: 60px;
        }

        .section-header h2 {
          font-size: 2.5rem;
          font-weight: 700;
          margin-bottom: 16px;
          color: var(--gray-900);
        }

        .subtitle {
          font-size: 1.25rem;
          color: var(--gray-600);
          max-width: 700px;
          margin: 0 auto;
        }

        /* Grid Layout */
        .use-case-grid {
          display: grid;
          gap: 32px;
        }

        .columns-2 {
          grid-template-columns: repeat(2, 1fr);
        }

        .columns-3 {
          grid-template-columns: repeat(3, 1fr);
        }

        .use-case-card {
          padding: 32px;
          background: white;
          border: 1px solid var(--gray-200);
          border-radius: 12px;
          transition: all 0.3s ease;
        }

        .use-case-card:hover {
          border-color: var(--primary);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
          transform: translateY(-4px);
        }

        .use-case-icon {
          font-size: 2.5rem;
          margin-bottom: 20px;
        }

        .use-case-image {
          margin-bottom: 20px;
          border-radius: 8px;
          overflow: hidden;
        }

        .use-case-image img {
          width: 100%;
          height: auto;
        }

        .use-case-card h3 {
          font-size: 1.5rem;
          font-weight: 700;
          margin-bottom: 12px;
          color: var(--gray-900);
        }

        .description {
          font-size: 1rem;
          line-height: 1.7;
          color: var(--gray-600);
          margin-bottom: 20px;
        }

        .benefits {
          list-style: none;
          padding: 0;
          margin: 0 0 24px 0;
        }

        .benefits li {
          padding-left: 28px;
          margin-bottom: 12px;
          position: relative;
          font-size: 0.9375rem;
          color: var(--gray-700);
        }

        .benefits li::before {
          content: '✓';
          position: absolute;
          left: 0;
          color: var(--primary);
          font-weight: 700;
        }

        .use-case-cta {
          display: inline-block;
          color: var(--primary);
          font-weight: 600;
          text-decoration: none;
          transition: transform 0.2s ease;
        }

        .use-case-cta:hover {
          transform: translateX(4px);
        }

        /* Tabs Layout */
        .tabs-layout {
          display: flex;
          flex-direction: column;
          gap: 32px;
        }

        .tab-navigation {
          display: flex;
          gap: 8px;
          border-bottom: 2px solid var(--gray-200);
          overflow-x: auto;
        }

        .tab-button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 16px 24px;
          background: none;
          border: none;
          border-bottom: 3px solid transparent;
          font-size: 1rem;
          font-weight: 600;
          color: var(--gray-600);
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .tab-button:hover {
          color: var(--primary);
        }

        .tab-button.active {
          color: var(--primary);
          border-bottom-color: var(--primary);
        }

        .tab-icon {
          font-size: 1.25rem;
        }

        .tab-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 48px;
          align-items: center;
          min-height: 400px;
        }

        .content-image img {
          width: 100%;
          border-radius: 12px;
        }

        .content-text h3 {
          font-size: 2rem;
          font-weight: 700;
          margin-bottom: 16px;
          color: var(--gray-900);
        }

        .btn-primary {
          display: inline-block;
          padding: 14px 28px;
          background: var(--primary);
          color: white;
          font-weight: 600;
          border-radius: 8px;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .btn-primary:hover {
          background: var(--primary-dark);
          transform: translateY(-2px);
        }

        /* Accordion Layout */
        .accordion-layout {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .accordion-item {
          background: white;
          border: 1px solid var(--gray-200);
          border-radius: 12px;
          overflow: hidden;
        }

        .accordion-header {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 20px 24px;
          background: none;
          border: none;
          cursor: pointer;
          text-align: left;
          transition: background 0.2s ease;
        }

        .accordion-header:hover {
          background: var(--gray-50);
        }

        .accordion-header.active {
          background: var(--primary-50);
        }

        .accordion-icon {
          font-size: 1.5rem;
          flex-shrink: 0;
        }

        .accordion-title {
          flex: 1;
          font-size: 1.125rem;
          font-weight: 600;
          color: var(--gray-900);
        }

        .chevron {
          flex-shrink: 0;
          transition: transform 0.3s ease;
          color: var(--gray-500);
        }

        .accordion-header.active .chevron {
          transform: rotate(180deg);
        }

        .accordion-content {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
          padding: 0 24px;
        }

        .accordion-content.open {
          max-height: 800px;
          padding: 0 24px 24px 24px;
        }

        .accordion-content img {
          width: 100%;
          border-radius: 8px;
          margin-bottom: 20px;
        }

        .accordion-cta {
          display: inline-block;
          color: var(--primary);
          font-weight: 600;
          text-decoration: none;
          margin-top: 16px;
        }

        /* Responsive */
        @media (max-width: 1024px) {
          .columns-3 {
            grid-template-columns: repeat(2, 1fr);
          }

          .tab-content {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 768px) {
          .use-case-section {
            padding: 60px 16px;
          }

          .section-header h2 {
            font-size: 2rem;
          }

          .subtitle {
            font-size: 1.125rem;
          }

          .columns-2,
          .columns-3 {
            grid-template-columns: 1fr;
          }

          .use-case-card {
            padding: 24px;
          }

          .use-case-card h3 {
            font-size: 1.25rem;
          }

          .tab-navigation {
            flex-direction: column;
            border-bottom: none;
          }

          .tab-button {
            justify-content: space-between;
            border-bottom: 1px solid var(--gray-200);
            border-left: 3px solid transparent;
          }

          .tab-button.active {
            border-left-color: var(--primary);
            border-bottom-color: var(--gray-200);
          }

          .content-text h3 {
            font-size: 1.5rem;
          }

          .accordion-header {
            padding: 16px 20px;
          }

          .accordion-title {
            font-size: 1rem;
          }
        }
      `}</style>
    </div>
  );
}
