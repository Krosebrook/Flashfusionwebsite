# Nexus POD — Unified Central Hub (Full‑Stack + PWA)

This repo merges the **Nexus POD** full-stack API (Express + optional Supabase + commerce connectors) with a richer **Central Hub** UI (React Router + Tailwind + PWA) into a single portable monorepo.

## What you get

- **server/** (TypeScript, Express)
  - `/api/health`, `/api/status`
  - `/api/seed` (web-grounded seed payload used for first-run bootstrapping)
  - `/api/readiness` (configuration checks) and `/api/readiness?run=1` (connectivity probes)
  - `/api/generate-design` (OpenAI `gpt-image-1` if `OPENAI_API_KEY` is set; otherwise Demo Mode placeholder)
  - `/api/designs/:id/download` (server-backed downloads with correct headers)
  - `/api/publish-product` (Shopify/WooCommerce/Etsy/Printify connectors; fail-soft into Demo Mode)
- **client/** (React + Vite + PWA)
  - Dashboard, Analytics, Orders, Profit, Fulfillment
  - Products, Templates, Bulk Generator, Design Studio
  - Publishing Suite (bulk publish + local event log)
  - Automation Suite (manual-safe automations + CSV exports)
  - Stores, Readiness, Settings
  - Local demo persistence via `localStorage` (bootstrapped from `/api/seed`, with offline fallback)
  - Global **Demo Mode banner** driven by `/api/status`

## Requirements

- Node.js **20+**

## Run (dev)

Two terminals:

```bash
# terminal 1
npm install
npm -w server run dev
```

```bash
# terminal 2
npm -w client run dev
```

Client runs on Vite dev server and proxies `/api/*` to the server.

## Run (production / single deploy)

```bash
npm install
npm run build
npm start
```

## Env vars (optional)

Set these to enable real integrations. Missing keys do **not** crash the app.

### OpenAI (design generation)
- `OPENAI_API_KEY`
- `OPENAI_IMAGE_MODEL` (optional, default `gpt-image-1`)
- `OPENAI_IMAGE_SIZE` (optional, default `1024x1024`)

### Supabase (best-effort persistence)
- `SUPABASE_URL`
- `SUPABASE_KEY`

### Shopify
- `SHOPIFY_STORE_URL`
- `SHOPIFY_ACCESS_TOKEN`

Optional:
- `SHOPIFY_API_VERSION` (default: `2025-10`)
- `SHOPIFY_API_MODE` (default: `graphql`)

### Etsy
- `ETSY_API_KEY`

For OAuth2 (recommended):
- `ETSY_SHARED_SECRET`
- `ETSY_ACCESS_TOKEN`
- `ETSY_REFRESH_TOKEN`
- `ETSY_SHOP_ID`

Optional:
- `ETSY_API_BASE_URL` (default: `https://openapi.etsy.com`)

### Printify (optional)
- `PRINTIFY_API_TOKEN`
- `PRINTIFY_USER_AGENT` (default: `nexus-pod/1.0`)

### WooCommerce (optional)
- `WOOCOMMERCE_STORE_URL`
- `WOOCOMMERCE_CONSUMER_KEY`
- `WOOCOMMERCE_CONSUMER_SECRET`

### Ops tuning (optional)
- `RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_MS`
- `READINESS_CONNECT_TIMEOUT_MS`

### Observability (optional)
- `SENTRY_DSN`

## Smoke checks

With the server running:

```bash
npm run smoke
```

## Replit notes

This repo ships with a **monorepo‑tuned Replit preset**:

- `.replit` (Run command + port mapping)
- `replit.nix` (Node 20 + native build toolchain)
- `scripts/replit-run.sh` (smart boot)

### Port wiring

- Replit webview is pinned to **local :3000 → external :80** via `.replit`.
- **Prod mode** runs the Express server on :3000 and serves the built client from `client/dist`.
- **Dev mode** runs **Vite on :3000** and the API on :3001 (Vite proxies `/api/* → :3001`).

### RUN_MODE toggle (prod vs dev)

Default is production:

- `RUN_MODE=prod` (default)

To use dev mode:

- Set `RUN_MODE=dev` in Replit **Secrets** (or edit `.replit` env block)
- Press **Run**

### Build/run behavior

- `scripts/replit-run.sh` installs deps only if `node_modules/` is missing.
- In **prod mode**, it builds only if `server/dist` or `client/dist` is missing.

### Recommended Replit settings

- Put env vars in **Replit Secrets** (never commit secrets)
- Leave the Replit **Run** button as-is (it uses the preset)

## Implementation Considerations

- **Explicit port wiring:** `.replit` pins `PORT=3000` and maps `localPort=3000 → externalPort=80` so Replit’s webview stays predictable.
- **No rebuild loops:** the Replit boot script only runs `npm run build` when `dist/` artifacts are missing (or if you force it).
- **Offline-first boot:** the client bootstraps from `GET /api/seed` and falls back to a grounded offline seed if the API is unreachable.

## Performance/Security Notes

- `replit.nix` includes `python3/gcc/make/pkg-config` so native modules can build cleanly (avoids node-gyp failures).
- The run script never prints secrets and only sets a safe default `PORT`.
- Readiness probes are **user-triggered** and time-bounded; failures never block app startup.

## Recommended Next Steps

1. Set `OPENAI_API_KEY` (optional) to enable real image generation.
2. Set commerce secrets only for the connectors you actually want live.
3. If you want scheduled automations (not just manual-run): add a server scheduler (BullMQ + Redis or cron) to execute Automation Suite rules.

## Claims Check

- **Claim:** The repo includes `replit.nix`, `.replit`, and a monorepo-aware boot script.
  - **Check:** See `replit.nix`, `.replit`, and `scripts/replit-run.sh` at the repo root.
- **Claim:** Dev mode uses Vite on :3000 with API proxied to :3001.
  - **Check:** `RUN_MODE=dev` triggers the dev branch in `scripts/replit-run.sh`; Vite proxy is configured in `client/vite.config.ts`.

License: MIT
