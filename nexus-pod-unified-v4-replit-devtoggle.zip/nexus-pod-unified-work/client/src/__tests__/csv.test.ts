import { describe, it, expect } from "vitest";
import { toCsv } from "../utils/csv";

describe("toCsv", () => {
  it("escapes commas, quotes, and newlines", () => {
    const out = toCsv([
      { a: "hello,world", b: "\"quoted\"", c: "line1\nline2" },
      { a: "plain", b: "ok", c: "" }
    ]);

    // headers
    expect(out.split("\n")[0]).toContain("a");

    // escaped cells
    expect(out).toContain('"hello,world"');
    expect(out).toContain('"""quoted"""');
    expect(out).toContain('"line1\nline2"');
  });
});
