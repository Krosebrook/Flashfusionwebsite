import * as React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

import Layout from "@/components/layout/Layout";
import Dashboard from "@/pages/Dashboard";
import Analytics from "@/pages/Analytics";
import Orders from "@/pages/Orders";
import Profit from "@/pages/Profit";
import Fulfillment from "@/pages/Fulfillment";
import Products from "@/pages/Products";
import BulkGenerator from "@/pages/BulkGenerator";
import Templates from "@/pages/Templates";
import DesignStudio from "@/pages/DesignStudio";
import PublishingSuite from "@/pages/PublishingSuite";
import AutomationSuite from "@/pages/AutomationSuite";
import Stores from "@/pages/Stores";
import Readiness from "@/pages/Readiness";
import Settings from "@/pages/Settings";

import { ThemeProvider } from "@/context/ThemeContext";
import { AppDataProvider } from "@/context/AppDataContext";

export default function App() {
  // One-time hint (safe, no PII)
  React.useEffect(() => {
    toast.dismiss();
  }, []);

  return (
    <ThemeProvider>
      <AppDataProvider>
        <Toaster position="top-right" />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/profit" element={<Profit />} />
            <Route path="/fulfillment" element={<Fulfillment />} />
            <Route path="/products" element={<Products />} />
            <Route path="/bulk-generator" element={<BulkGenerator />} />
            <Route path="/templates" element={<Templates />} />
            <Route path="/design-studio" element={<DesignStudio />} />
            <Route path="/publishing" element={<PublishingSuite />} />
            <Route path="/automations" element={<AutomationSuite />} />
            <Route path="/stores" element={<Stores />} />
            <Route path="/readiness" element={<Readiness />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Route>
        </Routes>
      </AppDataProvider>
    </ThemeProvider>
  );
}
