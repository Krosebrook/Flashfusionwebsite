import * as React from "react";
import { Download, Search } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { formatUsd } from "@/utils/format";
import { downloadText, toCsv } from "@/utils/csv";

export default function Orders() {
  const { orders } = useAppData();
  const [query, setQuery] = React.useState("");
  const [status, setStatus] = React.useState<"ALL" | "PENDING" | "SHIPPED" | "DELIVERED">("ALL");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders
      .filter((o) => (status === "ALL" ? true : o.status === status))
      .filter((o) => {
        if (!q) return true;
        return o.customerName.toLowerCase().includes(q) || o.id.toLowerCase().includes(q);
      })
      .slice()
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [orders, query, status]);

  const totals = React.useMemo(() => {
    const revenue = filtered.reduce((acc, o) => acc + o.total, 0);
    const byStatus = filtered.reduce(
      (acc, o) => {
        acc[o.status] += 1;
        return acc;
      },
      { PENDING: 0, SHIPPED: 0, DELIVERED: 0 }
    );
    return { revenue, byStatus, count: filtered.length };
  }, [filtered]);

  const exportCsv = () => {
    const rows = filtered.map((o) => ({
      id: o.id,
      customerName: o.customerName,
      status: o.status,
      total: o.total,
      createdAt: o.createdAt,
      items: (o.items || []).map((it) => `${it.productId} x${it.quantity}`).join("; ")
    }));
    const csv = toCsv(rows);
    downloadText(`orders-${new Date().toISOString().slice(0, 10)}.csv`, csv);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Orders</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Search, filter, export. (Seed orders are demo, but the workflows are production-shaped.)</p>
        </div>
        <Button variant="secondary" onClick={exportCsv} disabled={filtered.length === 0}>
          <Download className="h-4 w-4 mr-2" /> Export CSV
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="text-sm text-slate-500 dark:text-slate-400">Revenue</div>
          <div className="text-2xl font-bold">{formatUsd(totals.revenue)}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Filtered set</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-slate-500 dark:text-slate-400">Orders</div>
          <div className="text-2xl font-bold">{totals.count}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">P:{totals.byStatus.PENDING} • S:{totals.byStatus.SHIPPED} • D:{totals.byStatus.DELIVERED}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-slate-500 dark:text-slate-400">Average Order</div>
          <div className="text-2xl font-bold">{formatUsd(totals.count ? totals.revenue / totals.count : 0)}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Filtered set</div>
        </Card>
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-3 flex-1">
            <Search className="h-4 w-4 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by customer or order id…"
              className="w-full bg-transparent outline-none text-sm"
              aria-label="Search orders"
            />
          </div>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as any)}
            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            aria-label="Filter order status"
          >
            <option value="ALL">All statuses</option>
            <option value="PENDING">Pending</option>
            <option value="SHIPPED">Shipped</option>
            <option value="DELIVERED">Delivered</option>
          </select>
        </div>
      </Card>

      <Card className="p-0 overflow-hidden">
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-900/40 text-slate-600 dark:text-slate-300">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Order</th>
                <th className="text-left px-4 py-3 font-medium">Customer</th>
                <th className="text-left px-4 py-3 font-medium">Status</th>
                <th className="text-right px-4 py-3 font-medium">Total</th>
                <th className="text-left px-4 py-3 font-medium">Created</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o.id} className="border-t border-slate-200 dark:border-slate-800">
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{o.id}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{o.customerName}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span
                      className={
                        "text-xs px-2 py-0.5 rounded-full " +
                        (o.status === "DELIVERED"
                          ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200"
                          : o.status === "SHIPPED"
                            ? "bg-sky-50 text-sky-800 dark:bg-sky-950/30 dark:text-sky-200"
                            : "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200")
                      }
                    >
                      {o.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">{formatUsd(o.total)}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{new Date(o.createdAt).toLocaleString()}</td>
                </tr>
              ))}

              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
                    No orders match this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
