import { BarChart3, Percent, Users, Zap } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { KpiCard } from "@/components/charts/KpiCard";
import { LineChartCard } from "@/components/charts/LineChartCard";
import { formatPercent, formatUsd } from "@/utils/format";
import { avg, lastNDays, sum } from "@/utils/kpi";

export default function Analytics() {
  const { seed } = useAppData();
  const ts = seed?.timeseries || [];
  const last14 = lastNDays(ts, 14);
  const totalSessions = sum(last14, "sessions");
  const totalOrders = sum(last14, "orders");
  const totalRevenue = sum(last14, "revenue");
  const totalAdSpend = sum(last14, "adSpend");
  const avgCvr = avg(last14, "conversionRate");
  const avgAov = avg(last14, "aov");
  const roas = totalAdSpend > 0 ? totalRevenue / totalAdSpend : 0;

  const chartData = last14.map((p) => ({ ...p, day: p.date.slice(5) }));

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Web-grounded KPIs derived from the seed timeseries. Use this dashboard to validate performance assumptions before wiring real ad + storefront data.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <KpiCard icon={Users} label="Sessions (14d)" value={totalSessions.toLocaleString()} subtext={`Orders: ${totalOrders.toLocaleString()}`} />
        <KpiCard icon={BarChart3} label="Revenue (14d)" value={formatUsd(totalRevenue)} subtext={`AOV: ${formatUsd(avgAov)}`} />
        <KpiCard icon={Percent} label="Conversion (avg)" value={formatPercent(avgCvr, 1)} subtext={`Bench: ${formatPercent(seed?.benchmarks.conversionRateTypical || 0, 1)}`} />
        <KpiCard icon={Zap} label="ROAS" value={roas ? roas.toFixed(2) : "—"} subtext={`Ad spend: ${formatUsd(totalAdSpend)}`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LineChartCard
          title="Sessions vs Orders"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "sessions", label: "Sessions" }, { dataKey: "orders", label: "Orders" }]}
          yFormatter={(v) => Number(v).toLocaleString()}
          height={400}
        />
        <LineChartCard
          title="Revenue vs Ad Spend"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "revenue", label: "Revenue" }, { dataKey: "adSpend", label: "Ad Spend" }]}
          yFormatter={(v) => formatUsd(Number(v))}
          height={400}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LineChartCard
          title="Conversion Rate"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "conversionRate", label: "Conversion" }]}
          yFormatter={(v) => formatPercent(Number(v), 1)}
          height={340}
        />
        <LineChartCard
          title="Average Order Value"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "aov", label: "AOV" }]}
          yFormatter={(v) => formatUsd(Number(v))}
          height={340}
        />
      </div>
    </div>
  );
}
