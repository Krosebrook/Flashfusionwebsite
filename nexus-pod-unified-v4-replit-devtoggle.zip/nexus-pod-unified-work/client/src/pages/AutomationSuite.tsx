import * as React from "react";
import toast from "react-hot-toast";
import {
  Bot,
  PlayCircle,
  Plus,
  Trash2,
  UploadCloud,
  Download,
  Clock,
  AlertTriangle
} from "lucide-react";

import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useAppData } from "@/context/AppDataContext";
import { publishProduct } from "@/lib/api";
import { toCsv, downloadText } from "@/utils/csv";
import { computeProfitByDay, type ProfitPoint } from "@/utils/kpi";
import { uuid } from "@/utils/id";
import type {
  AutomationAction,
  AutomationRule,
  AutomationTrigger,
  DesignAsset,
  Order,
  Product,
  PublishEvent,
  SeedPayload,
  SeedTimeseriesPoint,
  StoreKind
} from "@/types";

type RunResult = { ok: boolean; message: string };

async function mapWithConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = [];
  let idx = 0;
  const workers = new Array(Math.max(1, limit)).fill(0).map(async () => {
    while (idx < items.length) {
      const i = idx++;
      // eslint-disable-next-line no-await-in-loop
      const r = await fn(items[i]);
      results[i] = r;
    }
  });
  await Promise.all(workers);
  return results;
}

function actionLabel(a: AutomationAction): string {
  switch (a.type) {
    case "PUBLISH_READY_PRODUCTS":
      return `Publish READY → ${a.store}`;
    case "EXPORT_KPI_CSV":
      return "Export KPI CSV";
    case "EXPORT_ORDERS_CSV":
      return "Export Orders CSV";
    default:
      return "Unknown action";
  }
}

function triggerLabel(t: AutomationTrigger): string {
  switch (t.type) {
    case "MANUAL":
      return "Manual";
    case "ON_STATUS_READY":
      return "On product READY";
    case "SCHEDULED":
      return `Scheduled (${t.cron})`;
    default:
      return "Trigger";
  }
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${
        checked ? "bg-indigo-600" : "bg-slate-300 dark:bg-slate-700"
      }`}
      aria-pressed={checked}
      aria-label={checked ? "Disable" : "Enable"}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full bg-white transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}

function clampCsvFilename(name: string): string {
  const clean = name.replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  return clean.slice(0, 80) || "export";
}

function buildKpiCsvRows(args: { seedTimeseries: SeedTimeseriesPoint[]; profitByDay: ProfitPoint[] }): Record<string, any>[] {
  const byDate = new Map<string, ProfitPoint>();
  for (const p of args.profitByDay || []) byDate.set(String(p.date), p);
  return (args.seedTimeseries || []).map((t: SeedTimeseriesPoint) => {
    const p = byDate.get(String(t.date));
    return {
      date: t.date,
      sessions: t.sessions,
      orders: t.orders,
      revenue: t.revenue,
      adSpend: t.adSpend,
      conversionRate: t.conversionRate,
      aov: t.aov,
      ...(p
        ? {
            cogs: p.cogs,
            grossProfit: p.grossProfit,
            netProfit: p.netProfit,
            netMargin: p.netMargin,
            roas: p.roas
          }
        : {})
    };
  });
}

function flattenOrdersForCsv(orders: Order[]): Record<string, any>[] {
  return (orders || []).map((o) => ({
    id: o.id,
    createdAt: o.createdAt,
    customerName: o.customerName,
    status: o.status,
    total: o.total,
    itemCount: Array.isArray(o.items) ? o.items.reduce((acc, it) => acc + (Number(it.quantity) || 0), 0) : 0,
    items_json: JSON.stringify(o.items || [])
  }));
}

function getDesignImagesForProduct(p: Product, designs: DesignAsset[]): string[] {
  if (!p.designAssetId) return [];
  const d = designs.find((x) => x.id === p.designAssetId);
  if (!d) return [];
  // Prefer server-backed URL for publishing payloads when present.
  // (Connectors may still require externally hosted URLs; Demo Mode accepts anything.)
  return [d.downloadUrl || d.imageDataUrl].filter(Boolean);
}

async function runAutomationAction(args: {
  rule: AutomationRule;
  products: Product[];
  designs: DesignAsset[];
  orders: Order[];
  seed: SeedPayload | null;
  onPublishEvent: (e: PublishEvent) => void;
  onProductPublished: (p: Product) => void;
}): Promise<RunResult> {
  const { rule, products, designs, orders, seed } = args;

  if (rule.action.type === "EXPORT_KPI_CSV") {
    const ts = seed?.timeseries || ([] as SeedTimeseriesPoint[]);
    if (!Array.isArray(ts) || ts.length === 0) return { ok: false, message: "No seed timeseries available." };
    const profit = computeProfitByDay(seed, orders || ([] as Order[]), products || ([] as Product[]));
    const rows = buildKpiCsvRows({ seedTimeseries: ts, profitByDay: profit });
    const csv = toCsv(rows);
    const name = clampCsvFilename(`kpi-${new Date().toISOString().slice(0, 10)}.csv`);
    downloadText(name, csv);
    return { ok: true, message: `Downloaded ${rows.length} KPI rows.` };
  }

  if (rule.action.type === "EXPORT_ORDERS_CSV") {
    if (!Array.isArray(orders) || orders.length === 0) return { ok: false, message: "No orders available." };
    const rows = flattenOrdersForCsv(orders);
    const csv = toCsv(rows);
    const name = clampCsvFilename(`orders-${new Date().toISOString().slice(0, 10)}.csv`);
    downloadText(name, csv);
    return { ok: true, message: `Downloaded ${rows.length} orders.` };
  }

  if (rule.action.type === "PUBLISH_READY_PRODUCTS") {
    const store = rule.action.store;
    const ready = (products || []).filter((p) => p.status === "READY");
    if (ready.length === 0) return { ok: false, message: "No READY products to publish." };

    const concurrency = 3;
    const results = await mapWithConcurrency(ready, concurrency, async (p) => {
      const images = getDesignImagesForProduct(p, designs);
      try {
        const res = await publishProduct({
          store,
          product: {
            title: p.title,
            description: p.description,
            price: p.price,
            currency: "USD",
            images,
            tags: p.tags
          }
        });

        const ok = !res.demoMode;
        args.onPublishEvent({
          id: uuid(),
          productId: p.id,
          storeId: store,
          storeKind: store,
          status: ok ? "SUCCESS" : "FAILED",
          publishedAt: new Date().toISOString(),
          url: res.url,
          notes: res.demoMode ? res.warning || "Demo Mode" : res.warning
        });

        if (ok) {
          args.onProductPublished({ ...p, status: "PUBLISHED", updatedAt: new Date().toISOString() });
        }

        return { ok, demoMode: res.demoMode };
      } catch (e: any) {
        args.onPublishEvent({
          id: uuid(),
          productId: p.id,
          storeId: store,
          storeKind: store,
          status: "FAILED",
          publishedAt: new Date().toISOString(),
          notes: e instanceof Error ? e.message : String(e)
        });
        return { ok: false, demoMode: true };
      }
    });

    const live = results.filter((r) => r.ok).length;
    const demo = results.filter((r) => !r.ok && r.demoMode).length;
    return { ok: live > 0, message: `Publish complete: ${live} live • ${demo} demo/failed.` };
  }

  return { ok: false, message: "Unsupported automation action." };
}

function newAutomationDraft(now = new Date()): AutomationRule {
  const iso = now.toISOString();
  return {
    id: `aut_${uuid()}`,
    name: "New automation",
    enabled: true,
    trigger: { type: "MANUAL" },
    action: { type: "EXPORT_KPI_CSV" },
    createdAt: iso
  };
}

export default function AutomationSuite() {
  const {
    automations,
    upsertAutomation,
    deleteAutomation,
    products,
    designs,
    orders,
    seed,
    addEvent,
    updateProduct
  } = useAppData();

  const [runningId, setRunningId] = React.useState<string | null>(null);
  const [creating, setCreating] = React.useState(false);
  const [draft, setDraft] = React.useState<AutomationRule>(() => newAutomationDraft());

  const enabledCount = automations.filter((a) => a.enabled).length;

  const runOne = async (rule: AutomationRule) => {
    setRunningId(rule.id);
    try {
      const res = await runAutomationAction({
        rule,
        products,
        designs,
        orders,
        seed,
        onPublishEvent: addEvent,
        onProductPublished: updateProduct
      });

      const updated: AutomationRule = {
        ...rule,
        lastRunAt: new Date().toISOString(),
        lastRunStatus: res.ok ? "SUCCESS" : "FAILED",
        lastRunMessage: res.message
      };
      upsertAutomation(updated);

      if (res.ok) toast.success(res.message);
      else toast.error(res.message);
    } finally {
      setRunningId(null);
    }
  };

  const runAllEnabled = async () => {
    const list = automations.filter((a) => a.enabled);
    if (list.length === 0) {
      toast.error("No enabled automations.");
      return;
    }

    setRunningId("__all__");
    try {
      // Run sequentially to keep side effects obvious.
      for (const a of list) {
        // eslint-disable-next-line no-await-in-loop
        await runOne(a);
      }
    } finally {
      setRunningId(null);
    }
  };

  const onSaveDraft = () => {
    const name = draft.name.trim();
    if (!name) {
      toast.error("Automation name is required.");
      return;
    }
    upsertAutomation({ ...draft, name });
    setCreating(false);
    setDraft(newAutomationDraft());
    toast.success("Automation added.");
  };

  const setDraftTrigger = (t: AutomationTrigger) => setDraft((p) => ({ ...p, trigger: t }));
  const setDraftAction = (a: AutomationAction) => setDraft((p) => ({ ...p, action: a }));

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Automation Suite</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Built-in, fail-soft automations you can run manually today. Scheduled triggers are stored for future background execution
            (PWA/service-worker or server scheduler) without breaking your current deploy.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={runAllEnabled} disabled={runningId !== null}>
            <PlayCircle className="h-4 w-4 mr-2" /> {runningId === "__all__" ? "Running…" : `Run enabled (${enabledCount})`}
          </Button>
          <Button
            onClick={() => {
              setDraft(newAutomationDraft());
              setCreating(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" /> Add automation
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-4 lg:col-span-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="font-semibold flex items-center gap-2">
                <Bot className="h-4 w-4" /> Automations
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Stored locally. Runs are logged into each rule and publish runs also log publish events.
              </div>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Total: <strong>{automations.length}</strong> • Enabled: <strong>{enabledCount}</strong>
            </div>
          </div>

          <div className="mt-4 space-y-3">
            {automations.map((a) => (
              <div
                key={a.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-4"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="font-medium truncate">{a.name}</div>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${
                          a.enabled
                            ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200"
                            : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200"
                        }`}
                      >
                        {a.enabled ? "ENABLED" : "DISABLED"}
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 flex flex-wrap gap-2">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {triggerLabel(a.trigger)}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        {a.action.type === "PUBLISH_READY_PRODUCTS" ? <UploadCloud className="h-3 w-3" /> : <Download className="h-3 w-3" />}
                        {actionLabel(a.action)}
                      </span>
                    </div>
                    {a.lastRunAt ? (
                      <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                        Last run: <strong>{new Date(a.lastRunAt).toLocaleString()}</strong> •{" "}
                        <strong className={a.lastRunStatus === "SUCCESS" ? "text-emerald-700 dark:text-emerald-300" : "text-rose-700 dark:text-rose-300"}>
                          {a.lastRunStatus}
                        </strong>
                        {a.lastRunMessage ? <span className="text-slate-500 dark:text-slate-400"> — {a.lastRunMessage}</span> : null}
                      </div>
                    ) : (
                      <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">Never run.</div>
                    )}
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <Toggle checked={a.enabled} onChange={(v) => upsertAutomation({ ...a, enabled: v })} />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => runOne(a)}
                        disabled={runningId !== null}
                      >
                        <PlayCircle className="h-4 w-4 mr-1" /> Run
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          deleteAutomation(a.id);
                          toast.success("Automation removed.");
                        }}
                        disabled={runningId !== null}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {automations.length === 0 ? (
              <div className="text-sm text-slate-500 dark:text-slate-400">No automations yet.</div>
            ) : null}
          </div>
        </Card>

        <Card className="p-4">
          <div className="font-semibold">Runbook</div>
          <div className="mt-2 text-sm text-slate-600 dark:text-slate-300 space-y-2">
            <p>
              <span className="font-medium">Publish READY</span> sends your READY products to the backend connector.
              If store keys are missing, the backend returns Demo Mode.
            </p>
            <p>
              <span className="font-medium">Exports</span> generate CSV files locally (no PII beyond what’s already in your local demo data).
            </p>
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-100">
              <div className="flex items-center gap-2 font-medium">
                <AlertTriangle className="h-4 w-4" /> Scheduled triggers
              </div>
              <div className="text-xs mt-1">
                Stored for future execution. Running scheduled rules in the background requires a server scheduler or service worker and is intentionally
                not auto-executed in this starter to prevent surprises.
              </div>
            </div>
          </div>
        </Card>
      </div>

      {creating ? (
        <Card className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="font-semibold">Create automation</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Manual-safe defaults. You can edit later.</div>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setCreating(false)}>
                Cancel
              </Button>
              <Button onClick={onSaveDraft}>Save</Button>
            </div>
          </div>

          <div className="mt-4 grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Name</label>
              <input
                value={draft.name}
                onChange={(e) => setDraft((p) => ({ ...p, name: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
              />
              <div className="text-xs text-slate-500 dark:text-slate-400">Displayed in the automation list.</div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Trigger</label>
              <select
                value={draft.trigger.type}
                onChange={(e) => {
                  const t = e.target.value as AutomationTrigger["type"];
                  if (t === "MANUAL") setDraftTrigger({ type: "MANUAL" });
                  if (t === "ON_STATUS_READY") setDraftTrigger({ type: "ON_STATUS_READY" });
                  if (t === "SCHEDULED") setDraftTrigger({ type: "SCHEDULED", cron: "0 9 * * *" });
                }}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
              >
                <option value="MANUAL">MANUAL</option>
                <option value="ON_STATUS_READY">ON_STATUS_READY</option>
                <option value="SCHEDULED">SCHEDULED</option>
              </select>
              {draft.trigger.type === "SCHEDULED" ? (
                <input
                  value={draft.trigger.cron}
                  onChange={(e) => setDraftTrigger({ type: "SCHEDULED", cron: e.target.value })}
                  placeholder="cron, e.g. 0 9 * * *"
                  className="w-full mt-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
                />
              ) : null}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Action</label>
              <select
                value={draft.action.type}
                onChange={(e) => {
                  const v = e.target.value as AutomationAction["type"];
                  if (v === "EXPORT_KPI_CSV") setDraftAction({ type: "EXPORT_KPI_CSV" });
                  if (v === "EXPORT_ORDERS_CSV") setDraftAction({ type: "EXPORT_ORDERS_CSV" });
                  if (v === "PUBLISH_READY_PRODUCTS") setDraftAction({ type: "PUBLISH_READY_PRODUCTS", store: "shopify" });
                }}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
              >
                <option value="EXPORT_KPI_CSV">EXPORT_KPI_CSV</option>
                <option value="EXPORT_ORDERS_CSV">EXPORT_ORDERS_CSV</option>
                <option value="PUBLISH_READY_PRODUCTS">PUBLISH_READY_PRODUCTS</option>
              </select>

              {draft.action.type === "PUBLISH_READY_PRODUCTS" ? (
                <select
                  value={draft.action.store}
                  onChange={(e) => setDraftAction({ type: "PUBLISH_READY_PRODUCTS", store: e.target.value as StoreKind })}
                  className="w-full mt-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
                >
                  <option value="shopify">shopify</option>
                  <option value="woocommerce">woocommerce</option>
                  <option value="etsy">etsy</option>
                  <option value="printify">printify</option>
                </select>
              ) : null}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <Toggle
              checked={draft.enabled}
              onChange={(v) => setDraft((p) => ({ ...p, enabled: v }))}
            />
            <div className="text-sm">
              Enabled
              <div className="text-xs text-slate-500 dark:text-slate-400">Disable to keep it as a saved template.</div>
            </div>
          </div>
        </Card>
      ) : null}
    </div>
  );
}
