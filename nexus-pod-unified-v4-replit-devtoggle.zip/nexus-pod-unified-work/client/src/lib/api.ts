import type { ReadinessReport, SeedPayload, StoreKind } from "@/types";

export type StatusResponse = {
  ok: boolean;
  mode: "LIVE" | "PARTIAL" | "DEMO";
  score: number;
  demoMode: boolean;
  integrations: {
    openai: boolean;
    supabase: boolean;
    shopify: boolean;
    etsy: boolean;
    printify: boolean;
    woocommerce: boolean;
  };
  missing: string[];
  warnings: string[];
};

export type GenerateDesignRequest = {
  prompt: string;
  style?: string;
};

export type GenerateDesignResponse = {
  id: string;
  prompt: string;
  provider: "mock" | "openai";
  imageDataUrl: string;
  downloadUrl: string;
  filename: string;
  expiresAt: string;
  createdAt: string;
  demoMode: boolean;
};

export type PublishProductRequest = {
  store: StoreKind;
  product: {
    title: string;
    description?: string;
    price?: number;
    currency?: string;
    images?: string[];
    tags?: string[];
  };
};

export type PublishProductResponse = {
  demoMode: boolean;
  store: StoreKind;
  externalId: string;
  url?: string;
  warning?: string;
};

export class ApiError extends Error {
  status?: number;
  body?: unknown;
  constructor(message: string, args?: { status?: number; body?: unknown }) {
    super(message);
    this.name = "ApiError";
    this.status = args?.status;
    this.body = args?.body;
  }
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      "accept": "application/json",
      ...(init?.body ? { "content-type": "application/json" } : {}),
      ...(init?.headers || {})
    }
  });

  const raw = await res.text();
  const data = raw ? safeJson(raw) : null;

  if (!res.ok) {
    const msg = (data && typeof data === "object" && data !== null && "message" in data)
      ? String((data as any).message)
      : `${res.status} ${res.statusText}`;
    throw new ApiError(msg, { status: res.status, body: data });
  }

  return data as T;
}

function safeJson(text: string): unknown {
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

export function getApiBase(): string {
  // In dev, Vite proxy handles /api.
  // In prod, Express serves the built client and API at same origin.
  return "";
}

export async function fetchStatus(): Promise<StatusResponse> {
  return fetchJson<StatusResponse>(`${getApiBase()}/api/status`, { method: "GET" });
}

export async function fetchSeed(): Promise<SeedPayload> {
  const res = await fetchJson<{ ok: boolean; seed: SeedPayload }>(`${getApiBase()}/api/seed`, { method: "GET" });
  if (!res?.ok || !res.seed) throw new ApiError("Seed response missing payload.");
  return res.seed;
}

export async function fetchReadiness(args?: { runConnectivity?: boolean }): Promise<ReadinessReport> {
  const run = args?.runConnectivity ? "?run=1" : "";
  return fetchJson<ReadinessReport>(`${getApiBase()}/api/readiness${run}`, { method: "GET" });
}

export async function generateDesign(req: GenerateDesignRequest): Promise<GenerateDesignResponse> {
  return fetchJson<GenerateDesignResponse>(`${getApiBase()}/api/generate-design`, {
    method: "POST",
    body: JSON.stringify(req)
  });
}

export async function publishProduct(req: PublishProductRequest): Promise<PublishProductResponse> {
  return fetchJson<PublishProductResponse>(`${getApiBase()}/api/publish-product`, {
    method: "POST",
    body: JSON.stringify(req)
  });
}
