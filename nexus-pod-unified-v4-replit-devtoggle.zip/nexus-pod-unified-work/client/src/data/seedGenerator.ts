import { Product, StoreConnection, ProductTemplate, Order, DesignAsset } from '@/types';
import { uuid } from '@/utils/id';

const ADJECTIVES = ['Vintage', 'Retro', 'Modern', 'Minimalist', 'Neon', 'Abstract', 'Grunge', 'Classic', 'Urban', 'Cozy'];
const NOUNS = ['Sunset', 'Mountain', 'Cat', 'Dog', 'Skull', 'Wave', 'Forest', 'City', 'Quote', 'Pattern'];
const TYPES = ['T_SHIRT', 'HOODIE', 'MUG'] as const;

export function generateProducts(count: number): Product[] {
  return Array.from({ length: count }).map((_, i) => {
    const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
    const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
    const type = TYPES[Math.floor(Math.random() * TYPES.length)];
    
    return {
      id: uuid(),
      title: `${adj} ${noun} ${i + 1}`,
      description: `A high-quality ${type.toLowerCase().replace('_', '-')} featuring a ${adj.toLowerCase()} design.`,
      productType: type,
      price: type === 'HOODIE' ? 49.99 : type === 'T_SHIRT' ? 24.99 : 14.99,
      cost: type === 'HOODIE' ? 25.00 : type === 'T_SHIRT' ? 10.00 : 5.00,
      status: Math.random() > 0.7 ? 'PUBLISHED' : Math.random() > 0.4 ? 'READY' : 'DRAFT',
      designAssetId: null,
      storeId: null,
      tags: [adj.toLowerCase(), noun.toLowerCase(), 'trending'],
      variants: [
        { size: 'M', color: 'Black', sku: `SKU-${i}-BLK-M`, inventory: 100 },
        { size: 'L', color: 'Black', sku: `SKU-${i}-BLK-L`, inventory: 80 }
      ],
      createdAt: new Date(Date.now() - Math.floor(Math.random() * 1000000000)).toISOString(),
      updatedAt: new Date().toISOString()
    };
  });
}

export const SEED_TEMPLATES: ProductTemplate[] = [
  { id: uuid(), name: 'Standard Tee High Margin', baseProductType: 'T_SHIRT', defaultPrice: 29.99, defaultCost: 9.50, defaultTags: ['cotton', 'unisex'], createdAt: new Date().toISOString() },
  { id: uuid(), name: 'Premium Hoodie', baseProductType: 'HOODIE', defaultPrice: 59.99, defaultCost: 28.00, defaultTags: ['fleece', 'winter'], createdAt: new Date().toISOString() }
];

export const SEED_STORES: StoreConnection[] = [
  { id: uuid(), platform: 'Shopify', storeName: 'Retro Vibes Shop', apiKeyMasked: 'shpat_********', connectedAt: new Date().toISOString(), status: 'CONNECTED' },
  { id: uuid(), platform: 'Etsy', storeName: 'CraftyCorner', apiKeyMasked: 'etsy_********', connectedAt: new Date().toISOString(), status: 'CONNECTED' }
];

export const SEED_ORDERS: Order[] = Array.from({ length: 25 }).map((_, i) => ({
  id: `ORD-${1000 + i}`,
  customerName: `Customer ${i + 1}`,
  total: Math.floor(Math.random() * 100) + 20,
  status: Math.random() > 0.5 ? 'DELIVERED' : 'SHIPPED',
  items: [],
  createdAt: new Date(Date.now() - Math.floor(Math.random() * 500000000)).toISOString()
}));