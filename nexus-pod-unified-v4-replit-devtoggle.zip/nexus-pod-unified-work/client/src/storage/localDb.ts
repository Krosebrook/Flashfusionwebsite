export const KEYS = {
  PRODUCTS: 'pod_products',
  STORES: 'pod_stores',
  DESIGNS: 'pod_designs',
  EVENTS: 'pod_events',
  TEMPLATES: 'pod_templates',
  ORDERS: 'pod_orders',
  SEED: 'pod_seed',
  AUTOMATIONS: 'pod_automations',
  THEME: 'pod_theme',
  SCHEMA: 'pod_schema_v2',
  // Legacy keys (used only for cleanup / migrations)
  SCHEMA_V1: 'pod_schema_v1'
};

export const localDb = {
  get: <T>(key: string, defaultVal: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultVal;
    } catch (e) {
      console.error('Storage Read Error', e);
      return defaultVal;
    }
  },
  set: <T>(key: string, value: T): void => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage Write Error', e);
    }
  },
  /**
   * DANGER: This clears the entire origin storage.
   * We keep it for debugging, but the app uses scoped resets instead.
   */
  clearAllOriginStorage: () => {
    localStorage.clear();
    window.location.reload();
  }
};