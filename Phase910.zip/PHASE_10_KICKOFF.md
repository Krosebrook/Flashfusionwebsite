# Phase 10: Provider Implementation Fixes + Tests

**Start Date:** December 30, 2025
**Prerequisite:** Phase 9 complete (core tests passing)
**Blockers from Phase 9:** 4 TypeScript compilation errors in provider implementations

---

## TL;DR

Phase 9 revealed that **provider implementations have TypeScript bugs** preventing test execution. Phase 10 must fix these BEFORE continuing provider testing.

**Estimated Time:**
- Fix implementations: 1-2 hours
- Complete provider tests: 3-4 hours
- **Total: 4-6 hours**

---

## Critical Implementation Fixes (Do First)

### Fix 1: types.ts - Missing/Wrong ErrorCode Values
**File:** `src/core/types.ts`
**Issue:** `ErrorCode.AUTH_FAILED` doesn't exist

**Check current ErrorCode enum:**
```bash
grep -A 20 "export enum ErrorCode" src/core/types.ts
```

**Expected values (from OWASP + MCP spec):**
- UNAUTHORIZED (or AUTH_FAILED) - 401
- FORBIDDEN - 403
- NOT_FOUND - 404
- BAD_REQUEST - 400/422
- RATE_LIMITED - 429
- PROVIDER_ERROR - 500
- INTERNAL_ERROR - 500

**Action:** Add missing values or map to existing equivalents

---

### Fix 2: GitHubProvider - Wrong Enum Imports
**File:** `src/providers/github-provider.ts:15`
**Current:**
```typescript
import {
  MCPProvider,
  MCPCapability,  // ❌ WRONG
  MCPRequest,
  MCPResponse,
  ErrorCode,
  MCPError,
} from '../core/types';
```

**Fix:**
```typescript
import {
  MCPProvider,
  ProviderCapability,  // ✅ CORRECT
  MCPRequest,
  MCPResponse,
  ErrorCode,
  MCPError,
} from '../core/types';
```

**Affected lines:** Search/replace `MCPCapability` → `ProviderCapability` throughout file

---

### Fix 3: GitHubProvider - Wrong Return Type
**File:** `src/providers/github-provider.ts:59`
**Current:**
```typescript
getProviderName(): MCPProvider {
  return 'github';  // ❌ WRONG (string)
}
```

**Fix:**
```typescript
getProviderName(): MCPProvider {
  return MCPProvider.GITHUB;  // ✅ CORRECT (enum)
}
```

---

### Fix 4: GitHubProvider - Wrong ErrorCode Values
**File:** `src/providers/github-provider.ts:111`
**Current:**
```typescript
return new MCPError(ErrorCode.AUTH_FAILED, ...);  // ❌ Doesn't exist
```

**Fix:** Map to correct enum value from types.ts
```typescript
return new MCPError(ErrorCode.UNAUTHORIZED, ...);  // If that's the correct name
```

**Search for all ErrorCode usage:**
```bash
grep -n "ErrorCode\." src/providers/github-provider.ts
```

**Expected mappings:**
- 401 → UNAUTHORIZED (or AUTH_FAILED if it exists)
- 403 → FORBIDDEN
- 404 → NOT_FOUND
- 422 → BAD_REQUEST

---

### Fix 5: GitHubProvider - Octokit Param Typing
**File:** `src/providers/github-provider.ts:261`
**Current:**
```typescript
state: params.state,  // Type includes 'all' but Octokit doesn't accept it
```

**Fix:** Filter or type correctly
```typescript
state: params.state === 'all' ? undefined : params.state,
```

---

## Verification Steps

### Step 1: Fix types.ts
```bash
# Check what ErrorCode values exist
grep -A 30 "export enum ErrorCode" src/core/types.ts

# If AUTH_FAILED missing, add it or note equivalent
```

### Step 2: Fix GitHubProvider
```bash
# Apply fixes above
# Then compile
cd /home/claude/intinc-implementation/universal-mcp-server
npm run build 2>&1 | grep error
```

### Step 3: Test Compilation
```bash
# Should have ZERO TypeScript errors
npm test -- tests/unit/providers/github.test.ts 2>&1 | grep "error TS"
```

### Step 4: Run Tests
```bash
# Should execute (may fail tests, but shouldn't have compilation errors)
npm test -- tests/unit/providers/github.test.ts
```

---

## Audit Other Providers

Once GitHubProvider compiles, check all other providers for same issues:

```bash
# Check for MCPCapability usage (wrong)
grep -r "MCPCapability" src/providers/

# Check for string return in getProviderName()
grep -A 3 "getProviderName()" src/providers/*.ts | grep "return '"

# Check for ErrorCode usage
grep -r "ErrorCode\." src/providers/ | grep -v "import"
```

**Likely affected providers:**
- linear-provider.ts
- notion-provider.ts
- slack-provider.ts
- jira-provider.ts
- confluence-provider.ts
- figma-provider.ts
- sentry-provider.ts
- pagerduty-provider.ts
- datadog-provider.ts

---

## After Fixes: Complete Provider Tests

### Test Structure (Per Provider)
1. **Constructor** - Mock client initialization
2. **getProviderName** - Returns correct enum
3. **getSupportedCapabilities** - Lists capabilities
4. **getDefaultRateLimits** - Correct limits
5. **calculateCost** - Cost model
6. **convertProviderError** - Error mapping (4xx/5xx)
7. **executeRequest by capability:**
   - search (if supported)
   - read (if supported)
   - create (if supported)
   - update (if supported)
   - delete (if supported)

### Example Test Count
- GitHubProvider: ~30 tests (5 capabilities × 6 methods)
- LinearProvider: ~25 tests (4 capabilities)
- NotionProvider: ~25 tests (4 capabilities)
- Total expected: **~150-200 provider tests**

---

## Success Criteria

### Phase 10 Complete When:
- [ ] All provider implementations compile with zero TS errors
- [ ] All provider tests execute (compilation successful)
- [ ] Core tests still passing (65/65)
- [ ] Provider tests coverage:
  - [ ] GitHubProvider: 30+ tests
  - [ ] LinearProvider: 25+ tests
  - [ ] NotionProvider: 25+ tests
  - [ ] Other providers: 15+ tests each
- [ ] Total tests: 200+ passing

---

## Timeline

**Hour 1:** Fix types.ts + GitHubProvider (compilation)
**Hour 2:** Audit and fix other providers
**Hour 3-4:** Complete GitHubProvider tests (30 tests)
**Hour 5-6:** Complete Linear/Notion tests (50 tests)

**Total: 4-6 hours**

---

## Notes for Kyle

**Why Phase 9 Stopped Here:**
- We successfully tested everything we COULD test (core managers)
- Provider tests hit actual implementation bugs (not test issues)
- Fixing implementations is Phase 10 work, not Phase 9
- Proper separation of concerns: Phase 9 = testing, Phase 10 = implementation

**What's Already Done:**
- ✅ Bull mock (142 lines, production-ready)
- ✅ Test fixtures (all 10 providers)
- ✅ Core tests (65 passing, 100% success)
- ✅ Test patterns established
- ✅ Enum usage documented

**What's Blocked:**
- ⏳ Provider tests (implementation bugs)
- ⏳ Integration tests (needs working providers)
- ⏳ E2E tests (needs full stack)

**Recommended Approach:**
1. Fix implementations first (1-2 hours)
2. Then complete testing (3-4 hours)
3. This maintains separation and clean audit trail

---

**Document Version:** 1.0
**Last Updated:** December 30, 2025 05:20 UTC
**Status:** Ready for Phase 10 execution
