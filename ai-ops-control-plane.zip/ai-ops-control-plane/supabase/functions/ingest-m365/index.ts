import { corsHeaders } from "../_shared/cors.ts";
import { reqEnv } from "../_shared/env.ts";
import { supabaseAdmin, supabaseAuthed } from "../_shared/supabase.ts";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function getGraphToken() {
  const tenant = reqEnv("AZURE_TENANT_ID");
  const clientId = reqEnv("AZURE_CLIENT_ID");
  const clientSecret = reqEnv("AZURE_CLIENT_SECRET");
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
    scope: "https://graph.microsoft.com/.default"
  });
  const resp = await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!resp.ok) throw new Error(await resp.text());
  return await resp.json();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    const authHeader = req.headers.get("Authorization");
    const authed = supabaseAuthed(authHeader);
    const { data: userRes, error: userErr } = await authed.auth.getUser();
    if (userErr || !userRes.user) return jsonResponse(401, { error: "Unauthorized" });

    const roles = (userRes.user.app_metadata?.roles ?? []) as string[];
    if (!roles.includes("support_agent") && !roles.includes("admin")) return jsonResponse(403, { error: "support_agent role required" });

    const mailboxUpn = reqEnv("FOH_DEFAULT_MAILBOX_UPN");
    const top = 10;

    const { access_token } = await getGraphToken();
    const url = `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(mailboxUpn)}/mailFolders/Inbox/messages?$top=${top}&$select=id,subject,from,receivedDateTime,bodyPreview`;

    const resp = await fetch(url, { headers: { Authorization: `Bearer ${access_token}` } });
    if (!resp.ok) return jsonResponse(500, { error: await resp.text() });
    const json = await resp.json();

    const admin = supabaseAdmin();
    let upserts = 0;

    for (const m of json.value ?? []) {
      const id = m.id as string;
      const subject = m.subject as string;
      const from = m.from?.emailAddress?.address as string | undefined;
      const received = m.receivedDateTime as string | undefined;
      const excerpt = m.bodyPreview as string | undefined;

      const ins = await admin.from("foh_queue_items").upsert({
        source_type: "outlook",
        source_ref: id,
        subject,
        from_address: from ?? null,
        received_at: received ?? null,
        excerpt: excerpt ?? null,
        status: "new",
        last_error: null
      }, { onConflict: "source_type,source_ref" });

      if (!ins.error) upserts++;
    }

    await admin.rpc("append_audit", {
      p_domain: "foh",
      p_event_type: "foh.ingest.m365",
      p_payload: { mailbox_upn: mailboxUpn, fetched: (json.value ?? []).length, upserts },
      p_correlation_id: null,
      p_ip: null,
      p_user_agent: req.headers.get("user-agent") ?? ""
    });

    return jsonResponse(200, { ok: true, fetched: (json.value ?? []).length, upserts });
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
