-- 0004_directory_rolemap.sql
-- user_directory (email → user_id) for Entra role sync, plus role_mappings.

create table if not exists public.user_directory (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  roles jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_touch_user_directory on public.user_directory;
create trigger trg_touch_user_directory
before update on public.user_directory
for each row
execute function public.touch_updated_at();

alter table public.user_directory enable row level security;

drop policy if exists user_dir_select on public.user_directory;
create policy user_dir_select
on public.user_directory for select
to authenticated
using (
  user_id = auth.uid()
  or public.has_role('approver')
  or public.has_role('admin')
);

drop policy if exists user_dir_insert on public.user_directory;
create policy user_dir_insert
on public.user_directory for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists user_dir_update on public.user_directory;
create policy user_dir_update
on public.user_directory for update
to authenticated
using (user_id = auth.uid() or public.has_role('approver') or public.has_role('admin'))
with check (user_id = auth.uid() or public.has_role('approver') or public.has_role('admin'));

drop policy if exists user_dir_no_delete on public.user_directory;
create policy user_dir_no_delete
on public.user_directory for delete
to authenticated
using (false);

create table if not exists public.role_mappings (
  id uuid primary key default gen_random_uuid(),
  entra_group_id text not null unique,
  role_name text not null check (role_name in ('support_agent','engineer','approver','admin')),
  created_at timestamptz not null default now()
);

alter table public.role_mappings enable row level security;

drop policy if exists role_mappings_admin_only on public.role_mappings;
create policy role_mappings_admin_only
on public.role_mappings
for all
to authenticated
using (public.has_role('admin'))
with check (public.has_role('admin'));
