"use client";

export function JsonBlock({ value }: { value: unknown }) {
  return (
    <pre className="mt-2 p-2 rounded bg-slate-950 overflow-x-auto text-sm border border-slate-800">
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}
