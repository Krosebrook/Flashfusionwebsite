"use client";
import { ButtonHTMLAttributes } from "react";

export function Button({ className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={[
        "px-3 py-2 rounded font-semibold disabled:opacity-50 disabled:cursor-not-allowed",
        className
      ].join(" ")}
    />
  );
}
