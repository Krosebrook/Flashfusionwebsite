"use client";
import { ReactNode } from "react";

export function Shell({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <main className="min-h-screen p-8 bg-slate-950 text-slate-100">
      <div className="max-w-6xl mx-auto space-y-6">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">{title}</h1>
          <div className="flex items-center gap-2">{right}</div>
        </header>
        {children}
      </div>
    </main>
  );
}
