"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { JsonBlock } from "@/components/JsonBlock";
import { Button } from "@/components/Button";

export default function Dashboard() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [user, setUser] = useState<any>(null);
  const [approvals, setApprovals] = useState<any[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = async () => {
    setLoading(true);
    const u = await supabase.auth.getUser();
    setUser(u.data.user ?? null);

    const a = await supabase.from("approvals").select("*").order("requested_at", { ascending: false }).limit(20);
    setApprovals(a.data ?? []);

    const l = await supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(20);
    setAudit(l.data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    window.location.href = "/";
  };

  return (
    <Shell
      title="Dashboard"
      right={
        <>
          <a className="px-3 py-2 rounded bg-slate-800" href="/foh">FOH</a>
          <a className="px-3 py-2 rounded bg-slate-800" href="/boh">BOH</a>
          <a className="px-3 py-2 rounded bg-slate-800" href="/approvals">Approvals</a>
          <a className="px-3 py-2 rounded bg-slate-800" href="/audit">Audit</a>
          <a className="px-3 py-2 rounded bg-slate-800" href="/runbooks">Runbooks</a>
          <a className="px-3 py-2 rounded bg-slate-800" href="/slo">SLO</a>
          <Button className="bg-slate-800" onClick={signOut}>Sign out</Button>
        </>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
          <h2 className="font-semibold">Session</h2>
          <div className="text-sm text-slate-300">{user?.email ? `Signed in: ${user.email}` : "Not signed in"}</div>
          <div className="text-sm text-slate-400">
            roles: {(user?.app_metadata?.roles ?? []).join(", ") || "—"}
          </div>
          <Button className="bg-cyan-500 text-slate-950" onClick={refresh} disabled={loading}>
            {loading ? "Refreshing…" : "Refresh"}
          </Button>
        </section>

        <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <h2 className="font-semibold mb-3">Latest Approvals</h2>
          <div className="space-y-2 text-sm">
            {approvals.map(a => (
              <div key={a.id} className="flex items-center justify-between border border-slate-800 rounded p-2">
                <div>
                  <div className="font-semibold">{String(a.domain).toUpperCase()} • {a.action}</div>
                  <div className="text-slate-400">{new Date(a.requested_at).toLocaleString()}</div>
                </div>
                <div className="text-slate-300">{a.status} / {a.execution_status}</div>
              </div>
            ))}
            {approvals.length === 0 && <div className="text-slate-400">No approvals visible.</div>}
          </div>
        </section>
      </div>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <h2 className="font-semibold mb-3">Latest Audit Events</h2>
        <div className="space-y-3 text-sm">
          {audit.map(e => (
            <div key={e.id} className="border border-slate-800 rounded p-2">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{String(e.domain).toUpperCase()} • {e.event_type}</div>
                <div className="text-slate-400">{new Date(e.created_at).toLocaleString()}</div>
              </div>
              <div className="text-slate-400">corr: {e.correlation_id ?? "—"}</div>
              <JsonBlock value={e.payload} />
            </div>
          ))}
          {audit.length === 0 && <div className="text-slate-400">No audit events visible.</div>}
        </div>
      </section>
    </Shell>
  );
}
