import assert from "node:assert/strict";

function required(name) {
  const v = process.env[name];
  assert.ok(v && v.trim().length > 0, `Missing required env var: ${name}`);
  return v;
}

function main() {
  // Browser-safe vars required to run UI.
  required("NEXT_PUBLIC_SUPABASE_URL");
  required("NEXT_PUBLIC_SUPABASE_ANON_KEY");

  // Optional, but strongly recommended if you run server routes.
  // Do NOT require it for basic UI-only deployment.
  console.log("[ok] Basic env present.");

  // Guardrail: service role key must never be exposed to browser builds.
  if (process.env.NEXT_PUBLIC_SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error("NEXT_PUBLIC_SUPABASE_SERVICE_ROLE_KEY must never exist. Use SUPABASE_SERVICE_ROLE_KEY only.");
  }

  console.log("[ok] No dangerous NEXT_PUBLIC_* secret vars detected.");
}

main();
