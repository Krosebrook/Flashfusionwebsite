/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  experimental: {
    // Keep defaults. Do not opt into unstable flags without a need.
  }
};

export default nextConfig;
