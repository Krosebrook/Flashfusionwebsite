import { describe, it, expect, beforeEach } from "vitest";
import request from "supertest";
import { createApp } from "../src/app.js";

describe("API smoke", () => {
  beforeEach(() => {
    delete process.env.OPENAI_API_KEY;
    delete process.env.SUPABASE_URL;
    delete process.env.SUPABASE_KEY;
  });

  it("GET /api/health", async () => {
    const app = createApp();
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("ok", true);
  });

  it("GET /api/status returns demoMode when integrations missing", async () => {
    const app = createApp();
    const res = await request(app).get("/api/status");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("demoMode");
    expect(res.body).toHaveProperty("mode");
    expect(res.body).toHaveProperty("missing");
    expect(Array.isArray(res.body.missing)).toBe(true);
  });

  it("GET /api/seed returns grounded seed payload", async () => {
    const app = createApp();
    const res = await request(app).get("/api/seed");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("ok", true);
    expect(res.body).toHaveProperty("seed");
    expect(res.body.seed).toHaveProperty("products");
    expect(res.body.seed).toHaveProperty("templates");
    expect(res.body.seed).toHaveProperty("orders");
    expect(res.body.seed).toHaveProperty("timeseries");
  });

  it("GET /api/readiness returns report", async () => {
    const app = createApp();
    const res = await request(app).get("/api/readiness");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("ok", true);
    expect(res.body).toHaveProperty("mode");
    expect(res.body).toHaveProperty("categories");
    expect(Array.isArray(res.body.categories)).toBe(true);
  });

  it("POST /api/generate-design returns mock without OPENAI_API_KEY and provides download", async () => {
    const app = createApp();
    const res = await request(app).post("/api/generate-design").send({ prompt: "simple logo", style: "minimal" });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("provider", "mock");
    expect(res.body).toHaveProperty("imageDataUrl");
    expect(res.body).toHaveProperty("downloadUrl");
    expect(String(res.body.downloadUrl)).toMatch(/^\/api\/designs\//);

    // Download should work
    const dl = await request(app).get(String(res.body.downloadUrl));
    expect(dl.status).toBe(200);
    expect(dl.header["content-disposition"]).toMatch(/attachment/);
  });
});
