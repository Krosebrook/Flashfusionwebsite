import { readEnv, readEnvBool } from "../utils/env.js";
import { getSupabaseClient } from "../supabase.js";

export type ReadinessStatus = "OK" | "WARN" | "MISSING" | "ERROR";

export type ReadinessItem = {
  id: string;
  label: string;
  status: ReadinessStatus;
  detail?: string;
  envVars?: string[];
  docsUrl?: string;
  fix?: string[];
};

export type ReadinessCategory = {
  id: string;
  title: string;
  score: number; // 0..100
  items: ReadinessItem[];
};

export type ReadinessReport = {
  ok: boolean;
  mode: "LIVE" | "PARTIAL" | "DEMO";
  score: number; // 0..100
  generatedAt: string;
  missingEnvVars: string[];
  warnings: string[];
  categories: ReadinessCategory[];
  connectivity?: Record<string, { ok: boolean; detail?: string; status?: number }>;
};

function isPresent(v: string | undefined | null): boolean {
  return Boolean(v && String(v).trim().length > 0);
}

function env(name: string): string | undefined {
  return readEnv(name, { warnIfMissing: false });
}

function nodeMajor(): number {
  const m = process.versions.node.split(".")[0];
  return Number(m);
}

function scoreFromItems(items: ReadinessItem[]): number {
  if (!items.length) return 100;
  const weights: Record<ReadinessStatus, number> = { OK: 1, WARN: 0.6, MISSING: 0.0, ERROR: 0.0 };
  const sum = items.reduce((acc, it) => acc + weights[it.status], 0);
  return Math.round((sum / items.length) * 100);
}

function addMissing(missing: Set<string>, names?: string[]) {
  (names || []).forEach((n) => missing.add(n));
}

async function fetchJsonWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<{ ok: boolean; status: number; json?: any; text?: string }> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const text = await res.text();
    let json: any | undefined;
    try { json = JSON.parse(text); } catch { /* ignore */ }
    return { ok: res.ok, status: res.status, json, text };
  } finally {
    clearTimeout(t);
  }
}

function normalizeHttpsUrl(url: string | undefined): string | undefined {
  if (!url) return undefined;
  const trimmed = url.trim().replace(/\/$/, "");
  if (!trimmed) return undefined;
  if (trimmed.startsWith("http://")) return trimmed; // allow, but will warn
  if (trimmed.startsWith("https://")) return trimmed;
  return `https://${trimmed}`;
}

export async function buildReadinessReport(opts: { runConnectivity?: boolean } = {}): Promise<ReadinessReport> {
  const generatedAt = new Date().toISOString();
  const missing = new Set<string>();
  const warnings: string[] = [];
  const connectivity: Record<string, { ok: boolean; detail?: string; status?: number }> = {};

  // Runtime
  const runtimeItems: ReadinessItem[] = [];
  const major = nodeMajor();
  runtimeItems.push({
    id: "runtime.node",
    label: "Node.js runtime",
    status: major >= 20 ? "OK" : "WARN",
    detail: major >= 20 ? `Node ${process.version}` : `Node ${process.version} (recommended >=20)`
  });

  const nodeEnv = env("NODE_ENV") || "development";
  runtimeItems.push({
    id: "runtime.node_env",
    label: "NODE_ENV",
    status: nodeEnv === "production" ? "OK" : "WARN",
    detail: nodeEnv === "production" ? "production" : `Currently '${nodeEnv}'. Set NODE_ENV=production for deploy.`
  });

  // Security / ops
  const securityItems: ReadinessItem[] = [];
  const corsOrigin = env("CORS_ORIGIN");
  securityItems.push({
    id: "security.cors",
    label: "CORS_ORIGIN configured",
    status: corsOrigin ? "OK" : (nodeEnv === "production" ? "WARN" : "OK"),
    detail: corsOrigin ? corsOrigin : (nodeEnv === "production" ? "Missing CORS_ORIGIN; default allow-all is unsafe for production." : "Dev default allow-all."),
    envVars: ["CORS_ORIGIN"],
    fix: ["Set CORS_ORIGIN to a comma-separated allowlist, e.g. https://your-domain.com"]
  });

  const rateLimitMax = env("RATE_LIMIT_MAX");
  const rateLimitWindowMs = env("RATE_LIMIT_WINDOW_MS");
  securityItems.push({
    id: "security.rate_limit",
    label: "Rate limiting tuned",
    status: (rateLimitMax && rateLimitWindowMs) ? "OK" : "WARN",
    detail: (rateLimitMax && rateLimitWindowMs) ? `max=${rateLimitMax}, windowMs=${rateLimitWindowMs}` : "Using defaults (max=120/min). Tune RATE_LIMIT_* for production traffic patterns.",
    envVars: ["RATE_LIMIT_MAX", "RATE_LIMIT_WINDOW_MS"],
    fix: ["Set RATE_LIMIT_MAX and RATE_LIMIT_WINDOW_MS to match expected load. Consider stricter limits on expensive routes."]
  });

  // AI
  const aiItems: ReadinessItem[] = [];
  const openaiKey = env("OPENAI_API_KEY");
  aiItems.push({
    id: "ai.openai_key",
    label: "OpenAI API key",
    status: openaiKey ? "OK" : "MISSING",
    detail: openaiKey ? "Configured" : "Missing OPENAI_API_KEY (Design Studio will run in Demo Mode).",
    envVars: ["OPENAI_API_KEY"]
  });
  if (!openaiKey) addMissing(missing, ["OPENAI_API_KEY"]);

  const openaiModel = env("OPENAI_IMAGE_MODEL") || "gpt-image-1";
  aiItems.push({
    id: "ai.openai_model",
    label: "Image model",
    status: "OK",
    detail: `Using ${openaiModel} (override via OPENAI_IMAGE_MODEL)`
  });

  // Data / persistence
  const dataItems: ReadinessItem[] = [];
  const supabaseUrl = env("SUPABASE_URL");
  const supabaseKey = env("SUPABASE_KEY");
  dataItems.push({
    id: "data.supabase",
    label: "Supabase server client",
    status: (supabaseUrl && supabaseKey) ? "OK" : "MISSING",
    detail: (supabaseUrl && supabaseKey) ? "Configured" : "Missing SUPABASE_URL / SUPABASE_KEY. Persistence runs in Demo Mode.",
    envVars: ["SUPABASE_URL", "SUPABASE_KEY"]
  });
  if (!supabaseUrl) addMissing(missing, ["SUPABASE_URL"]);
  if (!supabaseKey) addMissing(missing, ["SUPABASE_KEY"]);

  const supabase = getSupabaseClient();
  dataItems.push({
    id: "data.supabase_runtime",
    label: "Supabase client instantiation",
    status: supabase ? "OK" : "WARN",
    detail: supabase ? "Client created" : "Client not created (missing envs or init error)."
  });

  // Commerce integrations
  const commerceItems: ReadinessItem[] = [];

  const shopifyStoreUrlRaw = env("SHOPIFY_STORE_URL");
  const shopifyStoreUrl = normalizeHttpsUrl(shopifyStoreUrlRaw);
  const shopifyToken = env("SHOPIFY_ACCESS_TOKEN");
  const shopifyApiVersion = (env("SHOPIFY_API_VERSION") || "2025-10").trim();
  const shopifyApiMode = (env("SHOPIFY_API_MODE") || "graphql").trim().toLowerCase();

  commerceItems.push({
    id: "commerce.shopify",
    label: "Shopify",
    status: (shopifyStoreUrl && shopifyToken) ? "OK" : "MISSING",
    detail: (shopifyStoreUrl && shopifyToken)
      ? `Configured (${shopifyApiMode.toUpperCase()} ${shopifyApiVersion})`
      : "Missing SHOPIFY_STORE_URL / SHOPIFY_ACCESS_TOKEN.",
    envVars: ["SHOPIFY_STORE_URL", "SHOPIFY_ACCESS_TOKEN", "SHOPIFY_API_VERSION", "SHOPIFY_API_MODE"],
    docsUrl: "https://shopify.dev/docs/api/usage/versioning",
    fix: [
      "Set SHOPIFY_STORE_URL to https://{your-shop}.myshopify.com",
      "Set SHOPIFY_ACCESS_TOKEN (Admin API access token)",
      "Prefer GraphQL (SHOPIFY_API_MODE=graphql) unless you have a legacy REST dependency."
    ]
  });
  if (!shopifyStoreUrl) addMissing(missing, ["SHOPIFY_STORE_URL"]);
  if (!shopifyToken) addMissing(missing, ["SHOPIFY_ACCESS_TOKEN"]);
  if (shopifyStoreUrlRaw && shopifyStoreUrlRaw.startsWith("http://")) {
    warnings.push("Shopify store URL is http:// — use https:// in production.");
  }

  // Etsy
  const etsyKey = env("ETSY_API_KEY"); // keystring
  const etsySecret = env("ETSY_SHARED_SECRET"); // shared secret
  const etsyAccessToken = env("ETSY_ACCESS_TOKEN");
  const etsyRefreshToken = env("ETSY_REFRESH_TOKEN");
  const etsyShopId = env("ETSY_SHOP_ID");
  commerceItems.push({
    id: "commerce.etsy",
    label: "Etsy",
    status: (etsyKey && etsyAccessToken && etsyShopId) ? "OK" : "WARN",
    detail: (etsyKey && etsyAccessToken && etsyShopId)
      ? "Configured (OAuth2)"
      : "Etsy requires OAuth2 (access + refresh tokens) and x-api-key header. Missing pieces will run in Demo Mode.",
    envVars: ["ETSY_API_KEY", "ETSY_SHARED_SECRET", "ETSY_ACCESS_TOKEN", "ETSY_REFRESH_TOKEN", "ETSY_SHOP_ID"],
    docsUrl: "https://developer.etsy.com/documentation/essentials/authentication",
    fix: [
      "Set ETSY_API_KEY (keystring) and ETSY_SHARED_SECRET (do not commit).",
      "Implement OAuth2 code grant + refresh grant to obtain ETSY_ACCESS_TOKEN / ETSY_REFRESH_TOKEN.",
      "Set ETSY_SHOP_ID for shop-scoped endpoints."
    ]
  });
  if (!etsyKey) addMissing(missing, ["ETSY_API_KEY"]);
  if (!etsyAccessToken) addMissing(missing, ["ETSY_ACCESS_TOKEN"]);
  if (!etsyShopId) addMissing(missing, ["ETSY_SHOP_ID"]);

  // Printify
  const printifyToken = env("PRINTIFY_API_TOKEN");
  commerceItems.push({
    id: "commerce.printify",
    label: "Printify",
    status: printifyToken ? "OK" : "WARN",
    detail: printifyToken ? "Configured" : "Missing PRINTIFY_API_TOKEN (optional unless publishing via Printify API).",
    envVars: ["PRINTIFY_API_TOKEN"],
    docsUrl: "https://developers.printify.com/",
    fix: ["Generate a Printify API token (scoped) and set PRINTIFY_API_TOKEN."]
  });

  // WooCommerce
  const wooUrlRaw = env("WOOCOMMERCE_STORE_URL");
  const wooUrl = normalizeHttpsUrl(wooUrlRaw);
  const wooKey = env("WOOCOMMERCE_CONSUMER_KEY");
  const wooSecret = env("WOOCOMMERCE_CONSUMER_SECRET");
  commerceItems.push({
    id: "commerce.woocommerce",
    label: "WooCommerce",
    status: (wooUrl && wooKey && wooSecret) ? "OK" : "WARN",
    detail: (wooUrl && wooKey && wooSecret) ? "Configured" : "Missing WooCommerce URL/keys (optional unless publishing to Woo).",
    envVars: ["WOOCOMMERCE_STORE_URL", "WOOCOMMERCE_CONSUMER_KEY", "WOOCOMMERCE_CONSUMER_SECRET"],
    docsUrl: "https://woocommerce.com/document/woocommerce-rest-api/",
    fix: ["Generate WooCommerce REST API keys and set WOOCOMMERCE_* env vars. Prefer HTTPS."]
  });
  if (wooUrlRaw && wooUrlRaw.startsWith("http://")) {
    warnings.push("WooCommerce store URL is http:// — use https:// to avoid credential leakage.");
  }

  // Observability (optional)
  const obsItems: ReadinessItem[] = [];
  const sentryDsn = env("SENTRY_DSN");
  obsItems.push({
    id: "obs.sentry",
    label: "Sentry DSN",
    status: sentryDsn ? "OK" : "WARN",
    detail: sentryDsn ? "Configured" : "Not configured (optional but recommended for production).",
    envVars: ["SENTRY_DSN"],
    fix: ["Set SENTRY_DSN to enable error tracking."]
  });

  const categories: ReadinessCategory[] = [
    { id: "runtime", title: "Runtime", score: scoreFromItems(runtimeItems), items: runtimeItems },
    { id: "security", title: "Security & Ops", score: scoreFromItems(securityItems), items: securityItems },
    { id: "ai", title: "AI", score: scoreFromItems(aiItems), items: aiItems },
    { id: "data", title: "Data & Persistence", score: scoreFromItems(dataItems), items: dataItems },
    { id: "commerce", title: "Commerce Integrations", score: scoreFromItems(commerceItems), items: commerceItems },
    { id: "observability", title: "Observability", score: scoreFromItems(obsItems), items: obsItems }
  ];

  const score = Math.round(categories.reduce((acc, c) => acc + c.score, 0) / categories.length);

  // Determine mode: LIVE if supabase configured AND at least one commerce connector configured.
  const commerceConfigured = Boolean((shopifyStoreUrl && shopifyToken) || (etsyKey && etsyAccessToken && etsyShopId) || printifyToken || (wooUrl && wooKey && wooSecret));
  const supabaseConfigured = Boolean(supabaseUrl && supabaseKey);

  const mode: ReadinessReport["mode"] =
    supabaseConfigured && commerceConfigured ? "LIVE" :
    (supabaseConfigured || commerceConfigured || openaiKey) ? "PARTIAL" : "DEMO";

  if (opts.runConnectivity) {
    const timeoutMs = Number(env("READINESS_CONNECT_TIMEOUT_MS") || 7000);

    // Shopify: GraphQL ping if configured
    if (shopifyStoreUrl && shopifyToken) {
      const endpoint = `${shopifyStoreUrl}/admin/api/${shopifyApiVersion}/graphql.json`;
      try {
        const r = await fetchJsonWithTimeout(endpoint, {
          method: "POST",
          headers: {
            "X-Shopify-Access-Token": shopifyToken,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: JSON.stringify({ query: "query { shop { name } }" })
        }, timeoutMs);
        connectivity.shopify = r.ok ? { ok: true } : { ok: false, status: r.status, detail: (r.json?.errors?.[0]?.message || r.text || "").slice(0, 200) };
      } catch (e) {
        connectivity.shopify = { ok: false, detail: e instanceof Error ? e.message : String(e) };
      }
    }

    // Etsy: openapi-ping if key present
    if (etsyKey) {
      const url = "https://api.etsy.com/v3/application/openapi-ping";
      const xApiKey = etsySecret ? `${etsyKey}:${etsySecret}` : etsyKey;
      try {
        const r = await fetchJsonWithTimeout(url, {
          method: "GET",
          headers: { "x-api-key": xApiKey, "Accept": "application/json" }
        }, timeoutMs);
        connectivity.etsy = r.ok ? { ok: true } : { ok: false, status: r.status, detail: (r.text || "").slice(0, 200) };
      } catch (e) {
        connectivity.etsy = { ok: false, detail: e instanceof Error ? e.message : String(e) };
      }
    }

    // Printify: shops list if token present
    if (printifyToken) {
      const url = "https://api.printify.com/v1/shops.json";
      const userAgent = env("PRINTIFY_USER_AGENT") || "nexus-pod/1.0";
      try {
        const r = await fetchJsonWithTimeout(url, {
          method: "GET",
          headers: { "Authorization": `Bearer ${printifyToken}`, "User-Agent": userAgent, "Accept": "application/json" }
        }, timeoutMs);
        connectivity.printify = r.ok ? { ok: true } : { ok: false, status: r.status, detail: (r.text || "").slice(0, 200) };
      } catch (e) {
        connectivity.printify = { ok: false, detail: e instanceof Error ? e.message : String(e) };
      }
    }

    // WooCommerce: system status (requires auth)
    if (wooUrl && wooKey && wooSecret) {
      const url = `${wooUrl}/wp-json/wc/v3/system_status`;
      const basic = Buffer.from(`${wooKey}:${wooSecret}`).toString("base64");
      try {
        const r = await fetchJsonWithTimeout(url, {
          method: "GET",
          headers: { "Authorization": `Basic ${basic}`, "Accept": "application/json" }
        }, timeoutMs);
        connectivity.woocommerce = r.ok ? { ok: true } : { ok: false, status: r.status, detail: (r.text || "").slice(0, 200) };
      } catch (e) {
        connectivity.woocommerce = { ok: false, detail: e instanceof Error ? e.message : String(e) };
      }
    }
  }

  return {
    ok: true,
    mode,
    score,
    generatedAt,
    missingEnvVars: Array.from(missing),
    warnings,
    categories,
    connectivity: opts.runConnectivity ? connectivity : undefined
  };
}
