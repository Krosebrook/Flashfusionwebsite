import * as React from "react";
import { ExternalLink, RefreshCcw, PlayCircle } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { fetchReadiness } from "@/lib/api";
import type { ReadinessCategory, ReadinessItem, ReadinessReport, ReadinessStatus } from "@/types";

function StatusPill({ status }: { status: ReadinessStatus }) {
  const cls = status === "OK"
    ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200"
    : status === "WARN"
      ? "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200"
      : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200";
  return <span className={`text-xs px-2 py-0.5 rounded-full ${cls}`}>{status}</span>;
}

function CategoryCard({ cat }: { cat: ReadinessCategory }) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="font-semibold">{cat.title}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Score: {cat.score}/100</div>
        </div>
        <div className="w-32">
          <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-900 overflow-hidden">
            <div className="h-2 bg-indigo-600" style={{ width: `${cat.score}%` }} />
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {cat.items.map((it) => (
          <ItemRow key={it.id} item={it} />
        ))}
      </div>
    </Card>
  );
}

function ItemRow({ item }: { item: ReadinessItem }) {
  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3 bg-white dark:bg-slate-950">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <div className="font-medium truncate">{item.label}</div>
            <StatusPill status={item.status} />
          </div>
          {item.detail ? <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">{item.detail}</div> : null}
          {item.envVars?.length ? (
            <div className="mt-2 flex flex-wrap gap-1">
              {item.envVars.map((v) => (
                <code key={v} className="text-xs px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10">{v}</code>
              ))}
            </div>
          ) : null}
        </div>

        {item.docsUrl ? (
          <a
            href={item.docsUrl}
            target="_blank"
            rel="noreferrer"
            className="text-xs underline opacity-90 hover:opacity-100 whitespace-nowrap"
          >
            Docs <ExternalLink className="inline h-3 w-3 ml-1" />
          </a>
        ) : null}
      </div>

      {item.fix?.length ? (
        <ul className="mt-2 text-xs text-slate-600 dark:text-slate-300 list-disc pl-5 space-y-1">
          {item.fix.map((f, idx) => (
            <li key={idx}>{f}</li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export default function Readiness() {
  const [report, setReport] = React.useState<ReadinessReport | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [runningProbes, setRunningProbes] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async (args?: { runConnectivity?: boolean }) => {
    setError(null);
    try {
      const r = await fetchReadiness(args);
      setReport(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load({ runConnectivity: false });
  }, [load]);

  const runProbes = async () => {
    setRunningProbes(true);
    try {
      await load({ runConnectivity: true });
    } finally {
      setRunningProbes(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Readiness</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Full config + integration readiness, sourced from the backend. Use probes to verify credentials without crashing the app.
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => load({ runConnectivity: false })}>
            <RefreshCcw className="h-4 w-4 mr-2" /> Refresh
          </Button>
          <Button onClick={runProbes} disabled={runningProbes}>
            <PlayCircle className="h-4 w-4 mr-2" /> {runningProbes ? "Running…" : "Run probes"}
          </Button>
        </div>
      </div>

      {loading ? (
        <Card className="p-6">Loading readiness…</Card>
      ) : error ? (
        <Card className="p-6 border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-100">
          Readiness error: {error}
        </Card>
      ) : !report ? (
        <Card className="p-6">No readiness report.</Card>
      ) : (
        <>
          <Card className="p-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div>
                <div className="font-semibold">Overall</div>
                <div className="text-sm text-slate-600 dark:text-slate-300">Mode: <strong>{report.mode}</strong> • Score: <strong>{report.score}/100</strong></div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Generated: {new Date(report.generatedAt).toLocaleString()}</div>
              </div>
              <div className="flex flex-wrap gap-2">
                {report.missingEnvVars?.length ? (
                  <div className="text-xs text-slate-600 dark:text-slate-300">
                    Missing: <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">{report.missingEnvVars.join(", ")}</code>
                  </div>
                ) : (
                  <div className="text-xs text-slate-600 dark:text-slate-300">No missing env vars detected.</div>
                )}
              </div>
            </div>

            {report.warnings?.length ? (
              <div className="mt-3 text-xs text-slate-600 dark:text-slate-300">
                <div className="font-medium">Warnings</div>
                <ul className="list-disc pl-5 mt-1 space-y-1">
                  {report.warnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Card>

          {report.connectivity ? (
            <Card className="p-4">
              <div className="font-semibold">Connectivity probes</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Best-effort checks with timeouts (never block app boot).</div>
              <div className="mt-3 grid md:grid-cols-2 gap-3">
                {Object.entries(report.connectivity).map(([k, v]) => (
                  <div key={k} className="rounded-lg border border-slate-200 dark:border-slate-800 p-3 bg-white dark:bg-slate-950">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{k}</div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${v.ok ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200" : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200"}`}>{v.ok ? "OK" : "FAIL"}</span>
                    </div>
                    {v.status ? <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">HTTP {v.status}</div> : null}
                    {v.detail ? <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 break-words">{v.detail}</div> : null}
                  </div>
                ))}
              </div>
            </Card>
          ) : null}

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {report.categories.map((c: ReadinessCategory) => (
              <CategoryCard key={c.id} cat={c} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
