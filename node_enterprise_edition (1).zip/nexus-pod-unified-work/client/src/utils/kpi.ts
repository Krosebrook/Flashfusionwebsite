import type { Order, Product, SeedPayload, SeedTimeseriesPoint } from "@/types";
import { safeNumber } from "@/utils/format";

export type ProfitPoint = {
  date: string;
  revenue: number;
  adSpend: number;
  cogs: number;
  grossProfit: number;
  netProfit: number;
  netMargin: number;
  roas: number;
};

export function lastNDays(timeseries: SeedTimeseriesPoint[], n: number): SeedTimeseriesPoint[] {
  if (!Array.isArray(timeseries)) return [];
  if (n <= 0) return [];
  return timeseries.slice(Math.max(0, timeseries.length - n));
}

export function sum<K extends keyof SeedTimeseriesPoint>(ts: SeedTimeseriesPoint[], key: K): number {
  return (ts || []).reduce((acc, p) => acc + safeNumber(p[key]), 0);
}

export function avg<K extends keyof SeedTimeseriesPoint>(ts: SeedTimeseriesPoint[], key: K): number {
  if (!ts?.length) return 0;
  return sum(ts, key) / ts.length;
}

export function computeProfitByDay(seed: SeedPayload | null, orders: Order[], products: Product[]): ProfitPoint[] {
  const ts = seed?.timeseries || [];
  if (!ts.length) return [];

  const byDateOrders = new Map<string, Order[]>();
  for (const o of orders || []) {
    const date = String(o.createdAt || "").slice(0, 10);
    if (!date) continue;
    const arr = byDateOrders.get(date) || [];
    arr.push(o);
    byDateOrders.set(date, arr);
  }

  const productById = new Map<string, Product>();
  for (const p of products || []) productById.set(p.id, p);

  const fallbackCost = (() => {
    const b = seed?.benchmarks?.baselineCostsUsd;
    if (b?.tee && b?.hoodie && b?.mug) return (b.tee + b.hoodie + b.mug) / 3;
    return 12;
  })();

  return ts.map((p) => {
    const revenue = safeNumber(p.revenue);
    const adSpend = safeNumber(p.adSpend);
    const dayOrders = byDateOrders.get(p.date) || [];

    const cogs = dayOrders.reduce((acc, o) => {
      return acc + (o.items || []).reduce((acc2, it) => {
        const prod = productById.get(it.productId);
        const unitCost = safeNumber(prod?.cost, fallbackCost);
        const qty = Math.max(1, safeNumber(it.quantity, 1));
        return acc2 + unitCost * qty;
      }, 0);
    }, 0);

    const grossProfit = revenue - cogs;
    const netProfit = grossProfit - adSpend;
    const netMargin = revenue > 0 ? netProfit / revenue : 0;
    const roas = adSpend > 0 ? revenue / adSpend : 0;

    return {
      date: p.date,
      revenue,
      adSpend,
      cogs: Math.round(cogs * 100) / 100,
      grossProfit: Math.round(grossProfit * 100) / 100,
      netProfit: Math.round(netProfit * 100) / 100,
      netMargin: Math.round(netMargin * 10000) / 10000,
      roas: Math.round(roas * 100) / 100
    };
  });
}

export function computeTopline(seed: SeedPayload | null): {
  totalRevenue: number;
  totalOrders: number;
  totalSessions: number;
  avgAov: number;
  avgConversionRate: number;
  totalAdSpend: number;
} {
  const ts = seed?.timeseries || [];
  return {
    totalRevenue: sum(ts, "revenue"),
    totalOrders: sum(ts, "orders"),
    totalSessions: sum(ts, "sessions"),
    avgAov: avg(ts, "aov"),
    avgConversionRate: avg(ts, "conversionRate"),
    totalAdSpend: sum(ts, "adSpend")
  };
}
