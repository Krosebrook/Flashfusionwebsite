// This component has been deprecated.
// Please use features/merch/components/MerchStudio.tsx instead.
export {};