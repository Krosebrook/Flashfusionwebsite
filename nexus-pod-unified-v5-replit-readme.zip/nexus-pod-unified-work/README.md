# Nexus POD — Unified Central Hub (Full‑Stack + PWA)

This repo merges the **Nexus POD** full-stack API (Express + optional Supabase + commerce connectors) with a richer **Central Hub** UI (React Router + Tailwind + PWA) into a single portable monorepo.

## What you get

- **server/** (TypeScript, Express)
  - `/api/health`, `/api/status`
  - `/api/seed` (web-grounded seed payload used for first-run bootstrapping)
  - `/api/readiness` (configuration checks) and `/api/readiness?run=1` (connectivity probes)
  - `/api/generate-design` (OpenAI `gpt-image-1` if `OPENAI_API_KEY` is set; otherwise Demo Mode placeholder)
  - `/api/designs/:id/download` (server-backed downloads with correct headers)
  - `/api/publish-product` (Shopify/WooCommerce/Etsy/Printify connectors; fail-soft into Demo Mode)
- **client/** (React + Vite + PWA)
  - Dashboard, Analytics, Orders, Profit, Fulfillment
  - Products, Templates, Bulk Generator, Design Studio
  - Publishing Suite (bulk publish + local event log)
  - Automation Suite (manual-safe automations + CSV exports)
  - Stores, Readiness, Settings
  - Local demo persistence via `localStorage` (bootstrapped from `/api/seed`, with offline fallback)
  - Global **Demo Mode banner** driven by `/api/status`

## Requirements

- Node.js **20+**

## Run (dev)

Two terminals:

```bash
# terminal 1
npm install
npm -w server run dev
```

```bash
# terminal 2
npm -w client run dev
```

Client runs on Vite dev server and proxies `/api/*` to the server.

## Run (production / single deploy)

```bash
npm install
npm run build
npm start
```

## Env vars (optional)

Set these to enable real integrations. Missing keys do **not** crash the app.

### OpenAI (design generation)
- `OPENAI_API_KEY`
- `OPENAI_IMAGE_MODEL` (optional, default `gpt-image-1`)
- `OPENAI_IMAGE_SIZE` (optional, default `1024x1024`)

### Supabase (best-effort persistence)
- `SUPABASE_URL`
- `SUPABASE_KEY`

### Shopify
- `SHOPIFY_STORE_URL`
- `SHOPIFY_ACCESS_TOKEN`

Optional:
- `SHOPIFY_API_VERSION` (default: `2025-10`)
- `SHOPIFY_API_MODE` (default: `graphql`)

### Etsy
- `ETSY_API_KEY`

For OAuth2 (recommended):
- `ETSY_SHARED_SECRET`
- `ETSY_ACCESS_TOKEN`
- `ETSY_REFRESH_TOKEN`
- `ETSY_SHOP_ID`

Optional:
- `ETSY_API_BASE_URL` (default: `https://openapi.etsy.com`)

### Printify (optional)
- `PRINTIFY_API_TOKEN`
- `PRINTIFY_USER_AGENT` (default: `nexus-pod/1.0`)

### WooCommerce (optional)
- `WOOCOMMERCE_STORE_URL`
- `WOOCOMMERCE_CONSUMER_KEY`
- `WOOCOMMERCE_CONSUMER_SECRET`

### Ops tuning (optional)
- `RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_MS`
- `READINESS_CONNECT_TIMEOUT_MS`

### Observability (optional)
- `SENTRY_DSN`

## Smoke checks

With the server running:

```bash
npm run smoke
```

## Replit notes

This repo ships with a **monorepo‑tuned Replit preset**:

- `.replit` (Run command + port mapping)
- `replit.nix` (Node 20 + native build toolchain)
- `scripts/replit-run.sh` (smart boot)

### Port wiring

- Replit webview is pinned to **local :3000 → external :80** via `.replit`.
- **Prod mode** runs the Express server on :3000 and serves the built client from `client/dist`.
- **Dev mode** runs **Vite on :3000** and the API on :3001 (Vite proxies `/api/* → :3001`).

### RUN_MODE toggle (prod vs dev)

Default is production:

- `RUN_MODE=prod` (default)

To use dev mode:

- Set `RUN_MODE=dev` in Replit **Secrets** (or edit `.replit` env block)
- Press **Run**

### Build/run behavior

- `scripts/replit-run.sh` installs deps only if `node_modules/` is missing.
- In **prod mode**, it builds only if `server/dist` or `client/dist` is missing.

### Recommended Replit settings

- Put env vars in **Replit Secrets** (never commit secrets)
- Leave the Replit **Run** button as-is (it uses the preset)

## Implementation Considerations

Port wiring stays explicit and stable: Replit webview remains pinned to :3000 → :80 in both modes.

No rebuild loops: prod boot builds only when server/dist or client/dist is missing (or you force build).

Dev mode doesn’t fight the port mapping: Vite is forced to --port 3000 --strictPort, while the API stays on 3001 and is reached via proxy.

## Performance/Security Notes

replit.nix includes python3/gcc/make/pkg-config so native dependencies compile cleanly without node-gyp pain.

The run script does not print secrets and only applies safe env defaults; it won’t crash the app if integrations are unset (Demo/Partial stays intact).

Dev mode starts the API watcher as a background process and cleans it up on exit.

## Recommended Next Steps

### Replit Secrets

Keep RUN_MODE=prod for normal use; flip to dev only when actively iterating UI/API.

### Quick verification

In prod: open /api/health, /api/status, /api/readiness

In dev: UI loads on webview; /api/* calls should work via proxy

If you want scheduled automations (not manual-run): add a server scheduler (BullMQ + Redis or cron) to execute Automation Suite rules.

## CLAIMS CHECK

Claim: The repo zip contains replit.nix, .replit, and a monorepo-aware boot script.  
Check: All three are at repo root + scripts/replit-run.sh is present.

Claim: Dev mode uses Vite on :3000 with API proxied to :3001 without changing Replit’s webview mapping.  
Check: .replit keeps port mapping to 3000; RUN_MODE=dev branch in scripts/replit-run.sh starts server on 3001 and Vite on 3000; proxy is in client/vite.config.ts.

License: MIT
