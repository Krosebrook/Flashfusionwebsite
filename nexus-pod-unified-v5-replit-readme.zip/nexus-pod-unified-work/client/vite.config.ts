import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";
import path from "node:path";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icons/pwa-192x192.png", "icons/pwa-512x512.png"],
      manifest: {
        name: "Nexus POD — Central Hub",
        short_name: "NexusPOD",
        description: "Central Print-on-Demand Hub (PWA)",
        start_url: "/",
        scope: "/",
        display: "standalone",
        background_color: "#0b0f19",
        theme_color: "#111827",
        icons: [
          { src: "icons/pwa-192x192.png", sizes: "192x192", type: "image/png" },
          { src: "icons/pwa-512x512.png", sizes: "512x512", type: "image/png" }
        ]
      }
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src")
    }
  },
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:3001",
        changeOrigin: true
      }
    }
  }
});
