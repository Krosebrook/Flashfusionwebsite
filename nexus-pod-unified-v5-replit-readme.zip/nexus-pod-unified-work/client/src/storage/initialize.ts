import { localDb, KEYS } from "./localDb";
import { generateProducts, SEED_STORES, SEED_TEMPLATES, SEED_ORDERS } from "@/data/seedGenerator";

/**
 * Local schema versioning.
 * - We store a numeric version at KEYS.SCHEMA (string key).
 * - If you change the local shapes, bump SCHEMA_VERSION and re-seed (or implement migrations).
 */
const SCHEMA_VERSION = 1;

export function initializeApp() {
  const version = localDb.get<number>(KEYS.SCHEMA, 0);

  if (version === SCHEMA_VERSION) return;

  // Seed only our app keys (do not nuke full localStorage).
  // This keeps Replit / other apps safe on the same origin.
  console.log(`🌱 Initializing Seed Data (schema v${SCHEMA_VERSION})…`);

  localDb.set(KEYS.PRODUCTS, generateProducts(50));
  localDb.set(KEYS.STORES, SEED_STORES);
  localDb.set(KEYS.TEMPLATES, SEED_TEMPLATES);
  localDb.set(KEYS.ORDERS, SEED_ORDERS);
  localDb.set(KEYS.DESIGNS, []);
  localDb.set(KEYS.EVENTS, []);
  localDb.set(KEYS.SCHEMA, SCHEMA_VERSION);
}
