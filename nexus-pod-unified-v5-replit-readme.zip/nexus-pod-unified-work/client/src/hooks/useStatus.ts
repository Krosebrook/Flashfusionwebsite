import { useEffect, useState } from "react";
import { fetchStatus, type StatusResponse } from "../lib/api";

export function useStatus() {
  const [status, setStatus] = useState<StatusResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    fetchStatus()
      .then((s) => { if (mounted) setStatus(s); })
      .catch((e) => { if (mounted) setError(e instanceof Error ? e.message : String(e)); });
    return () => { mounted = false; };
  }, []);

  return { status, error };
}
