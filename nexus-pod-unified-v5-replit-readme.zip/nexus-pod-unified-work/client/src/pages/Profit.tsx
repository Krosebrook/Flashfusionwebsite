import { DollarSign, Percent, PiggyBank, Zap } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { KpiCard } from "@/components/charts/KpiCard";
import { LineChartCard } from "@/components/charts/LineChartCard";
import { formatPercent, formatUsd } from "@/utils/format";
import { computeProfitByDay } from "@/utils/kpi";

export default function Profit() {
  const { seed, orders, products } = useAppData();
  const profit = computeProfitByDay(seed, orders, products);

  const totals = profit.reduce(
    (acc, p) => {
      acc.revenue += p.revenue;
      acc.adSpend += p.adSpend;
      acc.cogs += p.cogs;
      acc.netProfit += p.netProfit;
      return acc;
    },
    { revenue: 0, adSpend: 0, cogs: 0, netProfit: 0 }
  );

  const netMargin = totals.revenue > 0 ? totals.netProfit / totals.revenue : 0;
  const roas = totals.adSpend > 0 ? totals.revenue / totals.adSpend : 0;

  const chartData = profit.map((p) => ({ ...p, day: p.date.slice(5) }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Profit</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Estimated profitability: Revenue − COGS − Ad Spend. COGS is inferred from order items using product costs; unknown items fall back to benchmark costs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <KpiCard icon={DollarSign} label="Net Profit (14d)" value={formatUsd(totals.netProfit)} subtext={`Revenue: ${formatUsd(totals.revenue)}`} />
        <KpiCard icon={PiggyBank} label="COGS (14d)" value={formatUsd(totals.cogs)} subtext={`Ad spend: ${formatUsd(totals.adSpend)}`} />
        <KpiCard icon={Percent} label="Net Margin" value={formatPercent(netMargin, 1)} subtext="(Net profit / revenue)" />
        <KpiCard icon={Zap} label="ROAS" value={Number.isFinite(roas) && roas > 0 ? roas.toFixed(2) : "—"} subtext="(Revenue / ad spend)" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LineChartCard
          title="Net Profit"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "netProfit", label: "Net Profit" }]}
          yFormatter={(v) => formatUsd(Number(v))}
          height={400}
        />
        <LineChartCard
          title="Revenue vs COGS"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "revenue", label: "Revenue" }, { dataKey: "cogs", label: "COGS" }]}
          yFormatter={(v) => formatUsd(Number(v))}
          height={400}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LineChartCard
          title="Margin"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "netMargin", label: "Net Margin" }]}
          yFormatter={(v) => formatPercent(Number(v), 1)}
          height={340}
        />
        <LineChartCard
          title="ROAS"
          data={chartData}
          xKey="day"
          lines={[{ dataKey: "roas", label: "ROAS" }]}
          yFormatter={(v) => (Number(v) ? Number(v).toFixed(2) : "0.00")}
          height={340}
        />
      </div>
    </div>
  );
}
