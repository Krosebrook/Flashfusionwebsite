import * as React from "react";
import toast from "react-hot-toast";
import { Download, ExternalLink, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { useAppData } from "@/context/AppDataContext";
import { useStatus } from "@/hooks/useStatus";
import { publishProduct } from "@/lib/api";
import type { Product, StoreKind } from "@/types";
import { formatUsd } from "@/utils/format";
import { uuid } from "@/utils/id";

type PublishRow = {
  productId: string;
  title: string;
  ok: boolean;
  demoMode: boolean;
  externalId?: string;
  url?: string;
  message?: string;
};

async function mapWithConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = [];
  let idx = 0;
  const workers = new Array(Math.max(1, limit)).fill(0).map(async () => {
    while (idx < items.length) {
      const i = idx++;
      // eslint-disable-next-line no-await-in-loop
      const r = await fn(items[i]);
      results[i] = r;
    }
  });
  await Promise.all(workers);
  return results;
}

function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function PublishingSuite() {
  const { status } = useStatus();
  const { products, designs, addEvent, updateProduct, events } = useAppData();
  const [store, setStore] = React.useState<StoreKind>("shopify");
  const [query, setQuery] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<"ALL" | "DRAFT" | "READY" | "PUBLISHED">("READY");
  const [selected, setSelected] = React.useState<Record<string, boolean>>({});
  const [running, setRunning] = React.useState(false);
  const [results, setResults] = React.useState<PublishRow[]>([]);

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return products
      .filter((p) => (statusFilter === "ALL" ? true : p.status === statusFilter))
      .filter((p) => (!q ? true : p.title.toLowerCase().includes(q) || p.productType.toLowerCase().includes(q)))
      .slice()
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [products, query, statusFilter]);

  const selectedIds = React.useMemo(() => Object.keys(selected).filter((k) => selected[k]), [selected]);
  const selectedProducts = React.useMemo(() => filtered.filter((p) => selected[p.id]), [filtered, selected]);

  const toggleAll = (on: boolean) => {
    const next: Record<string, boolean> = {};
    for (const p of filtered) next[p.id] = on;
    setSelected(next);
  };

  const exportPayload = () => {
    const payload = selectedProducts.map((p) => ({
      title: p.title,
      description: p.description,
      price: p.price,
      currency: "USD",
      tags: p.tags,
      images: p.designAssetId ? designs.filter((d) => d.id === p.designAssetId).map((d) => d.downloadUrl || d.imageDataUrl) : []
    }));
    downloadJson(`publish-payload-${store}-${new Date().toISOString().slice(0, 10)}.json`, payload);
  };

  const runPublish = async () => {
    if (!selectedIds.length) {
      toast.error("Select at least one product.");
      return;
    }

    setRunning(true);
    setResults([]);
    const concurrency = 3;

    try {
      const out = await mapWithConcurrency(selectedProducts, concurrency, async (p: Product): Promise<PublishRow> => {
        const images = p.designAssetId
          ? designs.filter((d) => d.id === p.designAssetId).map((d) => d.downloadUrl || d.imageDataUrl)
          : [];

        try {
          const res = await publishProduct({
            store,
            product: {
              title: p.title,
              description: p.description,
              price: p.price,
              currency: "USD",
              images,
              tags: p.tags
            }
          });

          const ok = !res.demoMode;
          addEvent({
            id: uuid(),
            productId: p.id,
            storeId: store,
            storeKind: store,
            status: ok ? "SUCCESS" : "FAILED",
            publishedAt: new Date().toISOString(),
            url: res.url,
            notes: res.demoMode ? res.warning || "Demo Mode" : res.warning
          });

          if (ok) {
            updateProduct({ ...p, status: "PUBLISHED", updatedAt: new Date().toISOString() });
          }

          return {
            productId: p.id,
            title: p.title,
            ok,
            demoMode: res.demoMode,
            externalId: res.externalId,
            url: res.url,
            message: res.warning
          };
        } catch (e: any) {
          addEvent({
            id: uuid(),
            productId: p.id,
            storeId: store,
            storeKind: store,
            status: "FAILED",
            publishedAt: new Date().toISOString(),
            notes: e instanceof Error ? e.message : String(e)
          });
          return {
            productId: p.id,
            title: p.title,
            ok: false,
            demoMode: true,
            message: e instanceof Error ? e.message : String(e)
          };
        }
      });

      setResults(out);
      const successes = out.filter((r) => r.ok).length;
      const demos = out.filter((r) => !r.ok && r.demoMode).length;
      toast.success(`Publishing finished: ${successes} live • ${demos} demo/failed.`);
    } finally {
      setRunning(false);
    }
  };

  const storeConfigured = (() => {
    const i = status?.integrations;
    if (!i) return false;
    if (store === "shopify") return i.shopify;
    if (store === "etsy") return i.etsy;
    if (store === "printify") return i.printify;
    if (store === "woocommerce") return i.woocommerce;
    return false;
  })();

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Publishing Suite</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Bulk publish with fail-soft safety: missing keys → Demo Mode, no crashes. For best results, configure integrations and run readiness probes.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={exportPayload} disabled={!selectedIds.length}>
            <Download className="h-4 w-4 mr-2" /> Export JSON
          </Button>
          <Button onClick={runPublish} disabled={running || !selectedIds.length}>
            <UploadCloud className="h-4 w-4 mr-2" /> {running ? "Publishing…" : `Publish (${selectedIds.length})`}
          </Button>
        </div>
      </div>

      <Card className="p-4">
        <div className="grid md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Store</label>
            <select
              value={store}
              onChange={(e) => setStore(e.target.value as StoreKind)}
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            >
              <option value="shopify">Shopify</option>
              <option value="woocommerce">WooCommerce</option>
              <option value="etsy">Etsy (demo connector)</option>
              <option value="printify">Printify (demo connector)</option>
            </select>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Status: {storeConfigured ? <span className="text-emerald-700 dark:text-emerald-300">configured</span> : <span className="text-amber-700 dark:text-amber-300">demo</span>}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Product filter</label>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search title/type…"
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            >
              <option value="READY">READY (recommended)</option>
              <option value="DRAFT">DRAFT</option>
              <option value="PUBLISHED">PUBLISHED</option>
              <option value="ALL">All</option>
            </select>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => toggleAll(true)} disabled={!filtered.length}>Select all</Button>
          <Button variant="ghost" onClick={() => toggleAll(false)} disabled={!filtered.length}>Clear</Button>
          <Button
            variant="ghost"
            onClick={() => window.open(store === "shopify" ? "https://shopify.dev/docs/api" : store === "woocommerce" ? "https://woocommerce.com/document/woocommerce-rest-api/" : store === "etsy" ? "https://developer.etsy.com/documentation/" : "https://developers.printify.com/", "_blank", "noreferrer")}
          >
            Docs <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </Card>

      <Card className="p-0 overflow-hidden">
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-900/40 text-slate-600 dark:text-slate-300">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Select</th>
                <th className="text-left px-4 py-3 font-medium">Product</th>
                <th className="text-left px-4 py-3 font-medium">Type</th>
                <th className="text-left px-4 py-3 font-medium">Status</th>
                <th className="text-right px-4 py-3 font-medium">Price</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-t border-slate-200 dark:border-slate-800">
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={Boolean(selected[p.id])}
                      onChange={(e) => setSelected((prev) => ({ ...prev, [p.id]: e.target.checked }))}
                    />
                  </td>
                  <td className="px-4 py-3 font-medium whitespace-nowrap">{p.title}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{p.productType}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">{p.status}</span>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">{formatUsd(p.price)}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-500 dark:text-slate-400">No products.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {(results.length > 0) && (
        <Card className="p-4">
          <h3 className="text-lg font-semibold">Latest publish run</h3>
          <div className="mt-3 space-y-2">
            {results.map((r) => (
              <div key={r.productId} className="flex items-start justify-between gap-4 rounded-lg border border-slate-200 dark:border-slate-800 p-3 bg-white dark:bg-slate-950">
                <div>
                  <div className="font-medium">{r.title}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{r.externalId ? `External: ${r.externalId}` : ""}</div>
                  {r.message ? <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">{r.message}</div> : null}
                </div>
                <div className="text-right">
                  <div className={`text-xs px-2 py-0.5 rounded-full ${r.ok ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200" : "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200"}`}>{r.ok ? "LIVE" : "DEMO"}</div>
                  {r.url ? (
                    <a href={r.url} target="_blank" rel="noreferrer" className="text-xs underline mt-2 inline-block">Open <ExternalLink className="inline h-3 w-3 ml-1" /></a>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {(events.length > 0) && (
        <Card className="p-4">
          <h3 className="text-lg font-semibold">Publish events (local log)</h3>
          <div className="mt-3 overflow-auto">
            <table className="min-w-full text-sm">
              <thead className="text-left text-slate-600 dark:text-slate-300">
                <tr className="border-b border-slate-200 dark:border-slate-800">
                  <th className="py-2 pr-4">Time</th>
                  <th className="py-2 pr-4">Product</th>
                  <th className="py-2 pr-4">Store</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2 pr-4">Notes</th>
                </tr>
              </thead>
              <tbody>
                {events.slice(0, 20).map((e) => (
                  <tr key={e.id} className="border-b border-slate-100 dark:border-slate-900">
                    <td className="py-2 pr-4 whitespace-nowrap">{new Date(e.publishedAt).toLocaleString()}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{products.find((p) => p.id === e.productId)?.title || e.productId}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{e.storeKind}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{e.status}</td>
                    <td className="py-2 pr-4">{e.notes || ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
