import * as React from "react";
import toast from "react-hot-toast";
import { ImagePlus, Loader2, Download } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useAppData } from "@/context/AppDataContext";
import { uuid } from "@/utils/id";
import { generateDesign } from "@/lib/api";
import type { DesignAsset } from "@/types";

export default function DesignStudio() {
  const { designs, addDesign } = useAppData();
  const [prompt, setPrompt] = React.useState("");
  const [style, setStyle] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [preview, setPreview] = React.useState<DesignAsset | null>(null);

  const run = async () => {
    const p = prompt.trim();
    if (!p) return toast.error("Add a prompt first.");

    setLoading(true);
    try {
      const res = await generateDesign({ prompt: p, style: style.trim() || undefined });
      const asset: DesignAsset = {
        id: res.id ?? uuid(),
        name: `Design • ${new Date(res.createdAt ?? Date.now()).toLocaleString()}`,
        prompt: p,
        imageDataUrl: res.imageDataUrl,
        createdAt: res.createdAt ?? new Date().toISOString(),
        downloadUrl: res.downloadUrl,
        filename: res.filename,
        expiresAt: res.expiresAt,
        provider: res.provider
      };
      addDesign(asset);
      setPreview(asset);
      toast.success(res.demoMode ? "Generated (Demo Mode placeholder)." : "Generated with OpenAI.");
    } catch (e: any) {
      toast.error("Design generation failed.");
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const download = async (asset: DesignAsset) => {
    const fallback = () => {
      const a = document.createElement("a");
      a.href = asset.imageDataUrl;
      a.download = asset.filename || `design-${asset.id}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    };

    // Prefer the server-backed download URL when present.
    if (asset.downloadUrl) {
      try {
        const res = await fetch(asset.downloadUrl, { method: "GET" });
        if (!res.ok) throw new Error(`Download failed (${res.status})`);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = asset.filename || `design-${asset.id}.png`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        return;
      } catch (e) {
        // eslint-disable-next-line no-console
        console.warn("Server download failed; falling back to data URL.", e);
      }
    }

    try {
      fallback();
    } catch {
      toast.error("Download failed in this browser.");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Design Studio</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Generate a design asset via the backend (<code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">/api/generate-design</code>).
          Missing keys automatically falls back to Demo Mode.
        </p>
      </div>

      <Card className="space-y-4">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="md:col-span-2 space-y-2">
            <label className="text-sm font-medium">Prompt</label>
            <input
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., 'Minimalist neon wolf, screenprint style'"
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Style (optional)</label>
            <input
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              placeholder="e.g., 'vector, 2 colors'"
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
            />
          </div>
        </div>

        <Button onClick={run} disabled={loading} className="w-full md:w-auto">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ImagePlus className="mr-2 h-4 w-4" />}
          {loading ? "Generating…" : "Generate design"}
        </Button>
      </Card>

      {(preview || designs.length > 0) && (
        <div className="grid lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold">Preview</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{preview?.prompt ?? "Select from history."}</p>
              </div>
              {preview && (
                <Button variant="secondary" onClick={() => void download(preview)}>
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              )}
            </div>
            <div className="mt-4 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
              {preview ? (
                <img src={preview.imageDataUrl} alt={preview.prompt} className="w-full h-auto" />
              ) : (
                <div className="p-10 text-center text-slate-500 dark:text-slate-400">No preview selected.</div>
              )}
            </div>
          </Card>

          <Card className="p-4">
            <h3 className="font-semibold">History</h3>
            <div className="mt-3 space-y-2 max-h-[520px] overflow-auto pr-1">
              {designs.slice(0, 20).map((d) => (
                <button
                  key={d.id}
                  onClick={() => setPreview(d)}
                  className="w-full text-left rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-900 p-2 transition"
                >
                  <div className="text-xs text-slate-500 dark:text-slate-400">{new Date(d.createdAt).toLocaleString()}</div>
                  <div className="text-sm font-medium line-clamp-2">{d.prompt}</div>
                </button>
              ))}
              {designs.length === 0 && (
                <div className="text-sm text-slate-500 dark:text-slate-400">No designs yet.</div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
