import * as React from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Card } from "@/components/ui/Card";

function DefaultTooltip({ active, payload, label, formatter }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-3 text-xs">
      <div className="font-semibold mb-1">{label}</div>
      <div className="space-y-1">
        {payload.map((p: any) => (
          <div key={p.dataKey} className="flex items-center justify-between gap-6">
            <span className="text-slate-500 dark:text-slate-400">{p.name}</span>
            <span className="font-medium">{formatter ? formatter(p.value, p.dataKey) : String(p.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function BarChartCard<T extends Record<string, any>>(props: {
  title: string;
  data: T[];
  xKey: keyof T;
  barKey: keyof T;
  barLabel: string;
  yFormatter?: (value: any, dataKey?: string) => string;
  height?: number;
}) {
  const { title, data, xKey, barKey, barLabel, yFormatter, height = 340 } = props;
  return (
    <Card className="p-4" style={{ height }}>
      <h3 className="text-lg font-semibold">{title}</h3>
      <div className="mt-4" style={{ height: height - 64 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
            <XAxis dataKey={String(xKey)} tickLine={false} axisLine={false} fontSize={12} />
            <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v) => (yFormatter ? yFormatter(v) : String(v))} />
            <Tooltip content={<DefaultTooltip formatter={yFormatter} />} />
            <Bar dataKey={String(barKey)} name={barLabel} fill="#4f46e5" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
