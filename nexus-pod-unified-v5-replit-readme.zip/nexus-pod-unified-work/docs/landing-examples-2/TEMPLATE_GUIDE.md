# Template Selection Guide

Choose the right template for your project based on your goals and stage.

## Quick Decision Tree

```
Are you pre-launch or validating demand?
├─ Yes → Use coming-soon.tsx
└─ No → Continue...

Is pricing your main competitive advantage?
├─ Yes → Use pricing-focused.tsx
└─ No → Continue...

Are you highlighting a specific feature/product?
├─ Yes → Use product-focused.tsx
└─ No → Continue...

Do you need to launch in <1 week?
├─ Yes → Use minimal-mvp.tsx
└─ No → Use landing-page.tsx (full-featured)
```

---

## Template Comparison

| Template | Use When | Time to Launch | Components | Conversion Goal |
|----------|----------|----------------|------------|-----------------|
| **coming-soon.tsx** | Pre-launch, building in public, collecting waitlist | 1-2 hours | Hero, Form, Features preview | Email capture |
| **minimal-mvp.tsx** | Quick validation, testing PMF, <1 week launch | 2-4 hours | Hero, 3 features, Form, Footer | Email capture or signup |
| **product-focused.tsx** | Specific feature launch, niche marketing | 4-6 hours | Split Hero, Problem/Solution, Steps, Metrics | Feature trial signup |
| **pricing-focused.tsx** | Price competitive, transparent pricing model | 6-8 hours | Hero, Pricing, Comparison, ROI, FAQ | Pricing page conversion |
| **landing-page.tsx** | Full product launch, comprehensive marketing | 8-12 hours | All components, Testimonials, CTA | Full funnel (awareness → trial) |

---

## Detailed Template Guides

### 1. coming-soon.tsx
**Perfect for:**
- Pre-launch products (3+ months out)
- Building in public / generating buzz
- Validating demand before building
- Collecting early adopters

**Key Features:**
- Single-focus email capture
- Launch timeline indicator
- Feature preview list
- Early supporter badges
- Pulsing "Building in Public" indicator

**Customization Priority:**
1. Update brand name and logo
2. Set launch timeline (Q1 2025 → your date)
3. Replace feature preview with your actual features
4. Connect email form to provider (Resend, SendGrid, etc.)
5. Update social links (Twitter, contact email)

**Metrics to Track:**
- Waitlist signups per day
- Traffic sources
- Referral patterns
- Email engagement (when you send updates)

---

### 2. minimal-mvp.tsx
**Perfect for:**
- Quick MVPs (<1 week to launch)
- Testing product-market fit
- Limited scope / single feature products
- Bootstrap / no-funding projects

**Key Features:**
- Center-aligned hero
- 3-feature grid (minimal but effective)
- Email waitlist form
- Simple footer

**Customization Priority:**
1. Update hero headline and subheading
2. Replace 3 features with your core value props
3. Connect waitlist form (or switch to signup)
4. Add logo/branding
5. Update privacy/terms links

**When to Upgrade:**
- Getting 100+ signups/week → Add testimonials
- Launching paid tiers → Switch to pricing-focused.tsx
- Adding multiple features → Switch to landing-page.tsx

---

### 3. product-focused.tsx
**Perfect for:**
- Launching specific features (not full products)
- Targeting niche use cases
- Marketing to specific personas
- Product-led growth campaigns

**Key Features:**
- Split hero with product demo
- Problem → Solution narrative
- 3-step "How It Works" flow
- Specific metrics (10K+, 85%, etc.)
- Urgency-focused CTA

**Customization Priority:**
1. Define ONE clear problem you solve
2. Explain solution in 2-3 sentences max
3. Create 3-step flow (Connect → Analyze → Get Results)
4. Replace metrics with YOUR real numbers
5. Add product screenshots/demo video

**Copy Formula:**
- Problem: Describe current pain (be specific)
- Solution: Your unique approach (not features)
- How It Works: Simple 3-step process
- Proof: Real metrics + social proof
- CTA: Clear next action + urgency

---

### 4. pricing-focused.tsx
**Perfect for:**
- Price as competitive advantage
- Self-service / PLG model
- Transparent pricing strategy
- Disrupting expensive incumbents

**Key Features:**
- Price-anchored hero ($9/mo in badge)
- Competitor comparison table
- ROI calculator (interactive)
- Detailed FAQ
- Three-tier pricing

**Customization Priority:**
1. Set your actual pricing tiers
2. Add real competitor prices (be accurate!)
3. Build ROI calculator logic
4. Write honest FAQ answers
5. Add customer logos/testimonials

**Pricing Psychology:**
- Anchor high (show competitor prices first)
- Make middle tier most attractive (badges, highlighting)
- Include "hidden fee" comparisons
- Show total annual savings
- Make upgrades feel like bargains

**A/B Test Ideas:**
- Annual vs monthly default
- Show savings percentage vs dollar amount
- 3 tiers vs 2 tiers
- Free tier vs free trial
- CTA copy ("Start Free" vs "Try Free" vs "Get Started")

---

### 5. landing-page.tsx (Full-Featured)
**Perfect for:**
- Full product launches
- Series A+ companies
- Multi-feature products
- Comprehensive marketing funnels

**Key Features:**
- Center hero with trust badges
- 6-feature grid
- Logo wall (social proof)
- Three-tier pricing
- Customer testimonials
- Final CTA section

**Customization Priority:**
1. Replace hero visual with actual product screenshot
2. Update 6 features (use real value props)
3. Add real customer testimonials
4. Connect pricing to Stripe
5. Add real company logos (with permission!)
6. Set up analytics tracking

**Content Checklist:**
- [ ] Above-fold value prop clear in 5 seconds
- [ ] Features focus on outcomes (not tech)
- [ ] Testimonials include name, role, company
- [ ] Pricing includes all hidden costs
- [ ] CTAs consistent throughout page
- [ ] Mobile responsive (test on real device)

---

## Common Customizations

### Adding Analytics
```typescript
// In any template, add to <head>
{process.env.NEXT_PUBLIC_GA_ID && (
  <Script
    src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GA_ID}`}
    strategy="afterInteractive"
  />
)}
```

### Adding Auth
```typescript
// Replace signup links
href="/signup" 
// becomes
href="/api/auth/signup" // with Supabase/Auth0/etc
```

### Adding Payment
```typescript
// In pricing tiers CTA
onClick={async () => {
  const { sessionId } = await fetch('/api/checkout', {
    method: 'POST',
    body: JSON.stringify({ priceId: 'price_xxx' })
  }).then(r => r.json());
  
  // Redirect to Stripe
  stripe.redirectToCheckout({ sessionId });
}}
```

### Email Capture
```typescript
// Connect to Resend
const handleSubmit = async (email: string) => {
  await fetch('/api/waitlist', {
    method: 'POST',
    body: JSON.stringify({ email })
  });
};
```

---

## Migration Paths

### From coming-soon.tsx → minimal-mvp.tsx
**When:** You have an MVP ready to test
**Changes:**
- Replace "Join Waitlist" → "Start Free Trial"
- Add 3 actual features (not previews)
- Update status badge (Building → Live/Beta)
- Add actual signup flow (not just email)

### From minimal-mvp.tsx → landing-page.tsx
**When:** You have paying customers and need to scale
**Changes:**
- Add testimonials section
- Expand to 6 features
- Add pricing tiers
- Add logo wall
- Add FAQ section

### From product-focused.tsx → landing-page.tsx
**When:** Launching additional features beyond the single focus
**Changes:**
- Switch split hero → center hero
- Add feature grid (all features, not just one)
- Add pricing (if monetizing)
- Broaden copy from single use case to platform

---

## Performance Checklist

Use this for ANY template before launch:

**Speed:**
- [ ] Images optimized (WebP, <200KB each)
- [ ] Fonts loaded locally or from CDN
- [ ] No unnecessary scripts above-fold
- [ ] Lazy load below-fold images

**SEO:**
- [ ] Title tag (50-60 chars)
- [ ] Meta description (150-160 chars)
- [ ] OG image (1200x630px)
- [ ] Canonical URL set
- [ ] Structured data (JSON-LD)

**Conversion:**
- [ ] Primary CTA above fold
- [ ] Mobile CTA always visible
- [ ] Forms validate on blur
- [ ] Success states show immediately
- [ ] Error messages are helpful

**Accessibility:**
- [ ] Color contrast ≥4.5:1
- [ ] All images have alt text
- [ ] Keyboard navigation works
- [ ] Focus states visible
- [ ] Form labels present

---

## Next Steps After Choosing Template

1. **Copy template file** → Rename to `page.tsx` in your app
2. **Update .env.example** → Add your actual env vars
3. **Replace placeholders:**
   - Brand name
   - Images (add to `/public`)
   - Copy (headlines, features, etc.)
   - Links (signup, contact, etc.)
4. **Connect integrations:**
   - Email provider (Resend, etc.)
   - Analytics (PostHog, GA)
   - Payment (Stripe)
   - Auth (Supabase, Clerk)
5. **Test thoroughly:**
   - Desktop (Chrome, Safari, Firefox)
   - Mobile (iOS Safari, Chrome Android)
   - Forms submit correctly
   - Links work
   - Images load
6. **Deploy:**
   - Push to Vercel/Netlify
   - Set env vars in dashboard
   - Test production URL
   - Set up monitoring

---

## Questions? Start Here

**"Which template should I use?"**
→ See decision tree at top of this doc

**"Can I combine templates?"**
→ Yes! Take sections from different templates

**"How do I add [feature]?"**
→ Check main README.md for component docs

**"Where do I put custom code?"**
→ Create new components in `/components` folder

**"How do I deploy?"**
→ Push to GitHub → Connect to Vercel → Deploy

**"Something's broken, help!"**
→ Check browser console for errors
→ Verify all env vars are set
→ Test in incognito mode (clear cache)
