import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler.js";
import { readEnv } from "../utils/env.js";
import { StoreConnector, type StoreKind } from "../connectors/StoreConnector.js";

export const publishProductRouter = Router();

const StoreEnum = z.enum(["shopify", "etsy", "printify", "woocommerce"]);

const BodySchema = z.object({
  store: StoreEnum,
  product: z.object({
    title: z.string().min(1).max(140),
    description: z.string().max(5000).optional(),
    price: z.number().positive().optional(),
    currency: z.string().min(3).max(3).optional(),
    images: z.array(z.string().min(5)).max(10).optional(),
    tags: z.array(z.string().min(1).max(30)).max(25).optional()
  })
});

publishProductRouter.post("/publish-product", asyncHandler(async (req, res) => {
  const parsed = BodySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_request", details: parsed.error.flatten() });
    return;
  }

  const store = parsed.data.store as StoreKind;
  const product = parsed.data.product;

  // In this starter, connectors read from env.
  // Each connector must fail-soft into Demo Mode if missing keys.
  const connector = new StoreConnector({
    kind: store,
    apiKey: store === "shopify" ? readEnv("SHOPIFY_ACCESS_TOKEN", { warnIfMissing: false })
      : store === "etsy" ? readEnv("ETSY_ACCESS_TOKEN", { warnIfMissing: false })
      : store === "printify" ? readEnv("PRINTIFY_API_TOKEN", { warnIfMissing: false })
      : undefined,
    storeUrl: store === "shopify" ? readEnv("SHOPIFY_STORE_URL", { warnIfMissing: false })
      : store === "etsy" ? (readEnv("ETSY_API_BASE_URL", { warnIfMissing: false }) || "https://openapi.etsy.com")
      : store === "printify" ? "https://api.printify.com"
      : store === "woocommerce" ? readEnv("WOOCOMMERCE_STORE_URL", { warnIfMissing: false })
      : undefined,
    extra: {
      SHOPIFY_API_VERSION: readEnv("SHOPIFY_API_VERSION", { warnIfMissing: false }) || "2025-10",
      SHOPIFY_API_MODE: readEnv("SHOPIFY_API_MODE", { warnIfMissing: false }) || "graphql",

      ETSY_API_KEY: readEnv("ETSY_API_KEY", { warnIfMissing: false }),
      ETSY_SHARED_SECRET: readEnv("ETSY_SHARED_SECRET", { warnIfMissing: false }),
      ETSY_ACCESS_TOKEN: readEnv("ETSY_ACCESS_TOKEN", { warnIfMissing: false }),
      ETSY_REFRESH_TOKEN: readEnv("ETSY_REFRESH_TOKEN", { warnIfMissing: false }),
      ETSY_SHOP_ID: readEnv("ETSY_SHOP_ID", { warnIfMissing: false }),

      PRINTIFY_USER_AGENT: readEnv("PRINTIFY_USER_AGENT", { warnIfMissing: false }) || "nexus-pod/1.0",

      WOOCOMMERCE_CONSUMER_KEY: readEnv("WOOCOMMERCE_CONSUMER_KEY", { warnIfMissing: false }),
      WOOCOMMERCE_CONSUMER_SECRET: readEnv("WOOCOMMERCE_CONSUMER_SECRET", { warnIfMissing: false })
    }
  });

  const result = await connector.publishProduct(product);
  res.json(result);
}));
