import { Router } from "express";
import { createGroundedSeed } from "../data/groundedSeed.js";

export const seedRouter = Router();

/**
 * GET /api/seed
 * Returns web-grounded seed data for Demo Mode / first-run bootstrapping.
 *
 * This is intentionally static-ish and does NOT scrape at runtime.
 */
seedRouter.get("/seed", (_req, res) => {
  const seed = createGroundedSeed(new Date());
  res.json({ ok: true, seed });
});
