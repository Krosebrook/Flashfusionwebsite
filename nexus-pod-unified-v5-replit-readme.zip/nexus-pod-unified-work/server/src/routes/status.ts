import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { readEnv } from "../utils/env.js";
import { getSupabaseClient } from "../supabase.js";
import { buildReadinessReport } from "../services/readiness.js";

export const statusRouter = Router();

/**
 * Lightweight status endpoint used by the UI banner.
 * - Never throws (fail-soft): returns best-effort booleans + missing env vars.
 * - For deeper diagnostics, use GET /api/readiness (optionally with ?run=1).
 */
statusRouter.get("/status", asyncHandler(async (_req, res) => {
  const hasOpenAI = Boolean(readEnv("OPENAI_API_KEY", { warnIfMissing: false }));
  const hasSupabase = Boolean(getSupabaseClient());

  const hasShopify = Boolean(readEnv("SHOPIFY_ACCESS_TOKEN", { warnIfMissing: false }) && readEnv("SHOPIFY_STORE_URL", { warnIfMissing: false }));
  const hasEtsy = Boolean(readEnv("ETSY_API_KEY", { warnIfMissing: false }) && readEnv("ETSY_ACCESS_TOKEN", { warnIfMissing: false }) && readEnv("ETSY_SHOP_ID", { warnIfMissing: false }));
  const hasPrintify = Boolean(readEnv("PRINTIFY_API_TOKEN", { warnIfMissing: false }));
  const hasWoo = Boolean(readEnv("WOOCOMMERCE_STORE_URL", { warnIfMissing: false }) && readEnv("WOOCOMMERCE_CONSUMER_KEY", { warnIfMissing: false }) && readEnv("WOOCOMMERCE_CONSUMER_SECRET", { warnIfMissing: false }));

  const report = await buildReadinessReport({ runConnectivity: false });

  res.json({
    ok: true,
    mode: report.mode,
    score: report.score,
    demoMode: report.mode !== "LIVE",
    integrations: {
      openai: hasOpenAI,
      supabase: hasSupabase,
      shopify: hasShopify,
      etsy: hasEtsy,
      printify: hasPrintify,
      woocommerce: hasWoo
    },
    missing: report.missingEnvVars,
    warnings: report.warnings
  });
}));
