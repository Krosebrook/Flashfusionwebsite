import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { getDesign, decodeDesignToBuffer } from "../services/designStore.js";

export const designsRouter = Router();

// Metadata
designsRouter.get("/designs/:id", asyncHandler(async (req, res) => {
  const id = String(req.params.id || "");
  const d = getDesign(id);
  if (!d) {
    res.status(404).json({ error: "not_found", message: "Design not found (expired or unknown)." });
    return;
  }

  res.json({
    ok: true,
    design: {
      id: d.id,
      prompt: d.prompt,
      provider: d.provider,
      createdAt: d.createdAt,
      mime: d.mime,
      sizeBytes: d.sizeBytes,
      filename: d.filename,
      expiresAt: d.expiresAt,
      downloadUrl: `/api/designs/${encodeURIComponent(d.id)}/download`
    }
  });
}));

// Download as an attachment
designsRouter.get("/designs/:id/download", asyncHandler(async (req, res) => {
  const id = String(req.params.id || "");
  const d = getDesign(id);
  if (!d) {
    res.status(404).json({ error: "not_found", message: "Design not found (expired or unknown)." });
    return;
  }

  const buf = decodeDesignToBuffer(d);

  res.setHeader("Content-Type", d.mime);
  res.setHeader("Content-Length", String(buf.length));
  res.setHeader("Content-Disposition", `attachment; filename="${d.filename}"`);
  res.send(buf);
}));
