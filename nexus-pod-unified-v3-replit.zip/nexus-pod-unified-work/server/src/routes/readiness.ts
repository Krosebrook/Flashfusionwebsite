import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { buildReadinessReport } from "../services/readiness.js";

export const readinessRouter = Router();

/**
 * GET /api/readiness
 * - Default: static env/config checks.
 * - ?run=1: also runs limited connectivity probes (timeouts, fail-soft).
 */
readinessRouter.get("/readiness", asyncHandler(async (req, res) => {
  const run = String(req.query.run || "") === "1";
  const report = await buildReadinessReport({ runConnectivity: run });
  res.json(report);
}));
