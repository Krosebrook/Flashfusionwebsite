import { Router } from "express";
import { z } from "zod";
import { nanoid } from "nanoid";
import { asyncHandler } from "../utils/asyncHandler.js";
import { generateDesign } from "../services/designGenerator.js";
import { putDesign } from "../services/designStore.js";
import { getSupabaseClient } from "../supabase.js";
import { logger } from "../utils/logger.js";

export const generateDesignRouter = Router();

const BodySchema = z.object({
  prompt: z.string().min(3).max(500),
  style: z.string().max(80).optional()
});

generateDesignRouter.post("/generate-design", asyncHandler(async (req, res) => {
  const parsed = BodySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_request", details: parsed.error.flatten() });
    return;
  }

  const prompt = parsed.data.style ? `${parsed.data.prompt} (${parsed.data.style})` : parsed.data.prompt;

  const out = await generateDesign(prompt);
  const id = nanoid();
  const createdAt = new Date().toISOString();

  // Best-effort persistence
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      // Table creation is not enforced in this starter. Create a `designs` table if you want persistence.
      const { error } = await supabase.from("designs").insert({
        id,
        prompt,
        provider: out.provider,
        image_data_url: out.imageDataUrl,
        created_at: createdAt
      });
      if (error) logger.warn("Supabase insert failed (designs table may not exist yet).", error.message);
    } catch (e) {
      logger.warn("Supabase insert threw; continuing in Demo Mode.", String(e));
    }
  }

  const stored = putDesign({ id, prompt, provider: out.provider, createdAt, imageDataUrl: out.imageDataUrl });

  res.json({
    id,
    prompt,
    provider: out.provider,
    imageDataUrl: out.imageDataUrl,
    downloadUrl: `/api/designs/${encodeURIComponent(id)}/download`,
    filename: stored.filename,
    expiresAt: stored.expiresAt,
    createdAt,
    demoMode: out.provider === "mock"
  });
}));
