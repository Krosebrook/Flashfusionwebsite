import { createHash } from "node:crypto";
import { readEnv } from "../utils/env.js";

export type StoredDesign = {
  id: string;
  prompt: string;
  provider: "mock" | "openai";
  createdAt: string;
  imageDataUrl: string;
  mime: string;
  sizeBytes: number;
  filename: string;
  expiresAt: string;
};

const designs = new Map<string, StoredDesign>();

function nowMs(): number {
  return Date.now();
}

function parseIntOr(name: string, fallback: number): number {
  const v = readEnv(name, { warnIfMissing: false });
  if (!v) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

const TTL_MS = parseIntOr("DESIGN_STORE_TTL_MS", 1000 * 60 * 30); // 30 minutes
const MAX_ITEMS = parseIntOr("DESIGN_STORE_MAX_ITEMS", 200);
const MAX_DATAURL_BYTES = parseIntOr("DESIGN_STORE_MAX_DATAURL_BYTES", 8 * 1024 * 1024); // 8MB

function sanitizeFilename(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\-\s_]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 60) || "design";
}

function inferMime(dataUrl: string): string {
  const m = dataUrl.match(/^data:([^;]+);/i);
  return m?.[1] || "application/octet-stream";
}

function approximateBytesFromDataUrl(dataUrl: string): number {
  // data:<mime>;base64,<payload>
  const idx = dataUrl.indexOf(",");
  if (idx < 0) return dataUrl.length;
  const b64 = dataUrl.slice(idx + 1);
  // base64 4 chars -> 3 bytes
  return Math.floor((b64.length * 3) / 4);
}

function prune(): void {
  const cutoff = nowMs();
  for (const [id, d] of designs.entries()) {
    if (Date.parse(d.expiresAt) <= cutoff) designs.delete(id);
  }
  // If still too large, evict oldest
  if (designs.size <= MAX_ITEMS) return;

  const byCreated = Array.from(designs.values()).sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));
  const toDrop = Math.max(0, designs.size - MAX_ITEMS);
  for (let i = 0; i < toDrop; i++) {
    designs.delete(byCreated[i].id);
  }
}

export function putDesign(args: {
  id: string;
  prompt: string;
  provider: "mock" | "openai";
  createdAt: string;
  imageDataUrl: string;
}): StoredDesign {
  prune();

  const sizeBytes = approximateBytesFromDataUrl(args.imageDataUrl);
  if (sizeBytes > MAX_DATAURL_BYTES) {
    throw Object.assign(new Error(`Design exceeds max size (${sizeBytes} > ${MAX_DATAURL_BYTES})`), { status: 413 });
  }

  const mime = inferMime(args.imageDataUrl);
  const baseName = sanitizeFilename(args.prompt);
  const ext = mime.includes("svg") ? "svg" : mime.includes("png") ? "png" : mime.includes("jpeg") ? "jpg" : "bin";
  const hash = createHash("sha1").update(args.id).digest("hex").slice(0, 8);
  const filename = `${baseName}-${hash}.${ext}`;

  const expiresAt = new Date(nowMs() + TTL_MS).toISOString();
  const stored: StoredDesign = {
    id: args.id,
    prompt: args.prompt,
    provider: args.provider,
    createdAt: args.createdAt,
    imageDataUrl: args.imageDataUrl,
    mime,
    sizeBytes,
    filename,
    expiresAt
  };

  designs.set(args.id, stored);
  return stored;
}

export function getDesign(id: string): StoredDesign | null {
  prune();
  const d = designs.get(id) || null;
  if (!d) return null;
  if (Date.parse(d.expiresAt) <= nowMs()) {
    designs.delete(id);
    return null;
  }
  return d;
}

export function decodeDesignToBuffer(design: StoredDesign): Buffer {
  const idx = design.imageDataUrl.indexOf(",");
  if (idx < 0) return Buffer.from(design.imageDataUrl, "utf-8");
  const b64 = design.imageDataUrl.slice(idx + 1);
  return Buffer.from(b64, "base64");
}
