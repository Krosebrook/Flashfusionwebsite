import * as React from "react";
import type {
  AutomationRule,
  DesignAsset,
  Order,
  Product,
  ProductTemplate,
  PublishEvent,
  SeedPayload,
  StoreConnection
} from "@/types";
import { localDb, KEYS } from "@/storage/localDb";
import { ensureBootstrapped, removeAppKeys } from "@/storage/bootstrap";

export type BootState = {
  status: "loading" | "ready" | "error";
  usedNetworkSeed?: boolean;
  error?: string;
};

export type AppDataCtx = {
  boot: BootState;
  seed: SeedPayload | null;

  products: Product[];
  stores: StoreConnection[];
  templates: ProductTemplate[];
  orders: Order[];
  designs: DesignAsset[];
  events: PublishEvent[];
  automations: AutomationRule[];

  addProduct: (p: Product) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;

  addTemplate: (t: ProductTemplate) => void;

  addDesign: (d: DesignAsset) => void;
  addEvent: (e: PublishEvent) => void;
  addStore: (s: StoreConnection) => void;

  upsertAutomation: (a: AutomationRule) => void;
  deleteAutomation: (id: string) => void;

  resetData: () => Promise<void>;
  refreshSeedMeta: () => Promise<void>;
};

const noop = () => undefined;

const AppDataContext = React.createContext<AppDataCtx>({
  boot: { status: "loading" },
  seed: null,
  products: [],
  stores: [],
  templates: [],
  orders: [],
  designs: [],
  events: [],
  automations: [],
  addProduct: noop,
  updateProduct: noop,
  deleteProduct: noop,
  addTemplate: noop,
  addDesign: noop,
  addEvent: noop,
  addStore: noop,
  upsertAutomation: noop,
  deleteAutomation: noop,
  resetData: async () => undefined,
  refreshSeedMeta: async () => undefined
});

function loadAll() {
  const seed = localDb.get<SeedPayload | null>(KEYS.SEED, null);
  return {
    seed,
    products: localDb.get<Product[]>(KEYS.PRODUCTS, [] as Product[]),
    stores: localDb.get<StoreConnection[]>(KEYS.STORES, [] as StoreConnection[]),
    templates: localDb.get<ProductTemplate[]>(KEYS.TEMPLATES, [] as ProductTemplate[]),
    orders: localDb.get<Order[]>(KEYS.ORDERS, [] as Order[]),
    designs: localDb.get<DesignAsset[]>(KEYS.DESIGNS, [] as DesignAsset[]),
    events: localDb.get<PublishEvent[]>(KEYS.EVENTS, [] as PublishEvent[]),
    automations: localDb.get<AutomationRule[]>(KEYS.AUTOMATIONS, [] as AutomationRule[])
  };
}

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [{ seed, products, stores, templates, orders, designs, events, automations }, setState] = React.useState(() => loadAll());
  const [boot, setBoot] = React.useState<BootState>({ status: "loading" });

  const hydrateFromStorage = React.useCallback(() => {
    setState(loadAll());
  }, []);

  const bootstrap = React.useCallback(async () => {
    setBoot({ status: "loading" });
    try {
      const result = await ensureBootstrapped();
      hydrateFromStorage();
      setBoot({ status: "ready", usedNetworkSeed: result.usedNetworkSeed });
    } catch (e) {
      setBoot({ status: "error", error: e instanceof Error ? e.message : String(e) });
    }
  }, [hydrateFromStorage]);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const result = await ensureBootstrapped();
        if (!mounted) return;
        hydrateFromStorage();
        setBoot({ status: "ready", usedNetworkSeed: result.usedNetworkSeed });
      } catch (e) {
        if (!mounted) return;
        setBoot({ status: "error", error: e instanceof Error ? e.message : String(e) });
      }
    })();
    return () => { mounted = false; };
  }, [hydrateFromStorage]);

  // Persist to local storage (scoped keys only).
  React.useEffect(() => localDb.set(KEYS.PRODUCTS, products), [products]);
  React.useEffect(() => localDb.set(KEYS.STORES, stores), [stores]);
  React.useEffect(() => localDb.set(KEYS.TEMPLATES, templates), [templates]);
  React.useEffect(() => localDb.set(KEYS.ORDERS, orders), [orders]);
  React.useEffect(() => localDb.set(KEYS.DESIGNS, designs), [designs]);
  React.useEffect(() => localDb.set(KEYS.EVENTS, events), [events]);
  React.useEffect(() => localDb.set(KEYS.AUTOMATIONS, automations), [automations]);
  React.useEffect(() => { if (seed) localDb.set(KEYS.SEED, seed); }, [seed]);

  const addProduct = React.useCallback((p: Product) => setState((prev) => ({ ...prev, products: [p, ...prev.products] })), []);
  const updateProduct = React.useCallback((p: Product) => setState((prev) => ({ ...prev, products: prev.products.map((x) => (x.id === p.id ? p : x)) })), []);
  const deleteProduct = React.useCallback((id: string) => setState((prev) => ({ ...prev, products: prev.products.filter((x) => x.id !== id) })), []);

  const addTemplate = React.useCallback((t: ProductTemplate) => setState((prev) => ({ ...prev, templates: [t, ...prev.templates] })), []);
  const addDesign = React.useCallback((d: DesignAsset) => setState((prev) => ({ ...prev, designs: [d, ...prev.designs] })), []);
  const addEvent = React.useCallback((e: PublishEvent) => setState((prev) => ({ ...prev, events: [e, ...prev.events] })), []);
  const addStore = React.useCallback((s: StoreConnection) => setState((prev) => ({ ...prev, stores: [s, ...prev.stores] })), []);

  const upsertAutomation = React.useCallback((a: AutomationRule) => {
    setState((prev) => {
      const exists = prev.automations.some((x) => x.id === a.id);
      return {
        ...prev,
        automations: exists ? prev.automations.map((x) => (x.id === a.id ? a : x)) : [a, ...prev.automations]
      };
    });
  }, []);

  const deleteAutomation = React.useCallback((id: string) => {
    setState((prev) => ({ ...prev, automations: prev.automations.filter((x) => x.id !== id) }));
  }, []);

  const resetData = React.useCallback(async () => {
    removeAppKeys();
    await bootstrap();
  }, [bootstrap]);

  const refreshSeedMeta = React.useCallback(async () => {
    // Force a refresh of KEYS.SEED by re-running bootstrap without deleting user-created entities.
    // For now, this simply reboots if API is reachable; if not, it preserves current seed.
    await bootstrap();
  }, [bootstrap]);

  const value = React.useMemo<AppDataCtx>(
    () => ({
      boot,
      seed,
      products,
      stores,
      templates,
      orders,
      designs,
      events,
      automations,
      addProduct,
      updateProduct,
      deleteProduct,
      addTemplate,
      addDesign,
      addEvent,
      addStore,
      upsertAutomation,
      deleteAutomation,
      resetData,
      refreshSeedMeta
    }),
    [
      boot,
      seed,
      products,
      stores,
      templates,
      orders,
      designs,
      events,
      automations,
      addProduct,
      updateProduct,
      deleteProduct,
      addTemplate,
      addDesign,
      addEvent,
      addStore,
      upsertAutomation,
      deleteAutomation,
      resetData,
      refreshSeedMeta
    ]
  );

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  return React.useContext(AppDataContext);
}
