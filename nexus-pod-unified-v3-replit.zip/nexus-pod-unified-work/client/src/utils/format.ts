export function formatUsd(n: number): string {
  if (!Number.isFinite(n)) return "$0.00";
  return n.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

export function formatPercent(n: number, digits = 1): string {
  if (!Number.isFinite(n)) return "0%";
  return `${(n * 100).toFixed(digits)}%`;
}

export function formatDateShort(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  } catch {
    return iso;
  }
}

export function formatDayLabel(dateOnly: string): string {
  // dateOnly: YYYY-MM-DD
  try {
    const d = new Date(`${dateOnly}T00:00:00`);
    return d.toLocaleDateString(undefined, { weekday: "short" });
  } catch {
    return dateOnly;
  }
}

export function safeNumber(n: unknown, fallback = 0): number {
  const v = typeof n === "number" ? n : Number(n);
  return Number.isFinite(v) ? v : fallback;
}
