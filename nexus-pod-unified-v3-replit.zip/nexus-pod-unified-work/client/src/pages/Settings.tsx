import * as React from "react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useTheme } from "@/context/ThemeContext";
import { useAppData } from "@/context/AppDataContext";

export default function Settings() {
  const { isDark, toggle } = useTheme();
  const { resetData } = useAppData();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Local preferences and safety controls.</p>
      </div>

      <Card className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="font-semibold">Theme</div>
            <div className="text-sm text-slate-500 dark:text-slate-400">Toggle dark mode (stored locally).</div>
          </div>
          <Button variant="secondary" onClick={toggle}>{isDark ? "Dark" : "Light"}</Button>
        </div>

        <div className="border-t border-slate-200 dark:border-slate-800 pt-4 flex items-center justify-between gap-4">
          <div>
            <div className="font-semibold">Reset local data</div>
            <div className="text-sm text-slate-500 dark:text-slate-400">
              Clears only Nexus POD keys and re-seeds demo data. Does not wipe whole browser storage.
            </div>
          </div>
          <Button
            variant="danger"
            onClick={() => {
              const ok = confirm("Reset local app data? This will reload the page.");
              if (ok) resetData();
            }}
          >
            Reset database
          </Button>
        </div>
      </Card>
    </div>
  );
}
