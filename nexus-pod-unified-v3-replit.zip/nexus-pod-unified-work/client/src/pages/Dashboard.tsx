import { DollarSign, Package, ShoppingCart, TrendingUp } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { KpiCard } from "@/components/charts/KpiCard";
import { LineChartCard } from "@/components/charts/LineChartCard";
import { Card } from "@/components/ui/Card";
import { formatPercent, formatUsd } from "@/utils/format";
import { computeTopline, lastNDays } from "@/utils/kpi";

export default function Dashboard() {
  const { seed, products, orders } = useAppData();

  const topline = computeTopline(seed);
  const activeProducts = products.filter((p) => p.status === "PUBLISHED").length;
  const last7 = lastNDays(seed?.timeseries || [], 7).map((p) => ({ ...p, day: p.date.slice(5) }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <span className="text-sm text-slate-500">
          Seed: {seed?.generatedAt ? new Date(seed.generatedAt).toLocaleString() : "—"}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <KpiCard
          icon={DollarSign}
          label="Revenue (14d)"
          value={formatUsd(topline.totalRevenue)}
          subtext={`Ad spend: ${formatUsd(topline.totalAdSpend)}`}
        />
        <KpiCard
          icon={ShoppingCart}
          label="Orders (14d)"
          value={String(topline.totalOrders || orders.length)}
          subtext={`Sessions: ${topline.totalSessions.toLocaleString()}`}
        />
        <KpiCard
          icon={Package}
          label="Active Products"
          value={String(activeProducts)}
          subtext={`Total products: ${products.length}`}
        />
        <KpiCard
          icon={TrendingUp}
          label="Conversion (avg)"
          value={formatPercent(topline.avgConversionRate, 1)}
          subtext={`AOV: ${formatUsd(topline.avgAov)}`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LineChartCard
          title="Revenue (last 7 days)"
          data={last7}
          xKey="day"
          lines={[{ dataKey: "revenue", label: "Revenue" }, { dataKey: "adSpend", label: "Ad Spend" }]}
          yFormatter={(v) => formatUsd(Number(v))}
          height={400}
        />

        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-4">Recent Orders</h3>
          <div className="space-y-3">
            {orders.slice(0, 8).map((order) => (
              <div
                key={order.id}
                className="flex justify-between items-center p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950"
              >
                <div className="flex flex-col min-w-0">
                  <span className="font-medium truncate">{order.customerName}</span>
                  <span className="text-xs text-slate-500 truncate">{order.id}</span>
                </div>
                <div className="text-right">
                  <div className="font-bold">{formatUsd(order.total)}</div>
                  <span
                    className={
                      "text-xs px-2 py-0.5 rounded-full " +
                      (order.status === "DELIVERED"
                        ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200"
                        : order.status === "SHIPPED"
                          ? "bg-sky-50 text-sky-800 dark:bg-sky-950/30 dark:text-sky-200"
                          : "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200")
                    }
                  >
                    {order.status}
                  </span>
                </div>
              </div>
            ))}

            {orders.length === 0 && (
              <div className="text-sm text-slate-500 dark:text-slate-400">No orders yet.</div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
