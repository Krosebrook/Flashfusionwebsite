import * as React from "react";
import { useNavigate } from "react-router-dom";
import { ExternalLink, CheckCircle2, XCircle, RefreshCcw, PlayCircle } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useStatus } from "@/hooks/useStatus";
import { fetchReadiness } from "@/lib/api";
import type { ReadinessReport } from "@/types";

function BoolPill({ ok }: { ok: boolean }) {
  return ok ? (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
      <CheckCircle2 className="h-3 w-3" /> Connected
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200">
      <XCircle className="h-3 w-3" /> Not configured
    </span>
  );
}

export default function Stores() {
  const { status } = useStatus();
  const navigate = useNavigate();
  const [readiness, setReadiness] = React.useState<ReadinessReport | null>(null);
  const [loadingReadiness, setLoadingReadiness] = React.useState(true);
  const [runningProbes, setRunningProbes] = React.useState(false);
  const [readinessError, setReadinessError] = React.useState<string | null>(null);

  const loadReadiness = React.useCallback(async (runConnectivity: boolean) => {
    setReadinessError(null);
    try {
      const r = await fetchReadiness({ runConnectivity });
      setReadiness(r);
    } catch (e) {
      setReadinessError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoadingReadiness(false);
    }
  }, []);

  React.useEffect(() => {
    loadReadiness(false);
  }, [loadReadiness]);

  const openReplitSecrets = () => {
    alert(
      "On Replit: Tools → Secrets (Environment variables).\nAdd the required keys, then redeploy/restart."
    );
  };

  const runProbes = async () => {
    setRunningProbes(true);
    try {
      await loadReadiness(true);
    } finally {
      setRunningProbes(false);
    }
  };

  const probe = (key: string): { ok: boolean; detail?: string } | null => {
    const v = readiness?.connectivity?.[key];
    if (!v) return null;
    return { ok: Boolean(v.ok), detail: v.detail };
  };

  const CategoryChip = ({ title, score }: { title: string; score: number }) => (
    <span className="inline-flex items-center gap-2 text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
      <span className="font-medium">{title}</span>
      <span className={`px-1.5 py-0.5 rounded-full ${score >= 90 ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200" : score >= 70 ? "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200" : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200"}`}>{score}</span>
    </span>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Stores</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Publishing is handled by the backend (<code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">/api/publish-product</code>).
          Configure env vars to publish for real; otherwise Demo Mode returns a mocked response.
        </p>
      </div>

      <Card className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-semibold">Readiness snapshot</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Summary of configuration, best-practice warnings, and optional live probes.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => loadReadiness(false)} disabled={loadingReadiness || runningProbes}>
              <RefreshCcw className="h-4 w-4 mr-2" /> Refresh
            </Button>
            <Button onClick={runProbes} disabled={loadingReadiness || runningProbes}>
              <PlayCircle className="h-4 w-4 mr-2" /> {runningProbes ? "Running…" : "Run probes"}
            </Button>
            <Button variant="ghost" onClick={() => navigate("/readiness")}>
              Open full report
            </Button>
          </div>
        </div>

        {loadingReadiness ? (
          <div className="mt-4 text-sm text-slate-500 dark:text-slate-400">Loading readiness…</div>
        ) : readinessError ? (
          <div className="mt-4 text-sm text-rose-700 dark:text-rose-300">Readiness error: {readinessError}</div>
        ) : readiness ? (
          <>
            <div className="mt-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div>
                <div className="text-sm text-slate-600 dark:text-slate-300">
                  Mode: <strong>{readiness.mode}</strong> • Score: <strong>{readiness.score}/100</strong>
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Generated: {new Date(readiness.generatedAt).toLocaleString()}
                </div>
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-300">
                {readiness.missingEnvVars?.length ? (
                  <>
                    Missing: <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">{readiness.missingEnvVars.join(", ")}</code>
                  </>
                ) : (
                  <>No missing env vars detected.</>
                )}
              </div>
            </div>

            {readiness.warnings?.length ? (
              <div className="mt-3 text-xs text-slate-600 dark:text-slate-300">
                <div className="font-medium">Warnings</div>
                <ul className="list-disc pl-5 mt-1 space-y-1">
                  {readiness.warnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div className="mt-4 flex flex-wrap gap-2">
              {readiness.categories?.map((c) => (
                <CategoryChip key={c.id} title={c.title} score={c.score} />
              ))}
            </div>

            {readiness.connectivity ? (
              <div className="mt-4 grid md:grid-cols-4 gap-3">
                {Object.entries(readiness.connectivity).map(([k, v]) => (
                  <div key={k} className="rounded-lg border border-slate-200 dark:border-slate-800 p-3 bg-white dark:bg-slate-950">
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-sm">{k}</div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${v.ok ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200" : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200"}`}>{v.ok ? "OK" : "FAIL"}</span>
                    </div>
                    {v.detail ? <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 break-words">{v.detail}</div> : null}
                  </div>
                ))}
              </div>
            ) : null}
          </>
        ) : null}
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">Shopify</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: SHOPIFY_STORE_URL, SHOPIFY_ACCESS_TOKEN</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.shopify)} />
          </div>

          {probe("shopify") ? (
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Probe: {probe("shopify")!.ok ? <span className="text-emerald-700 dark:text-emerald-300">OK</span> : <span className="text-rose-700 dark:text-rose-300">FAIL</span>}
              {probe("shopify")!.detail ? <span className="text-slate-500 dark:text-slate-400"> — {probe("shopify")!.detail}</span> : null}
            </div>
          ) : null}

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Once configured, you can publish a product via the Publish panel in the app (or build a per-product “Publish” action).</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Use a private app / admin API token with least privilege.</li>
              <li>Never commit tokens; store them as env vars (Replit Secrets / Vercel env).</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://shopify.dev/docs/api", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>

        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">Etsy</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: ETSY_API_KEY (+ OAuth2), ETSY_ACCESS_TOKEN, ETSY_SHOP_ID</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.etsy)} />
          </div>

          {probe("etsy") ? (
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Probe: {probe("etsy")!.ok ? <span className="text-emerald-700 dark:text-emerald-300">OK</span> : <span className="text-rose-700 dark:text-rose-300">FAIL</span>}
              {probe("etsy")!.detail ? <span className="text-slate-500 dark:text-slate-400"> — {probe("etsy")!.detail}</span> : null}
            </div>
          ) : null}

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Etsy publishing requires OAuth and correct shop context. The backend connector is structured to “fail soft” into Demo Mode.</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Use short-lived tokens where possible; rotate regularly.</li>
              <li>Validate payload sizes; images are capped.</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://developers.etsy.com/", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>

        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">Printify</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: PRINTIFY_API_TOKEN (optional)</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.printify)} />
          </div>

          {probe("printify") ? (
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Probe: {probe("printify")!.ok ? <span className="text-emerald-700 dark:text-emerald-300">OK</span> : <span className="text-rose-700 dark:text-rose-300">FAIL</span>}
              {probe("printify")!.detail ? <span className="text-slate-500 dark:text-slate-400"> — {probe("printify")!.detail}</span> : null}
            </div>
          ) : null}

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Use Printify for catalog + fulfillment orchestration. Token missing → features stay in Demo Mode.</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Provide a stable User-Agent when calling the API.</li>
              <li>Keep tokens scoped and rotate regularly.</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://developers.printify.com/", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>

        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">WooCommerce</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: WOOCOMMERCE_STORE_URL, WOOCOMMERCE_CONSUMER_KEY, WOOCOMMERCE_CONSUMER_SECRET</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.woocommerce)} />
          </div>

          {probe("woocommerce") ? (
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Probe: {probe("woocommerce")!.ok ? <span className="text-emerald-700 dark:text-emerald-300">OK</span> : <span className="text-rose-700 dark:text-rose-300">FAIL</span>}
              {probe("woocommerce")!.detail ? <span className="text-slate-500 dark:text-slate-400"> — {probe("woocommerce")!.detail}</span> : null}
            </div>
          ) : null}

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Woo REST API publishing uses Basic Auth with consumer key/secret. Prefer HTTPS always.</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Never use http:// in production URLs.</li>
              <li>Use least-privilege keys and rotate.</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://woocommerce.com/document/woocommerce-rest-api/", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
