'use client';

import React, { useState, useEffect, useRef } from 'react';

interface Stat {
  value: string;
  label: string;
  suffix?: string;
  prefix?: string;
  description?: string;
}

interface StatsShowcaseProps {
  title?: string;
  subtitle?: string;
  stats: Stat[];
  layout?: 'horizontal' | 'grid' | 'centered';
  background?: 'light' | 'dark' | 'gradient' | 'primary';
  animated?: boolean;
}

/**
 * StatsShowcase - Quantifiable results/metrics display
 * 
 * Usage: 60% of high-converting SaaS sites use "by the numbers" sections.
 * Displays impressive metrics like user count, revenue growth, time saved.
 * 
 * @param title - Main heading
 * @param subtitle - Supporting description
 * @param stats - Array of statistics with value, label, and optional prefix/suffix
 * @param layout - Display arrangement: horizontal (single row), grid (2x2), centered (stacked)
 * @param background - Color scheme
 * @param animated - Count-up animation on scroll into view
 */
export default function StatsShowcase({
  title,
  subtitle,
  stats,
  layout = 'horizontal',
  background = 'light',
  animated = true,
}: StatsShowcaseProps) {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!animated) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [animated]);

  return (
    <div className={`stats-showcase bg-${background}`} ref={sectionRef}>
      <div className="stats-container">
        {(title || subtitle) && (
          <div className="stats-header">
            {title && <h2>{title}</h2>}
            {subtitle && <p className="subtitle">{subtitle}</p>}
          </div>
        )}

        <div className={`stats-grid layout-${layout}`}>
          {stats.map((stat, index) => (
            <div key={index} className={`stat-item ${isVisible ? 'visible' : ''}`}>
              <div className="stat-value">
                {stat.prefix && <span className="prefix">{stat.prefix}</span>}
                <span className="value">{stat.value}</span>
                {stat.suffix && <span className="suffix">{stat.suffix}</span>}
              </div>
              <div className="stat-label">{stat.label}</div>
              {stat.description && (
                <p className="stat-description">{stat.description}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .stats-showcase {
          padding: 80px 20px;
          position: relative;
        }

        /* Background Variants */
        .bg-light {
          background: white;
        }

        .bg-dark {
          background: var(--gray-900);
          color: white;
        }

        .bg-gradient {
          background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
          color: white;
        }

        .bg-primary {
          background: var(--primary);
          color: white;
        }

        .stats-container {
          max-width: 1200px;
          margin: 0 auto;
        }

        /* Header */
        .stats-header {
          text-align: center;
          margin-bottom: 60px;
        }

        .stats-header h2 {
          font-size: 2.5rem;
          font-weight: 700;
          margin-bottom: 16px;
        }

        .bg-dark .stats-header h2,
        .bg-gradient .stats-header h2,
        .bg-primary .stats-header h2 {
          color: white;
        }

        .subtitle {
          font-size: 1.25rem;
          opacity: 0.9;
          max-width: 700px;
          margin: 0 auto;
        }

        /* Layout Variants */
        .stats-grid.layout-horizontal {
          display: flex;
          justify-content: space-around;
          gap: 48px;
          flex-wrap: wrap;
        }

        .stats-grid.layout-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 48px;
        }

        .stats-grid.layout-centered {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 48px;
          max-width: 600px;
          margin: 0 auto;
        }

        /* Stat Items */
        .stat-item {
          text-align: center;
          opacity: 0;
          transform: translateY(30px);
          transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .stat-item.visible {
          opacity: 1;
          transform: translateY(0);
        }

        /* Staggered animation */
        .stat-item:nth-child(1).visible { transition-delay: 0.1s; }
        .stat-item:nth-child(2).visible { transition-delay: 0.2s; }
        .stat-item:nth-child(3).visible { transition-delay: 0.3s; }
        .stat-item:nth-child(4).visible { transition-delay: 0.4s; }
        .stat-item:nth-child(5).visible { transition-delay: 0.5s; }
        .stat-item:nth-child(6).visible { transition-delay: 0.6s; }

        .stat-value {
          font-size: 3.5rem;
          font-weight: 800;
          line-height: 1;
          margin-bottom: 16px;
          display: flex;
          align-items: baseline;
          justify-content: center;
          gap: 4px;
        }

        .bg-light .stat-value {
          color: var(--primary);
        }

        .bg-dark .stat-value,
        .bg-gradient .stat-value,
        .bg-primary .stat-value {
          color: white;
        }

        .prefix,
        .suffix {
          font-size: 2rem;
          font-weight: 700;
          opacity: 0.8;
        }

        .stat-label {
          font-size: 1.125rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          opacity: 0.9;
        }

        .bg-light .stat-label {
          color: var(--gray-700);
        }

        .stat-description {
          margin-top: 12px;
          font-size: 0.875rem;
          opacity: 0.8;
          line-height: 1.6;
          max-width: 300px;
          margin-left: auto;
          margin-right: auto;
        }

        /* Decorative Elements */
        .stats-showcase::before {
          content: '';
          position: absolute;
          top: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 60px;
          height: 4px;
          background: var(--primary);
          border-radius: 2px;
        }

        .bg-dark::before,
        .bg-gradient::before,
        .bg-primary::before {
          background: white;
          opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 1024px) {
          .stats-grid.layout-horizontal {
            gap: 40px;
          }

          .stat-value {
            font-size: 3rem;
          }

          .prefix,
          .suffix {
            font-size: 1.75rem;
          }
        }

        @media (max-width: 768px) {
          .stats-showcase {
            padding: 60px 20px;
          }

          .stats-header h2 {
            font-size: 2rem;
          }

          .subtitle {
            font-size: 1.125rem;
          }

          .stats-grid.layout-horizontal,
          .stats-grid.layout-grid {
            grid-template-columns: 1fr;
            gap: 32px;
          }

          .stat-value {
            font-size: 2.5rem;
          }

          .prefix,
          .suffix {
            font-size: 1.5rem;
          }

          .stat-label {
            font-size: 1rem;
          }

          .stat-description {
            font-size: 0.875rem;
          }
        }
      `}</style>
    </div>
  );
}
