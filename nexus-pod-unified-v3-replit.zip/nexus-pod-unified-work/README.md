# Nexus POD — Unified Central Hub (Full‑Stack + PWA)

This repo merges the **Nexus POD** full-stack API (Express + optional Supabase + commerce connectors) with a richer **Central Hub** UI (React Router + Tailwind + PWA) into a single portable monorepo.

## What you get

- **server/** (TypeScript, Express)
  - `/api/health`, `/api/status`
  - `/api/seed` (web-grounded seed payload used for first-run bootstrapping)
  - `/api/readiness` (configuration checks) and `/api/readiness?run=1` (connectivity probes)
  - `/api/generate-design` (OpenAI `gpt-image-1` if `OPENAI_API_KEY` is set; otherwise Demo Mode placeholder)
  - `/api/designs/:id/download` (server-backed downloads with correct headers)
  - `/api/publish-product` (Shopify/WooCommerce/Etsy/Printify connectors; fail-soft into Demo Mode)
- **client/** (React + Vite + PWA)
  - Dashboard, Analytics, Orders, Profit, Fulfillment
  - Products, Templates, Bulk Generator, Design Studio
  - Publishing Suite (bulk publish + local event log)
  - Automation Suite (manual-safe automations + CSV exports)
  - Stores, Readiness, Settings
  - Local demo persistence via `localStorage` (bootstrapped from `/api/seed`, with offline fallback)
  - Global **Demo Mode banner** driven by `/api/status`

## Requirements

- Node.js **20+**

## Run (dev)

Two terminals:

```bash
# terminal 1
npm install
npm -w server run dev
```

```bash
# terminal 2
npm -w client run dev
```

Client runs on Vite dev server and proxies `/api/*` to the server.

## Run (production / single deploy)

```bash
npm install
npm run build
npm start
```

## Env vars (optional)

Set these to enable real integrations. Missing keys do **not** crash the app.

### OpenAI (design generation)
- `OPENAI_API_KEY`
- `OPENAI_IMAGE_MODEL` (optional, default `gpt-image-1`)
- `OPENAI_IMAGE_SIZE` (optional, default `1024x1024`)

### Supabase (best-effort persistence)
- `SUPABASE_URL`
- `SUPABASE_KEY`

### Shopify
- `SHOPIFY_STORE_URL`
- `SHOPIFY_ACCESS_TOKEN`

Optional:
- `SHOPIFY_API_VERSION` (default: `2025-10`)
- `SHOPIFY_API_MODE` (default: `graphql`)

### Etsy
- `ETSY_API_KEY`

For OAuth2 (recommended):
- `ETSY_SHARED_SECRET`
- `ETSY_ACCESS_TOKEN`
- `ETSY_REFRESH_TOKEN`
- `ETSY_SHOP_ID`

Optional:
- `ETSY_API_BASE_URL` (default: `https://openapi.etsy.com`)

### Printify (optional)
- `PRINTIFY_API_TOKEN`
- `PRINTIFY_USER_AGENT` (default: `nexus-pod/1.0`)

### WooCommerce (optional)
- `WOOCOMMERCE_STORE_URL`
- `WOOCOMMERCE_CONSUMER_KEY`
- `WOOCOMMERCE_CONSUMER_SECRET`

### Ops tuning (optional)
- `RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_MS`
- `READINESS_CONNECT_TIMEOUT_MS`

### Observability (optional)
- `SENTRY_DSN`

## Smoke checks

With the server running:

```bash
npm run smoke
```

## Replit notes

- Put env vars in **Replit Secrets**
- Use **Build**: `npm run build`
- Use **Run**: `npm start`

License: MIT
