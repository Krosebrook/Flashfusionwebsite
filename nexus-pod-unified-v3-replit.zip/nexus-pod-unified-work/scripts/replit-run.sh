#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

export PORT="${PORT:-3000}"

echo "==> Nexus POD (Replit) boot"
echo "==> Node: $(node -v)"
echo "==> NPM : $(npm -v)"
echo "==> PORT: $PORT"

# Install deps if missing
if [[ ! -d "node_modules" ]]; then
  echo "==> Installing dependencies (npm install)..."
  npm install
else
  echo "==> Dependencies already present (node_modules/)."
fi

# Build if dist outputs are missing
NEED_BUILD=0
if [[ ! -f "server/dist/index.js" ]]; then
  NEED_BUILD=1
fi
if [[ ! -f "client/dist/index.html" ]]; then
  NEED_BUILD=1
fi

if [[ "${SKIP_BUILD:-0}" == "1" ]]; then
  echo "==> SKIP_BUILD=1; skipping build."
elif [[ "$NEED_BUILD" == "1" ]]; then
  echo "==> Building workspace (npm run build)..."
  npm run build
else
  echo "==> Build artifacts present; skipping build."
fi

echo "==> Starting production server..."
exec npm start
