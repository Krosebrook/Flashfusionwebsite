/**
 * Minimal smoke checks. Run with:
 *   npm run smoke
 *
 * This expects the server to be running on localhost.
 */
const port = process.env.PORT || "3000";
const base = process.env.SMOKE_BASE_URL || `http://localhost:${port}`;

async function fetchJson(url, init) {
  const res = await fetch(url, {
    ...init,
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      ...(init?.headers || {})
    }
  });
  const text = await res.text();
  let body = null;
  try { body = JSON.parse(text); } catch { body = text; }
  return { ok: res.ok, status: res.status, body };
}

async function main() {
  const results = [];

  // Basic health / status
  for (const ep of ["/api/health", "/api/status"]) {
    const url = new URL(ep, base).toString();
    const r = await fetchJson(url);
    results.push({ name: ep, ok: r.ok, status: r.status, body: r.body });
  }

  // Generate design (should always succeed; Demo Mode if OPENAI_API_KEY missing)
  {
    const url = new URL("/api/generate-design", base).toString();
    const r = await fetchJson(url, { method: "POST", body: JSON.stringify({ prompt: "smoke test design", style: "vector" }) });
    const ok = r.ok && r.body && typeof r.body.imageDataUrl === "string";
    results.push({ name: "/api/generate-design", ok, status: r.status, body: r.body });
  }

  // Publish product (should return demoMode true if keys missing, but should not crash)
  {
    const url = new URL("/api/publish-product", base).toString();
    const r = await fetchJson(url, {
      method: "POST",
      body: JSON.stringify({
        store: "shopify",
        product: { title: "Smoke Test Product", description: "smoke", price: 9.99, currency: "USD", tags: ["smoke"] }
      })
    });
    const ok = r.ok && r.body && typeof r.body.demoMode === "boolean";
    results.push({ name: "/api/publish-product", ok, status: r.status, body: r.body });
  }

  // Report
  console.log("\nSmoke results:");
  for (const r of results) {
    console.log(`- ${r.ok ? "✅" : "❌"} ${r.name} (HTTP ${r.status})`);
    if (!r.ok) console.log("  Body:", r.body);
  }

  const allOk = results.every((r) => r.ok);
  if (!allOk) {
    console.error("\nSmoke check failed. Ensure the server is running, then retry:");
    console.error("  npm run dev   (two terminals)  OR  npm run build && npm start");
    process.exit(1);
  }
}

main().catch((e) => {
  console.error("Smoke check crashed:", e);
  process.exit(1);
});
