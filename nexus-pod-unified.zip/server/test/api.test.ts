import { describe, it, expect, beforeEach } from "vitest";
import request from "supertest";
import { createApp } from "../src/app.js";

describe("API smoke", () => {
  beforeEach(() => {
    delete process.env.OPENAI_API_KEY;
  });

  it("GET /api/health", async () => {
    const app = createApp();
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("ok", true);
  });

  it("POST /api/generate-design returns mock without OPENAI_API_KEY", async () => {
    const app = createApp();
    const res = await request(app).post("/api/generate-design").send({ prompt: "test design" });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("provider", "mock");
    expect(res.body).toHaveProperty("imageDataUrl");
    expect(String(res.body.imageDataUrl)).toMatch(/^data:image\//);
  });

  it("GET /api/status returns demoMode when integrations missing", async () => {
    const app = createApp();
    const res = await request(app).get("/api/status");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("demoMode");
    expect(res.body).toHaveProperty("missing");
    expect(Array.isArray(res.body.missing)).toBe(true);
  });
});
