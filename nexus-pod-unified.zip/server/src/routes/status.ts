import { Router } from "express";
import { readEnv } from "../utils/env.js";
import { getSupabaseClient } from "../supabase.js";

export const statusRouter = Router();

statusRouter.get("/status", (_req, res) => {
  const hasOpenAI = Boolean(readEnv("OPENAI_API_KEY", { warnIfMissing: false }));
  const hasSupabase = Boolean(getSupabaseClient());
  const hasShopify = Boolean(readEnv("SHOPIFY_ACCESS_TOKEN", { warnIfMissing: false }) && readEnv("SHOPIFY_STORE_URL", { warnIfMissing: false }));
  const hasEtsy = Boolean(readEnv("ETSY_API_KEY", { warnIfMissing: false }) && readEnv("ETSY_ACCESS_TOKEN", { warnIfMissing: false }) && readEnv("ETSY_SHOP_ID", { warnIfMissing: false }));

  const missing: string[] = [];
  if (!hasOpenAI) missing.push("OPENAI_API_KEY");
  if (!hasSupabase) missing.push("SUPABASE_URL", "SUPABASE_KEY");
  if (!hasShopify) missing.push("SHOPIFY_STORE_URL", "SHOPIFY_ACCESS_TOKEN");
  if (!hasEtsy) missing.push("ETSY_API_KEY", "ETSY_ACCESS_TOKEN", "ETSY_SHOP_ID");

  res.json({
    ok: true,
    demoMode: missing.length > 0,
    integrations: {
      openai: hasOpenAI,
      supabase: hasSupabase,
      shopify: hasShopify,
      etsy: hasEtsy
    },
    missing: Array.from(new Set(missing))
  });
});
