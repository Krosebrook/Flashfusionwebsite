import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler.js";
import { readEnv } from "../utils/env.js";
import { StoreConnector } from "../connectors/StoreConnector.js";

export const publishProductRouter = Router();

const BodySchema = z.object({
  store: z.enum(["shopify", "etsy"]),
  product: z.object({
    title: z.string().min(1).max(140),
    description: z.string().max(5000).optional(),
    price: z.number().positive().optional(),
    currency: z.string().min(3).max(3).optional(),
    images: z.array(z.string().min(5)).max(10).optional(),
    tags: z.array(z.string().min(1).max(30)).max(25).optional()
  })
});

publishProductRouter.post("/publish-product", asyncHandler(async (req, res) => {
  const parsed = BodySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "invalid_request", details: parsed.error.flatten() });
    return;
  }

  const { store, product } = parsed.data;

  if (store === "shopify") {
    const connector = new StoreConnector({
      kind: "shopify",
      apiKey: readEnv("SHOPIFY_ACCESS_TOKEN"),
      storeUrl: readEnv("SHOPIFY_STORE_URL"),
      extra: {
        SHOPIFY_API_VERSION: readEnv("SHOPIFY_API_VERSION", { warnIfMissing: false }) || "2024-04"
      }
    });

    const result = await connector.publishProduct(product);
    res.json(result);
    return;
  }

  const connector = new StoreConnector({
    kind: "etsy",
    // Treat apiKey as access token for Etsy
    apiKey: readEnv("ETSY_ACCESS_TOKEN"),
    storeUrl: readEnv("ETSY_API_BASE_URL", { warnIfMissing: false }) || "https://openapi.etsy.com",
    extra: {
      ETSY_API_KEY: readEnv("ETSY_API_KEY"),
      ETSY_ACCESS_TOKEN: readEnv("ETSY_ACCESS_TOKEN"),
      ETSY_SHOP_ID: readEnv("ETSY_SHOP_ID")
    }
  });

  const result = await connector.publishProduct(product);
  res.json(result);
}));
