import { logger } from "../utils/logger.js";

export type StoreKind = "shopify" | "etsy";

export type PublishProductPayload = {
  title: string;
  description?: string;
  price?: number; // store currency units (e.g., USD dollars)
  currency?: string;
  images?: string[]; // data URLs or remote URLs
  tags?: string[];
};

export type PublishProductResult = {
  demoMode: boolean;
  store: StoreKind;
  externalId: string;
  url?: string;
  raw?: unknown;
  warning?: string;
};

export class StoreConnector {
  private apiKey?: string;
  private storeUrl?: string;
  private kind: StoreKind;
  private extra?: Record<string, string | undefined>;

  constructor(args: { apiKey?: string; storeUrl?: string; kind: StoreKind; extra?: Record<string, string | undefined> }) {
    this.apiKey = args.apiKey;
    this.storeUrl = args.storeUrl;
    this.kind = args.kind;
    this.extra = args.extra;
  }

  async publishProduct(payload: PublishProductPayload): Promise<PublishProductResult> {
    if (this.kind === "shopify") return this.publishShopify(payload);
    if (this.kind === "etsy") return this.publishEtsy(payload);
    // Exhaustive guard
    const neverKind: never = this.kind;
    throw new Error(`Unsupported store kind: ${neverKind}`);
  }

  private async publishShopify(payload: PublishProductPayload): Promise<PublishProductResult> {
    const token = this.apiKey;
    const storeUrl = normalizeHttpsUrl(this.storeUrl);

    if (!token) {
      return demoResult("shopify", "Missing Env Var: SHOPIFY_ACCESS_TOKEN");
    }
    if (!storeUrl) {
      return demoResult("shopify", "Missing Env Var: SHOPIFY_STORE_URL");
    }

    const apiVersion = (this.extra?.SHOPIFY_API_VERSION || "2024-04").trim();
    const endpoint = `${storeUrl}/admin/api/${apiVersion}/products.json`;

    const images = (payload.images || []).map((img) => {
      const data = parseDataUrl(img);
      if (data?.mime?.startsWith("image/") && data.base64) {
        // Shopify REST supports base64 attachments
        return { attachment: data.base64, filename: "nexus-pod.png" };
      }
      if (img.startsWith("http://") || img.startsWith("https://")) {
        return { src: img };
      }
      return undefined;
    }).filter(Boolean) as any[];

    const bodyHtml = payload.description ? payload.description : "Generated with Nexus POD";
    const price = typeof payload.price === "number" ? payload.price.toFixed(2) : "19.99";

    const product = {
      product: {
        title: payload.title,
        body_html: bodyHtml,
        vendor: "Nexus POD",
        product_type: "Print-on-Demand",
        tags: (payload.tags || []).join(", "),
        variants: [{ price }],
        images
      }
    };

    const res = await fetchJson(endpoint, {
      method: "POST",
      headers: {
        "X-Shopify-Access-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(product)
    });

    const externalId = String(res?.product?.id ?? "unknown");
    const url = res?.product?.admin_graphql_api_id
      ? `${storeUrl}/admin/products/${externalId}`
      : `${storeUrl}/admin/products/${externalId}`;

    return { demoMode: false, store: "shopify", externalId, url, raw: res };
  }

  private async publishEtsy(payload: PublishProductPayload): Promise<PublishProductResult> {
    // NOTE: Etsy publishing is OAuth2-driven. This implementation is a best-effort example and is demo-first.
    const accessToken = this.apiKey || this.extra?.ETSY_ACCESS_TOKEN;
    const clientId = this.extra?.ETSY_API_KEY; // Etsy uses client_id / x-api-key with OAuth.
    const shopId = this.extra?.ETSY_SHOP_ID;

    if (!clientId) return demoResult("etsy", "Missing Env Var: ETSY_API_KEY");
    if (!accessToken) return demoResult("etsy", "Missing Env Var: ETSY_ACCESS_TOKEN");
    if (!shopId) return demoResult("etsy", "Missing Env Var: ETSY_SHOP_ID");

    const base = normalizeHttpsUrl(this.storeUrl) || "https://openapi.etsy.com";

    // Create listing (fields are often required by Etsy; defaults may need adjustment).
    // If Etsy rejects the request, we fail soft and return demo response with a warning.
    try {
      const listing = await fetchJson(`${base}/v3/application/shops/${encodeURIComponent(shopId)}/listings`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "x-api-key": clientId,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          title: payload.title,
          description: payload.description || "Generated with Nexus POD",
          price: typeof payload.price === "number" ? payload.price : 19.99,
          quantity: 999,
          who_made: "i_did",
          when_made: "made_to_order",
          taxonomy_id: 1,
          is_supply: false,
          should_auto_renew: true
        })
      });

      const externalId = String(listing?.listing_id ?? listing?.id ?? "unknown");
      const url = externalId !== "unknown" ? `https://www.etsy.com/listing/${externalId}` : undefined;

      // Image upload is a separate endpoint in Etsy; omitted here to keep this safe/portable.
      // You can extend this by calling:
      // POST /v3/application/shops/{shop_id}/listings/{listing_id}/images
      // with multipart/form-data.

      return { demoMode: false, store: "etsy", externalId, url, raw: listing, warning: "Etsy images upload not implemented in this starter." };
    } catch (err) {
      logger.warn("Etsy publish failed; returning Demo Mode response.", String(err));
      return demoResult("etsy", "Etsy publish failed; check OAuth scopes + required fields.");
    }
  }
}

function demoResult(store: StoreKind, warning: string): PublishProductResult {
  return {
    demoMode: true,
    store,
    externalId: `demo_${store}_${Date.now()}`,
    url: undefined,
    warning
  };
}

function normalizeHttpsUrl(url?: string): string | undefined {
  if (!url) return undefined;
  const trimmed = url.trim();
  if (!trimmed) return undefined;
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed.replace(/\/$/, "");
  return `https://${trimmed.replace(/\/$/, "")}`;
}

function parseDataUrl(input: string): { mime: string; base64: string } | null {
  if (!input.startsWith("data:")) return null;
  const match = input.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  return { mime: match[1]!, base64: match[2]! };
}

async function fetchJson(url: string, init: RequestInit): Promise<any> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);

  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const text = await res.text();
    const contentType = res.headers.get("content-type") || "";

    if (!res.ok) {
      throw Object.assign(new Error(`HTTP ${res.status} ${res.statusText}: ${text.slice(0, 500)}`), { status: res.status });
    }

    if (contentType.includes("application/json")) return JSON.parse(text);
    // Some APIs may return JSON with a different content-type; try parse.
    try {
      return JSON.parse(text);
    } catch {
      return { raw: text };
    }
  } finally {
    clearTimeout(timeout);
  }
}
