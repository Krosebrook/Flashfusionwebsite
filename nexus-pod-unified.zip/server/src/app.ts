import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import morgan from "morgan";
import { applySecurityMiddleware } from "./middleware/security.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { healthRouter } from "./routes/health.js";
import { statusRouter } from "./routes/status.js";
import { generateDesignRouter } from "./routes/generateDesign.js";
import { publishProductRouter } from "./routes/publishProduct.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createApp() {
  const app = express();

  applySecurityMiddleware(app);
  app.use(morgan("tiny"));

  app.use(express.json({ limit: "8mb" }));

  app.get("/api", (_req, res) => {
    res.json({ ok: true, name: "nexus-pod-api" });
  });

  app.use("/api", healthRouter);
  app.use("/api", statusRouter);
  app.use("/api", generateDesignRouter);
  app.use("/api", publishProductRouter);

  // Serve built client in production (single deployable server).
  // Vite outputs to client/dist by default.
  if (process.env.NODE_ENV === "production") {
    const clientDist = path.resolve(__dirname, "../../client/dist");
    app.use(express.static(clientDist, { maxAge: "1h", etag: true }));

    // SPA fallback
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api")) return next();
      res.sendFile(path.join(clientDist, "index.html"));
    });
  }

  app.use(errorHandler);

  return app;
}
