import { logger } from "./logger.js";

export type EnvReadOptions = {
  /** If true, logs a warning when missing. Defaults to true. */
  warnIfMissing?: boolean;
  /** Optional alias name for friendlier warnings. */
  displayName?: string;
};

export function readEnv(name: string, opts: EnvReadOptions = {}): string | undefined {
  const value = process.env[name];
  const warn = opts.warnIfMissing !== false;
  if (!value && warn) {
    const label = opts.displayName || name;
    logger.warnOnce(`env:${name}`, `Missing Env Var: ${label}`);
  }
  return value || undefined;
}

export function readEnvBool(name: string, defaultValue = false): boolean {
  const v = readEnv(name, { warnIfMissing: false });
  if (!v) return defaultValue;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
}
