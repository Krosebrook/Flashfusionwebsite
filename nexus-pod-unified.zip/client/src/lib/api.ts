export type StatusResponse = {
  ok: boolean;
  demoMode: boolean;
  integrations: {
    openai: boolean;
    supabase: boolean;
    shopify: boolean;
    etsy: boolean;
  };
  missing: string[];
};

export type GenerateDesignRequest = {
  prompt: string;
  style?: string;
};

export type GenerateDesignResponse = {
  id: string;
  prompt: string;
  provider: "mock" | "openai";
  imageDataUrl: string;
  createdAt: string;
  demoMode: boolean;
};

export type PublishProductRequest = {
  store: "shopify" | "etsy";
  product: {
    title: string;
    description?: string;
    price?: number;
    currency?: string;
    images?: string[];
    tags?: string[];
  };
};

export type PublishProductResponse = {
  demoMode: boolean;
  store: "shopify" | "etsy";
  externalId: string;
  url?: string;
  warning?: string;
};

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      "content-type": "application/json",
      "accept": "application/json",
      ...(init?.headers || {})
    }
  });

  const text = await res.text();
  const data = text ? safeJson(text) : null;

  if (!res.ok) {
    const msg = (data && (data as any).message) ? String((data as any).message) : `${res.status} ${res.statusText}`;
    throw new Error(msg);
  }

  return data as T;
}

function safeJson(text: string): unknown {
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

export function getApiBase(): string {
  // In dev, Vite proxy handles /api.
  // In prod, Express serves the built client and API at same origin.
  return "";
}

export async function fetchStatus(): Promise<StatusResponse> {
  return fetchJson<StatusResponse>(`${getApiBase()}/api/status`, { method: "GET" });
}

export async function generateDesign(req: GenerateDesignRequest): Promise<GenerateDesignResponse> {
  return fetchJson<GenerateDesignResponse>(`${getApiBase()}/api/generate-design`, {
    method: "POST",
    body: JSON.stringify(req)
  });
}

export async function publishProduct(req: PublishProductRequest): Promise<PublishProductResponse> {
  return fetchJson<PublishProductResponse>(`${getApiBase()}/api/publish-product`, {
    method: "POST",
    body: JSON.stringify(req)
  });
}
