import * as React from "react";
import { ExternalLink, CheckCircle2, XCircle } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useStatus } from "@/hooks/useStatus";

function BoolPill({ ok }: { ok: boolean }) {
  return ok ? (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
      <CheckCircle2 className="h-3 w-3" /> Connected
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-200">
      <XCircle className="h-3 w-3" /> Not configured
    </span>
  );
}

export default function Stores() {
  const { status } = useStatus();

  const openReplitSecrets = () => {
    alert(
      "On Replit: Tools → Secrets (Environment variables).\nAdd the required keys, then redeploy/restart."
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Stores</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Publishing is handled by the backend (<code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">/api/publish-product</code>).
          Configure env vars to publish for real; otherwise Demo Mode returns a mocked response.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">Shopify</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: SHOPIFY_STORE_URL, SHOPIFY_ACCESS_TOKEN</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.shopify)} />
          </div>

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Once configured, you can publish a product via the Publish panel in the app (or build a per-product “Publish” action).</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Use a private app / admin API token with least privilege.</li>
              <li>Never commit tokens; store them as env vars (Replit Secrets / Vercel env).</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://shopify.dev/docs/api", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>

        <Card className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold">Etsy</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Requires: ETSY_API_KEY, ETSY_ACCESS_TOKEN, ETSY_SHOP_ID</p>
            </div>
            <BoolPill ok={Boolean(status?.integrations.etsy)} />
          </div>

          <div className="text-sm text-slate-600 dark:text-slate-300">
            <p className="mb-2">Etsy publishing requires OAuth and correct shop context. The backend connector is structured to “fail soft” into Demo Mode.</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Use short-lived tokens where possible; rotate regularly.</li>
              <li>Validate payload sizes; images are capped.</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button variant="secondary" onClick={openReplitSecrets}>Configure env vars</Button>
            <Button variant="ghost" onClick={() => window.open("https://developers.etsy.com/", "_blank", "noreferrer")}>
              Docs <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="font-semibold">Quick status</h3>
        <div className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          <div>OpenAI: <BoolPill ok={Boolean(status?.integrations.openai)} /></div>
          <div className="mt-1">Supabase: <BoolPill ok={Boolean(status?.integrations.supabase)} /></div>
          {status?.missing?.length ? (
            <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              Missing: <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">{status.missing.join(", ")}</code>
            </p>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
