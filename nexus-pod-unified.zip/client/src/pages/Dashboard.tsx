import { useAppData } from '@/context/AppDataContext';
import { Card } from '@/components/ui/Card';
import { DollarSign, Package, ShoppingCart, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const { products, orders } = useAppData();
  
  const totalRevenue = orders.reduce((acc, o) => acc + o.total, 0);
  const activeProducts = products.filter(p => p.status === 'PUBLISHED').length;
  
  // Mock Data for chart
  const data = [
    { name: 'Mon', sales: 400 },
    { name: 'Tue', sales: 300 },
    { name: 'Wed', sales: 600 },
    { name: 'Thu', sales: 200 },
    { name: 'Fri', sales: 900 },
    { name: 'Sat', sales: 1200 },
    { name: 'Sun', sales: 800 },
  ];

  const StatCard = ({ icon: Icon, label, value, color }: any) => (
    <Card className="flex items-center gap-4">
      <div className={`p-3 rounded-xl ${color}`}><Icon size={24} /></div>
      <div>
        <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
        <p className="text-2xl font-bold dark:text-white">{value}</p>
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <span className="text-sm text-slate-500">Last updated: Just now</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard icon={DollarSign} label="Total Revenue" value={`$${totalRevenue.toLocaleString()}`} color="bg-green-100 text-green-600 dark:bg-green-900/30" />
        <StatCard icon={ShoppingCart} label="Total Orders" value={orders.length} color="bg-blue-100 text-blue-600 dark:bg-blue-900/30" />
        <StatCard icon={Package} label="Active Products" value={activeProducts} color="bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30" />
        <StatCard icon={TrendingUp} label="Conversion Rate" value="3.2%" color="bg-orange-100 text-orange-600 dark:bg-orange-900/30" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="h-[400px]">
          <h3 className="text-lg font-semibold mb-6">Revenue Overview</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
              <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
              <Bar dataKey="sales" fill="#4f46e5" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold mb-4">Recent Orders</h3>
          <div className="space-y-4">
            {orders.slice(0, 5).map(order => (
              <div key={order.id} className="flex justify-between items-center p-3 hover:bg-slate-50 dark:hover:bg-slate-900 rounded-lg transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-800">
                <div className="flex flex-col">
                  <span className="font-medium">{order.customerName}</span>
                  <span className="text-xs text-slate-500">{order.id}</span>
                </div>
                <div className="text-right">
                  <div className="font-bold">${order.total}</div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${order.status === 'DELIVERED' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}