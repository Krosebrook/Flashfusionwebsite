import * as React from "react";
import toast from "react-hot-toast";
import { Loader2, Wand2 } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { uuid } from "@/utils/id";
import type { Product } from "@/types";

export default function BulkGenerator() {
  const { templates, addProduct } = useAppData();
  const [loading, setLoading] = React.useState(false);
  const [prompt, setPrompt] = React.useState("");
  const [selectedTemplateId, setSelectedTemplateId] = React.useState<string>("");
  const [count, setCount] = React.useState(5);

  const selectedTemplate = React.useMemo(
    () => templates.find((t) => t.id === selectedTemplateId) ?? null,
    [templates, selectedTemplateId]
  );

  const handleGenerate = async () => {
    if (!selectedTemplate) {
      toast.error("Pick a template first.");
      return;
    }

    const basePrompt = prompt.trim();
    if (!basePrompt) {
      toast.error("Add a prompt / theme first.");
      return;
    }

    setLoading(true);

    try {
      // Soft delay to make the UI feel intentional and to mimic long-running generation.
      await new Promise((r) => setTimeout(r, 700));

      const now = new Date();
      for (let i = 0; i < count; i++) {
        const p: Product = {
          id: uuid(),
          title: `${basePrompt} — Variant ${i + 1}`,
          description: `Generated from template: ${selectedTemplate.name}`,
          productType: selectedTemplate.baseProductType,
          price: selectedTemplate.defaultPrice,
          cost: selectedTemplate.defaultCost,
          status: "DRAFT",
          designAssetId: null,
          storeId: null,
          tags: Array.from(new Set([...(selectedTemplate.defaultTags || []), "bulk"])),
          variants: [],
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        };

        addProduct(p);
      }

      toast.success(`Generated ${count} products.`);
      setPrompt("");
    } catch (e) {
      toast.error("Bulk generation failed.");
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Bulk Generator</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Generate many draft products quickly (Demo mode uses local generation; publishing happens in Stores).
        </p>
      </div>

      <Card className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">1. Pick a template</label>
          <select
            value={selectedTemplateId}
            onChange={(e) => setSelectedTemplateId(e.target.value)}
            className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
          >
            <option value="">Select…</option>
            {templates.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">2. Prompt / theme</label>
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g., 'Neon mountain sunset quote'"
            className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-sm outline-none"
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">3. Quantity</label>
          <input
            type="range"
            min={1}
            max={50}
            value={count}
            onChange={(e) => setCount(parseInt(e.target.value, 10))}
            className="w-full accent-indigo-600"
          />
          <div className="text-right text-sm text-slate-500 dark:text-slate-400">{count} items</div>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-4"
        >
          {loading ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : <Wand2 className="mr-2 h-4 w-4" />}
          {loading ? "Generating…" : "Generate products"}
        </Button>
      </Card>
    </div>
  );
}
