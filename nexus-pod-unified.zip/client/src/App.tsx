import * as React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

import Layout from "@/components/layout/Layout";
import Dashboard from "@/pages/Dashboard";
import Products from "@/pages/Products";
import BulkGenerator from "@/pages/BulkGenerator";
import Templates from "@/pages/Templates";
import DesignStudio from "@/pages/DesignStudio";
import Stores from "@/pages/Stores";
import Settings from "@/pages/Settings";

import { ThemeProvider } from "@/context/ThemeContext";
import { AppDataProvider } from "@/context/AppDataContext";

export default function App() {
  // One-time hint (safe, no PII)
  React.useEffect(() => {
    toast.dismiss();
  }, []);

  return (
    <ThemeProvider>
      <AppDataProvider>
        <Toaster position="top-right" />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/products" element={<Products />} />
            <Route path="/bulk-generator" element={<BulkGenerator />} />
            <Route path="/templates" element={<Templates />} />
            <Route path="/design-studio" element={<DesignStudio />} />
            <Route path="/stores" element={<Stores />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Route>
        </Routes>
      </AppDataProvider>
    </ThemeProvider>
  );
}
