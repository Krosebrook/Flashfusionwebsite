import { uuid } from '@/utils/id';

export const KEYS = {
  PRODUCTS: 'pod_products',
  STORES: 'pod_stores',
  DESIGNS: 'pod_designs',
  EVENTS: 'pod_events',
  TEMPLATES: 'pod_templates',
  ORDERS: 'pod_orders',
  THEME: 'pod_theme',
  SCHEMA: 'pod_schema_v1'
};

export const localDb = {
  get: <T>(key: string, defaultVal: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultVal;
    } catch (e) {
      console.error('Storage Read Error', e);
      return defaultVal;
    }
  },
  set: <T>(key: string, value: T): void => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage Write Error', e);
    }
  },
  clear: () => {
    localStorage.clear();
    window.location.reload();
  }
};