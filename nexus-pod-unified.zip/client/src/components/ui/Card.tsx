import type * as React from "react";
import { twMerge } from "tailwind-merge";

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={twMerge(
        "bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6",
        className
      )}
    >
      {children}
    </div>
  );
}
