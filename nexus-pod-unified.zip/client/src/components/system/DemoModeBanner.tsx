import * as React from "react";
import type { StatusResponse } from "@/lib/api";

export function DemoModeBanner(props: { status: StatusResponse | null; error?: string | null }) {
  const { status, error } = props;

  if (error) {
    return (
      <div className="w-full rounded-xl border border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-100 px-4 py-3 text-sm">
        <strong>API not reachable.</strong> {error}{" "}
        <span className="opacity-80">
          Start the server with <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">npm run dev</code> or{" "}
          <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">npm start</code>.
        </span>
      </div>
    );
  }

  if (!status) return null;

  if (!status.demoMode) {
    return (
      <div className="w-full rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-900 dark:border-indigo-900/40 dark:bg-indigo-950/30 dark:text-indigo-100 px-4 py-3 text-sm">
        <strong>All integrations configured.</strong> You’re live (not in Demo Mode).
      </div>
    );
  }

  return (
    <div className="w-full rounded-xl border border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-100 px-4 py-3 text-sm">
      <strong>Demo Mode active.</strong>{" "}
      Missing env vars:{" "}
      <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">{status.missing.join(", ")}</code>. The app still runs, but uses mock flows.
    </div>
  );
}
