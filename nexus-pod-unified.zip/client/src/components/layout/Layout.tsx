import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import { useStatus } from "@/hooks/useStatus";
import { DemoModeBanner } from "@/components/system/DemoModeBanner";

export default function Layout() {
  const { status, error } = useStatus();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-black text-slate-900 dark:text-slate-100 font-sans">
      <Sidebar />
      <main className="ml-64 p-8 min-h-screen">
        <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-500">
          <DemoModeBanner status={status} error={error} />
          <Outlet />
        </div>
      </main>
    </div>
  );
}
