export type ProductStatus = 'DRAFT' | 'READY' | 'PUBLISHED';
export type ProductType = 'T_SHIRT' | 'HOODIE' | 'MUG';

export interface ProductVariant {
  size: string;
  color: string;
  sku: string;
  inventory: number;
}

export interface Product {
  id: string;
  title: string;
  description?: string;
  productType: ProductType;
  price: number;
  cost: number;
  status: ProductStatus;
  designAssetId: string | null;
  storeId: string | null;
  tags: string[];
  variants: ProductVariant[];
  createdAt: string;
  updatedAt: string;
}

export interface StoreConnection {
  id: string;
  platform: string;
  storeName: string;
  apiKeyMasked: string;
  connectedAt: string;
  status: 'CONNECTED' | 'DISCONNECTED';
}

export interface DesignAsset {
  id: string;
  name: string;
  prompt: string;
  imageDataUrl: string; // Base64 or local path
  createdAt: string;
}

export interface PublishEvent {
  id: string;
  productId: string;
  storeId: string;
  status: 'SUCCESS' | 'FAILED';
  publishedAt: string;
  notes?: string;
}

export interface ProductTemplate {
  id: string;
  name: string;
  baseProductType: ProductType;
  defaultPrice: number;
  defaultCost: number;
  defaultTags: string[];
  createdAt: string;
}

export interface Order {
  id: string;
  customerName: string;
  total: number;
  status: 'PENDING' | 'SHIPPED' | 'DELIVERED';
  items: { productId: string; quantity: number }[];
  createdAt: string;
}