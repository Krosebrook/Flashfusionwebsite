import type * as React from "react";
import { createContext, useContext, useEffect, useState } from "react";
import { localDb, KEYS } from "@/storage/localDb";

const ThemeContext = createContext({ isDark: false, toggle: () => {} });

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [isDark, setIsDark] = useState(() => localDb.get(KEYS.THEME, true)); // default dark

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) root.classList.add("dark");
    else root.classList.remove("dark");
    localDb.set(KEYS.THEME, isDark);
  }, [isDark]);

  return <ThemeContext.Provider value={{ isDark, toggle: () => setIsDark((v) => !v) }}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => useContext(ThemeContext);
