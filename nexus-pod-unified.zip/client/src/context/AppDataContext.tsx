import * as React from "react";
import type { DesignAsset, Order, Product, ProductTemplate, PublishEvent, StoreConnection } from "@/types";
import { localDb, KEYS } from "@/storage/localDb";
import { initializeApp } from "@/storage/initialize";

initializeApp();

export type AppDataCtx = {
  products: Product[];
  stores: StoreConnection[];
  templates: ProductTemplate[];
  orders: Order[];
  designs: DesignAsset[];
  events: PublishEvent[];

  addProduct: (p: Product) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;

  addTemplate: (t: ProductTemplate) => void;

  addDesign: (d: DesignAsset) => void;
  addEvent: (e: PublishEvent) => void;
  addStore: (s: StoreConnection) => void;

  resetData: () => void;
};

const noop = () => undefined;

const AppDataContext = React.createContext<AppDataCtx>({
  products: [],
  stores: [],
  templates: [],
  orders: [],
  designs: [],
  events: [],
  addProduct: noop,
  updateProduct: noop,
  deleteProduct: noop,
  addTemplate: noop,
  addDesign: noop,
  addEvent: noop,
  addStore: noop,
  resetData: noop
});

function removeAppKeys() {
  for (const key of Object.values(KEYS)) {
    try {
      localStorage.removeItem(key);
    } catch {
      // ignore
    }
  }
}

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = React.useState<Product[]>(() => localDb.get(KEYS.PRODUCTS, [] as Product[]));
  const [stores, setStores] = React.useState<StoreConnection[]>(() => localDb.get(KEYS.STORES, [] as StoreConnection[]));
  const [templates, setTemplates] = React.useState<ProductTemplate[]>(() => localDb.get(KEYS.TEMPLATES, [] as ProductTemplate[]));
  const [orders, setOrders] = React.useState<Order[]>(() => localDb.get(KEYS.ORDERS, [] as Order[]));
  const [designs, setDesigns] = React.useState<DesignAsset[]>(() => localDb.get(KEYS.DESIGNS, [] as DesignAsset[]));
  const [events, setEvents] = React.useState<PublishEvent[]>(() => localDb.get(KEYS.EVENTS, [] as PublishEvent[]));

  // Persist to local storage (best-effort).
  React.useEffect(() => localDb.set(KEYS.PRODUCTS, products), [products]);
  React.useEffect(() => localDb.set(KEYS.STORES, stores), [stores]);
  React.useEffect(() => localDb.set(KEYS.TEMPLATES, templates), [templates]);
  React.useEffect(() => localDb.set(KEYS.ORDERS, orders), [orders]);
  React.useEffect(() => localDb.set(KEYS.DESIGNS, designs), [designs]);
  React.useEffect(() => localDb.set(KEYS.EVENTS, events), [events]);

  const addProduct = React.useCallback((p: Product) => setProducts((prev) => [p, ...prev]), []);
  const updateProduct = React.useCallback((p: Product) => setProducts((prev) => prev.map((x) => (x.id === p.id ? p : x))), []);
  const deleteProduct = React.useCallback((id: string) => setProducts((prev) => prev.filter((x) => x.id !== id)), []);

  const addTemplate = React.useCallback((t: ProductTemplate) => setTemplates((prev) => [t, ...prev]), []);
  const addDesign = React.useCallback((d: DesignAsset) => setDesigns((prev) => [d, ...prev]), []);
  const addEvent = React.useCallback((e: PublishEvent) => setEvents((prev) => [e, ...prev]), []);
  const addStore = React.useCallback((s: StoreConnection) => setStores((prev) => [s, ...prev]), []);

  const resetData = React.useCallback(() => {
    removeAppKeys();
    // Re-seed and hard refresh to guarantee consistent state across all hooks.
    initializeApp();
    window.location.reload();
  }, []);

  const value = React.useMemo<AppDataCtx>(
    () => ({
      products,
      stores,
      templates,
      orders,
      designs,
      events,
      addProduct,
      updateProduct,
      deleteProduct,
      addTemplate,
      addDesign,
      addEvent,
      addStore,
      resetData
    }),
    [products, stores, templates, orders, designs, events, addProduct, updateProduct, deleteProduct, addTemplate, addDesign, addEvent, addStore, resetData]
  );

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  return React.useContext(AppDataContext);
}
