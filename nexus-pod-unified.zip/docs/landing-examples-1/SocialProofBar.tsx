'use client';

import React from 'react';

interface Logo {
  name: string;
  imageUrl?: string;
  darkImageUrl?: string; // Optional dark mode version
}

interface SocialProofBarProps {
  title?: string;
  logos: Logo[];
  variant?: 'scroll' | 'grid' | 'fade';
  speed?: 'slow' | 'medium' | 'fast';
  grayscale?: boolean;
  itemsPerView?: number;
}

/**
 * SocialProofBar - Customer logo showcase component
 * 
 * Usage: 85% of high-converting SaaS sites display customer logos.
 * Shows trust and credibility through recognizable brands.
 * 
 * @param title - Optional heading text (e.g., "Trusted by 10,000+ companies")
 * @param logos - Array of customer logos with names and image URLs
 * @param variant - Display style: scroll (auto-scroll), grid (static grid), fade (fade in/out)
 * @param speed - Animation speed for scroll variant
 * @param grayscale - Convert logos to grayscale (90% of sites do this for cohesion)
 * @param itemsPerView - Number of logos visible at once (default: 6)
 */
export default function SocialProofBar({
  title = 'Trusted by leading companies',
  logos,
  variant = 'scroll',
  speed = 'medium',
  grayscale = true,
  itemsPerView = 6,
}: SocialProofBarProps) {
  const speedValues = {
    slow: '60s',
    medium: '40s',
    fast: '20s',
  };

  // Duplicate logos for seamless scrolling
  const duplicatedLogos = variant === 'scroll' ? [...logos, ...logos] : logos;

  return (
    <div className="social-proof-bar">
      {title && (
        <div className="proof-header">
          <p className="title">{title}</p>
        </div>
      )}

      <div className={`logo-container variant-${variant}`}>
        <div className="logo-track">
          {duplicatedLogos.map((logo, index) => (
            <div key={`${logo.name}-${index}`} className="logo-item">
              {logo.imageUrl ? (
                <img
                  src={logo.imageUrl}
                  alt={logo.name}
                  loading="lazy"
                  className={grayscale ? 'grayscale' : ''}
                />
              ) : (
                <div className="logo-placeholder">
                  <span>{logo.name}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .social-proof-bar {
          padding: 40px 20px;
          background: var(--gray-50);
          border-top: 1px solid var(--gray-200);
          border-bottom: 1px solid var(--gray-200);
          overflow: hidden;
        }

        .proof-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .title {
          font-size: 0.875rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--gray-600);
        }

        .logo-container {
          max-width: 1200px;
          margin: 0 auto;
          position: relative;
        }

        /* Scroll Variant */
        .variant-scroll {
          overflow: hidden;
          mask-image: linear-gradient(
            to right,
            transparent,
            black 10%,
            black 90%,
            transparent
          );
        }

        .variant-scroll .logo-track {
          display: flex;
          gap: 60px;
          animation: scroll ${speedValues[speed]} linear infinite;
        }

        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .variant-scroll:hover .logo-track {
          animation-play-state: paused;
        }

        /* Grid Variant */
        .variant-grid .logo-track {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 40px;
          max-width: 1000px;
          margin: 0 auto;
        }

        /* Fade Variant */
        .variant-fade .logo-track {
          display: flex;
          justify-content: center;
          flex-wrap: wrap;
          gap: 48px;
          max-width: 1000px;
          margin: 0 auto;
        }

        .variant-fade .logo-item {
          animation: fadeInUp 0.6s ease-out backwards;
        }

        .variant-fade .logo-item:nth-child(1) { animation-delay: 0.1s; }
        .variant-fade .logo-item:nth-child(2) { animation-delay: 0.2s; }
        .variant-fade .logo-item:nth-child(3) { animation-delay: 0.3s; }
        .variant-fade .logo-item:nth-child(4) { animation-delay: 0.4s; }
        .variant-fade .logo-item:nth-child(5) { animation-delay: 0.5s; }
        .variant-fade .logo-item:nth-child(6) { animation-delay: 0.6s; }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Logo Items */
        .logo-item {
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          height: 60px;
          min-width: 140px;
        }

        .logo-item img {
          max-width: 140px;
          max-height: 60px;
          width: auto;
          height: auto;
          object-fit: contain;
          transition: all 0.3s ease;
        }

        .logo-item img.grayscale {
          filter: grayscale(100%) brightness(0.9);
          opacity: 0.7;
        }

        .logo-item:hover img.grayscale {
          filter: grayscale(0%) brightness(1);
          opacity: 1;
        }

        .logo-placeholder {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 140px;
          height: 60px;
          background: white;
          border: 2px solid var(--gray-200);
          border-radius: 8px;
          font-weight: 600;
          color: var(--gray-600);
          font-size: 0.875rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
          .social-proof-bar {
            padding: 32px 16px;
          }

          .proof-header {
            margin-bottom: 24px;
          }

          .variant-scroll .logo-track {
            gap: 40px;
          }

          .variant-grid .logo-track {
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 24px;
          }

          .variant-fade .logo-track {
            gap: 32px;
          }

          .logo-item {
            min-width: 100px;
            height: 40px;
          }

          .logo-item img {
            max-width: 100px;
            max-height: 40px;
          }

          .logo-placeholder {
            width: 100px;
            height: 40px;
            font-size: 0.75rem;
          }
        }
      `}</style>
    </div>
  );
}
