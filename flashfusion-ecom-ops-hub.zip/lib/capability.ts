export type Capability = "native" | "requires_workaround" | "unsupported";

export function badge(cap: Capability) {
  if (cap === "native") return "🟢 Native";
  if (cap === "requires_workaround") return "🟡 Workaround";
  return "🔴 Unsupported";
}
