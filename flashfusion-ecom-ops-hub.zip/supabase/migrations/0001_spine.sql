-- FlashFusion E-commerce Operations Hub
-- NOTE: Full schema provided in chat; this migration is the authoritative spine.

create extension if not exists pgcrypto;

create table if not exists orgs (
  org_id uuid primary key default gen_random_uuid(),
  name text not null
);

create table if not exists jobs (
  job_id uuid primary key default gen_random_uuid(),
  org_id uuid not null references orgs(org_id),
  status text not null,
  idempotency_key text not null,
  created_at timestamptz default now(),
  unique(org_id, idempotency_key)
);

alter table orgs enable row level security;
alter table jobs enable row level security;
