export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>FlashFusion — E-commerce Operations Hub</h1>
      <p>Universal, policy-driven ecommerce control plane.</p>
    </main>
  );
}
