import { badge, Capability } from "@/lib/capability";

const MOCK_CAPS: Record<string, Record<string, Capability>> = {
  PRINTIFY: { publish: "native", bulk: "requires_workaround" },
  SHOPIFY: { publish: "native", bulk: "requires_workaround" },
  ETSY: { publish: "native", bulk: "requires_workaround" },
  AMAZON: { publish: "requires_workaround" },
  AMAZON_KDP: { publish: "unsupported" }
};

export default function PluginPage({ params }: { params: { pluginKey: string } }) {
  const caps = MOCK_CAPS[params.pluginKey] || {};
  return (
    <main style={{ padding: 24 }}>
      <h2>Plugin: {params.pluginKey}</h2>
      <ul>
        {Object.entries(caps).map(([k, v]) => (
          <li key={k}>{k}: {badge(v)}</li>
        ))}
      </ul>
    </main>
  );
}
