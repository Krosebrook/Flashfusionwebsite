"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { ensureUserDirectory } from "@/lib/auth";
import { Button } from "@/components/Button";

export default function Home() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (data.user) {
        setEmail(data.user.email ?? null);
        await ensureUserDirectory(data.user);
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange(async (_evt, session) => {
      setEmail(session?.user?.email ?? null);
      if (session?.user) await ensureUserDirectory(session.user);
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase]);

  const signIn = async () => {
    const redirectTo = `${location.origin}/auth/callback`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "azure",
      options: { redirectTo }
    });
    if (error) alert(error.message);
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) alert(error.message);
    setEmail(null);
  };

  return (
    <main className="min-h-screen p-8 bg-slate-950 text-slate-100">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">AI Ops Control Plane</h1>
        <p className="text-slate-300">
          Approval-gated FOH/BOH operations with immutable audit logging and four-ecosystem wiring (M365, Claude, OpenAI, Gemini).
        </p>

        {!email ? (
          <Button className="bg-cyan-500 text-slate-950" onClick={signIn}>
            Sign in with Azure (Entra)
          </Button>
        ) : (
          <div className="space-y-3">
            <div className="text-sm text-slate-300">Signed in as {email}</div>
            <div className="flex gap-2">
              <a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Dashboard</a>
              <Button className="bg-slate-800" onClick={signOut}>Sign out</Button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
