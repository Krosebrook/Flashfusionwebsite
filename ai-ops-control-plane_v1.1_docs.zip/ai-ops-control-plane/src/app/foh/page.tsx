"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { Button } from "@/components/Button";
import { JsonBlock } from "@/components/JsonBlock";

async function callFunction(path: string, token: string, body: unknown) {
  const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/${path}`;
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body)
  });
  const json = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(json?.error ?? resp.statusText);
  return json;
}

export default function FOHPage() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [queue, setQueue] = useState<any[]>([]);
  const [drafts, setDrafts] = useState<any[]>([]);
  const [tab, setTab] = useState<"queue"|"drafts">("queue");
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = async () => {
    const q = await supabase.from("foh_queue_items").select("*").order("received_at", { ascending: false }).limit(100);
    setQueue(q.data ?? []);
    const d = await supabase.from("foh_drafts").select("*").order("created_at", { ascending: false }).limit(100);
    setDrafts(d.data ?? []);
  };

  useEffect(() => { refresh(); }, []);

  const triage = async (itemId: string) => {
    setBusy(itemId);
    const { data: session } = await supabase.auth.getSession();
    const token = session.session?.access_token;
    if (!token) throw new Error("Missing session token");
    try {
      await callFunction("analyze", token, {
        domain: "foh",
        task: "triage",
        input: { queue_item_id: itemId }
      });
      await refresh();
    } finally {
      setBusy(null);
    }
  };

  const draftReply = async (itemId: string) => {
    setBusy(itemId);
    const { data: session } = await supabase.auth.getSession();
    const token = session.session?.access_token;
    if (!token) throw new Error("Missing session token");
    try {
      await callFunction("analyze", token, {
        domain: "foh",
        task: "draft_reply",
        input: { queue_item_id: itemId }
      });
      setTab("drafts");
      await refresh();
    } finally {
      setBusy(null);
    }
  };

  const requestSendApproval = async (draftId: string) => {
  setBusy(draftId);
  const { data: session } = await supabase.auth.getSession();
  if (!session.session) throw new Error("Missing session token");
  try {
    const { data, error } = await supabase.rpc("request_approval", {
      p_domain: "foh",
      p_action: "send_reply",
      p_details: { draft_id: draftId },
      p_expires_at: null
    });
    if (error) throw error;
    alert(`Send approval requested: ${data?.id ?? "—"}`);
  } finally {
    setBusy(null);
  }
};

return (
    <Shell
      title="FOH — Intake → Enrichment → Verification → Status"
      right={<a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Back</a>}
    >
      <div className="flex gap-2">
        <Button className={tab==="queue" ? "bg-cyan-500 text-slate-950" : "bg-slate-800"} onClick={() => setTab("queue")}>
          Queue
        </Button>
        <Button className={tab==="drafts" ? "bg-cyan-500 text-slate-950" : "bg-slate-800"} onClick={() => setTab("drafts")}>
          Drafts
        </Button>
      </div>

      {tab === "queue" && (
        <div className="space-y-3">
          {queue.map(i => (
            <div key={i.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{i.subject ?? "(no subject)"}</div>
                <div className="text-sm text-slate-300">{i.status}</div>
              </div>
              <div className="text-sm text-slate-400">
                from: {i.from_address ?? "—"} • received: {i.received_at ? new Date(i.received_at).toLocaleString() : "—"}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                <div className="rounded bg-slate-950 p-2 border border-slate-800">
                  product: <span className="text-slate-200">{i.product ?? "—"}</span>
                </div>
                <div className="rounded bg-slate-950 p-2 border border-slate-800">
                  urgency: <span className="text-slate-200">{i.urgency ?? "—"}</span>
                </div>
                <div className="rounded bg-slate-950 p-2 border border-slate-800">
                  sentiment: <span className="text-slate-200">{i.sentiment ?? "—"}</span>
                </div>
              </div>

              {i.excerpt && <JsonBlock value={{ excerpt: i.excerpt }} />}

              <div className="flex gap-2">
                <Button
                  className="bg-slate-800"
                  onClick={() => triage(i.id)}
                  disabled={busy === i.id}
                >
                  {busy === i.id ? "Working…" : "Auto-triage"}
                </Button>
                <Button
                  className="bg-cyan-500 text-slate-950"
                  onClick={() => draftReply(i.id)}
                  disabled={busy === i.id}
                >
                  {busy === i.id ? "Working…" : "Generate draft reply"}
                </Button>
              </div>

              {i.last_error && (
                <div className="text-sm text-rose-300">last_error: {i.last_error}</div>
              )}
            </div>
          ))}
          {queue.length === 0 && <div className="text-slate-400">No queue items visible (or not ingested yet).</div>}
        </div>
      )}

      {tab === "drafts" && (
        <div className="space-y-3">
          {drafts.map(d => (
            <div key={d.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{d.subject ?? "(no subject)"}</div>
                <div className="text-sm text-slate-400">{d.model_provider}/{d.model_name ?? "—"}</div>
              </div>
              <JsonBlock value={{ token_usage: d.token_usage, to: d.to_recipients, cc: d.cc_recipients, queue_item_id: d.queue_item_id }} />
              <pre className="p-2 rounded bg-slate-950 overflow-x-auto text-sm border border-slate-800">
                {d.body_markdown}
              </pre>
              <div className="flex items-center gap-2">
  <Button
    className="bg-cyan-500 text-slate-950"
    onClick={() => requestSendApproval(d.id)}
    disabled={busy === d.id}
  >
    {busy === d.id ? "Working…" : "Request send approval"}
  </Button>
  <a className="text-cyan-400 underline text-sm" href="/approvals">View approvals</a>
</div>
            </div>
          ))}
          {drafts.length === 0 && <div className="text-slate-400">No drafts yet.</div>}
        </div>
      )}
    </Shell>
  );
}
