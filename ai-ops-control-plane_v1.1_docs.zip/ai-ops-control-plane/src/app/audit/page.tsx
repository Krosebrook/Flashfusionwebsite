"use client";
import { useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { Button } from "@/components/Button";
import { JsonBlock } from "@/components/JsonBlock";

export default function AuditPage() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [domain, setDomain] = useState<string>("");
  const [actor, setActor] = useState<string>("");
  const [corr, setCorr] = useState<string>("");
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    setLoading(true);
    let q = supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(200);
    if (domain) q = q.eq("domain", domain);
    if (actor) q = q.eq("actor_id", actor);
    if (corr) q = q.eq("correlation_id", corr);
    const res = await q;
    setRows(res.data ?? []);
    setLoading(false);
  };

  return (
    <Shell title="Audit" right={<a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Back</a>}>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <select className="p-2 rounded bg-slate-900 border border-slate-800" value={domain} onChange={e=>setDomain(e.target.value)}>
          <option value="">All domains</option>
          <option value="foh">FOH</option>
          <option value="boh">BOH</option>
          <option value="platform">Platform</option>
        </select>
        <input className="p-2 rounded bg-slate-900 border border-slate-800" placeholder="actor_id (uuid)" value={actor} onChange={e=>setActor(e.target.value)} />
        <input className="p-2 rounded bg-slate-900 border border-slate-800" placeholder="correlation_id (uuid)" value={corr} onChange={e=>setCorr(e.target.value)} />
        <Button className="bg-cyan-500 text-slate-950" onClick={search} disabled={loading}>
          {loading ? "Searching…" : "Search"}
        </Button>
      </div>

      <div className="space-y-2 text-sm">
        {rows.map(r => (
          <div key={r.id} className="rounded border border-slate-800 bg-slate-900 p-3">
            <div className="flex justify-between">
              <div className="font-semibold">{String(r.domain).toUpperCase()} • {r.event_type}</div>
              <div className="text-slate-400">{new Date(r.created_at).toLocaleString()}</div>
            </div>
            <div className="text-slate-400">actor: {r.actor_id ?? "—"} • corr: {r.correlation_id ?? "—"}</div>
            <JsonBlock value={r.payload} />
          </div>
        ))}
        {rows.length === 0 && <div className="text-slate-400">No events (or not authorized to view).</div>}
      </div>
    </Shell>
  );
}
