"use client";
import { useEffect } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { ensureUserDirectory } from "@/lib/auth";

export default function Callback() {
  const supabase = supabaseBrowser();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (data.user) await ensureUserDirectory(data.user);
      window.location.href = "/dashboard";
    })();
  }, [supabase]);

  return (
    <main className="min-h-screen p-8 bg-slate-950 text-slate-100">
      <div className="max-w-xl mx-auto">Signing you in…</div>
    </main>
  );
}
