# AI Ops Control Plane (FOH/BOH) — Post-Production Kit

This repo is a production-grade control plane for **approval-gated AI operations**:
- **FOH**: intake → enrichment → verification → status communications
- **BOH**: preflight → gated CI → canary/blue-green deploy → rollback-first ops

## Security invariants (non-negotiable)
1) **Browser cannot send/deploy/write**. It can only request approvals and view state.
2) **All irreversible actions** run in **Supabase Edge Functions** **after** verifying:
   - approval status = `approved`
   - execution status can be claimed exactly once at a time
3) **RLS is the real gate**. UI state is convenience, not control.
4) **Service role key never enters the browser**. Supabase documents this explicitly for Edge Functions secrets.  
   - See: Supabase Edge Functions secrets docs (service role bypasses RLS; never use in browser).

## What’s wired (the “four ecosystems”)
- **Microsoft 365 (Entra + Graph)**: SSO + FOH read-only ingestion + app-only sendMail (approval-gated)
- **Anthropic Claude**: primary drafting and triage via Messages API
- **OpenAI**: optional analysis provider via Responses API
- **Google Gemini**: optional analysis provider via generateContent

## Stack
- Next.js (App Router) UI
- Supabase Auth (Azure provider) + Postgres + RLS + RPC gates
- Supabase Edge Functions: model routing + execution layer

---

# Build

## 1) Create Supabase project + configure Auth (Azure/Entra)
1) Supabase Dashboard → Auth → Providers → **Azure**
2) Create Entra App Registration (redirect URL = your Supabase callback)
3) Enable provider, test login once.

## 2) Apply DB migrations (RLS + tables + RPC)
### Using Supabase CLI (recommended)
```bash
npm i
npx supabase init
npx supabase db push
```

Migrations live in: `supabase/migrations/`

## 3) Deploy Edge Functions
```bash
npx supabase functions deploy analyze
npx supabase functions deploy execute-approved
npx supabase functions deploy ingest-m365
npx supabase functions deploy ingest-preflight-results
npx supabase functions deploy role-sync
npx supabase functions deploy export-audit
```

## 4) Set Edge Function secrets (server-only)
```bash
# Microsoft Graph app-only
npx supabase secrets set AZURE_TENANT_ID="..." AZURE_CLIENT_ID="..." AZURE_CLIENT_SECRET="..."

# Email send strategy + default mailbox
npx supabase secrets set FOH_SEND_STRATEGY="graph" FOH_DEFAULT_MAILBOX_UPN="shared-mailbox-upn@example.com"  # set to your real shared mailbox UPN

# GitHub workflow_dispatch
npx supabase secrets set GITHUB_TOKEN="..." GITHUB_DEFAULT_REPO="owner/repo"   GITHUB_PREFLIGHT_WORKFLOW_FILE="preflight.yml" GITHUB_DEPLOY_WORKFLOW_FILE="deploy.yml"

# Webhook signing secret for CI → Control Plane callbacks
npx supabase secrets set CONTROL_PLANE_WEBHOOK_SECRET="..."

# LLM providers
npx supabase secrets set ANTHROPIC_API_KEY="..." OPENAI_API_KEY="..." GEMINI_API_KEY="..."
```

## 5) Configure UI environment (browser-safe only)
Copy `.env.example` → `.env.local`, fill:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Then:
```bash
npm run dev
```

## 6) Seed role mappings (admin-only)
In Supabase SQL editor, insert group mappings in `role_mappings`:
- entra_group_id → role_name (`support_agent`, `engineer`, `approver`, `admin`)

Then run `role-sync` once (manual):
```bash
curl -X POST "$SUPABASE_URL/functions/v1/role-sync"   -H "Authorization: Bearer <ADMIN_USER_JWT>"
```


## 4.1) Configure GitHub repository secrets (required for CI → Control Plane)
In the GitHub repo you’re dispatching workflows from, set these **Repository Secrets**:

- `CONTROL_PLANE_WEBHOOK_URL` = `https://<your-project-ref>.functions.supabase.co/ingest-preflight-results`
- `CONTROL_PLANE_WEBHOOK_SECRET` = the exact same value as Supabase `CONTROL_PLANE_WEBHOOK_SECRET`

This is what lets `preflight.yml` POST results back to the control plane safely (HMAC-signed).


---



## 7) Create Storage bucket for audit exports
Create a private Storage bucket named `audit-exports` (Supabase Dashboard → Storage). The `export-audit` function uploads daily JSONL exports there.

# Output

## UI routes
- `/` login
- `/dashboard` overview
- `/foh` FOH queue + draft generation
- `/boh` BOH preflight runs + approval requests
- `/approvals` approve/reject + execute approved actions
- `/audit` filtered audit viewer
- `/runbooks` rollback runbooks
- `/slo` SLO metrics viewer



## BOH Deploy workflow (Vercel example)
If you use the included `deploy.yml`, set these GitHub repo secrets:
- `VERCEL_TOKEN` (Vercel personal token with deploy rights)

The workflow deploys to Vercel **preview** by default (canary-style), or **production** if dispatched with `environment=production`.


## Edge Functions (endpoints)
- `POST /functions/v1/analyze` — triage/drafts/risk summaries (server-only model calls)
- `POST /functions/v1/execute-approved` — executes approved actions (Graph sendMail, GitHub workflow_dispatch)
- `POST /functions/v1/ingest-m365` — read-only ingestion into FOH queue (Graph)
- `POST /functions/v1/ingest-preflight-results` — CI callback → updates preflight runs (HMAC-signed)
- `POST /functions/v1/role-sync` — Entra groups → Supabase roles
- `POST /functions/v1/export-audit` — daily audit export + checksum

## Verification / smoke
```bash
# UI
npm run smoke
npm run build
npm run verify:no-secrets

# FOH: ingest (read-only)
curl -X POST "$SUPABASE_URL/functions/v1/ingest-m365"   -H "Authorization: Bearer <SUPPORT_AGENT_JWT>"   -H "Content-Type: application/json"   -d '{"source":"outlook"}'

# FOH: triage + draft via /foh UI; request approval; approve; execute.

# BOH: create preflight run in /boh; request approval; approve; execute dispatch.
```

## Acceptance criteria (post-production)
- ✅ No irreversible action occurs without an `approved` record.
- ✅ Approvals decision fields are immutable after decision (DB enforced).
- ✅ Execution is idempotent via claim/finish execution logic.
- ✅ Audit events exist for: request → decision → execution → outcome.
- ✅ Service role key is not present in browser bundles (verify:no-secrets).

---

## Implementation Considerations

### Microsoft Graph sendMail (FOH outbound)
- **Send is Edge-only**: the browser never calls Graph; only an Edge Function executes after an approval is `approved`.
- Microsoft Graph `sendMail` supports sending via either `/me/sendMail` or `/users/{id|userPrincipalName}/sendMail`, and `Mail.Send` is the least-privileged permission listed for both delegated and application flows on that API.  
  https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0
- **Sent Items behavior matters** when sending “as” another mailbox; Microsoft documents differences depending on whether you send through `/me` or `/users/{id}` and the mailbox permissions (Send As / Send on Behalf).  
  https://learn.microsoft.com/en-us/graph/outlook-send-mail-from-other-user

### JWT role freshness (Supabase)
- Supabase notes that **JWTs are not always fresh**: changes to `app_metadata` (roles/teams) won't be reflected in `auth.jwt()` checks until the user's JWT is refreshed. Practical ops rule: role-sync + logout/login (or token refresh) after role changes.  
  https://supabase.com/docs/guides/database/postgres/row-level-security

### RBAC source of truth
- This kit uses `app_metadata.roles` + `has_role()` checks in RLS policies. For stronger issuance guarantees (and smaller tokens), consider a **Custom Access Token Hook** to control which claims are issued and when.  
  https://supabase.com/docs/guides/auth/auth-hooks/custom-access-token-hook

## Performance / Security Notes

### Service role keys
- Supabase warns: **never expose `service_role` / secret keys publicly**; they are designed for server-controlled components (Edge Functions, jobs, back-office) and can bypass RLS via the BYPASSRLS attribute.  
  https://supabase.com/docs/guides/api/api-keys  
  https://supabase.com/docs/guides/database/postgres/row-level-security

### GitHub workflow_dispatch status codes
- GitHub documents `workflow_dispatch` as returning **204 No Content**, so you can't rely on a workflow run ID from the dispatch call; `correlation_id` is the correct join key across approval → dispatch → CI callback.  
  https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event

### OpenAI/LLM key hygiene
- OpenAI documents that API keys are secrets and **must not be exposed in client-side code**; keep them server-side (Edge Functions) via environment variables / KMS.  
  https://platform.openai.com/docs/api-reference/introduction

## Recommended Next Steps

1. Add Entra group IDs into `role_mappings`, then call `role-sync` once to populate roles (and refresh JWTs for users).
2. Create a private Storage bucket named `audit-exports`, then schedule `export-audit` daily.
3. Keep FOH in **read-only ingestion** first; add `Mail.Send` only when you're ready to allow approved sends.
4. Replace `deploy.yml` with your real canary/blue-green + rollback mechanism; the control plane contract stays unchanged (approval → dispatch → results → audit).

## CLAIMS CHECK

- **Claim:** Irreversible actions never run in the browser; they only run after `approvals.status="approved"` inside Edge Functions.  
  **Evidence:** Supabase guidance is explicit about keeping privileged keys server-side and not in browsers.  
  https://supabase.com/docs/guides/api/api-keys

- **Claim:** `workflow_dispatch` is the correct primitive for approval-gated CI/deploy triggers, and it returns 204.  
  **Evidence:** GitHub REST docs.  
  https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event

- **Counterexample:** If `SUPABASE_SERVICE_ROLE_KEY` leaks into a client bundle, RLS is bypassed and guarantees collapse.  
  **Mitigation:** Keep service keys only in Edge Function secrets + CI secret stores; verify build artifacts.  
  https://supabase.com/docs/guides/api/api-keys

- **Potential contradiction:** “No placeholders” vs “don’t expose secrets.”  
  **Resolution:** Provide env schemas and require runtime secret injection; never hardcode keys in code or docs.

# Troubleshooting (cause → fix → retry)
- Login loops: Azure provider misconfigured → fix redirect URL in Entra + Supabase provider settings → retry.
- “not authorized” on approvals: roles missing → run role-sync + refresh JWT (logout/login).
- execute-approved fails: missing function secrets → set with `supabase secrets set ...` → redeploy functions.
- CI callback rejected: invalid signature → ensure CONTROL_PLANE_WEBHOOK_SECRET matches GitHub secret → retry.

