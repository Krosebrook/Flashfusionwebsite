import { corsHeaders } from "../_shared/cors.ts";
import { supabaseAdmin, supabaseAuthed } from "../_shared/supabase.ts";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function sha256Hex(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function ymd(d: Date) {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    const authHeader = req.headers.get("Authorization");
    const authed = supabaseAuthed(authHeader);
    const { data: userRes, error: userErr } = await authed.auth.getUser();
    if (userErr || !userRes.user) return jsonResponse(401, { error: "Unauthorized" });

    const roles = (userRes.user.app_metadata?.roles ?? []) as string[];
    if (!roles.includes("admin")) return jsonResponse(403, { error: "Admin role required" });

    const admin = supabaseAdmin();

    // Export last 24h
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const res = await admin.from("audit_logs").select("*").gte("created_at", since).order("created_at", { ascending: true });
    if (res.error) return jsonResponse(500, { error: res.error.message });

    const records = res.data ?? [];
    const jsonl = records.map(r => JSON.stringify(r)).join("\n");
    const checksum = await sha256Hex(jsonl);

    // Upload to Supabase Storage (bucket: audit-exports). This is a staging sink.
    // For true WORM, replicate the object to S3 Object Lock or Azure Immutable Blob.
    const bucket = "audit-exports";
    const day = ymd(new Date());
    const objectPath = `${day}/audit-${day}.jsonl`;

    const upload = await admin.storage.from(bucket).upload(objectPath, new Blob([jsonl], { type: "text/plain" }), {
      upsert: false,
      contentType: "text/plain"
    });

    if (upload.error) {
      // Still write checksum event so you can alert on missing exports.
      await admin.rpc("append_audit", {
        p_domain: "platform",
        p_event_type: "audit.export.failed",
        p_payload: { count: records.length, checksum, since, bucket, objectPath, error: upload.error.message },
        p_correlation_id: null,
        p_ip: null,
        p_user_agent: "export-audit"
      });
      return jsonResponse(500, { ok: false, error: upload.error.message, checksum, count: records.length });
    }

    await admin.rpc("append_audit", {
      p_domain: "platform",
      p_event_type: "audit.exported",
      p_payload: { count: records.length, checksum, since, bucket, objectPath },
      p_correlation_id: null,
      p_ip: null,
      p_user_agent: "export-audit"
    });

    return jsonResponse(200, { ok: true, count: records.length, checksum, bucket, objectPath });
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
