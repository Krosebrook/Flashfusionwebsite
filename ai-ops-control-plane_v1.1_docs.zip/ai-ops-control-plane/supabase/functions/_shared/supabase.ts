import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { reqEnv } from "./env.ts";

export function supabaseAdmin() {
  return createClient(reqEnv("SUPABASE_URL"), reqEnv("SUPABASE_SERVICE_ROLE_KEY"));
}

export function supabaseAuthed(authHeader: string | null) {
  const anon = reqEnv("SUPABASE_ANON_KEY");
  const url = reqEnv("SUPABASE_URL");
  return createClient(url, anon, {
    global: authHeader ? { headers: { Authorization: authHeader } } : undefined
  });
}
