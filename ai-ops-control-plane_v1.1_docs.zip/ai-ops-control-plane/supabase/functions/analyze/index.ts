import { corsHeaders } from "../_shared/cors.ts";
import { reqEnv } from "../_shared/env.ts";
import { supabaseAdmin, supabaseAuthed } from "../_shared/supabase.ts";

type Domain = "foh" | "boh";
type Task = "triage" | "draft_reply" | "risk_summary";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

function nowMs() { return Date.now(); }

async function callAnthropic(model: string, prompt: string) {
  const apiKey = reqEnv("ANTHROPIC_API_KEY");
  const version = reqEnv("ANTHROPIC_VERSION");
  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": version,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model,
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }]
    })
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json?.error?.message ?? `Anthropic error: ${resp.status}`);
  const text = (json?.content ?? []).map((c: any) => c?.text).filter(Boolean).join("");
  const usage = { input_tokens: json?.usage?.input_tokens ?? null, output_tokens: json?.usage?.output_tokens ?? null };
  return { text, usage };
}

async function callOpenAI(model: string, prompt: string) {
  const apiKey = reqEnv("OPENAI_API_KEY");
  const resp = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      input: prompt
    })
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json?.error?.message ?? `OpenAI error: ${resp.status}`);
  // Responses API returns output in a structured list; safest is to join any output_text fields.
  const text = (json?.output ?? [])
    .flatMap((o: any) => o?.content ?? [])
    .map((c: any) => c?.text)
    .filter(Boolean)
    .join("");
  const usage = json?.usage ?? {};
  return { text, usage };
}

async function callGemini(model: string, prompt: string) {
  const apiKey = reqEnv("GEMINI_API_KEY");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "x-goog-api-key": apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    })
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json?.error?.message ?? `Gemini error: ${resp.status}`);
  const text = (json?.candidates ?? [])
    .flatMap((c: any) => c?.content?.parts ?? [])
    .map((p: any) => p?.text)
    .filter(Boolean)
    .join("");
  const usage = json?.usageMetadata ?? {};
  return { text, usage };
}

function pickProvider(): { provider: "anthropic" | "openai" | "gemini"; model: string } {
  // Default: Anthropic primary, others optional
  const provider = (Deno.env.get("DEFAULT_LLM_PROVIDER") ?? "anthropic") as any;
  if (provider === "openai") return { provider, model: Deno.env.get("OPENAI_DEFAULT_MODEL") ?? "gpt-4.1-mini" };
  if (provider === "gemini") return { provider, model: Deno.env.get("GEMINI_DEFAULT_MODEL") ?? "gemini-2.5-flash" };
  return { provider: "anthropic", model: Deno.env.get("ANTHROPIC_DEFAULT_MODEL") ?? "claude-sonnet-4-5" };
}

function safeJsonParse(s: string): any | null {
  try { return JSON.parse(s); } catch { return null; }
}

function extractFirstJsonObject(text: string): any | null {
  // Robust-ish: find first {...} and parse.
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return safeJsonParse(text.slice(start, end + 1));
}

function triagePrompt(subject: string, excerpt: string) {
  return `You are a support triage classifier. Output STRICT JSON only.

Schema:
{
  "product": string,
  "urgency": "low"|"medium"|"high"|"urgent",
  "sentiment": "negative"|"neutral"|"positive",
  "summary": string
}

Input:
SUBJECT: ${subject}
EXCERPT: ${excerpt}

Return only JSON.`;
}

function draftPrompt(subject: string, excerpt: string) {
  return `You are a FOH support agent. Draft a helpful, concise reply in Markdown.

Constraints:
- Ask for missing details (only the minimum).
- Provide a clear next step.
- Be polite, direct, not fluffy.
- Do NOT claim you performed actions you didn't do.

Context:
SUBJECT: ${subject}
EXCERPT: ${excerpt}

Return Markdown only.`;
}

function riskPrompt(repo: string, ref: string) {
  return `You are an engineering change-risk analyst. Output STRICT JSON only.

Schema:
{
  "risk_score": number,     // 0-100
  "risk_flags": string[],   // short bullets
  "summary": string
}

Input:
REPO: ${repo}
REF: ${ref}

Assume you don't have code access. Base risk on typical hazards: secrets, licenses, failing tests, infra blast radius, missing rollback.

Return only JSON.`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    const authHeader = req.headers.get("Authorization");
    const authed = supabaseAuthed(authHeader);
    const { data: userRes, error: userErr } = await authed.auth.getUser();
    if (userErr || !userRes.user) return jsonResponse(401, { error: "Unauthorized" });

    const body = await req.json();
    const domain = body?.domain as Domain;
    const task = body?.task as Task;
    const input = body?.input ?? {};

    if (!domain || !task) return jsonResponse(400, { error: "Missing domain/task" });
    if (domain !== "foh" && domain !== "boh") return jsonResponse(400, { error: "Invalid domain" });

    const admin = supabaseAdmin();
    const started = nowMs();
    const { provider, model } = pickProvider();

    let prompt = "";
    let resultText = "";
    let usage: any = {};

    if (domain === "foh") {
      if (task !== "triage" && task !== "draft_reply") return jsonResponse(400, { error: "Invalid FOH task" });

      // Load queue item
      const qid = input?.queue_item_id as string;
      if (!qid) return jsonResponse(400, { error: "Missing queue_item_id" });

      const q = await admin.from("foh_queue_items").select("*").eq("id", qid).single();
      if (q.error) return jsonResponse(400, { error: q.error.message });

      const subject = q.data.subject ?? "(no subject)";
      const excerpt = q.data.excerpt ?? "";

      prompt = task === "triage" ? triagePrompt(subject, excerpt) : draftPrompt(subject, excerpt);

      const call = provider === "openai"
        ? await callOpenAI(model, prompt)
        : provider === "gemini"
          ? await callGemini(model, prompt)
          : await callAnthropic(model, prompt);

      resultText = call.text;
      usage = call.usage;

      if (task === "triage") {
        const parsed = extractFirstJsonObject(resultText);
        if (!parsed) {
          await admin.from("foh_queue_items").update({ status: "error", last_error: "triage JSON parse failed" }).eq("id", qid);
          return jsonResponse(422, { error: "Model returned non-JSON triage output", raw: resultText.slice(0, 1000) });
        }

        await admin.from("foh_queue_items").update({
          product: parsed.product ?? null,
          urgency: parsed.urgency ?? null,
          sentiment: parsed.sentiment ?? null,
          status: "triaged",
          last_error: null
        }).eq("id", qid);

        await admin.rpc("append_audit", {
          p_domain: "foh",
          p_event_type: "foh.triaged",
          p_payload: { queue_item_id: qid, provider, model, usage, triage: parsed },
          p_correlation_id: null,
          p_ip: null,
          p_user_agent: req.headers.get("user-agent") ?? ""
        });

        return jsonResponse(200, { ok: true, triage: parsed });
      }

      // Draft reply
      const ins = await admin.from("foh_drafts").insert({
        queue_item_id: qid,
        requester: userRes.user.id,
        source_type: q.data.source_type,
        source_ref: q.data.source_ref,
        subject,
        body_markdown: resultText,
        model_provider: provider,
        model_name: model,
        token_usage: usage
      }).select().single();

      if (ins.error) return jsonResponse(500, { error: ins.error.message });

      await admin.from("foh_queue_items").update({ status: "drafting", last_error: null }).eq("id", qid);

      await admin.rpc("append_audit", {
        p_domain: "foh",
        p_event_type: "foh.draft.created",
        p_payload: { queue_item_id: qid, draft_id: ins.data.id, provider, model, usage, latency_ms: nowMs() - started },
        p_correlation_id: null,
        p_ip: null,
        p_user_agent: req.headers.get("user-agent") ?? ""
      });

      return jsonResponse(200, { ok: true, draft_id: ins.data.id });
    }

    // BOH
    if (task !== "risk_summary") return jsonResponse(400, { error: "Invalid BOH task" });
    const repo = input?.repo_full_name as string;
    const ref = input?.ref as string;
    if (!repo || !ref) return jsonResponse(400, { error: "Missing repo_full_name/ref" });

    prompt = riskPrompt(repo, ref);
    const call = provider === "openai"
      ? await callOpenAI(model, prompt)
      : provider === "gemini"
        ? await callGemini(model, prompt)
        : await callAnthropic(model, prompt);

    resultText = call.text;
    usage = call.usage;

    const parsed = extractFirstJsonObject(resultText);
    if (!parsed) return jsonResponse(422, { error: "Model returned non-JSON risk output", raw: resultText.slice(0, 1000) });

    const run = await admin.from("boh_preflight_runs").insert({
      requester: userRes.user.id,
      repo_full_name: repo,
      ref,
      ci_provider: "github_actions",
      risk_score: Math.max(0, Math.min(100, Number(parsed.risk_score ?? 0))),
      risk_flags: parsed.risk_flags ?? [],
      model_provider: provider,
      model_name: model,
      token_usage: usage,
      status: "queued"
    }).select().single();

    if (run.error) return jsonResponse(500, { error: run.error.message });

    await admin.rpc("append_audit", {
      p_domain: "boh",
      p_event_type: "boh.risk.created",
      p_payload: { preflight_id: run.data.id, provider, model, usage, risk: parsed, latency_ms: nowMs() - started },
      p_correlation_id: null,
      p_ip: null,
      p_user_agent: req.headers.get("user-agent") ?? ""
    });

    return jsonResponse(200, { ok: true, preflight_id: run.data.id, risk: parsed });
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
