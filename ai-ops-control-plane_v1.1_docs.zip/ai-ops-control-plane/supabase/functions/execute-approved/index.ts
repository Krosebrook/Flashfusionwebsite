import { corsHeaders } from "../_shared/cors.ts";
import { reqEnv } from "../_shared/env.ts";
import { supabaseAdmin, supabaseAuthed } from "../_shared/supabase.ts";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function getGraphToken() {
  const tenant = reqEnv("AZURE_TENANT_ID");
  const clientId = reqEnv("AZURE_CLIENT_ID");
  const clientSecret = reqEnv("AZURE_CLIENT_SECRET");
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
    scope: "https://graph.microsoft.com/.default"
  });
  const resp = await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!resp.ok) throw new Error(`Graph token error: ${await resp.text()}`);
  return await resp.json();
}

async function sendMailGraph(mailboxUpn: string, subject: string, bodyText: string, toRecipients: any[], ccRecipients: any[]) {
  const { access_token } = await getGraphToken();
  const resp = await fetch(`https://graph.microsoft.com/v1.0/users/${encodeURIComponent(mailboxUpn)}/sendMail`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${access_token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message: {
        subject,
        body: { contentType: "Text", content: bodyText },
        toRecipients: (toRecipients ?? []).map((r: any) => ({ emailAddress: { address: r.address ?? r } })),
        ccRecipients: (ccRecipients ?? []).map((r: any) => ({ emailAddress: { address: r.address ?? r } }))
      },
      saveToSentItems: true
    })
  });
  if (!resp.ok) throw new Error(await resp.text());
}

async function dispatchWorkflow(repoFullName: string, workflowFile: string, ref: string, inputs: Record<string,string>, token: string) {
  const url = `https://api.github.com/repos/${repoFullName}/actions/workflows/${workflowFile}/dispatches`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ ref, inputs })
  });
  // GitHub returns 204 No Content on success.
  if (resp.status !== 204) throw new Error(await resp.text());
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    const authHeader = req.headers.get("Authorization");
    const authed = supabaseAuthed(authHeader);
    const { data: userRes, error: userErr } = await authed.auth.getUser();
    if (userErr || !userRes.user) return jsonResponse(401, { error: "Unauthorized" });

    const admin = supabaseAdmin();
    const { approval_id } = await req.json();
    if (!approval_id) return jsonResponse(400, { error: "Missing approval_id" });

    const appr = await admin.from("approvals").select("*").eq("id", approval_id).single();
    if (appr.error) return jsonResponse(400, { error: appr.error.message });

    if (appr.data.status !== "approved") return jsonResponse(409, { error: "Approval not approved" });

    // Role gate: FOH sends require support_agent/admin; BOH actions require engineer/admin; approver/admin can always execute.
    const roles = (userRes.user.app_metadata?.roles ?? []) as string[];
    const isAdmin = roles.includes("admin");
    const isApprover = roles.includes("approver");
    const isSupport = roles.includes("support_agent");
    const isEngineer = roles.includes("engineer");

    const action = appr.data.action as string;
    const domain = appr.data.domain as string;

    const canExecute =
      isAdmin || isApprover ||
      (domain === "foh" && isSupport) ||
      (domain === "boh" && isEngineer);

    if (!canExecute) return jsonResponse(403, { error: "Insufficient role to execute" });

    // Claim execution (server-side compare-and-swap).
    try {
      await admin.rpc("claim_execution", { p_approval_id: approval_id });
    } catch (e) {
      return jsonResponse(409, { error: (e as Error).message });
    }

    // Record started
    await admin.rpc("record_action_execution", { p_approval_id: approval_id, p_status: "started", p_outcome: { started_at: new Date().toISOString() } });

    const strategy = (Deno.env.get("FOH_SEND_STRATEGY") ?? "graph") as "graph" | "n8n";
    let outcome: any = { action };

    try {
      if (action === "send_reply") {
        const draftId = appr.data.details?.draft_id;
        const mailboxUpn = appr.data.details?.mailbox_upn ?? Deno.env.get("FOH_DEFAULT_MAILBOX_UPN");
        if (!draftId || !mailboxUpn) throw new Error("Missing draft_id or mailbox_upn");

        const draft = await admin.from("foh_drafts").select("*").eq("id", draftId).single();
        if (draft.error) throw new Error(draft.error.message);

        const subject = draft.data.subject ?? "(no subject)";
        const bodyText = draft.data.body_markdown ?? "";

// If this draft is tied to a queue item, mark it sent after successful execution.
const queueItemId = draft.data.queue_item_id as string | null | undefined;


        const toRecipients = draft.data.to_recipients ?? [];
        const ccRecipients = draft.data.cc_recipients ?? [];

        if (strategy === "graph") {
          await sendMailGraph(mailboxUpn, subject, bodyText, toRecipients, ccRecipients);

if (queueItemId) {
  await admin.from("foh_queue_items").update({ status: "sent", last_error: null }).eq("id", queueItemId);
}

          outcome = { ...outcome, sent_via: "graph", mailbox_upn: mailboxUpn, draft_id: draftId };
        } else {
          throw new Error("n8n strategy not implemented in this kit. Use graph or implement webhook call here.");
        }
      } } else if (action === "run_preflight" || action === "deploy_canary") {
  const ghToken = reqEnv("GITHUB_TOKEN");

  const preflightId = appr.data.details?.preflight_id as string | undefined;
  const repoFullName = (appr.data.details?.repo_full_name ?? Deno.env.get("GITHUB_DEFAULT_REPO")) as string | undefined;
  const workflowFile = (appr.data.details?.workflow_file ?? (action === "run_preflight"
    ? Deno.env.get("GITHUB_PREFLIGHT_WORKFLOW_FILE")
    : Deno.env.get("GITHUB_DEPLOY_WORKFLOW_FILE"))) as string | undefined;
  const ref = appr.data.details?.ref as string | undefined;

  if (!repoFullName || !workflowFile || !ref) throw new Error("Missing repo/workflow/ref");

  // Optional safety: deploy requires a successful preflight run
  if (action === "deploy_canary") {
    if (!preflightId) throw new Error("Missing preflight_id for deploy");
    const run = await admin.from("boh_preflight_runs").select("*").eq("id", preflightId).single();
    if (run.error) throw new Error(run.error.message);
    if (run.data.status !== "succeeded") throw new Error("Preflight run not succeeded; deploy blocked");
  }

  // For preflight dispatch: bind correlation_id to the run so CI can report back.
  if (action === "run_preflight" && preflightId) {
    await admin.from("boh_preflight_runs").update({
      correlation_id: appr.data.correlation_id,
      status: "running",
      last_error: null
    }).eq("id", preflightId);
  }

  const inputs: Record<string, string> = {
    ref,
    correlation_id: appr.data.correlation_id
  };

  await dispatchWorkflow(repoFullName, workflowFile, ref, inputs, ghToken);
  outcome = { ...outcome, dispatched: true, repo: repoFullName, workflow: workflowFile, ref, preflight_id: preflightId ?? null };
} else {
        throw new Error(`Unknown action: ${action}`);
      }

      await admin.rpc("record_action_execution", { p_approval_id: approval_id, p_status: "succeeded", p_outcome: outcome });
      await admin.rpc("finish_execution", { p_approval_id: approval_id, p_status: "succeeded", p_error: null });

      await admin.rpc("append_audit", {
        p_domain: domain,
        p_event_type: "action.executed",
        p_payload: { approval_id, outcome },
        p_correlation_id: appr.data.correlation_id,
        p_ip: null,
        p_user_agent: req.headers.get("user-agent") ?? ""
      });

      return jsonResponse(200, { ok: true, outcome });
    } catch (e) {
      const err = (e as Error).message;
      await admin.rpc("record_action_execution", { p_approval_id: approval_id, p_status: "failed", p_outcome: { error: err } });
      await admin.rpc("finish_execution", { p_approval_id: approval_id, p_status: "failed", p_error: err });

      await admin.rpc("append_audit", {
        p_domain: domain,
        p_event_type: "action.failed",
        p_payload: { approval_id, error: err },
        p_correlation_id: appr.data.correlation_id,
        p_ip: null,
        p_user_agent: req.headers.get("user-agent") ?? ""
      });

      return jsonResponse(500, { ok: false, error: err });
    }
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
