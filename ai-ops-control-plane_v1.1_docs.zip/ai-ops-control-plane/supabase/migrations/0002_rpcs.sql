-- 0002_rpcs.sql
-- Server-trusted RPCs: audit append, approval request/decision, execution claim/finish, execution record.

create or replace function public.append_audit(
  p_domain control_plane_domain,
  p_event_type text,
  p_payload jsonb,
  p_correlation_id uuid,
  p_ip inet,
  p_user_agent text
)
returns uuid
language plpgsql
security definer
as $$
declare
  v_id uuid;
begin
  insert into public.audit_logs(domain, event_type, actor_id, payload, correlation_id, ip, user_agent)
  values (p_domain, p_event_type, auth.uid(), coalesce(p_payload,'{}'::jsonb), p_correlation_id, p_ip, p_user_agent)
  returning id into v_id;

  return v_id;
end $$;

revoke all on function public.append_audit(control_plane_domain,text,jsonb,uuid,inet,text) from public;
grant execute on function public.append_audit(control_plane_domain,text,jsonb,uuid,inet,text) to authenticated;

-- Request approval with allowlisted actions
create or replace function public.request_approval(
  p_domain control_plane_domain,
  p_action text,
  p_details jsonb,
  p_expires_at timestamptz
)
returns public.approvals
language plpgsql
security definer
as $$
declare
  v_row public.approvals;
begin
  if p_action not in ('send_reply','run_preflight','deploy_canary') then
    raise exception 'action not allowed';
  end if;

  insert into public.approvals(domain, action, details, requester, expires_at)
  values (p_domain, p_action, coalesce(p_details,'{}'::jsonb), auth.uid(), p_expires_at)
  returning * into v_row;

  perform public.append_audit(p_domain, 'approval.requested', jsonb_build_object('action', p_action), v_row.correlation_id, null, 'rpc');
  return v_row;
end $$;

revoke all on function public.request_approval(control_plane_domain,text,jsonb,timestamptz) from public;
grant execute on function public.request_approval(control_plane_domain,text,jsonb,timestamptz) to authenticated;

-- Decide approval (approve/reject) – only approver/admin
create or replace function public.decide_approval(
  p_approval_id uuid,
  p_decision approval_status,
  p_reason text
)
returns public.approvals
language plpgsql
security definer
as $$
declare
  v_row public.approvals;
begin
  if not (public.has_role('approver') or public.has_role('admin')) then
    raise exception 'not authorized';
  end if;

  if p_decision not in ('approved','rejected','cancelled') then
    raise exception 'invalid decision';
  end if;

  update public.approvals
  set status = p_decision,
      decided_at = now(),
      decided_by = auth.uid(),
      decision_reason = p_reason
  where id = p_approval_id
    and status = 'pending'
  returning * into v_row;

  if v_row.id is null then
    raise exception 'approval not found or not pending';
  end if;

  perform public.append_audit(v_row.domain, 'approval.decided', jsonb_build_object('decision', p_decision, 'reason', p_reason), v_row.correlation_id, null, 'rpc');

  return v_row;
end $$;

revoke all on function public.decide_approval(uuid,approval_status,text) from public;
grant execute on function public.decide_approval(uuid,approval_status,text) to authenticated;

-- Claim an approved action for execution (idempotent-ish: only one 'executing' at a time)
create or replace function public.claim_execution(p_approval_id uuid)
returns public.approvals
language plpgsql
security definer
as $$
declare
  v_row public.approvals;
begin
  update public.approvals
  set execution_status = 'executing',
      execution_attempts = execution_attempts + 1,
      execution_error = null
  where id = p_approval_id
    and status = 'approved'
    and execution_status in ('not_started','failed')
  returning * into v_row;

  if v_row.id is null then
    raise exception 'cannot claim execution (not approved, already executing, or succeeded)';
  end if;

  perform public.append_audit(v_row.domain, 'execution.claimed', jsonb_build_object('approval_id', p_approval_id), v_row.correlation_id, null, 'rpc');
  return v_row;
end $$;

revoke all on function public.claim_execution(uuid) from public;
-- Only service_role should execute this (Edge Functions)
grant execute on function public.claim_execution(uuid) to service_role;

-- Finish execution state
create or replace function public.finish_execution(
  p_approval_id uuid,
  p_status execution_status,
  p_error text
)
returns public.approvals
language plpgsql
security definer
as $$
declare
  v_row public.approvals;
begin
  if p_status not in ('succeeded','failed') then
    raise exception 'invalid execution status';
  end if;

  update public.approvals
  set execution_status = p_status,
      executed_at = case when p_status = 'succeeded' then now() else executed_at end,
      execution_error = case when p_status = 'failed' then p_error else null end
  where id = p_approval_id
    and status = 'approved'
    and execution_status = 'executing'
  returning * into v_row;

  if v_row.id is null then
    raise exception 'cannot finish execution (not executing)';
  end if;

  perform public.append_audit(v_row.domain, 'execution.finished', jsonb_build_object('status', p_status, 'error', p_error), v_row.correlation_id, null, 'rpc');
  return v_row;
end $$;

revoke all on function public.finish_execution(uuid,execution_status,text) from public;
grant execute on function public.finish_execution(uuid,execution_status,text) to service_role;

-- Record execution attempt outcome (append-only)
create or replace function public.record_action_execution(
  p_approval_id uuid,
  p_status text,
  p_outcome jsonb
)
returns uuid
language plpgsql
security definer
as $$
declare
  v_app public.approvals;
  v_id uuid;
begin
  select * into v_app from public.approvals where id = p_approval_id;
  if v_app.id is null then
    raise exception 'approval missing';
  end if;

  insert into public.action_executions(approval_id, domain, action, status, finished_at, outcome)
  values (v_app.id, v_app.domain, v_app.action, p_status, now(), coalesce(p_outcome,'{}'::jsonb))
  returning id into v_id;

  return v_id;
end $$;

revoke all on function public.record_action_execution(uuid,text,jsonb) from public;
grant execute on function public.record_action_execution(uuid,text,jsonb) to service_role;
