-- 0005_runbooks_slo_settings.sql
-- Runbooks + SLO metrics + non-secret settings.

create table if not exists public.rollback_runbooks (
  id uuid primary key default gen_random_uuid(),
  domain control_plane_domain not null,
  title text not null,
  steps_markdown text not null,
  created_by uuid references auth.users(id) default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_touch_runbooks on public.rollback_runbooks;
create trigger trg_touch_runbooks
before update on public.rollback_runbooks
for each row
execute function public.touch_updated_at();

alter table public.rollback_runbooks enable row level security;

drop policy if exists runbooks_select on public.rollback_runbooks;
create policy runbooks_select
on public.rollback_runbooks for select
to authenticated
using (true);

drop policy if exists runbooks_insert on public.rollback_runbooks;
create policy runbooks_insert
on public.rollback_runbooks for insert
to authenticated
with check (public.has_role('approver') or public.has_role('admin'));

drop policy if exists runbooks_update on public.rollback_runbooks;
create policy runbooks_update
on public.rollback_runbooks for update
to authenticated
using (public.has_role('approver') or public.has_role('admin'))
with check (public.has_role('approver') or public.has_role('admin'));

drop policy if exists runbooks_no_delete on public.rollback_runbooks;
create policy runbooks_no_delete
on public.rollback_runbooks for delete
to authenticated
using (false);

create table if not exists public.slo_metrics (
  id uuid primary key default gen_random_uuid(),
  domain control_plane_domain not null,
  metric text not null,
  value numeric not null,
  window_start timestamptz not null,
  window_end timestamptz not null,
  created_at timestamptz not null default now()
);

alter table public.slo_metrics enable row level security;

drop policy if exists slo_select on public.slo_metrics;
create policy slo_select
on public.slo_metrics for select
to authenticated
using (true);

drop policy if exists slo_no_insert on public.slo_metrics;
create policy slo_no_insert
on public.slo_metrics for insert
to authenticated
with check (false);

drop policy if exists slo_no_update on public.slo_metrics;
create policy slo_no_update
on public.slo_metrics for update
to authenticated
using (false);

drop policy if exists slo_no_delete on public.slo_metrics;
create policy slo_no_delete
on public.slo_metrics for delete
to authenticated
using (false);

create table if not exists public.settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

alter table public.settings enable row level security;

drop policy if exists settings_select on public.settings;
create policy settings_select
on public.settings for select
to authenticated
using (true);

drop policy if exists settings_admin_write on public.settings;
create policy settings_admin_write
on public.settings for all
to authenticated
using (public.has_role('admin'))
with check (public.has_role('admin'));
