-- 0001_core.sql
-- Core tables, enums, RLS policies, and immutability guardrails.

create extension if not exists pgcrypto;

-- Helper: role checks from JWT app_metadata.roles
create or replace function public.has_role(role_name text)
returns boolean
language sql
stable
as $$
  select exists (
    select 1
    from jsonb_array_elements_text(coalesce(auth.jwt() -> 'app_metadata' -> 'roles', '[]'::jsonb)) r
    where r = role_name
  );
$$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'approval_status') then
    create type approval_status as enum ('pending','approved','rejected','expired','cancelled');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'control_plane_domain') then
    create type control_plane_domain as enum ('foh','boh','platform');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'execution_status') then
    create type execution_status as enum ('not_started','executing','succeeded','failed');
  end if;
end $$;

create table if not exists public.approvals (
  id uuid primary key default gen_random_uuid(),
  domain control_plane_domain not null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  requester uuid not null default auth.uid() references auth.users(id) on delete cascade,
  status approval_status not null default 'pending',
  requested_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by uuid references auth.users(id),
  decision_reason text,
  expires_at timestamptz,
  correlation_id uuid not null default gen_random_uuid(),

  -- Execution tracking (allowed to change post-decision, via server-only RPC)
  execution_status execution_status not null default 'not_started',
  execution_attempts int not null default 0,
  executed_at timestamptz,
  execution_error text
);

create index if not exists approvals_status_idx on public.approvals(status);
create index if not exists approvals_domain_idx on public.approvals(domain);
create index if not exists approvals_requester_idx on public.approvals(requester);
create index if not exists approvals_corr_idx on public.approvals(correlation_id);

-- Decision-field immutability after decision: allows only execution_* columns to change.
create or replace function public.enforce_approval_immutability()
returns trigger
language plpgsql
as $$
begin
  if old.status <> 'pending' then
    if (new.domain is distinct from old.domain)
      or (new.action is distinct from old.action)
      or (new.details is distinct from old.details)
      or (new.requester is distinct from old.requester)
      or (new.status is distinct from old.status)
      or (new.requested_at is distinct from old.requested_at)
      or (new.decided_at is distinct from old.decided_at)
      or (new.decided_by is distinct from old.decided_by)
      or (new.decision_reason is distinct from old.decision_reason)
      or (new.correlation_id is distinct from old.correlation_id)
      or (new.expires_at is distinct from old.expires_at)
    then
      raise exception 'approval immutable after decision';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists trg_enforce_approval_immutability on public.approvals;
create trigger trg_enforce_approval_immutability
before update on public.approvals
for each row
execute function public.enforce_approval_immutability();

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  domain control_plane_domain not null,
  event_type text not null,
  actor_id uuid references auth.users(id),
  ip inet,
  user_agent text,
  correlation_id uuid,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);
create index if not exists audit_logs_corr_idx on public.audit_logs(correlation_id);

create table if not exists public.action_executions (
  id uuid primary key default gen_random_uuid(),
  approval_id uuid not null references public.approvals(id) on delete restrict,
  domain control_plane_domain not null,
  action text not null,
  status text not null check (status in ('started','succeeded','failed')),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  outcome jsonb not null default '{}'::jsonb
);

create index if not exists action_exec_approval_idx on public.action_executions(approval_id);
create index if not exists action_exec_started_idx on public.action_executions(started_at desc);

-- RLS
alter table public.approvals enable row level security;
alter table public.audit_logs enable row level security;
alter table public.action_executions enable row level security;

-- Approvals
drop policy if exists approvals_select_scope on public.approvals;
create policy approvals_select_scope
on public.approvals for select
to authenticated
using (
  requester = auth.uid()
  or public.has_role('approver')
  or public.has_role('admin')
);

drop policy if exists approvals_insert_self on public.approvals;
create policy approvals_insert_self
on public.approvals for insert
to authenticated
with check (requester = auth.uid());

drop policy if exists approvals_no_update on public.approvals;
create policy approvals_no_update
on public.approvals for update
to authenticated
using (false);

drop policy if exists approvals_no_delete on public.approvals;
create policy approvals_no_delete
on public.approvals for delete
to authenticated
using (false);

-- Audit logs: users can read their own; approver/admin can read all.
drop policy if exists audit_select_scope on public.audit_logs;
create policy audit_select_scope
on public.audit_logs for select
to authenticated
using (
  actor_id = auth.uid()
  or public.has_role('approver')
  or public.has_role('admin')
);

-- No direct insert/update/delete from authenticated; use RPC or service_role.
drop policy if exists audit_no_insert on public.audit_logs;
create policy audit_no_insert
on public.audit_logs for insert
to authenticated
with check (false);

drop policy if exists audit_no_update on public.audit_logs;
create policy audit_no_update
on public.audit_logs for update
to authenticated
using (false);

drop policy if exists audit_no_delete on public.audit_logs;
create policy audit_no_delete
on public.audit_logs for delete
to authenticated
using (false);

-- action_executions: requester can read executions for their approvals; approver/admin can read all.
drop policy if exists action_exec_select_scope on public.action_executions;
create policy action_exec_select_scope
on public.action_executions for select
to authenticated
using (
  public.has_role('approver')
  or public.has_role('admin')
  or approval_id in (select id from public.approvals where requester = auth.uid())
);

drop policy if exists action_exec_no_insert on public.action_executions;
create policy action_exec_no_insert
on public.action_executions for insert
to authenticated
with check (false);

drop policy if exists action_exec_no_update on public.action_executions;
create policy action_exec_no_update
on public.action_executions for update
to authenticated
using (false);

drop policy if exists action_exec_no_delete on public.action_executions;
create policy action_exec_no_delete
on public.action_executions for delete
to authenticated
using (false);
