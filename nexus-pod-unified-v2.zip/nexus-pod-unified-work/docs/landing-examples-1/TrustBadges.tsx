'use client';

import React from 'react';

interface Badge {
  name: string;
  imageUrl?: string;
  description?: string;
  verified?: boolean;
}

interface TrustBadgesProps {
  title?: string;
  badges: Badge[];
  layout?: 'horizontal' | 'grid' | 'inline';
  size?: 'small' | 'medium' | 'large';
  showDescription?: boolean;
}

/**
 * TrustBadges - Security, compliance, and certification badges
 * 
 * Usage: Non-compliance messaging = 23% higher abandonment rates.
 * Display SOC 2, GDPR, HIPAA, ISO, and other trust signals.
 * 
 * @param title - Optional section heading
 * @param badges - Array of trust badges with name, image, and optional description
 * @param layout - Display style: horizontal (single row), grid (multi-row), inline (minimal)
 * @param size - Badge size: small (48px), medium (64px), large (80px)
 * @param showDescription - Display badge descriptions on hover
 */
export default function TrustBadges({
  title,
  badges,
  layout = 'horizontal',
  size = 'medium',
  showDescription = false,
}: TrustBadgesProps) {
  const sizeMap = {
    small: '48px',
    medium: '64px',
    large: '80px',
  };

  return (
    <div className="trust-badges-section">
      {title && (
        <div className="badges-header">
          <h3>{title}</h3>
        </div>
      )}

      <div className={`badges-container layout-${layout}`}>
        {badges.map((badge, index) => (
          <div key={index} className="badge-item">
            {badge.imageUrl ? (
              <div className="badge-image">
                <img src={badge.imageUrl} alt={badge.name} loading="lazy" />
                {badge.verified && (
                  <div className="verified-indicator">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <circle cx="10" cy="10" r="10" fill="#10b981" />
                      <path
                        d="M6 10l2.5 2.5L14 7"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                )}
              </div>
            ) : (
              <div className="badge-placeholder">
                <span>{badge.name}</span>
              </div>
            )}
            
            {showDescription && badge.description && (
              <div className="badge-tooltip">
                <p>{badge.description}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      <style jsx>{`
        .trust-badges-section {
          padding: 40px 20px;
          background: var(--gray-50);
          border-top: 1px solid var(--gray-200);
        }

        .badges-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .badges-header h3 {
          font-size: 1rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--gray-600);
        }

        /* Layout Variants */
        .badges-container {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .layout-horizontal {
          flex-wrap: wrap;
          gap: 32px;
        }

        .layout-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 24px;
        }

        .layout-inline {
          gap: 20px;
          flex-wrap: nowrap;
        }

        /* Badge Items */
        .badge-item {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .badge-image {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          width: ${sizeMap[size]};
          height: ${sizeMap[size]};
          padding: 8px;
          background: white;
          border-radius: 8px;
          border: 1px solid var(--gray-200);
          transition: all 0.3s ease;
        }

        .badge-item:hover .badge-image {
          border-color: var(--primary);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
          transform: translateY(-2px);
        }

        .badge-image img {
          max-width: 100%;
          max-height: 100%;
          width: auto;
          height: auto;
          object-fit: contain;
        }

        .verified-indicator {
          position: absolute;
          top: -8px;
          right: -8px;
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }

        .badge-placeholder {
          display: flex;
          align-items: center;
          justify-content: center;
          width: ${sizeMap[size]};
          height: ${sizeMap[size]};
          background: white;
          border: 2px dashed var(--gray-300);
          border-radius: 8px;
          font-size: 0.75rem;
          font-weight: 600;
          color: var(--gray-600);
          text-align: center;
          padding: 8px;
        }

        /* Tooltip */
        .badge-tooltip {
          position: absolute;
          bottom: calc(100% + 12px);
          left: 50%;
          transform: translateX(-50%);
          padding: 12px 16px;
          background: var(--gray-900);
          color: white;
          border-radius: 8px;
          font-size: 0.875rem;
          line-height: 1.5;
          white-space: nowrap;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.2s ease;
          z-index: 10;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .badge-tooltip::after {
          content: '';
          position: absolute;
          top: 100%;
          left: 50%;
          transform: translateX(-50%);
          border: 6px solid transparent;
          border-top-color: var(--gray-900);
        }

        .badge-item:hover .badge-tooltip {
          opacity: 1;
        }

        /* Responsive */
        @media (max-width: 768px) {
          .trust-badges-section {
            padding: 32px 16px;
          }

          .badges-header {
            margin-bottom: 24px;
          }

          .layout-horizontal {
            gap: 20px;
          }

          .layout-grid {
            grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
            gap: 16px;
          }

          .layout-inline {
            flex-wrap: wrap;
            gap: 16px;
          }

          .badge-image {
            width: ${size === 'large' ? '60px' : size === 'medium' ? '50px' : '40px'};
            height: ${size === 'large' ? '60px' : size === 'medium' ? '50px' : '40px'};
            padding: 6px;
          }

          .badge-placeholder {
            width: ${size === 'large' ? '60px' : size === 'medium' ? '50px' : '40px'};
            height: ${size === 'large' ? '60px' : size === 'medium' ? '50px' : '40px'};
            font-size: 0.625rem;
          }

          .verified-indicator {
            width: 16px;
            height: 16px;
            top: -6px;
            right: -6px;
          }

          .verified-indicator svg {
            width: 16px;
            height: 16px;
          }

          .badge-tooltip {
            white-space: normal;
            max-width: 200px;
          }
        }
      `}</style>
    </div>
  );
}
