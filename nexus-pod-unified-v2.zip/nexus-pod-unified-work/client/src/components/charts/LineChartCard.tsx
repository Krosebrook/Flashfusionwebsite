import * as React from "react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Card } from "@/components/ui/Card";

type LineDef = {
  dataKey: string;
  label: string;
};

function DefaultTooltip({ active, payload, label, formatter }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-3 text-xs">
      <div className="font-semibold mb-1">{label}</div>
      <div className="space-y-1">
        {payload.map((p: any) => (
          <div key={p.dataKey} className="flex items-center justify-between gap-6">
            <span className="text-slate-500 dark:text-slate-400">{p.name}</span>
            <span className="font-medium">{formatter ? formatter(p.value, p.dataKey) : String(p.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function LineChartCard<T extends Record<string, any>>(props: {
  title: string;
  data: T[];
  xKey: keyof T;
  lines: LineDef[];
  yFormatter?: (value: any, dataKey?: string) => string;
  height?: number;
}) {
  const { title, data, xKey, lines, yFormatter, height = 340 } = props;
  return (
    <Card className="p-4" style={{ height }}>
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{title}</h3>
      </div>
      <div className="mt-4" style={{ height: height - 64 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
            <XAxis dataKey={String(xKey)} tickLine={false} axisLine={false} fontSize={12} />
            <YAxis tickLine={false} axisLine={false} fontSize={12} tickFormatter={(v) => (yFormatter ? yFormatter(v) : String(v))} />
            <Tooltip content={<DefaultTooltip formatter={yFormatter} />} />
            {lines.map((l, idx) => (
              <Line
                key={l.dataKey}
                type="monotone"
                dataKey={l.dataKey}
                name={l.label}
                strokeWidth={2}
                dot={false}
                // A small deterministic palette
                stroke={idx === 0 ? "#4f46e5" : idx === 1 ? "#0ea5e9" : idx === 2 ? "#10b981" : "#f97316"}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
