import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Palette,
  Store,
  Settings,
  Layers,
  Wand2,
  BarChart3,
  Receipt,
  Wallet,
  Truck,
  ShieldCheck,
  UploadCloud,
  Bot
} from 'lucide-react';
import clsx from 'clsx';

const NAV = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/analytics', icon: BarChart3, label: 'Analytics' },
  { to: '/orders', icon: Receipt, label: 'Orders' },
  { to: '/profit', icon: Wallet, label: 'Profit' },
  { to: '/fulfillment', icon: Truck, label: 'Fulfillment' },
  { to: '/products', icon: Package, label: 'Products' },
  { to: '/bulk-generator', icon: Wand2, label: 'Bulk Generator' },
  { to: '/templates', icon: Layers, label: 'Templates' },
  { to: '/design-studio', icon: Palette, label: 'Design Studio' },
  { to: '/publishing', icon: UploadCloud, label: 'Publishing Suite' },
  { to: '/automations', icon: Bot, label: 'Automation Suite' },
  { to: '/stores', icon: Store, label: 'Stores' },
  { to: '/readiness', icon: ShieldCheck, label: 'Readiness' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 flex flex-col h-screen fixed left-0 top-0 z-20">
      <div className="p-6 flex items-center gap-3 border-b border-slate-100 dark:border-slate-900">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">P</div>
        <span className="font-bold text-lg dark:text-white">POD Hub</span>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => clsx(
              'flex items-center gap-3 px-4 py-3 rounded-lg transition-all',
              isActive 
                ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400 font-medium shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900'
            )}
          >
            <item.icon size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3 px-4 py-2">
          <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-xs font-bold text-indigo-700 dark:text-indigo-300">JD</div>
          <div className="text-sm">
            <p className="font-medium dark:text-white">John Doe</p>
            <p className="text-xs text-slate-500">Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}