export type ProductStatus = 'DRAFT' | 'READY' | 'PUBLISHED';
export type ProductType = 'T_SHIRT' | 'HOODIE' | 'MUG';

export type StoreKind = 'shopify' | 'etsy' | 'printify' | 'woocommerce';

export interface ProductVariant {
  size: string;
  color: string;
  sku: string;
  inventory: number;
}

export interface Product {
  id: string;
  title: string;
  description?: string;
  productType: ProductType;
  price: number;
  cost: number;
  status: ProductStatus;
  designAssetId: string | null;
  storeId: string | null;
  tags: string[];
  variants: ProductVariant[];
  createdAt: string;
  updatedAt: string;
}

export interface StoreConnection {
  id: string;
  /** Human-facing platform name (used in UI lists). */
  platform: string;
  /** Optional canonical kind used by publishing + readiness. */
  kind?: StoreKind;
  storeName: string;
  apiKeyMasked: string;
  connectedAt: string;
  status: 'CONNECTED' | 'DISCONNECTED';
}

export interface DesignAsset {
  id: string;
  name: string;
  prompt: string;
  imageDataUrl: string; // data URL
  createdAt: string;
  /** Optional server-backed download URL (preferred for large assets). */
  downloadUrl?: string;
  filename?: string;
  expiresAt?: string;
  provider?: 'mock' | 'openai';
  mime?: string;
}

export interface PublishEvent {
  id: string;
  productId: string;
  storeId: string;
  storeKind: StoreKind;
  status: 'SUCCESS' | 'FAILED';
  publishedAt: string;
  url?: string;
  notes?: string;
}

export interface ProductTemplate {
  id: string;
  name: string;
  baseProductType: ProductType;
  defaultPrice: number;
  defaultCost: number;
  defaultTags: string[];
  createdAt: string;
}

export interface Order {
  id: string;
  customerName: string;
  total: number;
  status: 'PENDING' | 'SHIPPED' | 'DELIVERED';
  items: { productId: string; quantity: number }[];
  createdAt: string;
}

// -----------------------------
// Web-grounded seed & analytics
// -----------------------------

export type SeedSource = {
  name: string;
  url: string;
  asOf: string; // ISO date
  note?: string;
};

export type SeedBenchmarks = {
  conversionRateTypical: number;
  conversionRateShopifyAvg: number;
  conversionRateGood: number;
  printifyProductionDays: { min: number; max: number };
  printfulFulfillmentDays: { min: number; max: number };
  baselineCostsUsd: { tee: number; hoodie: number; mug: number };
};

export type SeedTimeseriesPoint = {
  date: string; // YYYY-MM-DD
  sessions: number;
  orders: number;
  revenue: number;
  adSpend: number;
  conversionRate: number;
  aov: number;
};

export type SeedPayload = {
  generatedAt: string;
  sources: SeedSource[];
  benchmarks: SeedBenchmarks;
  timeseries: SeedTimeseriesPoint[];
  products: Product[];
  templates: ProductTemplate[];
  orders: Order[];
  stores: StoreConnection[];
};

export type SeedMeta = Pick<SeedPayload, 'generatedAt' | 'sources' | 'benchmarks' | 'timeseries'>;

// -----------------------------
// Readiness report (backend)
// -----------------------------

export type ReadinessStatus = 'OK' | 'WARN' | 'MISSING' | 'ERROR';

export type ReadinessItem = {
  id: string;
  label: string;
  status: ReadinessStatus;
  detail?: string;
  envVars?: string[];
  docsUrl?: string;
  fix?: string[];
};

export type ReadinessCategory = {
  id: string;
  title: string;
  score: number;
  items: ReadinessItem[];
};

export type ReadinessConnectivity = Record<
  string,
  { ok: boolean; detail?: string; status?: number }
>;

export type ReadinessReport = {
  ok: boolean;
  mode: 'LIVE' | 'PARTIAL' | 'DEMO';
  score: number;
  generatedAt: string;
  missingEnvVars: string[];
  warnings: string[];
  categories: ReadinessCategory[];
  connectivity?: ReadinessConnectivity;
};

// -----------------------------
// Automation suite (client-side)
// -----------------------------

export type AutomationTrigger =
  | { type: 'MANUAL' }
  | { type: 'ON_STATUS_READY' }
  | { type: 'SCHEDULED'; cron: string };

export type AutomationAction =
  | { type: 'PUBLISH_READY_PRODUCTS'; store: StoreKind }
  | { type: 'EXPORT_KPI_CSV' }
  | { type: 'EXPORT_ORDERS_CSV' };

export type AutomationRule = {
  id: string;
  name: string;
  enabled: boolean;
  trigger: AutomationTrigger;
  action: AutomationAction;
  createdAt: string;
  lastRunAt?: string;
  lastRunStatus?: 'SUCCESS' | 'FAILED';
  lastRunMessage?: string;
};
