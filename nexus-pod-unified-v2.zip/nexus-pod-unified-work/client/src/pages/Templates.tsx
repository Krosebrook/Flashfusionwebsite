import * as React from "react";
import { Layers, Plus } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { uuid } from "@/utils/id";
import type { ProductTemplate } from "@/types";

export default function Templates() {
  const { templates, addTemplate } = useAppData();

  const createTemplate = () => {
    const name = prompt("Template name (e.g., 'Vintage Tee - Quotes')")?.trim();
    if (!name) return;

    const t: ProductTemplate = {
      id: uuid(),
      name,
      baseProductType: "T_SHIRT",
      defaultPrice: 24.99,
      defaultCost: 9.5,
      defaultTags: ["template"],
      createdAt: new Date().toISOString()
    };

    addTemplate(t);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Templates</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Reusable product defaults for bulk generation.</p>
        </div>
        <Button variant="secondary" onClick={createTemplate}>
          <Plus className="h-4 w-4 mr-2" />
          New template
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {templates.map((t) => (
          <Card key={t.id} className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Layers className="h-4 w-4 text-indigo-500" />
                  <h3 className="font-semibold">{t.name}</h3>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                  {t.baseProductType} • ${t.defaultPrice} • Tags: {t.defaultTags.join(", ")}
                </p>
              </div>
              <span className="text-xs text-slate-400">{new Date(t.createdAt).toLocaleDateString()}</span>
            </div>
          </Card>
        ))}

        {templates.length === 0 && (
          <Card className="p-10 md:col-span-2">
            <div className="text-center text-slate-500 dark:text-slate-400">No templates yet. Create one to speed up generation.</div>
          </Card>
        )}
      </div>
    </div>
  );
}
