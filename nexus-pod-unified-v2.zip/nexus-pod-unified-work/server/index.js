// Boot file required by the root `npm start` script.
// This keeps the runtime portable (Node runs JS), while the source lives in TypeScript under src/.
import "./dist/index.js";
