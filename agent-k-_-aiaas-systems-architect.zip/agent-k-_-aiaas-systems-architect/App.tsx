
import React, { useState, Suspense, lazy } from 'react';
import { Sidebar } from './components/Sidebar';
import { MetricsGrid } from './components/MetricsGrid';
import { ErrorBoundary } from './components/ErrorBoundary';
import { useProfile } from './hooks/useProfile';
import { useSystemUptime } from './hooks/useSystemUptime';

// Lazy loaded views for production performance
const SystemArchitecture = lazy(() => import('./components/SystemArchitecture').then(m => ({ default: m.SystemArchitecture })));
const ModelRouter = lazy(() => import('./components/ModelRouter').then(m => ({ default: m.ModelRouter })));
const SecurityDashboard = lazy(() => import('./components/SecurityDashboard').then(m => ({ default: m.SecurityDashboard })));
const ChatTerminal = lazy(() => import('./components/ChatTerminal').then(m => ({ default: m.ChatTerminal })));
const ProductDesigner = lazy(() => import('./components/ProductDesigner').then(m => ({ default: m.ProductDesigner })));
const AIaaSConsole = lazy(() => import('./components/AIaaSConsole').then(m => ({ default: m.AIaaSConsole })));

export type ViewState = 'architecture' | 'routing' | 'security' | 'terminal' | 'designer' | 'aiaas' | 'settings';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ViewState>('architecture');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const { profile, setProfile } = useProfile();
  const systemUptime = useSystemUptime();

  const renderView = () => {
    switch (activeView) {
      case 'architecture': return <SystemArchitecture profile={profile} />;
      case 'routing': return <ModelRouter />;
      case 'security': return <SecurityDashboard />;
      case 'terminal': return <ChatTerminal profile={profile} />;
      case 'designer': return <ProductDesigner />;
      case 'aiaas': return <AIaaSConsole />;
      case 'settings': return (
        <div className="bg-gray-900 border border-gray-800 rounded-[3rem] p-12 space-y-12 shadow-2xl animate-in fade-in duration-500">
          <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter border-b border-gray-800 pb-8">Global Configuration</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h3 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">User Profile</h3>
              <div className="space-y-4">
                <input 
                  type="text" 
                  value={profile.name} 
                  onChange={e => setProfile({...profile, name: e.target.value})}
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl p-4 text-sm mono focus:border-blue-500 text-gray-100 transition-colors"
                  placeholder="Architect Name"
                />
                <input 
                  type="text" 
                  value={profile.role} 
                  onChange={e => setProfile({...profile, role: e.target.value})}
                  className="w-full bg-gray-950 border border-gray-800 rounded-2xl p-4 text-sm mono focus:border-blue-500 text-gray-100 transition-colors"
                  placeholder="System Role"
                />
              </div>
            </div>
            <div className="space-y-6">
              <h3 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Environment Status</h3>
              <div className="bg-gray-950 border border-gray-800 rounded-2xl p-6 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">API Runtime</span>
                  <span className="text-[10px] font-black text-emerald-500 uppercase">Authenticated</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Node Region</span>
                  <span className="text-[10px] font-black text-blue-500 uppercase">US-EAST-1</span>
                </div>
                <div className="mt-4 p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl">
                  <p className="text-[9px] text-gray-500 leading-relaxed uppercase font-bold">Security Notice: API credentials are managed via secure environment injection. Manual overrides are disabled for production integrity.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
      default: return null;
    }
  };

  const LoadingFallback = () => (
    <div className="h-full flex flex-col items-center justify-center p-20 animate-pulse">
      <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-6"></div>
      <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em] mono">Initializing Node Telemetry...</span>
    </div>
  );

  return (
    <div className={`flex h-screen overflow-hidden ${profile.preferences.theme === 'dark' ? 'bg-[#030712]' : 'bg-gray-50'} text-gray-100 font-sans`}>
      <Sidebar 
        activeView={activeView} 
        onViewChange={setActiveView} 
        isOpen={isSidebarOpen}
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        profile={profile}
      />

      <main className="flex-1 flex flex-col min-w-0 h-full relative overflow-hidden bg-grid-pattern">
        <header className="h-16 border-b border-gray-900 flex items-center justify-between px-8 shrink-0 bg-[#030712]/80 backdrop-blur-xl z-10">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <h1 className="text-xs font-black tracking-[0.2em] text-blue-500 uppercase mono leading-none mb-1">
                Agent-K // {profile.name.split(' ')[0]} Console
              </h1>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mono">Node: {activeView.toUpperCase()}</span>
                <span className="w-1 h-1 rounded-full bg-gray-700"></span>
                <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest mono animate-pulse">Status: Operational</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mono">Uptime</span>
              <span className="text-xs font-black text-blue-500 mono">{systemUptime}</span>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 scroll-smooth custom-scrollbar relative">
          <div className="max-w-[1400px] mx-auto space-y-8">
            <ErrorBoundary>
              <Suspense fallback={<LoadingFallback />}>
                {renderView()}
              </Suspense>
            </ErrorBoundary>
            
            <div className="mt-12 pt-12 border-t border-gray-900">
              <MetricsGrid />
            </div>
          </div>
        </div>

        <footer className="h-10 border-t border-gray-900 bg-[#030712] flex items-center px-8 justify-between text-[10px] mono text-gray-600 shrink-0 font-bold uppercase tracking-widest">
          <div className="flex gap-8">
            <span>REGION: US-EAST-1</span>
            <span>VER: 6.0.1-PROD</span>
          </div>
          <span className="text-blue-500">SYSTEM_INTEGRITY: OPTIMAL</span>
        </footer>
      </main>

      <style>{`
        .bg-grid-pattern {
          background-image: radial-gradient(#1e293b 0.5px, transparent 0.5px);
          background-size: 24px 24px;
        }
      `}</style>
    </div>
  );
};

export default App;
