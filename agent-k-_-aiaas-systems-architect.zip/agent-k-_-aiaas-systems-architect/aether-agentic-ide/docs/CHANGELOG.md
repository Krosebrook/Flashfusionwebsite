# Changelog

All notable changes to this project will be documented in this file.

## [0.1.4] - 2024-05-22
### Added
- **Image Lab**: A specialized workspace for multi-modal image generation.
- Support for `gemini-2.5-flash-image` and `gemini-3-pro-image-preview`.
- Neural synthesis pipeline with reassuring progress messaging.
- Billing-aware API key selection logic for high-fidelity models.
- Image export and aspect ratio customization.

Provenance:
- Source: components/ImageGenerator.tsx
- Locator: UI/Inference Layer
- Confidence: HIGH
- Last Verified: 2024-05-22

## [0.1.3] - 2024-05-22
### Enhanced
- `ApiTerminal` diagnostic engine: Improved `diagnoseError` with provider-specific logic for OpenAI, Anthropic, and Groq.
- Terminal UI: Elevated error prominence with larger iconography, shadow-casting, and high-visibility documentation access points.
- Error Protocol: Standardized `ActionableError` interface to include mandatory documentation links.

Provenance:
- Source: components/ApiTerminal.tsx
- Locator: Diagnostic Layer
- Confidence: HIGH
- Last Verified: 2024-05-22

## [0.1.2] - 2024-05-22
### Added
- Real-time streaming status indicators in `ApiTerminal`.
- Pulsating "LIVE" badge for active inference nodes.
- Subtle progress animation during protocol streaming.

Provenance:
- Source: components/ApiTerminal.tsx
- Locator: UI/UX Layer
- Confidence: HIGH
- Last Verified: 2024-05-22

## [0.1.1] - 2024-05-22
### Added
- Enhanced `manifest.json` with standard PWA metadata (`id`, `scope`, `categories`).
- Deep-link shortcuts for Workflow Engine and API Terminal.

Provenance:
- Source: manifest.json
- Locator: root
- Confidence: HIGH
- Last Verified: 2024-05-22

## [0.1.0] - 2024-05-22
### Added
- Repository baseline established.
- Documentation Authority system initialized.
- Core documentation shells created (`SECURITY.md`, `ARCHITECTURE.md`, `FRAMEWORK.md`).
- `llms.txt` and `llms-full.txt` generation pipeline.

Provenance:
- Source: git history (implied)
- Locator: Initial Commit
- Confidence: HIGH
- Last Verified: 2024-05-22
