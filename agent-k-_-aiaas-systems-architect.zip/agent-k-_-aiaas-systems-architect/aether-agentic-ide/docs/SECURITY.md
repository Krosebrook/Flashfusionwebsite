# Security Policy

## Threat Model
> Status: UNKNOWN
> Action Required: Human Review. Define threat actors and attack surfaces.
> Confidence: LOW

## Prompt Injection
System uses `@google/genai`.
> Status: UNKNOWN. Are input sanitization or output validation guardrails in place?
> Action Required: Human Review.
> Confidence: LOW

## NHI (Non-Human Identity)
API keys are handled via `process.env.API_KEY` (server-side injection).
Additional keys stored in `Dexie` (IndexedDB) via `ApiKeysContext`.
- Source: `contexts/ApiKeysContext.tsx`
- Confidence: HIGH
- Last Verified: 2024-05-22

## Egress
- `services/geminiService.ts`: Outbound calls to Google GenAI API.
- Source: `services/geminiService.ts`
- Confidence: HIGH

## Patch Policy
> Status: UNKNOWN
> Action Required: Human Review.
> Confidence: LOW

## Incident Response
> Status: UNKNOWN
> Action Required: Human Review.
> Confidence: LOW

## Kill Switch
> Status: UNKNOWN
> Action Required: Human Review. Define mechanism to stop agent autonomy.
> Confidence: LOW
