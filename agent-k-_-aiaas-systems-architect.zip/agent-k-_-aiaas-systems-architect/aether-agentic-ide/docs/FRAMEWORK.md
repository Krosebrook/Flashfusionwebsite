# Technical Framework

## Stack
- **Frontend**: React 19 (`index.tsx`).
- **Styling**: Tailwind CSS (`index.html`).
- **Icons**: Lucide React.
- **Charts**: Recharts.
- **AI SDK**: `@google/genai`.
- **Persistence**: Dexie (IndexedDB) + LocalStorage.
- Source: `index.html` importmap, `package.json` (inferred).
- Confidence: HIGH

## LLM Models/Roles
- **Models**: Gemini 3 Flash, Gemini 3 Pro, Gemini Flash Lite, Imagen.
- **Roles**: Defined in `types.ts` (`ModelType` enum).
- Source: `types.ts`.
- Confidence: HIGH

## Tooling Boundaries
- **Build System**: ES Modules via CDN (esm.sh) defined in `index.html` importmap.
- Source: `index.html`.
- Confidence: HIGH

## CI/CD Hooks
- GitHub Actions workflow `docs-authority.yml` ensures documentation integrity.
- Source: `.github/workflows/docs-authority.yml`.
- Confidence: HIGH
