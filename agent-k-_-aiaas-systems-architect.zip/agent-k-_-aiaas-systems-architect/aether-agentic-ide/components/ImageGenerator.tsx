
import React, { useState, useCallback } from 'react';
import { 
  Image as ImageIcon, 
  Download, 
  Sparkles, 
  Settings2, 
  Maximize2, 
  ChevronRight, 
  AlertCircle,
  Loader2,
  Trash2,
  ExternalLink,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { ModelType } from '../types';

// Fixing TypeScript errors for global aistudio declaration. 
// Using AIStudio interface name and readonly modifier as expected by the environment.
declare global {
  interface AIStudio {
    hasSelectedApiKey(): Promise<boolean>;
    openSelectKey(): Promise<void>;
  }

  interface Window {
    readonly aistudio: AIStudio;
  }
}

interface ImageResult {
  url: string;
  prompt: string;
  timestamp: number;
  model: string;
}

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<ImageResult[]>([]);
  const [loadingMessage, setLoadingMessage] = useState('');
  
  // Settings
  const [model, setModel] = useState<ModelType>(ModelType.IMAGE);
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '3:4' | '4:3' | '9:16' | '16:9'>('1:1');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [useSearch, setUseSearch] = useState(false);

  const loadingMessages = [
    "Synthesizing neural latent space...",
    "Injecting chromatic variances...",
    "Defining structural geometry...",
    "Optimizing pixel density...",
    "Finalizing image manifold...",
    "Rendering visual semantics..."
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setError(null);
    setIsGenerating(true);
    
    let msgIdx = 0;
    setLoadingMessage(loadingMessages[0]);
    const msgInterval = setInterval(() => {
      msgIdx = (msgIdx + 1) % loadingMessages.length;
      setLoadingMessage(loadingMessages[msgIdx]);
    }, 3000);

    try {
      // Logic for Gemini 3 Pro requiring API key selection
      if (model === ModelType.IMAGE_PRO) {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await window.aistudio.openSelectKey();
        }
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const config: any = {
        imageConfig: {
          aspectRatio
        }
      };

      if (model === ModelType.IMAGE_PRO) {
        config.imageConfig.imageSize = imageSize;
        if (useSearch) {
          config.tools = [{ google_search: {} }];
        }
      }

      const response = await ai.models.generateContent({
        model: model,
        contents: {
          parts: [{ text: prompt }]
        },
        config
      });

      let imageUrl = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setResults(prev => [{
          url: imageUrl,
          prompt,
          timestamp: Date.now(),
          model
        }, ...prev]);
        setPrompt('');
      } else {
        throw new Error("Model failed to return image data.");
      }

    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setError("API Key configuration error. Please re-select your key.");
        await window.aistudio.openSelectKey();
      } else {
        setError(err.message || "Visual synthesis failure.");
      }
    } finally {
      clearInterval(msgInterval);
      setIsGenerating(false);
    }
  };

  const downloadImage = (url: string, p: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `aether-gen-${p.slice(0, 20).replace(/\s/g, '-')}-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden font-sans">
      <header className="px-8 py-6 border-b border-slate-800 bg-slate-950/50 backdrop-blur-md flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-indigo-500/10 rounded-xl">
            <ImageIcon className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
              Image Lab <span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded uppercase tracking-widest font-mono">Neural Synthesis</span>
            </h2>
            <p className="text-xs text-slate-500">Multi-modal generative engine powered by Gemini</p>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Settings Panel */}
        <div className="w-80 border-r border-slate-800 p-6 flex flex-col gap-8 bg-slate-950/40 backdrop-blur-2xl overflow-y-auto scrollbar-hide shrink-0">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-400">
              <Settings2 className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Synthesis Parameters</span>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Compute Node</label>
                <select 
                  value={model}
                  onChange={(e) => setModel(e.target.value as ModelType)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
                >
                  <option value={ModelType.IMAGE}>Gemini 2.5 Flash Image</option>
                  <option value={ModelType.IMAGE_PRO}>Gemini 3 Pro Image (2K/4K)</option>
                </select>
                {model === ModelType.IMAGE_PRO && (
                  <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl space-y-2">
                    <p className="text-[9px] text-amber-500 leading-tight font-medium flex items-center gap-2">
                      <AlertCircle className="w-3 h-3" /> External Billing Required
                    </p>
                    <a 
                      href="https://ai.google.dev/gemini-api/docs/billing" 
                      target="_blank" 
                      className="text-[8px] text-indigo-400 hover:text-indigo-300 underline font-bold uppercase tracking-tighter flex items-center gap-1"
                    >
                      Billing Docs <ExternalLink className="w-2 h-2" />
                    </a>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Aspect Ratio</label>
                <div className="grid grid-cols-3 gap-2">
                  {['1:1', '3:4', '4:3', '9:16', '16:9'].map(ratio => (
                    <button
                      key={ratio}
                      onClick={() => setAspectRatio(ratio as any)}
                      className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${aspectRatio === ratio ? 'bg-indigo-600/10 border-indigo-500 text-indigo-400' : 'bg-slate-900 border-slate-800 text-slate-500 hover:border-slate-700'}`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              {model === ModelType.IMAGE_PRO && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
                  <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Resolution</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['1K', '2K', '4K'].map(size => (
                      <button
                        key={size}
                        onClick={() => setImageSize(size as any)}
                        className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${imageSize === size ? 'bg-indigo-600/10 border-indigo-500 text-indigo-400' : 'bg-slate-900 border-slate-800 text-slate-500 hover:border-slate-700'}`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {model === ModelType.IMAGE_PRO && (
                <div className="pt-4 border-t border-slate-800 space-y-3">
                   <button 
                    onClick={() => setUseSearch(!useSearch)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${useSearch ? 'bg-indigo-600/10 border-indigo-500/30 shadow-lg' : 'bg-slate-900 border-slate-800 hover:border-slate-700'}`}
                   >
                     <div className="flex items-center gap-3">
                       <Globe className={`w-4 h-4 ${useSearch ? 'text-indigo-400' : 'text-slate-600'}`} />
                       <div className="text-left">
                         <p className={`text-[10px] font-bold ${useSearch ? 'text-indigo-200' : 'text-slate-400'}`}>Search Grounding</p>
                         <p className="text-[8px] text-slate-600 font-medium">Use real-time context</p>
                       </div>
                     </div>
                     <div className={`w-8 h-4 rounded-full p-1 transition-colors ${useSearch ? 'bg-indigo-600' : 'bg-slate-700'}`}>
                        <div className={`w-2 h-2 bg-white rounded-full transition-transform ${useSearch ? 'translate-x-4' : 'translate-x-0'}`} />
                     </div>
                   </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Workspace */}
        <div className="flex-1 flex flex-col p-8 gap-8 overflow-y-auto bg-slate-950 scrollbar-hide">
          {/* Prompt Entry */}
          <div className="w-full max-w-4xl mx-auto space-y-4">
             <div className="relative group">
               <textarea
                 value={prompt}
                 onChange={(e) => setPrompt(e.target.value)}
                 placeholder="Describe the visual concept in high fidelity..."
                 className="w-full h-32 bg-slate-900/50 border border-slate-800 rounded-3xl p-6 pr-16 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all resize-none shadow-2xl"
               />
               <button 
                 onClick={handleGenerate}
                 disabled={isGenerating || !prompt.trim()}
                 className="absolute bottom-6 right-6 p-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-2xl transition-all shadow-xl shadow-indigo-600/20 active:scale-95 group"
               >
                 {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />}
               </button>
             </div>

             {error && (
               <div className="flex items-center gap-3 p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl animate-in slide-in-from-top-2">
                 <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                 <p className="text-xs text-rose-200 font-medium">{error}</p>
                 <button onClick={() => setError(null)} className="ml-auto text-rose-500 hover:text-rose-400 font-bold uppercase tracking-tighter text-[10px]">Dismiss</button>
               </div>
             )}
          </div>

          {/* Results Grid */}
          <div className="w-full max-w-6xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Maximize2 className="w-4 h-4 text-indigo-500/50" /> Latent History
              </h3>
              {results.length > 0 && (
                <button onClick={() => setResults([])} className="p-2 text-slate-600 hover:text-rose-400 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            {isGenerating && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                <div className="aspect-square bg-slate-900 rounded-[2.5rem] border border-slate-800 flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="w-16 h-16 bg-indigo-500/10 rounded-full flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">{loadingMessage}</p>
                    <p className="text-[9px] text-slate-600 font-medium italic">Gemini is processing your request</p>
                  </div>
                </div>
              </div>
            )}

            {results.length === 0 && !isGenerating && (
              <div className="py-24 flex flex-col items-center justify-center text-slate-800 opacity-50 space-y-6">
                <div className="p-8 bg-slate-900/20 rounded-full border border-dashed border-slate-800">
                  <ImageIcon className="w-16 h-16" />
                </div>
                <div className="text-center">
                  <p className="font-bold uppercase tracking-widest text-sm">No Assets Generated</p>
                  <p className="text-xs mt-1">Initiate a generation request to begin neural synthesis</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {results.map((res) => (
                <div key={res.timestamp} className="group relative bg-slate-900 rounded-[2.5rem] border border-slate-800 overflow-hidden shadow-2xl hover:border-indigo-500/30 transition-all duration-500">
                  <img src={res.url} alt={res.prompt} className="w-full aspect-square object-cover transition-transform duration-700 group-hover:scale-110" />
                  
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Zap className="w-3 h-3 text-indigo-400" />
                          <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest">{res.model}</span>
                        </div>
                        <p className="text-xs text-slate-100 line-clamp-3 font-medium leading-relaxed italic">"{res.prompt}"</p>
                      </div>
                      
                      <div className="flex items-center gap-2 pt-2">
                        <button 
                          onClick={() => downloadImage(res.url, res.prompt)}
                          className="flex-1 flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all"
                        >
                          <Download className="w-3.5 h-3.5" /> Export
                        </button>
                        <button className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all">
                          <Maximize2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-4 right-4 p-2 bg-slate-950/80 backdrop-blur-md rounded-lg border border-slate-800 opacity-0 group-hover:opacity-100 transition-opacity">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;
