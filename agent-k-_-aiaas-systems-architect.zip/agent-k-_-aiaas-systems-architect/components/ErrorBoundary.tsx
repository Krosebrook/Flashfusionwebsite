
import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

// ErrorBoundary class component to catch rendering errors.
// Inherits from React.Component to access lifecycle methods and standard property types.
// Fixed: Explicitly extended React.Component and used property initializer for state to resolve TypeScript member access errors.
export class ErrorBoundary extends React.Component<Props, State> {
  // Explicitly declare state as a class property for correct TypeScript member recognition
  public state: State = {
    hasError: false
  };

  constructor(props: Props) {
    super(props);
  }

  // Lifecycle method to update state when an error occurs during render
  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  // Lifecycle method to log error details
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  render() {
    // Check state to determine if fallback UI should be rendered
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="h-full flex items-center justify-center p-8">
          <div className="max-w-md w-full bg-gray-950 border border-red-900/50 rounded-[2rem] p-8 text-center shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-red-600"></div>
            <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-red-500 text-2xl border border-red-500/20">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h2 className="text-xl font-black text-white uppercase tracking-widest mb-2 italic">System Critical Error</h2>
            <p className="text-[10px] text-gray-500 mono uppercase tracking-widest mb-6">Node Exception Detected</p>
            <div className="bg-red-950/30 border border-red-900/30 p-4 rounded-xl text-left mb-6 overflow-auto max-h-32 custom-scrollbar">
              <p className="text-xs font-mono text-red-400 break-words">{this.state.error?.message || 'Unknown error occurred in subsystem.'}</p>
            </div>
            <button 
                onClick={() => this.setState({ hasError: false, error: undefined })}
                className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-black rounded-xl uppercase tracking-widest text-xs transition-all shadow-lg shadow-red-600/20"
            >
                <i className="fa-solid fa-rotate-right mr-2"></i> Reboot Node
            </button>
          </div>
        </div>
      );
    }

    // Return children if no error is caught
    return this.props.children;
  }
}
