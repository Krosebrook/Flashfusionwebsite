
import React, { useState, useEffect, useRef } from 'react';
import { geminiService } from '../geminiService';
import { ChatMessage, UserProfile } from '../types';

interface TerminalProps {
  profile: UserProfile;
}

export const ChatTerminal: React.FC<TerminalProps> = ({ profile }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: `System ready. Architect ${profile.name.split(' ')[0]} initialized. Try /help for commands.`,
      timestamp: new Date().toLocaleTimeString(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleCommand = async (cmd: string): Promise<string | null> => {
    const parts = cmd.split(' ');
    const base = parts[0].toLowerCase();

    switch (base) {
      case '/help':
        return `AVAILABLE_COMMANDS:
/help - Show this menu
/clear - Clear terminal logs
/whoami - Show current user profile
/system - Display node telemetry
/exec [prompt] - Run direct AI execution`;
      case '/clear':
        setMessages([]);
        return null;
      case '/whoami':
        return `USER: ${profile.name}
ROLE: ${profile.role}
SESSION: ACTIVE`;
      case '/system':
        return `NODE: AGENT-K-PWA-6.0
UPTIME: ${window.performance.now().toFixed(0)}ms
MEMORY: ${((performance as any).memory?.usedJSHeapSize / 1024 / 1024).toFixed(2)}MB`;
      case '/exec':
        const prompt = parts.slice(1).join(' ');
        if (!prompt) return "ERROR: Missing prompt. Usage: /exec [prompt]";
        try {
          // Fixed: Removed API key passing as per security guidelines.
          const res = await geminiService.chatWithGrounding(prompt, []);
          return `EXECUTION_RESULT:\n${res.text}`;
        } catch (e: any) {
          return `EXECUTION_FAILED: ${e.message}`;
        }
      default:
        return null;
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Command Logic
    if (input.startsWith('/')) {
      const result = await handleCommand(input);
      if (result) {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'system',
          content: result,
          timestamp: new Date().toLocaleTimeString(),
        }]);
      }
      setIsTyping(false);
      return;
    }

    try {
      // Fixed: Removed API key passing as per security guidelines.
      const securityCheck = await geminiService.analyzeSystemPrompt(input);
      
      if (securityCheck.securityLevel === 'MALICIOUS') {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: 'system',
          content: `SECURITY ALERT: ${securityCheck.reasoning}`,
          timestamp: new Date().toLocaleTimeString(),
        }]);
        setIsTyping(false);
        return;
      }

      const history = messages.map(m => ({
        role: m.role === 'assistant' ? 'model' : m.role,
        parts: [{ text: m.content }]
      })).filter(h => h.role !== 'system');

      // Fixed: Removed API key passing as per security guidelines.
      const response = await geminiService.chatWithGrounding(input, history);
      
      const groundingLinks = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
        title: chunk.web?.title || 'Resource',
        uri: chunk.web?.uri || '#'
      })) || [];

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text || "No response received.",
        timestamp: new Date().toLocaleTimeString(),
        groundingLinks
      }]);
    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'system',
        content: `Error: ${err.message === 'API_KEY_MISSING' ? 'Secure API Runtime Failure.' : 'Connection failure.'}`,
        timestamp: new Date().toLocaleTimeString(),
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-[600px] bg-gray-900 border border-gray-800 rounded-3xl overflow-hidden shadow-2xl relative">
      <div className="bg-gray-800/50 px-6 py-4 flex items-center justify-between border-b border-gray-700">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
          <span className="ml-4 text-xs font-bold text-gray-400 mono tracking-widest uppercase italic tracking-tighter">Terminal_{profile.name.split(' ')[0]}</span>
        </div>
        <div className="text-[10px] text-blue-400 mono">PERSISTENT_SESSION_ENABLED</div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth custom-scrollbar">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-4 ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white' 
                : msg.role === 'system' 
                ? 'bg-red-500/10 border border-red-500/30 text-red-400 mono text-xs' 
                : 'bg-gray-800 text-gray-200 border border-gray-700'
            }`}>
              {msg.role !== 'user' && (
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-black uppercase tracking-widest opacity-50">
                    {msg.role === 'assistant' ? 'Tessa' : 'System'}
                  </span>
                  <span className="text-[9px] opacity-30">{msg.timestamp}</span>
                </div>
              )}
              <div className="text-sm leading-relaxed whitespace-pre-wrap mono tracking-tight">
                {msg.content}
              </div>
              
              {msg.groundingLinks && msg.groundingLinks.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-700/50 flex flex-wrap gap-2">
                   {msg.groundingLinks.map((link, idx) => (
                     <a key={idx} href={link.uri} target="_blank" className="text-[10px] bg-gray-950 px-3 py-1.5 rounded-lg border border-gray-700 text-blue-400 flex items-center gap-1">
                       <i className="fa-solid fa-link text-[8px]"></i> {link.title}
                     </a>
                   ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
              <span className="text-[10px] text-gray-400 mono font-bold tracking-widest">EXECUTING...</span>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSendMessage} className="p-4 bg-gray-800/30 border-t border-gray-800">
        <div className="relative group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type command (/help) or architectural directive..."
            className="w-full bg-gray-900 border border-gray-700 rounded-xl py-3 pl-4 pr-12 text-sm text-white focus:outline-none focus:border-blue-500 transition-all mono"
          />
          <button type="submit" disabled={isTyping} className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors">
            <i className="fa-solid fa-arrow-up text-xs"></i>
          </button>
        </div>
      </form>
    </div>
  );
};
