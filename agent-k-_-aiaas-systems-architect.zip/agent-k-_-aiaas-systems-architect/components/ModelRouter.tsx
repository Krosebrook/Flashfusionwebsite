import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Cell } from 'recharts';
import { ModelProvider } from '../types';

interface CustomRoutingRule {
  id: string;
  name: string;
  provider: ModelProvider | string;
  costThreshold: number;
  latencyLimit: number;
  active: boolean;
  tools: string[];
}

interface ProviderDetails {
  endpoint: string;
  version: string;
  keyConfig: string;
  description: string;
  health: 'STABLE' | 'DEGRADED' | 'MAINTENANCE';
  icon: string;
  nativeTools: string[]; // Added to map to AVAILABLE_TOOLS
}

const AVAILABLE_TOOLS = [
  { id: 'web_search', label: 'Web Search', icon: 'fa-magnifying-glass', description: 'Real-time grounding via Google Search for up-to-date facts.' },
  { id: 'code_interpreter', label: 'Code Interpreter', icon: 'fa-code', description: 'Sandboxed Python execution for complex math and data visualization.' },
  { id: 'image_gen', label: 'Image Generation', icon: 'fa-image', description: 'Native image synthesis using Gemini 2.5 Flash / 3 Pro models.' },
  { id: 'file_analysis', label: 'File Analysis', icon: 'fa-file-lines', description: 'High-fidelity extraction and analysis from PDF, CSV, and Doc formats.' },
  { id: 'db_access', label: 'Database Access', icon: 'fa-database', description: 'Direct secure R/W access to primary Supabase PostgreSQL nodes.' }
];

const providerMetadata: Record<string, ProviderDetails> = {
  [ModelProvider.GEMINI]: {
    endpoint: 'generativelanguage.googleapis.com/v1beta',
    version: 'Gemini 3 Pro / Flash Preview',
    keyConfig: 'process.env.API_KEY',
    description: 'Native multimodal reasoning with Google Search grounding support. Optimized for complex architectural synthesis.',
    health: 'STABLE',
    icon: 'fa-gem',
    nativeTools: ['web_search', 'image_gen', 'file_analysis']
  },
  [ModelProvider.OPENAI]: {
    endpoint: 'api.openai.com/v1/chat/completions',
    version: 'GPT-4o (Stable Release)',
    keyConfig: 'process.env.OPENAI_API_KEY',
    description: 'Industry standard reasoning with high-throughput JSON modes and robust function calling capabilities.',
    health: 'STABLE',
    icon: 'fa-microchip',
    nativeTools: ['code_interpreter', 'image_gen']
  },
  [ModelProvider.ANTHROPIC]: {
    endpoint: 'api.anthropic.com/v1/messages',
    version: 'Claude 3.5 Sonnet',
    keyConfig: 'process.env.ANTHROPIC_API_KEY',
    description: 'High-fidelity coding and structured analysis with native artifact support and human-centric reasoning.',
    health: 'STABLE',
    icon: 'fa-feather',
    nativeTools: ['file_analysis', 'code_interpreter']
  },
  [ModelProvider.GROQ]: {
    endpoint: 'api.groq.com/openai/v1',
    version: 'Llama 3 70B (Fast Inference)',
    keyConfig: 'process.env.GROQ_API_KEY',
    description: 'Ultra-low latency inference engine designed for high-concurrency real-time conversational agents.',
    health: 'STABLE',
    icon: 'fa-bolt-lightning',
    nativeTools: ['web_search']
  },
  [ModelProvider.OLLAMA]: {
    endpoint: 'localhost:11434/api',
    version: 'Local Instance (Self-Hosted)',
    keyConfig: 'N/A (Local Auth)',
    description: 'On-premise execution environment for maximum data sovereignty, zero cost, and air-gapped security.',
    health: 'STABLE',
    icon: 'fa-server',
    nativeTools: ['db_access']
  }
};

const initialChartData = [
  { name: 'Gemini 3 Flash', latency: 85, cost: 0.1 },
  { name: 'Gemini 3 Pro', latency: 420, cost: 1.2 },
  { name: 'Claude 3.5 Sonnet', latency: 310, cost: 0.8 },
  { name: 'GPT-4o', latency: 280, cost: 2.5 },
];

export const ModelRouter: React.FC = () => {
  const [rules, setRules] = useState<CustomRoutingRule[]>([]);
  const [hoveredRegistryProviderId, setHoveredRegistryProviderId] = useState<string | null>(null);
  const [hoveredRegistryToolsId, setHoveredRegistryToolsId] = useState<string | null>(null);
  const [hoveredFormProvider, setHoveredFormProvider] = useState<string | null>(null);
  
  const [formDefaultActive, setFormDefaultActive] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('agent-k-form-active-default');
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [newRule, setNewRule] = useState<Partial<CustomRoutingRule>>({
    name: '',
    provider: ModelProvider.GEMINI,
    costThreshold: 0.5,
    latencyLimit: 500,
    active: formDefaultActive,
    tools: []
  });

  useEffect(() => {
    setNewRule(prev => ({ ...prev, active: formDefaultActive }));
    localStorage.setItem('agent-k-form-active-default', JSON.stringify(formDefaultActive));
  }, [formDefaultActive]);

  useEffect(() => {
    const savedRules = localStorage.getItem('agent-k-routing-rules');
    if (savedRules) {
      try {
        const parsed = JSON.parse(savedRules);
        setRules(parsed.map((r: any) => ({ ...r, tools: Array.isArray(r.tools) ? r.tools : [] })));
      } catch (e) {
        console.error("Failed to parse routing rules", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('agent-k-routing-rules', JSON.stringify(rules));
  }, [rules]);

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRule.name) return;

    const rule: CustomRoutingRule = {
      id: Date.now().toString(),
      name: newRule.name as string,
      provider: newRule.provider as string,
      costThreshold: Number(newRule.costThreshold),
      latencyLimit: Number(newRule.latencyLimit),
      active: newRule.active ?? true,
      tools: newRule.tools || []
    };

    setRules(prev => [...prev, rule]);
    setNewRule({
      name: '',
      provider: ModelProvider.GEMINI,
      costThreshold: 0.5,
      latencyLimit: 500,
      active: formDefaultActive,
      tools: []
    });
  };

  const toggleTool = (toolId: string) => {
    setNewRule(prev => {
      const currentTools = prev.tools || [];
      return {
        ...prev,
        tools: currentTools.includes(toolId) 
          ? currentTools.filter(id => id !== toolId) 
          : [...currentTools, toolId]
      };
    });
  };

  const toggleRule = (id: string) => {
    setRules(rules.map(r => r.id === id ? { ...r, active: !r.active } : r));
  };

  const deleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const getProviderInfo = (provider: string) => {
    return providerMetadata[provider] || {
      endpoint: 'UNKNOWN_GATEWAY',
      version: 'N/A',
      keyConfig: 'N/A',
      description: 'Generic provider configuration.',
      health: 'MAINTENANCE' as const,
      icon: 'fa-server',
      nativeTools: []
    };
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Chart HUD */}
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <i className="fa-solid fa-chart-line text-4xl"></i>
          </div>
          <div className="flex items-center justify-between mb-6 relative z-10">
            <div>
              <h3 className="font-black text-gray-100 uppercase tracking-tight italic">Performance Observability</h3>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest mono">Node Latency Metrics (ms)</p>
            </div>
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={initialChartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                <XAxis dataKey="name" stroke="#4b5563" fontSize={9} tickLine={false} axisLine={false} tick={{ fill: '#6b7280', fontWeight: 'bold' }} />
                <YAxis stroke="#4b5563" fontSize={9} tickLine={false} axisLine={false} tick={{ fill: '#6b7280' }} />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '16px', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}
                  itemStyle={{ color: '#60a5fa', fontWeight: 'bold', fontSize: '10px' }}
                  cursor={{ fill: 'rgba(59, 130, 246, 0.05)' }}
                />
                <Bar dataKey="latency" radius={[6, 6, 0, 0]} barSize={40}>
                  {initialChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.latency > 350 ? '#ef4444' : '#3b82f6'} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Global Orchestration Logic */}
        <div className="bg-gray-900 border border-gray-800 rounded-3xl p-6 shadow-xl relative group overflow-hidden">
           <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <i className="fa-solid fa-microchip text-4xl"></i>
          </div>
           <div className="mb-6 relative z-10">
              <h3 className="font-black text-gray-100 uppercase tracking-tight italic">System Heuristics</h3>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest mono">Autonomous Routing Logic</p>
           </div>
           
           <div className="space-y-4 relative z-10">
              <div className="p-4 bg-gray-950/50 border border-gray-800 rounded-2xl flex items-center justify-between group/item hover:border-blue-500/30 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500 border border-blue-500/20 shadow-inner">
                    <i className="fa-solid fa-bolt"></i>
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-gray-100 uppercase tracking-wider">Low Latency Mode</h4>
                    <p className="text-[9px] text-gray-500 uppercase tracking-widest mono">Auto-switch to Flash nodes</p>
                  </div>
                </div>
                <div className="w-10 h-5 bg-blue-600 rounded-full relative cursor-pointer shadow-[0_0_15px_rgba(37,99,235,0.4)]">
                   <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                </div>
              </div>

              <div className="p-4 bg-gray-950/50 border border-gray-800 rounded-2xl flex items-center justify-between group/item hover:border-purple-500/30 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-500 border border-purple-500/20 shadow-inner">
                    <i className="fa-solid fa-brain"></i>
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-gray-100 uppercase tracking-wider">Deep Reasoning</h4>
                    <p className="text-[9px] text-gray-500 uppercase tracking-widest mono">Tiered Architectural Synthesis</p>
                  </div>
                </div>
                <div className="w-10 h-5 bg-gray-700 rounded-full relative cursor-pointer">
                   <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-800/50">
                <div className="flex items-center justify-between text-[10px] mb-2 px-1">
                  <span className="text-gray-500 font-black uppercase tracking-widest">Router Utilization</span>
                  <span className="text-blue-400 font-bold mono">76.8% Load</span>
                </div>
                <div className="w-full h-2.5 bg-gray-950 rounded-full overflow-hidden border border-gray-800 p-0.5 shadow-inner">
                   <div className="w-[76%] h-full bg-blue-500 rounded-full shadow-[0_0_12px_rgba(59,130,246,0.6)] animate-pulse"></div>
                </div>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Architectural Rule Form */}
        <div className="lg:col-span-4 bg-gray-900 border border-gray-800 rounded-3xl p-6 shadow-xl relative h-fit">
          <h3 className="font-black text-gray-100 uppercase tracking-tight italic mb-6 flex items-center gap-2">
            <i className="fa-solid fa-square-plus text-blue-500"></i>
            Commit Routing Directive
          </h3>
          <form onSubmit={handleAddRule} className="space-y-5">
            <div>
              <label className="block text-[9px] font-black text-gray-600 uppercase tracking-widest mb-2 ml-1 italic">Directive Name</label>
              <input 
                type="text" 
                value={newRule.name}
                onChange={e => setNewRule({...newRule, name: e.target.value})}
                placeholder="e.g. BALANCER_v2"
                className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-3 text-xs text-gray-200 focus:outline-none focus:border-blue-500/50 mono transition-all shadow-inner"
              />
            </div>

            <div className="relative">
              <label className="block text-[9px] font-black text-gray-600 uppercase tracking-widest mb-2 ml-1 italic">Provider Logic</label>
              <div className="grid grid-cols-1 gap-2">
                {Object.values(ModelProvider).map(provider => {
                  const pInfo = getProviderInfo(provider);
                  const isSelected = newRule.provider === provider;
                  return (
                    <div 
                      key={provider}
                      className="relative"
                      onMouseEnter={() => setHoveredFormProvider(provider)}
                      onMouseLeave={() => setHoveredFormProvider(null)}
                    >
                      <button
                        type="button"
                        onClick={() => setNewRule({...newRule, provider: provider})}
                        className={`w-full flex items-center justify-between px-4 py-4 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all duration-300 group/provider-btn ${
                          isSelected ? 'bg-blue-600/10 border-blue-500 text-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.1)]' : 'bg-gray-950 border-gray-800 text-gray-600 hover:border-gray-700 hover:text-gray-400'
                        }`}
                      >
                        <span className="flex items-center gap-4 flex-1">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${isSelected ? 'bg-blue-500 text-white shadow-lg' : 'bg-gray-900 text-gray-700'}`}>
                            <i className={`fa-solid ${pInfo.icon}`}></i>
                          </div>
                          <div className="flex flex-col items-start gap-1">
                            <span className="leading-none">{provider}</span>
                            {/* INTEGRATED ICONS FROM AVAILABLE_TOOLS AS CAPABILITY INDICATORS */}
                            <div className="flex gap-1">
                              {pInfo.nativeTools.map(toolId => {
                                const tool = AVAILABLE_TOOLS.find(t => t.id === toolId);
                                if (!tool) return null;
                                return (
                                  <i key={toolId} className={`fa-solid ${tool.icon} text-[7px] ${isSelected ? 'text-blue-300' : 'text-gray-700'} opacity-70`} title={tool.label}></i>
                                );
                              })}
                            </div>
                          </div>
                        </span>
                        {isSelected && <i className="fa-solid fa-circle-check text-blue-500 text-[10px] animate-in fade-in zoom-in duration-300"></i>}
                      </button>

                      {/* EXPANDED PROVIDER DETAIL TOOLTIP */}
                      {hoveredFormProvider === provider && (
                        <div className="absolute left-full ml-6 top-1/2 -translate-y-1/2 w-[320px] bg-[#020617] border border-blue-500/40 rounded-[2.5rem] p-8 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.9)] z-[500] backdrop-blur-3xl animate-in fade-in slide-in-from-left-4 duration-300 pointer-events-none border-l-4 border-l-blue-600 overflow-hidden">
                           <div className="flex items-center justify-between mb-6 border-b border-gray-800 pb-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                                  <i className={`fa-solid ${pInfo.icon} text-base`}></i>
                                </div>
                                <div className="text-[11px] font-black text-blue-400 uppercase mono tracking-[0.2em]">{provider}_SPEC</div>
                              </div>
                              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                <span className="text-[9px] font-black text-emerald-500 uppercase">{pInfo.health}</span>
                              </div>
                           </div>
                           
                           <div className="space-y-6">
                              <div className="p-4 bg-gray-950 border border-gray-800 rounded-2xl shadow-inner">
                                <p className="text-[11px] text-gray-300 italic leading-relaxed font-medium">
                                  {pInfo.description}
                                </p>
                              </div>
                              
                              <div className="grid grid-cols-1 gap-4">
                                <div className="space-y-2">
                                  <div className="text-[8px] font-black text-gray-600 uppercase tracking-widest ml-1">Gateway Cluster</div>
                                  <div className="text-[10px] text-blue-400 bg-gray-950 p-3 rounded-xl border border-gray-800 mono truncate font-bold shadow-inner">
                                    {pInfo.endpoint}
                                  </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 shadow-inner">
                                    <div className="text-[7px] text-gray-600 uppercase mb-1.5 font-black">Stable Ver.</div>
                                    <div className="text-[10px] text-gray-200 font-black truncate italic">{pInfo.version}</div>
                                  </div>
                                  <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 shadow-inner">
                                    <div className="text-[7px] text-gray-600 uppercase mb-1.5 font-black">Auth Integrity</div>
                                    <div className="text-[9px] text-purple-400 font-black mono flex items-center gap-1">
                                      <i className="fa-solid fa-lock text-[8px]"></i> SECURED
                                    </div>
                                  </div>
                                </div>
                              </div>
                           </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="space-y-3">
              <label className="block text-[9px] font-black text-gray-600 uppercase tracking-widest mb-2 ml-1 italic">Binding Tools</label>
              <div className="grid grid-cols-1 gap-2 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
                {AVAILABLE_TOOLS.map(tool => (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => toggleTool(tool.id)}
                    className={`flex items-center gap-4 px-4 py-4 rounded-2xl border transition-all duration-300 relative text-left group/tool-btn ${
                      newRule.tools?.includes(tool.id) ? 'bg-blue-600/10 border-blue-500 text-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.1)]' : 'bg-gray-950 border-gray-800 text-gray-600 hover:border-gray-700 hover:bg-gray-900/50'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all shrink-0 border shadow-inner ${
                      newRule.tools?.includes(tool.id) ? 'bg-blue-500 text-white border-blue-400/30 shadow-lg' : 'bg-gray-900 text-gray-700 border-gray-800'
                    }`}>
                      <i className={`fa-solid ${tool.icon} text-[14px]`}></i>
                    </div>
                    <div className="flex-1 min-w-0 pr-10">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black uppercase tracking-tight group-hover/tool-btn:text-gray-100 transition-colors">
                          {tool.label}
                        </span>
                        <span className="text-[8px] text-gray-500 font-medium italic group-hover/tool-btn:text-gray-400 transition-colors truncate">
                          {tool.description}
                        </span>
                      </div>
                    </div>
                    {newRule.tools?.includes(tool.id) && <i className="fa-solid fa-circle-check text-blue-500 text-[11px] absolute right-5 top-1/2 -translate-y-1/2 animate-in fade-in zoom-in duration-300"></i>}
                  </button>
                ))}
              </div>
            </div>

            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black text-[10px] tracking-widest uppercase py-4 rounded-2xl transition-all shadow-xl active:scale-95 group shadow-blue-500/20">
              <i className="fa-solid fa-microchip mr-2 group-hover:animate-pulse"></i> Commit Rule
            </button>
          </form>
        </div>

        {/* Rule Registry Viewer */}
        <div className="lg:col-span-8 bg-gray-900 border border-gray-800 rounded-3xl p-6 shadow-xl relative flex flex-col h-fit">
          <div className="flex items-center justify-between mb-8 relative z-10 shrink-0">
            <div>
              <h3 className="font-black text-gray-100 uppercase tracking-tight italic">Rule Registry</h3>
              <p className="text-[9px] text-gray-500 uppercase tracking-widest mono">{rules.length} Active Custom Directives</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-black bg-gray-950 border border-gray-800 px-3 py-1 rounded-full text-emerald-500 uppercase border-emerald-500/20">Router Active</span>
            </div>
          </div>
          
          <div className="space-y-4 min-h-[400px]">
            {rules.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-gray-800 rounded-3xl text-gray-700 bg-gray-950/20 opacity-50">
                <i className="fa-solid fa-code-branch mb-4 text-4xl"></i>
                <p className="text-[10px] uppercase tracking-widest font-black italic">Awaiting Directives</p>
              </div>
            ) : (
              rules.map((rule) => {
                const pInfo = getProviderInfo(rule.provider);
                return (
                  <div key={rule.id} className="bg-gray-950/80 border border-gray-800 rounded-3xl p-5 flex items-center justify-between group hover:border-blue-500/40 transition-all shadow-lg relative overflow-visible">
                    <div className={`absolute top-0 left-0 w-1 h-full rounded-l-3xl ${rule.active ? 'bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.8)]' : 'bg-gray-800'}`}></div>
                    
                    <div className="flex items-center gap-6 flex-1 min-w-0 overflow-visible">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl transition-all shrink-0 ${rule.active ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20 shadow-xl' : 'bg-gray-900 text-gray-700 border-gray-800'}`}>
                        <i className={`fa-solid ${rule.active ? 'fa-bolt' : 'fa-power-off'}`}></i>
                      </div>
                      
                      <div className="flex-1 min-w-0 overflow-visible">
                        <div className="flex items-center gap-3 mb-2 overflow-visible">
                          <h4 className={`text-sm font-black uppercase tracking-tight truncate ${rule.active ? 'text-gray-100' : 'text-gray-600'}`}>
                            {rule.name}
                          </h4>
                          <div className="relative overflow-visible" onMouseEnter={() => setHoveredRegistryProviderId(rule.id)} onMouseLeave={() => setHoveredRegistryProviderId(null)}>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest cursor-help transition-all border flex items-center gap-2 whitespace-nowrap ${
                              rule.active ? 'bg-blue-500/10 text-blue-500 border-blue-500/30' : 'bg-gray-900 text-gray-700 border-gray-800'
                            }`}>
                              <i className={`fa-solid ${pInfo.icon} text-[8px]`}></i>
                              {rule.provider}
                            </span>
                            
                            {/* REGISTRY NODE MANIFEST TOOLTIP */}
                            {hoveredRegistryProviderId === rule.id && (
                              <div className="absolute bottom-full left-0 mb-4 w-[320px] bg-[#020617] border border-blue-500/30 rounded-[2.5rem] p-8 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.8)] z-[500] backdrop-blur-3xl animate-in fade-in zoom-in-95 duration-200 pointer-events-none border-l-4 border-l-blue-600 origin-bottom-left overflow-hidden">
                                <div className="flex items-center justify-between border-b border-gray-800 pb-5 mb-6">
                                  <div className="flex items-center gap-2.5">
                                    <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500">
                                      <i className={`fa-solid ${pInfo.icon} text-xs`}></i>
                                    </div>
                                    <span className="text-[10px] font-black text-blue-400 uppercase mono tracking-[0.2em]">NODE_MANIFEST</span>
                                  </div>
                                  <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                    <span className="text-[9px] font-bold text-emerald-500 uppercase">{pInfo.health}</span>
                                  </div>
                                </div>
                                <div className="space-y-6">
                                  <div className="p-4 bg-gray-950/50 border border-gray-800 rounded-2xl shadow-inner">
                                    <p className="text-[11px] text-gray-400 italic leading-relaxed font-medium">{pInfo.description}</p>
                                  </div>
                                  <div className="space-y-4">
                                    <div>
                                      <div className="text-[8px] font-black text-gray-600 uppercase mb-2 tracking-widest flex items-center gap-2">
                                        <i className="fa-solid fa-link text-blue-500/30"></i> Gateway Endpoint
                                      </div>
                                      <div className="text-[10px] text-blue-400 mono bg-gray-950 px-4 py-3 rounded-xl border border-gray-800 break-all leading-tight font-bold shadow-inner">{pInfo.endpoint}</div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                      <div className="bg-gray-950/40 p-4 rounded-2xl border border-gray-800 shadow-inner">
                                        <div className="text-[8px] text-gray-600 uppercase mb-1.5 font-black">Release Tag</div>
                                        <div className="text-[11px] text-gray-200 font-black truncate uppercase italic tracking-tighter">{pInfo.version}</div>
                                      </div>
                                      <div className="bg-gray-950/40 p-4 rounded-2xl border border-gray-800 shadow-inner">
                                        <div className="text-[8px] text-gray-600 uppercase mb-1.5 font-black">Auth Mode</div>
                                        <div className="text-[9px] text-purple-400 font-bold mono truncate flex items-center gap-1">SECURED</div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* REGISTRY CAPABILITY MANIFEST TOOLTIP */}
                        <div className="relative flex flex-wrap gap-1.5 cursor-help min-h-[1.5rem] overflow-visible" onMouseEnter={() => setHoveredRegistryToolsId(rule.id)} onMouseLeave={() => setHoveredRegistryToolsId(null)}>
                          {rule.tools && rule.tools.length > 0 ? (
                            rule.tools.map(toolId => {
                              const tool = AVAILABLE_TOOLS.find(t => t.id === toolId);
                              return (
                                <span key={toolId} className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest border transition-all flex items-center gap-1.5 ${
                                  rule.active ? 'bg-gray-950 text-gray-400 border-gray-800 group-hover:border-blue-500/40' : 'bg-gray-950/30 text-gray-700 border-gray-900'
                                }`}>
                                  <i className={`fa-solid ${tool?.icon || 'fa-gear'}`}></i> {tool?.label || toolId}
                                </span>
                              );
                            })
                          ) : (
                            <span className="text-[8px] font-bold text-gray-700 uppercase italic tracking-widest opacity-60">NO_TOOLS_ASSOCIATED</span>
                          )}

                          {hoveredRegistryToolsId === rule.id && rule.tools.length > 0 && (
                            <div className="absolute bottom-full left-0 mb-4 w-[320px] bg-[#020617] border border-blue-500/30 rounded-[2.2rem] p-7 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.8)] z-[500] backdrop-blur-3xl animate-in fade-in zoom-in-95 duration-200 pointer-events-none border-l-4 border-l-blue-600 origin-bottom-left overflow-hidden">
                              <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-5">
                                <div className="flex items-center gap-2">
                                  <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500">
                                    <i className="fa-solid fa-microchip text-[10px]"></i>
                                  </div>
                                  <span className="text-[10px] font-black text-blue-400 uppercase mono tracking-widest">TOOL_MANIFEST</span>
                                </div>
                                <span className="text-[8px] font-black text-gray-600 uppercase tracking-[0.2em]">SECURED_V3</span>
                              </div>
                              <div className="space-y-4">
                                {rule.tools.map(toolId => {
                                  const tool = AVAILABLE_TOOLS.find(t => t.id === toolId);
                                  return (
                                    <div key={toolId} className="flex gap-4 group/t-info">
                                      <div className="w-10 h-10 rounded-xl bg-blue-500/5 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 shadow-inner group-hover/t-info:bg-blue-500/10 group-hover/t-info:border-blue-500/40 transition-all">
                                        <i className={`fa-solid ${tool?.icon || 'fa-gear'} text-[12px]`}></i>
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <div className="text-[10px] font-black text-gray-100 uppercase mb-0.5 tracking-tight flex items-center gap-2">
                                          {tool?.label || toolId}
                                        </div>
                                        <p className="text-[9px] text-gray-400 italic leading-tight font-medium opacity-80">{tool?.description || 'Contextual tool binding.'}</p>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="hidden lg:flex items-center gap-6 pr-8 border-l border-gray-800/30 pl-8 shrink-0">
                         <div className="text-center">
                            <div className="text-[8px] font-black text-gray-600 uppercase mb-1 tracking-widest opacity-60">SLA Max</div>
                            <div className={`text-[11px] font-black mono ${rule.active ? 'text-blue-400' : 'text-gray-700'}`}>{rule.latencyLimit}ms</div>
                         </div>
                         <div className="text-center">
                            <div className="text-[8px] font-black text-gray-600 uppercase mb-1 tracking-widest opacity-60">Bud/1k</div>
                            <div className={`text-[11px] font-black mono ${rule.active ? 'text-emerald-500' : 'text-gray-700'}`}>${rule.costThreshold}</div>
                         </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 ml-6 pl-6 border-l border-gray-800/50 shrink-0">
                      <button 
                        onClick={() => toggleRule(rule.id)} 
                        className={`w-10 h-5 rounded-full relative transition-all duration-500 ${rule.active ? 'bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.5)]' : 'bg-gray-800'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-300 ${rule.active ? 'right-1' : 'left-1'} shadow-xl`}></div>
                      </button>
                      <button 
                        onClick={() => deleteRule(rule.id)} 
                        className="text-gray-700 hover:text-red-500 transition-all p-2 active:scale-75"
                        title="Decommission Rule"
                      >
                        <i className="fa-solid fa-trash-can text-sm"></i>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #030712; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1f2937; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #3b82f6; }
      `}</style>
    </div>
  );
};
