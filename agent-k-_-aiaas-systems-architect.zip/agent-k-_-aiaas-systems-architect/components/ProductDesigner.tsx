
import React, { useState } from 'react';
import { geminiService } from '../geminiService';
import { TechStack, Manifest } from '../types';

const FRAMEWORKS = ['Next.js (App Router)', 'FastAPI (Python)', 'NestJS (Node)', 'Go (Gin)', 'SvelteKit', 'Laravel', 'Flutter', 'SST (Ion)'];
const ARCHITECTURES = ['Microservices (Mesh)', 'Event-Driven (Pub/Sub)', 'Edge-First (Serverless)', 'Monolithic (Modular)', 'Hexagonal', 'CQRS', 'Clean Arch'];
const INFRA_TOOLS = ['Supabase (DB/Auth)', 'AWS (RDS/S3)', 'Firebase', 'MongoDB Atlas', 'Neon (Postgres)', 'Redis (Upstash)', 'Cloudflare D1', 'Pinecone (Vector)'];
const INTELLIGENCE_TOOLS = ['Gemini 3 Pro', 'Claude 3.5 Sonnet', 'GPT-4o', 'Llama 3 (Groq)', 'Ollama (Local)', 'Mistral Large'];
const DEPLOYMENT_PLATFORMS = ['Vercel (Edge)', 'AWS Amplify', 'Cloudflare Pages', 'Railway', 'Netlify', 'Render', 'K8s (EKS)', 'Coolify'];
const REPOSITORIES = ['GitHub Mono-repo', 'GitLab Distributed', 'Bitbucket Enterprise', 'Azure DevOps', 'Self-hosted Gitea'];
const DOC_STANDARDS = ['Technical PRD', 'OpenAPI (Swagger)', 'Architecture RFC', 'System ADR', 'User Operations Guide'];
const CODE_STYLES = ['Veteran (Clean Code)', 'Rapid Prototype', 'Enterprise (Strict Types)', 'Extreme Performance', 'Minimalist'];

// New options requested
const STATE_MANAGEMENT = ['Zustand (Lightweight)', 'Redux Toolkit (Complex)', 'React Query (Server-state)', 'Server Actions Only', 'Context API'];
const DATA_CONSISTENCY = ['Eventual Consistency', 'Strong ACID', 'Causal Consistency', 'Hybrid (Read-After-Write)'];
const ERROR_PATTERNS = ['Graceful Degradation', 'Circuit Breaker', 'Retry with Backoff', 'Fail-Fast (Panic)', 'Safe-Mode Fallback'];

export const ProductDesigner: React.FC = () => {
  const [intent, setIntent] = useState('');
  const [stack, setStack] = useState<TechStack>({
    framework: FRAMEWORKS[0],
    architecture: ARCHITECTURES[0],
    infrastructure: [INFRA_TOOLS[0]],
    intelligence: [INTELLIGENCE_TOOLS[0]],
    deployment: DEPLOYMENT_PLATFORMS[0],
    repository: REPOSITORIES[0],
    documentation: DOC_STANDARDS[0],
    codeStyle: CODE_STYLES[0],
    stateManagement: STATE_MANAGEMENT[0],
    dataConsistency: DATA_CONSISTENCY[0],
    errorPattern: ERROR_PATTERNS[0]
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [activeTab, setActiveTab] = useState<'manifest' | 'aiaas' | 'scaffold' | 'docs' | 'ops'>('manifest');

  const handleSynthesize = async () => {
    if (!intent.trim() || isGenerating) return;
    setIsGenerating(true);
    try {
      const result = await geminiService.synthesizeDeepManifest({ ...stack, intent });
      setManifest(result);
      setActiveTab('manifest');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleSelection = (key: keyof TechStack, item: string) => {
    setStack(prev => {
      const val = prev[key];
      if (Array.isArray(val)) {
        return { ...prev, [key]: val.includes(item) ? val.filter(i => i !== item) : [...val, item] };
      }
      return { ...prev, [key]: item };
    });
  };

  return (
    <div className="space-y-8 pb-24">
      <div className="flex items-center justify-between border-b border-gray-900 pb-6">
        <div>
          <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">Product Synthesizer</h2>
          <p className="text-[10px] text-gray-500 mono uppercase tracking-[0.3em] mt-1">Multi-Stack Orchestration Engine v5.0</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-gray-900/60 border border-gray-800 rounded-[2.5rem] p-8 shadow-2xl space-y-8 backdrop-blur-xl">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-600 uppercase tracking-widest flex items-center gap-2">
                <i className="fa-solid fa-lightbulb text-blue-500"></i> Core Intent
              </label>
              <textarea 
                value={intent}
                onChange={e => setIntent(e.target.value)}
                placeholder="A high-performance AIaaS platform for financial forecasting..."
                className="w-full h-32 bg-gray-950 border border-gray-800 rounded-2xl p-4 text-xs text-gray-300 focus:border-blue-500/50 mono resize-none transition-all"
              />
            </div>

            <div className="space-y-6">
              {/* Primary Logic Tiers */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase">Framework</label>
                  <select value={stack.framework} onChange={e => toggleSelection('framework', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-2 text-[10px] text-gray-400 mono">
                    {FRAMEWORKS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase">Architecture</label>
                  <select value={stack.architecture} onChange={e => toggleSelection('architecture', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-2 text-[10px] text-gray-400 mono">
                    {ARCHITECTURES.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
              </div>

              {/* Extended Architectural options */}
              <div className="grid grid-cols-1 gap-4 border-t border-gray-800 pt-6">
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest text-blue-500">State Management</label>
                  <select value={stack.stateManagement} onChange={e => toggleSelection('stateManagement', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-[10px] text-gray-400 mono">
                    {STATE_MANAGEMENT.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest text-emerald-500">Data Consistency</label>
                  <select value={stack.dataConsistency} onChange={e => toggleSelection('dataConsistency', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-[10px] text-gray-400 mono">
                    {DATA_CONSISTENCY.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest text-red-500">Error Handling Pattern</label>
                  <select value={stack.errorPattern} onChange={e => toggleSelection('errorPattern', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-[10px] text-gray-400 mono">
                    {ERROR_PATTERNS.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                </div>
              </div>

              {/* SDLC Protocol */}
              <div className="grid grid-cols-1 gap-4 border-t border-gray-800 pt-6">
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Repository Protocol</label>
                  <select value={stack.repository} onChange={e => toggleSelection('repository', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-[10px] text-gray-400 mono">
                    {REPOSITORIES.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Documentation Standard</label>
                  <select value={stack.documentation} onChange={e => toggleSelection('documentation', e.target.value)} className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-[10px] text-gray-400 mono">
                    {DOC_STANDARDS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <button 
              onClick={handleSynthesize} 
              disabled={isGenerating || !intent.trim()} 
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black text-xs uppercase py-5 rounded-[2rem] shadow-xl active:scale-95 flex items-center justify-center gap-3 transition-all"
            >
              {isGenerating ? <i className="fa-solid fa-atom animate-spin text-xl"></i> : <i className="fa-solid fa-wand-magic-sparkles text-xl"></i>}
              {isGenerating ? 'Synthesizing Production Artifacts...' : 'Commit Synthesis'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-8">
          {isGenerating ? (
            <div className="h-full min-h-[600px] bg-gray-900 border border-gray-800 rounded-[3rem] p-20 flex flex-col items-center justify-center text-center">
              <div className="w-32 h-32 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-10"></div>
              <h3 className="text-3xl font-black text-white uppercase italic tracking-widest">Synthesizing Product Architecture</h3>
              <p className="text-xs text-gray-500 mono animate-pulse mt-4">Wiring Repository // Building Documentation // Implementing Error Patterns</p>
            </div>
          ) : manifest ? (
            <div className="bg-gray-900 border border-gray-800 rounded-[3rem] overflow-hidden flex flex-col h-full shadow-2xl">
               <div className="flex bg-gray-950 border-b border-gray-800 p-3 gap-3">
                 {[
                   { id: 'manifest', label: 'Manifest', icon: 'fa-file-invoice' },
                   { id: 'aiaas', label: 'AIaaS Spec', icon: 'fa-rocket' },
                   { id: 'scaffold', label: 'Code Scaffold', icon: 'fa-code' },
                   { id: 'docs', label: 'Docs Bundle', icon: 'fa-book' },
                   { id: 'ops', label: 'CI/CD Ops', icon: 'fa-gears' }
                 ].map(t => (
                   <button 
                    key={t.id} 
                    onClick={() => setActiveTab(t.id as any)} 
                    className={`flex-1 py-4 text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl transition-all flex items-center justify-center gap-3 ${activeTab === t.id ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300 hover:bg-gray-900'}`}
                   >
                     <i className={`fa-solid ${t.icon}`}></i> {t.label}
                   </button>
                 ))}
               </div>

               <div className="p-12 flex-1 overflow-y-auto custom-scrollbar">
                 {activeTab === 'manifest' && (
                   <div className="space-y-12 animate-in slide-in-from-bottom-4">
                      <div className="border-b border-gray-800 pb-10">
                         <h1 className="text-5xl font-black text-white uppercase italic tracking-tighter mb-6">{manifest.title}</h1>
                         <div className="flex flex-wrap gap-3 mb-8">
                            <span className="px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] font-black text-blue-500 uppercase">{stack.stateManagement}</span>
                            <span className="px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] font-black text-emerald-500 uppercase">{stack.dataConsistency}</span>
                            <span className="px-4 py-1.5 bg-red-500/10 border border-red-500/20 rounded-full text-[10px] font-black text-red-500 uppercase">{stack.errorPattern}</span>
                         </div>
                         <p className="mt-4 text-lg text-gray-400 italic leading-relaxed border-l-4 border-blue-600 pl-8">{manifest.summary}</p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                         <div className="space-y-4">
                            <h4 className="text-[11px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-2">
                               <i className="fa-solid fa-code-branch text-blue-500"></i> Repo Architecture
                            </h4>
                            <div className="p-8 bg-gray-950 border border-gray-800 rounded-[2.5rem] text-[11px] text-gray-400 italic mono leading-relaxed shadow-xl">
                               {manifest.orchestration.repoStructure}
                            </div>
                         </div>
                         <div className="space-y-4">
                            <h4 className="text-[11px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-2">
                               <i className="fa-solid fa-network-wired text-purple-500"></i> Infrastructure Wiring
                            </h4>
                            <div className="p-8 bg-gray-950 border border-gray-800 rounded-[2.5rem] text-[11px] text-gray-400 italic leading-relaxed shadow-xl border-l-4 border-l-purple-600">
                               {manifest.orchestration.wiring}
                            </div>
                         </div>
                      </div>
                   </div>
                 )}

                 {activeTab === 'aiaas' && (
                   <div className="space-y-10 animate-in slide-in-from-bottom-4">
                      <div className="bg-blue-600/5 border border-blue-600/20 p-10 rounded-[3rem] space-y-8">
                         <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">AIaaS Monetization Model</h2>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                           {manifest.aiaas?.tiers.map((tier, i) => (
                             <div key={i} className="bg-gray-950 border border-gray-800 p-6 rounded-3xl space-y-4">
                               <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest">{tier.name}</div>
                               <div className="text-2xl font-black text-white">{tier.pricing}</div>
                               <div className="text-[9px] text-gray-500 mono uppercase">Quota: {tier.rpm} RPM // {tier.tpd} TPD</div>
                             </div>
                           ))}
                         </div>
                      </div>
                      <div className="grid grid-cols-2 gap-8">
                         <div className="p-8 bg-gray-950 border border-gray-800 rounded-[2.5rem] space-y-3">
                            <h4 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Gateway Logic</h4>
                            <p className="text-xs text-gray-400 italic">{manifest.aiaas?.gateway}</p>
                         </div>
                         <div className="p-8 bg-gray-950 border border-gray-800 rounded-[2.5rem] space-y-3">
                            <h4 className="text-[11px] font-black text-gray-500 uppercase tracking-widest">Metering Engine</h4>
                            <p className="text-xs text-gray-400 italic">{manifest.aiaas?.metering}</p>
                         </div>
                      </div>
                   </div>
                 )}

                 {activeTab === 'scaffold' && (
                   <div className="space-y-10 animate-in slide-in-from-bottom-4">
                      {manifest.scaffold.map((f, i) => (
                        <div key={i} className="space-y-3">
                          <div className="flex justify-between px-4">
                             <span className="text-[10px] font-black text-gray-600 mono uppercase tracking-widest">{f.path}</span>
                             <span className="text-[9px] bg-gray-800 px-3 py-0.5 rounded-full text-blue-400 mono border border-gray-700">{f.language}</span>
                          </div>
                          <div className="bg-gray-950 p-10 rounded-[3rem] border border-gray-800 mono text-[12px] text-gray-300 overflow-x-auto whitespace-pre shadow-2xl relative group">
                             <button className="absolute top-6 right-8 text-gray-700 hover:text-white transition-colors" title="Copy to clipboard">
                               <i className="fa-solid fa-copy"></i>
                             </button>
                             {f.content}
                          </div>
                        </div>
                      ))}
                   </div>
                 )}

                 {activeTab === 'docs' && (
                   <div className="space-y-12 animate-in slide-in-from-bottom-4">
                      <div className="bg-emerald-500/5 border border-emerald-500/20 p-10 rounded-[3rem]">
                         <h4 className="text-sm font-black text-emerald-500 uppercase mb-4 flex items-center gap-2">
                           <i className="fa-solid fa-book-open"></i> OpenAPI Specification
                         </h4>
                         <div className="bg-gray-950 p-8 rounded-2xl mono text-[10px] text-gray-500 overflow-x-auto h-64 border border-gray-800">
                           {manifest.documentation.openapiSpec}
                         </div>
                      </div>
                      <div className="grid grid-cols-2 gap-8">
                         <div className="space-y-6">
                            <h4 className="text-[11px] font-black text-red-500 uppercase tracking-widest">Technical Constraints</h4>
                            {manifest.documentation.constraints.map((c, i) => (
                              <div key={i} className="p-6 bg-red-500/5 border border-red-500/10 rounded-2xl text-[11px] text-gray-400 italic">{c}</div>
                            ))}
                         </div>
                         <div className="space-y-6">
                            <h4 className="text-[11px] font-black text-emerald-500 uppercase tracking-widest">Production Guardrails</h4>
                            {manifest.documentation.guardrails.map((g, i) => (
                              <div key={i} className="p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl text-[11px] text-gray-400 italic">{g}</div>
                            ))}
                         </div>
                      </div>
                   </div>
                 )}

                 {activeTab === 'ops' && (
                   <div className="space-y-10 animate-in slide-in-from-bottom-4">
                      <div className="p-10 bg-gray-950 border border-gray-800 rounded-[3.5rem] space-y-6">
                         <div className="flex items-center gap-4 border-b border-gray-800 pb-6">
                            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500 text-xl shadow-lg">
                               <i className="fa-solid fa-gears"></i>
                            </div>
                            <div>
                               <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">CI/CD Pipeline Blueprint</h3>
                               <p className="text-[10px] text-gray-500 uppercase tracking-widest mono">GitHub Actions + Vercel Workflow</p>
                            </div>
                         </div>
                         <div className="text-sm text-gray-300 italic leading-relaxed whitespace-pre-wrap">
                            {manifest.orchestration.cicdPipeline}
                         </div>
                      </div>
                   </div>
                 )}
               </div>
            </div>
          ) : (
            <div className="h-full min-h-[600px] border-2 border-dashed border-gray-800 rounded-[3rem] bg-gray-950/20 flex flex-col items-center justify-center text-center p-20 opacity-40">
               <i className="fa-solid fa-microchip text-[10rem] mb-10 text-blue-500/10"></i>
               <h3 className="text-3xl font-black uppercase tracking-[0.2em] italic mb-4 text-gray-600">Awaiting SDLC Directive</h3>
               <p className="text-xs text-gray-700 max-w-sm mono uppercase leading-relaxed tracking-widest">
                 Configure your stack and architectural tiers to generate a production manifest.
               </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
