
import React, { useState } from 'react';
import { geminiService } from '../geminiService';
import { TOP_50_BLUEPRINTS } from '../constants';
import { UserProfile } from '../types';

interface SystemArchitectureProps {
  profile?: UserProfile;
}

export const SystemArchitecture: React.FC<SystemArchitectureProps> = ({ profile }) => {
  const [intent, setIntent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [blueprint, setBlueprint] = useState<any>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  
  const categories = ['All', 'SaaS', 'AI', 'Fintech', 'Edge', 'Data', 'Security', 'DevOps'];
  const filteredBlueprints = activeCategory === 'All' 
    ? TOP_50_BLUEPRINTS 
    : TOP_50_BLUEPRINTS.filter(b => b.category === activeCategory);

  const [nodes, setNodes] = useState([
    { id: 'auth', name: 'Auth Gateway', status: 'ACTIVE', load: 14, health: 98 },
    { id: 'api', name: 'Logic Core', status: 'ACTIVE', load: 42, health: 95 },
    { id: 'db', name: 'Primary Shard', status: 'ACTIVE', load: 68, health: 92 },
    { id: 'edge', name: 'Edge Worker', status: 'STANDBY', load: 0, health: 100 }
  ]);

  const handleSynthesize = async (pIntent?: string) => {
    const finalIntent = pIntent || intent;
    if (!finalIntent.trim() || isGenerating) return;
    setIsGenerating(true);
    try {
      // Removed API key passing; GeminiService now handles this internally via environment injection.
      const result = await geminiService.generateBlueprint(finalIntent);
      setBlueprint(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex items-center justify-between border-b border-gray-900 pb-6">
        <div>
          <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter flex items-center gap-3">
            <i className="fa-solid fa-microchip text-blue-500"></i>
            Architecture Ops
          </h2>
          <p className="text-[10px] text-gray-500 mono uppercase tracking-[0.3em] mt-1">Real-Time Infrastructure Visualization</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-gray-900 px-4 py-2 rounded-xl border border-gray-800 flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] font-black text-gray-400 mono">PROD_NODES: 4/4</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Expanded Blueprint Preset HUD */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-gray-900/40 border border-gray-800 rounded-3xl p-6 shadow-2xl backdrop-blur-sm">
            <h3 className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-6 flex items-center justify-between">
              <span>Veteran Preset Registry</span>
              <span className="text-[9px] bg-blue-500/10 text-blue-500 px-2 py-0.5 rounded border border-blue-500/20">TOP 50</span>
            </h3>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-1.5 mb-6">
               {categories.map(cat => (
                 <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`text-[9px] font-black px-2.5 py-1 rounded-lg border transition-all uppercase tracking-tighter ${
                    activeCategory === cat ? 'bg-blue-600 border-blue-500 text-white' : 'bg-gray-950 border-gray-800 text-gray-600 hover:text-gray-400'
                  }`}
                 >
                   {cat}
                 </button>
               ))}
            </div>

            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
              {filteredBlueprints.map(b => (
                <button 
                  key={b.id} 
                  onClick={() => handleSynthesize(`Architect a production-grade ${b.title} using ${b.tech}. Focus on ${b.intent}`)}
                  className="w-full bg-gray-950 border border-gray-800 p-4 rounded-2xl flex items-center gap-4 group hover:border-blue-500/50 transition-all text-left relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                    <i className={`fa-solid ${b.icon} text-3xl`}></i>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center text-gray-600 group-hover:text-blue-400 transition-colors shadow-inner shrink-0 border border-gray-800">
                    <i className={`fa-solid ${b.icon} text-sm`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] font-black text-gray-200 uppercase leading-none mb-1 truncate">{b.title}</div>
                    <div className="text-[8px] text-gray-600 mono truncate">{b.tech}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/40 border border-gray-800 rounded-3xl p-6 shadow-2xl backdrop-blur-sm">
            <h3 className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-6">Node Status</h3>
            <div className="space-y-4">
              {nodes.map(node => (
                <div key={node.id} className="bg-gray-950 border border-gray-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-white uppercase tracking-wider">{node.name}</span>
                    <span className={`text-[8px] font-bold px-2 py-0.5 rounded-full ${node.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-gray-800 text-gray-500'}`}>
                      {node.status}
                    </span>
                  </div>
                  <div className="w-full h-1 bg-gray-900 rounded-full overflow-hidden mb-1">
                    <div className={`h-full transition-all duration-1000 ${node.load > 60 ? 'bg-yellow-500' : 'bg-blue-500'}`} style={{ width: `${node.load}%` }}></div>
                  </div>
                  <div className="flex justify-between text-[8px] text-gray-600 font-black uppercase">
                    <span>Load: {node.load}%</span>
                    <span>Health: {node.health}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Blueprint Viewer Content */}
        <div className="lg:col-span-8">
          {isGenerating ? (
            <div className="h-full min-h-[600px] bg-gray-900 border border-gray-800 rounded-[3rem] flex flex-col items-center justify-center p-20 text-center animate-pulse">
              <div className="w-24 h-24 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-8 shadow-[0_0_30px_rgba(37,99,235,0.2)]"></div>
              <h3 className="text-2xl font-black text-white uppercase italic tracking-widest">Synthesizing Blueprint</h3>
              <p className="text-[10px] text-gray-500 mono mt-2 uppercase tracking-widest">Grounded Search Active // Auditing Category: {activeCategory}</p>
            </div>
          ) : blueprint ? (
            <div className="bg-gray-900 border border-gray-800 rounded-[3rem] p-12 shadow-2xl animate-in fade-in zoom-in-95 duration-700 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 flex gap-3">
                <button onClick={() => setBlueprint(null)} className="text-gray-600 hover:text-white transition-colors w-12 h-12 rounded-2xl bg-gray-950 border border-gray-800 flex items-center justify-center">
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>
              
              <div className="mb-12 border-b border-gray-800 pb-12">
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-[9px] font-black text-blue-500 bg-blue-500/5 border border-blue-500/20 px-3 py-1 rounded-full uppercase tracking-widest">Architectural_Commit_4.2</span>
                  <span className="text-[9px] text-gray-600 mono uppercase tracking-widest">Checksum: {Math.random().toString(16).slice(2, 10).toUpperCase()}</span>
                </div>
                <h1 className="text-5xl font-black text-white uppercase italic tracking-tighter leading-none">{blueprint.title}</h1>
                <p className="text-lg text-gray-400 mt-8 leading-relaxed max-w-4xl border-l-4 border-blue-600 pl-10 py-6 italic bg-blue-600/5 rounded-r-[3rem]">
                  {blueprint.summary}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-10">
                   <h4 className="text-[12px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-3">
                     <i className="fa-solid fa-layer-group text-blue-500"></i> Infrastructure Matrix
                   </h4>
                   <div className="space-y-4">
                     {blueprint.layers.map((l: any, i: number) => (
                       <div key={i} className="p-8 bg-gray-950 border border-gray-800 rounded-[2.5rem] group hover:border-blue-600/40 transition-all shadow-xl border-l-4 border-l-transparent hover:border-l-blue-600">
                         <div className="text-[10px] font-black text-blue-500 uppercase mb-2 tracking-widest">{l.name}</div>
                         <div className="text-base font-black text-gray-100 mb-4">{l.tech}</div>
                         <p className="text-[11px] text-gray-500 leading-relaxed italic">{l.rationale}</p>
                       </div>
                     ))}
                   </div>
                </div>

                <div className="space-y-10">
                   <h4 className="text-[12px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-3">
                     <i className="fa-solid fa-database text-emerald-500"></i> Entity Schema (Postgres)
                   </h4>
                   <div className="space-y-4">
                      {blueprint.dataModel.map((d: any, i: number) => (
                        <div key={i} className="p-6 bg-gray-950 border border-gray-800 rounded-3xl mono shadow-inner">
                          <div className="text-[11px] font-black text-emerald-500 uppercase mb-4 flex items-center gap-3">
                            <i className="fa-solid fa-table"></i> {d.table}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {d.columns.map((c: string, j: number) => (
                              <span key={j} className="text-[10px] bg-gray-900 border border-gray-800 px-4 py-1.5 rounded-xl text-gray-400 font-bold tracking-tight">
                                {c}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                   </div>

                   <h4 className="text-[12px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-3 pt-6">
                     <i className="fa-solid fa-shield-halved text-red-500"></i> Security Directives
                   </h4>
                   <div className="grid grid-cols-2 gap-4">
                      {blueprint.security.map((s: string, i: number) => (
                        <div key={i} className="text-[10px] font-black text-gray-400 bg-red-500/5 border border-red-500/10 px-5 py-4 rounded-[1.5rem] uppercase tracking-tighter italic hover:bg-red-500/10 transition-colors flex items-center gap-3 leading-tight">
                          <i className="fa-solid fa-shield-check text-red-500/50"></i>
                          {s}
                        </div>
                      ))}
                   </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[600px] flex flex-col items-center justify-center border-2 border-dashed border-gray-800 rounded-[4rem] bg-gray-950/20 text-gray-700 p-20 text-center relative overflow-hidden group">
               <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
               <i className="fa-solid fa-compass-drafting text-[10rem] mb-12 opacity-10 group-hover:scale-110 transition-transform duration-700 text-blue-500"></i>
               <h3 className="text-4xl font-black uppercase tracking-[0.2em] italic mb-6 text-gray-600">Awaiting Directive</h3>
               <p className="text-xs mono max-w-sm text-gray-700 leading-relaxed uppercase tracking-widest">
                 Commit a veteran configuration from the registry to initiate high-fidelity architectural synthesis.
               </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
