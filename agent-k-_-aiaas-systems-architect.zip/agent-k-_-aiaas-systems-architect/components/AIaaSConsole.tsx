
import React, { useState } from 'react';

export const AIaaSConsole: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tiers' | 'usage' | 'api-keys' | 'monetization'>('tiers');

  return (
    <div className="space-y-8 pb-12">
      <div className="flex items-center justify-between border-b border-gray-900 pb-6">
        <div>
          <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter flex items-center gap-3">
            <i className="fa-solid fa-cloud-arrow-up text-purple-500"></i>
            AIaaS Orchestrator
          </h2>
          <p className="text-[10px] text-gray-500 mono uppercase tracking-[0.3em] mt-1">Multi-Tenant API Service Manager</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-gray-900 px-4 py-2 rounded-xl border border-gray-800 flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] font-black text-gray-400 mono">API_GATEWAY: ACTIVE</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Quick Stats */}
        <div className="bg-gray-900/60 border border-gray-800 p-6 rounded-3xl space-y-2">
          <div className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Total API Revenue</div>
          <div className="text-2xl font-black text-emerald-500">$12,402.10</div>
          <div className="text-[8px] text-emerald-500/50 uppercase font-black tracking-widest">+12% vs last 24h</div>
        </div>
        <div className="bg-gray-900/60 border border-gray-800 p-6 rounded-3xl space-y-2">
          <div className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Total Tokens Processed</div>
          <div className="text-2xl font-black text-blue-500">842.1M</div>
          <div className="text-[8px] text-blue-500/50 uppercase font-black tracking-widest">Avg Cost: $0.00012/1k</div>
        </div>
        <div className="bg-gray-900/60 border border-gray-800 p-6 rounded-3xl space-y-2">
          <div className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Active Multi-Tenants</div>
          <div className="text-2xl font-black text-white">42 Nodes</div>
          <div className="text-[8px] text-gray-500 uppercase font-black tracking-widest">Peak Load: 68%</div>
        </div>
        <div className="bg-gray-900/60 border border-gray-800 p-6 rounded-3xl space-y-2">
          <div className="text-[9px] font-black text-gray-600 uppercase tracking-widest">SLA Uptime</div>
          <div className="text-2xl font-black text-white">99.999%</div>
          <div className="text-[8px] text-emerald-500 uppercase font-black tracking-widest">Zero Incidents (24h)</div>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-[3rem] overflow-hidden flex flex-col min-h-[500px] shadow-2xl">
        <div className="flex bg-gray-950 border-b border-gray-800 p-3 gap-3">
          {['tiers', 'usage', 'api-keys', 'monetization'].map((t) => (
            <button 
              key={t}
              onClick={() => setActiveTab(t as any)}
              className={`flex-1 py-4 text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl transition-all ${activeTab === t ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300 hover:bg-gray-900'}`}
            >
              {t.replace('-', ' ')}
            </button>
          ))}
        </div>

        <div className="p-12 flex-1 flex items-center justify-center text-center">
          <div className="max-w-md space-y-6">
            <i className="fa-solid fa-screwdriver-wrench text-6xl text-purple-500/20"></i>
            <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Console View: {activeTab.toUpperCase()}</h3>
            <p className="text-xs text-gray-500 mono uppercase tracking-widest leading-relaxed">
              This module is currently initializing telemetry hooks for the {activeTab} service. Automated usage metering and tiered billing sync is active in the background.
            </p>
            <button className="bg-gray-800 border border-gray-700 px-6 py-3 rounded-2xl text-[10px] font-black text-white uppercase tracking-widest hover:border-purple-500/50 transition-all">
              Initiate Manual Billing Audit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
