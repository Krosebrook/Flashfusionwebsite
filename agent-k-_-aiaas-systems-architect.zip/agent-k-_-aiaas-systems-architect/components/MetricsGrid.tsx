
import React from 'react';

export const MetricsGrid: React.FC = () => {
  const metrics = [
    { label: 'System Load', value: '14.2%', trend: 'down', color: 'text-green-400' },
    { label: 'Avg Latency', value: '184ms', trend: 'up', color: 'text-yellow-400' },
    { label: 'Cost/Request', value: '$0.0004', trend: 'stable', color: 'text-blue-400' },
    { label: 'Queue Depth', value: '42 ops', trend: 'down', color: 'text-green-400' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((m, i) => (
        <div key={i} className="bg-gray-900/50 border border-gray-800 rounded-2xl p-5 hover:border-gray-700 transition-colors group">
          <div className="text-xs text-gray-500 font-medium mb-1 uppercase tracking-widest">{m.label}</div>
          <div className="flex items-end justify-between">
            <div className={`text-2xl font-bold tracking-tight ${m.color}`}>{m.value}</div>
            <div className="text-[10px] flex items-center gap-1 font-bold">
               {m.trend === 'up' && <i className="fa-solid fa-arrow-trend-up text-red-500"></i>}
               {m.trend === 'down' && <i className="fa-solid fa-arrow-trend-down text-green-500"></i>}
               {m.trend === 'stable' && <i className="fa-solid fa-minus text-gray-500"></i>}
               <span className="uppercase text-gray-600">{m.trend}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
