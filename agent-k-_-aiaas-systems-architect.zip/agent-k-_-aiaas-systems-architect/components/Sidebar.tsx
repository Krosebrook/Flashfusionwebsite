
import React from 'react';
import { ViewState } from '../App';
import { UserProfile } from '../types';

interface SidebarProps {
  activeView: ViewState;
  onViewChange: (view: ViewState) => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  profile: UserProfile;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange, isOpen, toggleSidebar, profile }) => {
  const navItems = [
    { id: 'architecture', icon: 'fa-diagram-project', label: 'Architecture' },
    { id: 'designer', icon: 'fa-pen-ruler', label: 'Product Designer' },
    { id: 'aiaas', icon: 'fa-cloud-arrow-up', label: 'AIaaS Console' },
    { id: 'routing', icon: 'fa-route', label: 'Model Router' },
    { id: 'security', icon: 'fa-shield-halved', label: 'Security Guard' },
    { id: 'terminal', icon: 'fa-terminal', label: 'Terminal' },
    { id: 'settings', icon: 'fa-sliders', label: 'Settings' },
  ] as { id: ViewState, icon: string, label: string }[];

  return (
    <aside className={`${isOpen ? 'w-64' : 'w-20'} h-full bg-gray-900 border-r border-gray-800 flex flex-col transition-all duration-300 z-20`}>
      <div className="p-6 h-14 border-b border-gray-800 flex items-center justify-between shrink-0">
        {isOpen && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg italic tracking-tighter">K</div>
            <span className="font-bold tracking-tight text-white uppercase italic tracking-tighter">Agent K</span>
          </div>
        )}
        <button onClick={toggleSidebar} className="text-gray-400 hover:text-white transition-colors">
          <i className={`fa-solid ${isOpen ? 'fa-chevron-left' : 'fa-bars'} text-sm`}></i>
        </button>
      </div>

      <nav className="flex-1 p-4 flex flex-col gap-2 overflow-y-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`flex items-center gap-4 p-3 rounded-xl transition-all group ${
              activeView === item.id 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
            }`}
          >
            <i className={`fa-solid ${item.icon} w-5 text-center`}></i>
            {isOpen && <span className="text-sm font-black uppercase tracking-widest italic">{item.label}</span>}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-3">
           <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center font-black text-blue-400 text-xs">
             {profile.name.charAt(0)}
           </div>
           {isOpen && (
             <div className="flex flex-col overflow-hidden">
               <span className="text-[10px] font-black text-gray-200 uppercase tracking-tighter truncate">{profile.name}</span>
               <span className="text-[8px] text-emerald-500 uppercase font-black">{profile.role}</span>
             </div>
           )}
        </div>
      </div>
    </aside>
  );
};
