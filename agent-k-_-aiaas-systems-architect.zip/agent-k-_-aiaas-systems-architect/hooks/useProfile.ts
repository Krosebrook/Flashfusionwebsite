
import { useState, useEffect } from 'react';
import { UserProfile } from '../types';

const DEFAULT_PROFILE: UserProfile = {
  name: 'Kyle S. Architect',
  role: 'Level 10 Master Architect',
  // Removed apiKeys to comply with security guidelines
  preferences: {
    theme: 'dark',
    autoGrounding: true,
    terminalStyle: 'modern'
  }
};

export const useProfile = () => {
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('agent-k-profile');
      return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
    } catch (e) {
      return DEFAULT_PROFILE;
    }
  });

  useEffect(() => {
    localStorage.setItem('agent-k-profile', JSON.stringify(profile));
  }, [profile]);

  // Removed updateApiKey to comply with strictly enforced security guidelines

  const updatePreferences = (prefs: Partial<UserProfile['preferences']>) => {
    setProfile(prev => ({
      ...prev,
      preferences: { ...prev.preferences, ...prefs }
    }));
  };

  return { profile, setProfile, updatePreferences };
};
