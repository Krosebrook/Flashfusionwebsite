# Bundled Releases

This folder contains prior ZIP artifacts produced during this build thread.

- **ai-ops-control-plane_v1.0.zip** — initial post-production control plane repo (UI + migrations + functions).
- **ai-ops-control-plane_v1.1_docs.zip** — same repo with documentation patches (Implementation Considerations / Perf+Security / Next Steps / Claims Check) woven into README.

## Notes
- These ZIPs are provided for traceability and rollback. They should generally **not** be committed to Git.
- The canonical, current state is the parent repo folder.
