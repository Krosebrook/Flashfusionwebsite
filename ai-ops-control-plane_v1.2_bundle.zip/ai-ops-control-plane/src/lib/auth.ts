import type { User } from "@supabase/supabase-js";
import { supabaseBrowser } from "@/lib/supabase/browser";

export async function ensureUserDirectory(user: User) {
  // Mirrors email + roles into user_directory so role-sync has O(1) lookup by email.
  // Safe: RLS restricts rows to self/approver/admin.
  const supabase = supabaseBrowser();
  const roles = (user.app_metadata?.roles ?? []) as string[];
  const email = (user.email ?? null) as string | null;

  const { error } = await supabase.from("user_directory").upsert({
    user_id: user.id,
    email,
    roles
  });

  if (error) {
    // Do not hard-fail the app; log and continue.
    console.warn("ensureUserDirectory failed:", error.message);
  }
}
