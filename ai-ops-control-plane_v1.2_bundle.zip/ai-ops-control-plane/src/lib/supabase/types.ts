export type ControlPlaneDomain = "foh" | "boh" | "platform";
export type ApprovalStatus = "pending" | "approved" | "rejected" | "expired" | "cancelled";
export type ExecutionStatus = "not_started" | "executing" | "succeeded" | "failed";

export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export type Tables = {
  approvals: {
    Row: {
      id: string;
      domain: ControlPlaneDomain;
      action: string;
      details: Json;
      requester: string;
      status: ApprovalStatus;
      requested_at: string;
      decided_at: string | null;
      decided_by: string | null;
      decision_reason: string | null;
      expires_at: string | null;
      correlation_id: string;
      execution_status: ExecutionStatus;
      execution_attempts: number;
      executed_at: string | null;
      execution_error: string | null;
    };
  };
  audit_logs: {
    Row: {
      id: string;
      domain: ControlPlaneDomain;
      event_type: string;
      actor_id: string | null;
      ip: string | null;
      user_agent: string | null;
      correlation_id: string | null;
      payload: Json;
      created_at: string;
    };
  };
  foh_queue_items: {
    Row: {
      id: string;
      source_type: "outlook" | "teams" | "manual" | "sharepoint";
      source_ref: string | null;
      subject: string | null;
      from_address: string | null;
      received_at: string | null;
      product: string | null;
      urgency: "low" | "medium" | "high" | "urgent" | null;
      sentiment: "negative" | "neutral" | "positive" | null;
      status: "new" | "triaged" | "drafting" | "awaiting_approval" | "sent" | "closed" | "error";
      excerpt: string | null;
      last_error: string | null;
      created_at: string;
      updated_at: string;
    };
  };
  foh_drafts: {
    Row: {
      id: string;
      queue_item_id: string | null;
      requester: string;
      source_type: "outlook" | "teams" | "manual" | "sharepoint";
      source_ref: string | null;
      subject: string | null;
      to_recipients: Json;
      cc_recipients: Json;
      body_markdown: string;
      model_provider: "anthropic" | "openai" | "gemini";
      model_name: string | null;
      token_usage: Json;
      created_at: string;
      updated_at: string;
    };
  };
  boh_preflight_runs: {
    Row: {
      id: string;
      correlation_id: string | null;
      requester: string;
      repo_full_name: string;
      ref: string;
      ci_provider: "github_actions" | "other";
      sbom: Json;
      secrets_scan: Json;
      license_scan: Json;
      test_results: Json;
      lint_results: Json;
      risk_score: number;
      risk_flags: Json;
      model_provider: "anthropic" | "openai" | "gemini";
      model_name: string | null;
      token_usage: Json;
      status: "queued" | "running" | "succeeded" | "failed";
      created_at: string;
      updated_at: string;
      last_error: string | null;
    };
  };
  user_directory: {
    Row: {
      user_id: string;
      email: string | null;
      roles: Json;
      created_at: string;
      updated_at: string;
    };
  };
  rollback_runbooks: {
    Row: {
      id: string;
      domain: ControlPlaneDomain;
      title: string;
      steps_markdown: string;
      created_by: string | null;
      created_at: string;
      updated_at: string;
    };
  };
  slo_metrics: {
    Row: {
      id: string;
      domain: ControlPlaneDomain;
      metric: string;
      value: number;
      window_start: string;
      window_end: string;
      created_at: string;
    };
  };
};
