"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { Button } from "@/components/Button";
import { JsonBlock } from "@/components/JsonBlock";

export default function RunbooksPage() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [rows, setRows] = useState<any[]>([]);
  const [me, setMe] = useState<any>(null);

  const refresh = async () => {
    const u = await supabase.auth.getUser();
    setMe(u.data.user ?? null);
    const r = await supabase.from("rollback_runbooks").select("*").order("updated_at", { ascending: false }).limit(200);
    setRows(r.data ?? []);
  };

  useEffect(() => { refresh(); }, []);

  const roles = (me?.app_metadata?.roles ?? []) as string[];
  const canWrite = roles.includes("admin") || roles.includes("approver");

  const createRunbook = async () => {
    const domain = (prompt("domain: foh | boh | platform", "boh") ?? "").trim() as any;
    const title = (prompt("Title:") ?? "").trim();
    const steps = (prompt("Markdown steps (paste):") ?? "").trim();
    if (!domain || !title || !steps) return;

    const { error } = await supabase.from("rollback_runbooks").insert({
      domain,
      title,
      steps_markdown: steps
    });
    if (error) alert(error.message);
    else await refresh();
  };

  return (
    <Shell title="Runbooks (Rollback + Overrides)" right={<a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Back</a>}>
      <div className="flex items-center justify-between">
        <div className="text-sm text-slate-300">
          Write access requires approver/admin. Current roles: {roles.join(", ") || "—"}
        </div>
        {canWrite && <Button className="bg-cyan-500 text-slate-950" onClick={createRunbook}>New runbook</Button>}
      </div>

      <div className="space-y-3">
        {rows.map(r => (
          <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{String(r.domain).toUpperCase()} • {r.title}</div>
              <div className="text-sm text-slate-400">updated: {new Date(r.updated_at).toLocaleString()}</div>
            </div>
            <pre className="p-2 rounded bg-slate-950 overflow-x-auto text-sm border border-slate-800 whitespace-pre-wrap">
              {r.steps_markdown}
            </pre>
          </div>
        ))}
        {rows.length === 0 && <div className="text-slate-400">No runbooks yet.</div>}
      </div>
    </Shell>
  );
}
