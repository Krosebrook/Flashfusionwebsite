"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { Button } from "@/components/Button";
import { JsonBlock } from "@/components/JsonBlock";

async function callFunction(path: string, token: string, body: unknown) {
  const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/${path}`;
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body)
  });
  const json = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(json?.error ?? resp.statusText);
  return json;
}

export default function BOHPage() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [runs, setRuns] = useState<any[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = async () => {
    const r = await supabase.from("boh_preflight_runs").select("*").order("created_at", { ascending: false }).limit(100);
    setRuns(r.data ?? []);
  };

  useEffect(() => { refresh(); }, []);

  const requestPreflight = async () => {
    const repo = prompt("Repo full name (owner/repo):");
    const ref = prompt("Ref (branch or SHA):");
    if (!repo || !ref) return;

    setBusy("new");
    const { data: session } = await supabase.auth.getSession();
    const token = session.session?.access_token;
    if (!token) throw new Error("Missing session token");

    try {
      // Ask model for an initial risk summary (advisory only), stored as a preflight run.
      await callFunction("analyze", token, {
        domain: "boh",
        task: "risk_summary",
        input: { repo_full_name: repo, ref }
      });
      await refresh();
      alert("Preflight run created. Now request approval to run CI.");
    } finally {
      setBusy(null);
    }
  };

  const requestCiApproval = async (run: any) => {
    setBusy(run.id);
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return;

    const { data, error } = await supabase.rpc("request_approval", {
      p_domain: "boh",
      p_action: "run_preflight",
      p_details: {
        preflight_id: run.id,
        repo_full_name: run.repo_full_name,
        ref: run.ref,
        workflow_file: "preflight.yml"
      },
      p_expires_at: null
    });

    setBusy(null);
    if (error) {
      alert(error.message);
      return;
    }
    alert(`Approval requested: ${data?.id ?? "—"}`);
  };

  const requestDeployApproval = async (run: any) => {
    setBusy(run.id);
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return;

    const { data, error } = await supabase.rpc("request_approval", {
      p_domain: "boh",
      p_action: "deploy_canary",
      p_details: {
        preflight_id: run.id,
        repo_full_name: run.repo_full_name,
        ref: run.ref,
        workflow_file: "deploy.yml",
        risk_score: run.risk_score
      },
      p_expires_at: null
    });

    setBusy(null);
    if (error) {
      alert(error.message);
      return;
    }
    alert(`Deploy approval requested: ${data?.id ?? "—"}`);
  };

  return (
    <Shell title="BOH — Preflight → Gate → Canary/Blue-Green → Rollback" right={<a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Back</a>}>
      <div className="flex gap-2">
        <Button className="bg-cyan-500 text-slate-950" onClick={requestPreflight} disabled={busy === "new"}>
          {busy === "new" ? "Working…" : "New preflight (AI risk summary)"}
        </Button>
        <a className="px-3 py-2 rounded bg-slate-800" href="/approvals">Go to approvals</a>
      </div>

      <div className="space-y-3">
        {runs.map(r => (
          <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{r.repo_full_name} @ {r.ref}</div>
              <div className="text-sm text-slate-300">{r.status}</div>
            </div>
            <div className="text-sm text-slate-400">risk_score: {r.risk_score}</div>
            <JsonBlock value={{ risk_flags: r.risk_flags, last_error: r.last_error }} />
            <div className="flex gap-2">
              <Button className="bg-slate-800" onClick={() => requestCiApproval(r)} disabled={busy === r.id}>
                Request CI Preflight Approval
              </Button>
              <Button className="bg-emerald-500 text-slate-950" onClick={() => requestDeployApproval(r)} disabled={busy === r.id || r.status !== "succeeded"}>
                Request Deploy Approval
              </Button>
            </div>
            <div className="text-xs text-slate-400">
              Deploy approvals are only meaningful after CI results are ingested and this run is marked succeeded.
            </div>
          </div>
        ))}
        {runs.length === 0 && <div className="text-slate-400">No preflight runs yet.</div>}
      </div>
    </Shell>
  );
}
