"use client";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";
import { Shell } from "@/components/Shell";
import { Button } from "@/components/Button";
import { JsonBlock } from "@/components/JsonBlock";

type Decision = "approved" | "rejected" | "cancelled";

export default function ApprovalsPage() {
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [rows, setRows] = useState<any[]>([]);
  const [me, setMe] = useState<any>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = async () => {
    const u = await supabase.auth.getUser();
    setMe(u.data.user ?? null);
    const r = await supabase.from("approvals").select("*").order("requested_at", { ascending: false }).limit(200);
    setRows(r.data ?? []);
  };

  useEffect(() => { refresh(); }, []);

  const decide = async (id: string, decision: Exclude<Decision,"cancelled">, reason: string) => {
    setBusyId(id);
    const res = await supabase.rpc("decide_approval", {
      p_approval_id: id,
      p_decision: decision,
      p_reason: reason
    });
    setBusyId(null);
    if (res.error) {
      alert(res.error.message);
      return;
    }
    await refresh();
  };

  const execute = async (id: string) => {
    setBusyId(id);
    const { data: session } = await supabase.auth.getSession();
    const token = session.session?.access_token;
    if (!token) {
      alert("Missing session token");
      setBusyId(null);
      return;
    }
    const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/execute-approved`;
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ approval_id: id })
    });
    const json = await resp.json().catch(() => ({}));
    setBusyId(null);
    if (!resp.ok) {
      alert(`Execute failed: ${json?.error ?? resp.statusText}`);
      return;
    }
    alert("Executed.");
    await refresh();
  };

  const roles = (me?.app_metadata?.roles ?? []) as string[];
  const canDecide = roles.includes("approver") || roles.includes("admin");

  return (
    <Shell title="Approvals" right={<a className="px-3 py-2 rounded bg-slate-800" href="/dashboard">Back</a>}>
      <div className="text-sm text-slate-300">
        Signed in: {me?.email ?? "—"} • roles: {roles.join(", ") || "—"}
      </div>

      <div className="space-y-3">
        {rows.map(a => (
          <div key={a.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{String(a.domain).toUpperCase()} • {a.action}</div>
              <div className="text-slate-300">{a.status} / {a.execution_status}</div>
            </div>

            <div className="text-slate-400 text-sm">
              requested: {new Date(a.requested_at).toLocaleString()} • corr: {a.correlation_id}
            </div>

            <JsonBlock value={a.details} />

            {a.status === "pending" && canDecide && (
              <div className="flex gap-2">
                <Button
                  className="bg-emerald-500 text-slate-950"
                  onClick={() => decide(a.id, "approved", "Approved in control plane")}
                  disabled={busyId === a.id}
                >
                  Approve
                </Button>
                <Button
                  className="bg-rose-500 text-slate-950"
                  onClick={() => decide(a.id, "rejected", "Rejected in control plane")}
                  disabled={busyId === a.id}
                >
                  Reject
                </Button>
              </div>
            )}

            {a.status === "approved" && a.execution_status !== "succeeded" && (
              <Button
                className="bg-cyan-500 text-slate-950"
                onClick={() => execute(a.id)}
                disabled={busyId === a.id}
              >
                Execute Approved Action
              </Button>
            )}

            {a.execution_status === "failed" && (
              <div className="text-sm text-rose-300">
                execution_error: {a.execution_error ?? "—"}
              </div>
            )}
          </div>
        ))}
        {rows.length === 0 && <div className="text-slate-400">No approvals visible.</div>}
      </div>
    </Shell>
  );
}
