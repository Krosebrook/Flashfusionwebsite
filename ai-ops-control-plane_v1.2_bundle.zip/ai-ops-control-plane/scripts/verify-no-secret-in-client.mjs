import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const dir = path.join(root, ".next");
if (!fs.existsSync(dir)) {
  console.error("Build output not found. Run: npm run build");
  process.exit(1);
}

const needle = "SUPABASE_SERVICE_ROLE_KEY";
let hits = 0;

function walk(p) {
  const st = fs.statSync(p);
  if (st.isDirectory()) {
    for (const name of fs.readdirSync(p)) walk(path.join(p, name));
    return;
  }
  if (!st.isFile()) return;
  const txt = fs.readFileSync(p, "utf8");
  if (txt.includes(needle)) {
    console.error("[leak] Found service key string in:", p);
    hits++;
  }
}

walk(dir);

if (hits > 0) {
  console.error(`FAIL: detected ${hits} potential secret leaks in client build output.`);
  process.exit(2);
}
console.log("[ok] No service-role leak detected in .next build output.");
