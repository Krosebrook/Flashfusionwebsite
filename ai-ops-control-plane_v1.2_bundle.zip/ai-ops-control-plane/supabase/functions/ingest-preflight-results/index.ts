import { corsHeaders } from "../_shared/cors.ts";
import { reqEnv } from "../_shared/env.ts";
import { hmacSha256Hex, timingSafeEqual } from "../_shared/hmac.ts";
import { supabaseAdmin } from "../_shared/supabase.ts";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    const secret = reqEnv("CONTROL_PLANE_WEBHOOK_SECRET");
    const sig = req.headers.get("x-control-plane-signature") ?? "";
    const raw = await req.text();
    const expected = await hmacSha256Hex(secret, raw);
    if (!timingSafeEqual(sig, expected)) return jsonResponse(401, { error: "Invalid signature" });

    const body = JSON.parse(raw);
    const correlation_id = body?.correlation_id as string;
    const repo = body?.repo as string;
    const ref = body?.ref as string;
    const results = body?.results ?? {};

    if (!correlation_id || !repo || !ref) return jsonResponse(400, { error: "Missing correlation_id/repo/ref" });

    const admin = supabaseAdmin();
    const run = await admin.from("boh_preflight_runs").select("*").eq("correlation_id", correlation_id).single();

    if (run.error || !run.data?.id) {
      return jsonResponse(404, { error: "Preflight run not found for correlation_id" });
    }

    const ok = Boolean(results?.ok ?? true);
    const status = ok ? "succeeded" : "failed";

    const upd = await admin.from("boh_preflight_runs").update({
      status,
      test_results: results?.tests ?? {},
      lint_results: results?.lint ?? {},
      sbom: results?.sbom ?? {},
      secrets_scan: results?.secrets ?? {},
      license_scan: results?.licenses ?? {},
      last_error: ok ? null : String(results?.error ?? "preflight failed")
    }).eq("id", run.data.id);

    if (upd.error) return jsonResponse(500, { error: upd.error.message });

    await admin.rpc("append_audit", {
      p_domain: "boh",
      p_event_type: "boh.preflight.ingested",
      p_payload: { correlation_id, repo, ref, status, results },
      p_correlation_id: correlation_id,
      p_ip: null,
      p_user_agent: "ingest-preflight-results"
    });

    return jsonResponse(200, { ok: true, status });
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
