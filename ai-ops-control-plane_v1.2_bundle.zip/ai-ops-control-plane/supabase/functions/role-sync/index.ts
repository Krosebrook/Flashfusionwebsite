import { corsHeaders } from "../_shared/cors.ts";
import { reqEnv } from "../_shared/env.ts";
import { supabaseAdmin, supabaseAuthed } from "../_shared/supabase.ts";

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

type GraphTokenResp = { access_token: string };

async function getGraphToken(): Promise<GraphTokenResp> {
  const tenant = reqEnv("AZURE_TENANT_ID");
  const clientId = reqEnv("AZURE_CLIENT_ID");
  const clientSecret = reqEnv("AZURE_CLIENT_SECRET");
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
    scope: "https://graph.microsoft.com/.default"
  });
  const resp = await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!resp.ok) throw new Error(await resp.text());
  return await resp.json();
}

async function graphPaged(token: string, url: string): Promise<any[]> {
  const out: any[] = [];
  let next: string | null = url;

  while (next) {
    const resp = await fetch(next, { headers: { Authorization: `Bearer ${token}` } });
    if (!resp.ok) throw new Error(`Graph GET failed: ${resp.status} ${await resp.text()}`);
    const json = await resp.json();
    out.push(...(json.value ?? []));
    next = json["@odata.nextLink"] ?? null;
  }
  return out;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (req.method !== "POST") return jsonResponse(405, { error: "Method Not Allowed" });

    // Require caller to be admin (manual trigger). Schedules can call with service key separately if you want.
    const authHeader = req.headers.get("Authorization");
    const authed = supabaseAuthed(authHeader);
    const { data: userRes, error: userErr } = await authed.auth.getUser();
    if (userErr || !userRes.user) return jsonResponse(401, { error: "Unauthorized" });

    const roles = (userRes.user.app_metadata?.roles ?? []) as string[];
    if (!roles.includes("admin")) return jsonResponse(403, { error: "Admin role required" });

    const admin = supabaseAdmin();
    const { data: maps, error: mapErr } = await admin.from("role_mappings").select("*");
    if (mapErr) return jsonResponse(500, { error: mapErr.message });

    const { access_token } = await getGraphToken();

    // Map email -> roles set
    const roleByEmail = new Map<string, Set<string>>();

    for (const m of maps ?? []) {
      const members = await graphPaged(
        access_token,
        `https://graph.microsoft.com/v1.0/groups/${m.entra_group_id}/members?$select=id,mail,userPrincipalName`
      );

      for (const u of members) {
        const email = String((u.mail ?? u.userPrincipalName ?? "")).toLowerCase();
        if (!email) continue;
        if (!roleByEmail.has(email)) roleByEmail.set(email, new Set());
        roleByEmail.get(email)!.add(m.role_name);
      }
    }

    let changed = 0;
    for (const [email, rolesSet] of roleByEmail.entries()) {
      const rolesArr = Array.from(rolesSet);

      const dir = await admin.from("user_directory").select("*").eq("email", email).single();
      if (dir.error || !dir.data?.user_id) continue;

      const before = dir.data.roles ?? [];
      const beforeSorted = JSON.stringify([...before].sort());
      const afterSorted = JSON.stringify([...rolesArr].sort());
      if (beforeSorted === afterSorted) continue;

      // Update directory
      await admin.from("user_directory").update({ roles: rolesArr }).eq("user_id", dir.data.user_id);

      // Update JWT claims (app_metadata.roles)
      await admin.auth.admin.updateUserById(dir.data.user_id, { app_metadata: { roles: rolesArr } });

      await admin.rpc("append_audit", {
        p_domain: "platform",
        p_event_type: "roles.synced",
        p_payload: { email, before, after: rolesArr },
        p_correlation_id: null,
        p_ip: null,
        p_user_agent: "role-sync"
      });

      changed++;
    }

    await admin.rpc("append_audit", {
      p_domain: "platform",
      p_event_type: "roles.sync.summary",
      p_payload: { changed },
      p_correlation_id: null,
      p_ip: null,
      p_user_agent: "role-sync"
    });

    return jsonResponse(200, { ok: true, changed });
  } catch (e) {
    return jsonResponse(500, { error: (e as Error).message });
  }
});
