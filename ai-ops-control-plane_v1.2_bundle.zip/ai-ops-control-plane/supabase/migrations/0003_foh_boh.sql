-- 0003_foh_boh.sql
-- FOH queue + drafts; BOH preflight runs.

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end $$;

create table if not exists public.foh_queue_items (
  id uuid primary key default gen_random_uuid(),
  source_type text not null check (source_type in ('outlook','teams','manual','sharepoint')),
  source_ref text,
  subject text,
  from_address text,
  received_at timestamptz,
  product text,
  urgency text check (urgency in ('low','medium','high','urgent')),
  sentiment text check (sentiment in ('negative','neutral','positive')),
  status text not null default 'new' check (status in ('new','triaged','drafting','awaiting_approval','sent','closed','error')),
  excerpt text,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists foh_queue_source_idx
on public.foh_queue_items(source_type, source_ref)
where source_ref is not null;

drop trigger if exists trg_touch_queue on public.foh_queue_items;
create trigger trg_touch_queue
before update on public.foh_queue_items
for each row
execute function public.touch_updated_at();

alter table public.foh_queue_items enable row level security;

-- Queue visibility: support_agent/approver/admin
drop policy if exists foh_queue_select on public.foh_queue_items;
create policy foh_queue_select
on public.foh_queue_items for select
to authenticated
using (public.has_role('support_agent') or public.has_role('approver') or public.has_role('admin'));

-- Queue edits: support_agent/admin
drop policy if exists foh_queue_update on public.foh_queue_items;
create policy foh_queue_update
on public.foh_queue_items for update
to authenticated
using (public.has_role('support_agent') or public.has_role('admin'))
with check (public.has_role('support_agent') or public.has_role('admin'));

-- Queue inserts: support_agent/admin (manual intake)
drop policy if exists foh_queue_insert on public.foh_queue_items;
create policy foh_queue_insert
on public.foh_queue_items for insert
to authenticated
with check (public.has_role('support_agent') or public.has_role('admin'));

-- Queue delete blocked
drop policy if exists foh_queue_no_delete on public.foh_queue_items;
create policy foh_queue_no_delete
on public.foh_queue_items for delete
to authenticated
using (false);

create table if not exists public.foh_drafts (
  id uuid primary key default gen_random_uuid(),
  queue_item_id uuid references public.foh_queue_items(id) on delete set null,
  requester uuid not null default auth.uid() references auth.users(id) on delete cascade,
  source_type text not null check (source_type in ('outlook','teams','manual','sharepoint')),
  source_ref text,
  subject text,
  to_recipients jsonb not null default '[]'::jsonb,
  cc_recipients jsonb not null default '[]'::jsonb,
  body_markdown text not null,
  model_provider text not null check (model_provider in ('anthropic','openai','gemini')),
  model_name text,
  token_usage jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_touch_drafts on public.foh_drafts;
create trigger trg_touch_drafts
before update on public.foh_drafts
for each row
execute function public.touch_updated_at();

alter table public.foh_drafts enable row level security;

drop policy if exists foh_drafts_select on public.foh_drafts;
create policy foh_drafts_select
on public.foh_drafts for select
to authenticated
using (
  requester = auth.uid()
  or public.has_role('support_agent')
  or public.has_role('approver')
  or public.has_role('admin')
);

drop policy if exists foh_drafts_insert on public.foh_drafts;
create policy foh_drafts_insert
on public.foh_drafts for insert
to authenticated
with check (
  requester = auth.uid()
  and (public.has_role('support_agent') or public.has_role('admin') or requester = auth.uid())
);

drop policy if exists foh_drafts_update on public.foh_drafts;
create policy foh_drafts_update
on public.foh_drafts for update
to authenticated
using (
  requester = auth.uid()
  or public.has_role('support_agent')
  or public.has_role('admin')
)
with check (
  requester = auth.uid()
  or public.has_role('support_agent')
  or public.has_role('admin')
);

drop policy if exists foh_drafts_no_delete on public.foh_drafts;
create policy foh_drafts_no_delete
on public.foh_drafts for delete
to authenticated
using (false);

create table if not exists public.boh_preflight_runs (
  id uuid primary key default gen_random_uuid(),
  correlation_id uuid,
  requester uuid not null default auth.uid() references auth.users(id) on delete cascade,
  repo_full_name text not null,
  ref text not null,
  ci_provider text not null default 'github_actions' check (ci_provider in ('github_actions','other')),
  sbom jsonb not null default '{}'::jsonb,
  secrets_scan jsonb not null default '{}'::jsonb,
  license_scan jsonb not null default '{}'::jsonb,
  test_results jsonb not null default '{}'::jsonb,
  lint_results jsonb not null default '{}'::jsonb,
  risk_score int not null default 0,
  risk_flags jsonb not null default '[]'::jsonb,
  model_provider text not null check (model_provider in ('anthropic','openai','gemini')),
  model_name text,
  token_usage jsonb not null default '{}'::jsonb,
  status text not null default 'queued' check (status in ('queued','running','succeeded','failed')),
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists preflight_created_idx on public.boh_preflight_runs(created_at desc);
create index if not exists preflight_repo_idx on public.boh_preflight_runs(repo_full_name);
create index if not exists preflight_corr_idx on public.boh_preflight_runs(correlation_id);

drop trigger if exists trg_touch_preflight on public.boh_preflight_runs;
create trigger trg_touch_preflight
before update on public.boh_preflight_runs
for each row
execute function public.touch_updated_at();

alter table public.boh_preflight_runs enable row level security;

drop policy if exists preflight_select_scope on public.boh_preflight_runs;
create policy preflight_select_scope
on public.boh_preflight_runs for select
to authenticated
using (
  requester = auth.uid()
  or public.has_role('engineer')
  or public.has_role('approver')
  or public.has_role('admin')
);

drop policy if exists preflight_insert_scope on public.boh_preflight_runs;
create policy preflight_insert_scope
on public.boh_preflight_runs for insert
to authenticated
with check (requester = auth.uid());

drop policy if exists preflight_update_scope on public.boh_preflight_runs;
create policy preflight_update_scope
on public.boh_preflight_runs for update
to authenticated
using (requester = auth.uid() or public.has_role('engineer') or public.has_role('admin'))
with check (requester = auth.uid() or public.has_role('engineer') or public.has_role('admin'));

drop policy if exists preflight_no_delete on public.boh_preflight_runs;
create policy preflight_no_delete
on public.boh_preflight_runs for delete
to authenticated
using (false);
