# Security Assurance Notes (FOH/BOH AI Ops Control Plane)

This document is a canonical, audit-friendly explanation of the exact invariants this control plane relies on. It is intended to be **read by humans** (Security, IT, Engineering) and used as a **source-of-truth** for operating the system.

## Implementation Considerations

### Graph `sendMail` is powerful (keep it Edge-only)

- The `sendMail` API explicitly supports both:
  - `POST /me/sendMail`
  - `POST /users/{id|userPrincipalName}/sendMail`
  And the permissions table lists `Mail.Send` as **least-privileged** for both delegated and application usage.
  - https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0

- Success is **`202 Accepted`** (not “done”): it indicates Graph accepted the request for processing; delivery is still subject to Exchange Online limitations/throttling.
  - https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0

- Sent Items behavior depends on endpoint + mailbox permissions. Microsoft documents how save location differs based on `/me` vs `/users/{id}` and how Send As / Send on Behalf and admin “always save” settings impact storage.
  - https://learn.microsoft.com/en-us/graph/outlook-send-mail-from-other-user

- App-only vs delegated nuance:
  - apps using **application tokens** with `Mail.Send` can send mail “as any user” (admin-consented)
  - apps using **user tokens** use `Mail.Send.Shared` for “send as another mailbox” scenarios
  - https://learn.microsoft.com/en-us/graph/outlook-send-mail-from-other-user

**Operational invariant:** the browser never calls Graph. Outbound send happens only inside Edge Functions after verifying `approvals.status = 'approved'`.

### JWT role freshness (Supabase)

- Supabase RLS documentation warns JWTs are not always “fresh” and `auth.jwt()` won’t reflect `app_metadata` changes until the JWT is refreshed.
  - https://supabase.com/docs/guides/database/postgres/row-level-security

**Operational invariant:** after role-sync, users must refresh claims (logout/login or session refresh) before role changes are enforced everywhere.

### RBAC source of truth (`app_metadata.roles` + `has_role()`)

- This repo uses `app_metadata.roles` in the JWT plus a SQL helper (`has_role()`) referenced by RLS and RPC guards.
- Supabase’s **Custom Access Token Hook** runs before tokens are issued and is the intended mechanism to add/shape claims for stronger guarantees.
  - https://supabase.com/docs/guides/auth/auth-hooks/custom-access-token-hook
  - https://supabase.com/docs/guides/database/postgres/custom-claims-and-role-based-access-control-rbac

## Performance / Security Notes

### Service role key must never be used in browsers

- Supabase API key docs explicitly say:
  - “Never expose your `service_role` and secret keys”
  - “Never use in a browser, even on localhost”
  - and that service-role style access can bypass RLS (BYPASSRLS).
  - https://supabase.com/docs/guides/api/api-keys

**Operational invariant:** service credentials exist only in Edge Function secrets / server-controlled components. They never appear in client bundles, `NEXT_PUBLIC_*`, or front-end runtime.

### GitHub `workflow_dispatch` returns no run ID (`204`) → `correlation_id` is the join key

- GitHub REST docs for `workflow_dispatch` specify **`204 No Content`** (no body), so a workflow run id is not available from the dispatch call.
  - https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event

- Community reports confirm there have been periods where the endpoint returned `200` with a body containing a run id; do not hard-require `204`-only semantics.
  - https://github.com/orgs/community/discussions/182272

**Operational invariant:** `correlation_id` is the stable join across approval → dispatch → CI callback → audit.

### HMAC webhook verification for CI callbacks

- Verified callbacks + timing-safe compare prevents random internet input from mutating BOH state. This is standard webhook hardening.

## Recommended Next Steps

1. Populate `role_mappings` with Entra group IDs, then run `/role-sync` once; have users refresh JWTs (logout/login).
   - https://supabase.com/docs/guides/database/postgres/row-level-security

2. Create a private Storage bucket `audit-exports` and schedule `export-audit` daily.

3. Lock Graph scopes to read-only first; only add `Mail.Send` when you’re ready for approval-gated sending.
   - https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0

4. Swap deploy workflow to your real canary/blue-green mechanism; keep the control-plane contract (approve → execute → audit) unchanged.
   - https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event

5. Keep LLM keys server-side; OpenAI documentation warns against deploying keys in client-side environments.
   - https://platform.openai.com/docs/api-reference/introduction

## CLAIMS CHECK

- **Claim:** `sendMail` supports `/me` and `/users/{id|upn}` and `Mail.Send` is least-privileged.
  - **Confirmed:** https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0

- **Claim:** `202 Accepted` is not “done”; delivery subject to Exchange Online limits/throttling.
  - **Confirmed:** https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0

- **Claim:** Supabase JWT not always fresh; role changes require refresh to affect `auth.jwt()`.
  - **Confirmed:** https://supabase.com/docs/guides/database/postgres/row-level-security

- **Claim:** `workflow_dispatch` returns `204` and no run id.
  - **Confirmed:** https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event

- **Counterexample:** GitHub sometimes returned `200` with body; strict `204` parsing breaks.
  - **Mitigation:** keep `correlation_id` as the join key; treat response body as optional/unstable.
  - **Evidence:** https://github.com/orgs/community/discussions/182272

- **Counterexample:** `SUPABASE_SERVICE_ROLE_KEY` leak collapses RLS.
  - **Confirmed risk:** Supabase explicitly warns against browser use.
  - **Mitigation:** server-only secrets + bundle checks.
  - **Evidence:** https://supabase.com/docs/guides/api/api-keys

- **Potential contradiction:** “No placeholders” vs “don’t expose secrets.”
  - **Resolution:** env schemas + runtime secret injection; never hardcode keys in code or docs.
