import type { ColumnType, Generated, Insertable, Selectable, Updateable } from 'kysely';

// ============================================
// ENUM TYPES
// ============================================

export type ProductStatus = 'DRAFT' | 'ACTIVE' | 'PUBLISHED' | 'ARCHIVED';
export type ProductType = 'T_SHIRT' | 'HOODIE' | 'MUG' | 'POSTER' | 'PHONE_CASE' | 'TOTE_BAG' | 'CANVAS' | 'STICKER' | 'HAT' | 'BLANKET';
export type StoreType = 'SHOPIFY' | 'ETSY' | 'AMAZON' | 'WOOCOMMERCE' | 'EBAY' | 'CUSTOM';
export type SyncStatus = 'PENDING' | 'SYNCING' | 'SYNCED' | 'ERROR' | 'DISCONNECTED';
export type AssetType = 'IMAGE' | 'VECTOR' | 'DOCUMENT';
export type AssetStatus = 'UPLOADING' | 'PROCESSING' | 'READY' | 'ERROR';
export type EventType =
  | 'PRODUCT_CREATED' | 'PRODUCT_UPDATED' | 'PRODUCT_DELETED' | 'PRODUCT_PUBLISHED' | 'PRODUCT_UNPUBLISHED' | 'PRODUCT_ARCHIVED'
  | 'STORE_CONNECTED' | 'STORE_DISCONNECTED' | 'STORE_SYNC_STARTED' | 'STORE_SYNC_COMPLETED' | 'STORE_SYNC_FAILED'
  | 'ASSET_UPLOADED' | 'ASSET_DELETED' | 'ASSET_PROCESSED'
  | 'USER_LOGIN' | 'USER_LOGOUT' | 'USER_SETTINGS_UPDATED'
  | 'BULK_OPERATION_STARTED' | 'BULK_OPERATION_COMPLETED' | 'BULK_OPERATION_FAILED'
  | 'EXPORT_COMPLETED' | 'IMPORT_COMPLETED';
export type EntityType = 'PRODUCT' | 'STORE' | 'ASSET' | 'USER' | 'SYSTEM';
export type EventSeverity = 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
export type UserRole = 'USER' | 'ADMIN' | 'SUPER_ADMIN';

// ============================================
// TABLE TYPES
// ============================================

export interface UsersTable {
  id: Generated<string>;
  email: string;
  password_hash: string;
  name: string;
  role: ColumnType<UserRole, UserRole | undefined, UserRole>;
  avatar_url: string | null;
  email_verified: ColumnType<boolean, boolean | undefined, boolean>;
  email_verified_at: Date | null;
  last_login_at: Date | null;
  settings: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  created_at: ColumnType<Date, Date | undefined, never>;
  updated_at: ColumnType<Date, Date | undefined, never>;
  deleted_at: Date | null;
}

export type User = Selectable<UsersTable>;
export type NewUser = Insertable<UsersTable>;
export type UserUpdate = Updateable<UsersTable>;

export interface SessionsTable {
  id: Generated<string>;
  user_id: string;
  token_hash: string;
  ip_address: string | null;
  user_agent: string | null;
  expires_at: Date;
  created_at: ColumnType<Date, Date | undefined, never>;
  last_active_at: ColumnType<Date, Date | undefined, Date>;
}

export type Session = Selectable<SessionsTable>;
export type NewSession = Insertable<SessionsTable>;
export type SessionUpdate = Updateable<SessionsTable>;

export interface StoresTable {
  id: Generated<string>;
  user_id: string;
  name: string;
  type: StoreType;
  store_url: string | null;
  api_key_encrypted: string | null;
  api_secret_encrypted: string | null;
  access_token_encrypted: string | null;
  refresh_token_encrypted: string | null;
  token_expires_at: Date | null;
  is_active: ColumnType<boolean, boolean | undefined, boolean>;
  last_sync_at: Date | null;
  sync_status: ColumnType<SyncStatus, SyncStatus | undefined, SyncStatus>;
  sync_error: string | null;
  product_count: ColumnType<number, number | undefined, number>;
  metadata: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  created_at: ColumnType<Date, Date | undefined, never>;
  updated_at: ColumnType<Date, Date | undefined, never>;
  deleted_at: Date | null;
}

export type Store = Selectable<StoresTable>;
export type NewStore = Insertable<StoresTable>;
export type StoreUpdate = Updateable<StoresTable>;

export interface AssetsTable {
  id: Generated<string>;
  user_id: string;
  filename: string;
  original_filename: string;
  mime_type: string;
  type: AssetType;
  status: ColumnType<AssetStatus, AssetStatus | undefined, AssetStatus>;
  size_bytes: number;
  storage_url: string;
  storage_key: string;
  thumbnail_url: string | null;
  width: number | null;
  height: number | null;
  dpi: number | null;
  color_space: string | null;
  tags: ColumnType<string[], string[] | undefined, string[]>;
  usage_count: ColumnType<number, number | undefined, number>;
  metadata: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  created_at: ColumnType<Date, Date | undefined, never>;
  updated_at: ColumnType<Date, Date | undefined, never>;
  deleted_at: Date | null;
}

export type Asset = Selectable<AssetsTable>;
export type NewAsset = Insertable<AssetsTable>;
export type AssetUpdate = Updateable<AssetsTable>;

export interface ProductsTable {
  id: Generated<string>;
  user_id: string;
  store_id: string | null;
  design_asset_id: string | null;
  title: string;
  description: string | null;
  type: ProductType;
  sku: string;
  price: number;
  cost: ColumnType<number, number | undefined, number>;
  status: ColumnType<ProductStatus, ProductStatus | undefined, ProductStatus>;
  tags: ColumnType<string[], string[] | undefined, string[]>;
  external_id: string | null;
  external_url: string | null;
  metadata: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  published_at: Date | null;
  created_at: ColumnType<Date, Date | undefined, never>;
  updated_at: ColumnType<Date, Date | undefined, never>;
  deleted_at: Date | null;
}

export type Product = Selectable<ProductsTable>;
export type NewProduct = Insertable<ProductsTable>;
export type ProductUpdate = Updateable<ProductsTable>;

export interface ProductVariantsTable {
  id: Generated<string>;
  product_id: string;
  sku: string;
  name: string;
  price_modifier: ColumnType<number, number | undefined, number>;
  cost_modifier: ColumnType<number, number | undefined, number>;
  attributes: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  external_id: string | null;
  is_active: ColumnType<boolean, boolean | undefined, boolean>;
  created_at: ColumnType<Date, Date | undefined, never>;
  updated_at: ColumnType<Date, Date | undefined, never>;
}

export type ProductVariant = Selectable<ProductVariantsTable>;
export type NewProductVariant = Insertable<ProductVariantsTable>;
export type ProductVariantUpdate = Updateable<ProductVariantsTable>;

export interface EventsTable {
  id: Generated<string>;
  user_id: string;
  entity_type: EntityType;
  entity_id: string;
  event_type: EventType;
  severity: ColumnType<EventSeverity, EventSeverity | undefined, EventSeverity>;
  message: string | null;
  payload: ColumnType<Record<string, unknown>, Record<string, unknown> | undefined, Record<string, unknown>>;
  ip_address: string | null;
  user_agent: string | null;
  created_at: ColumnType<Date, Date | undefined, never>;
}

export type Event = Selectable<EventsTable>;
export type NewEvent = Insertable<EventsTable>;

export interface BulkOperationsTable {
  id: Generated<string>;
  user_id: string;
  operation_type: string;
  entity_type: EntityType;
  status: ColumnType<string, string | undefined, string>;
  total_items: ColumnType<number, number | undefined, number>;
  processed_items: ColumnType<number, number | undefined, number>;
  failed_items: ColumnType<number, number | undefined, number>;
  errors: ColumnType<unknown[], unknown[] | undefined, unknown[]>;
  result_url: string | null;
  started_at: Date | null;
  completed_at: Date | null;
  created_at: ColumnType<Date, Date | undefined, never>;
}

export type BulkOperation = Selectable<BulkOperationsTable>;
export type NewBulkOperation = Insertable<BulkOperationsTable>;
export type BulkOperationUpdate = Updateable<BulkOperationsTable>;

export interface RateLimitsTable {
  id: Generated<string>;
  identifier: string;
  endpoint: string;
  request_count: ColumnType<number, number | undefined, number>;
  window_start: ColumnType<Date, Date | undefined, Date>;
}

export type RateLimit = Selectable<RateLimitsTable>;
export type NewRateLimit = Insertable<RateLimitsTable>;
export type RateLimitUpdate = Updateable<RateLimitsTable>;

export interface PasswordResetTokensTable {
  id: Generated<string>;
  user_id: string;
  token_hash: string;
  expires_at: Date;
  used_at: Date | null;
  created_at: ColumnType<Date, Date | undefined, never>;
}

export type PasswordResetToken = Selectable<PasswordResetTokensTable>;
export type NewPasswordResetToken = Insertable<PasswordResetTokensTable>;

export interface EmailVerificationTokensTable {
  id: Generated<string>;
  user_id: string;
  token_hash: string;
  expires_at: Date;
  verified_at: Date | null;
  created_at: ColumnType<Date, Date | undefined, never>;
}

export type EmailVerificationToken = Selectable<EmailVerificationTokensTable>;
export type NewEmailVerificationToken = Insertable<EmailVerificationTokensTable>;

// ============================================
// DATABASE INTERFACE
// ============================================

export interface Database {
  users: UsersTable;
  sessions: SessionsTable;
  password_reset_tokens: PasswordResetTokensTable;
  email_verification_tokens: EmailVerificationTokensTable;
  stores: StoresTable;
  assets: AssetsTable;
  products: ProductsTable;
  product_variants: ProductVariantsTable;
  events: EventsTable;
  bulk_operations: BulkOperationsTable;
  rate_limits: RateLimitsTable;
}
