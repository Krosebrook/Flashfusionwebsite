-- ============================================
-- POD CENTRAL HUB - DATABASE SCHEMA
-- PostgreSQL 15+
-- ============================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For fuzzy text search

-- ============================================
-- ENUM TYPES
-- ============================================

-- Product status lifecycle
CREATE TYPE product_status AS ENUM ('DRAFT', 'ACTIVE', 'PUBLISHED', 'ARCHIVED');

-- Product types (POD specific)
CREATE TYPE product_type AS ENUM (
    'T_SHIRT',
    'HOODIE',
    'MUG',
    'POSTER',
    'PHONE_CASE',
    'TOTE_BAG',
    'CANVAS',
    'STICKER',
    'HAT',
    'BLANKET'
);

-- Store integration types
CREATE TYPE store_type AS ENUM ('SHOPIFY', 'ETSY', 'AMAZON', 'WOOCOMMERCE', 'EBAY', 'CUSTOM');

-- Store sync status
CREATE TYPE sync_status AS ENUM ('PENDING', 'SYNCING', 'SYNCED', 'ERROR', 'DISCONNECTED');

-- Asset types
CREATE TYPE asset_type AS ENUM ('IMAGE', 'VECTOR', 'DOCUMENT');

-- Asset processing status
CREATE TYPE asset_status AS ENUM ('UPLOADING', 'PROCESSING', 'READY', 'ERROR');

-- Event types for audit log
CREATE TYPE event_type AS ENUM (
    -- Product events
    'PRODUCT_CREATED',
    'PRODUCT_UPDATED',
    'PRODUCT_DELETED',
    'PRODUCT_PUBLISHED',
    'PRODUCT_UNPUBLISHED',
    'PRODUCT_ARCHIVED',
    -- Store events
    'STORE_CONNECTED',
    'STORE_DISCONNECTED',
    'STORE_SYNC_STARTED',
    'STORE_SYNC_COMPLETED',
    'STORE_SYNC_FAILED',
    -- Asset events
    'ASSET_UPLOADED',
    'ASSET_DELETED',
    'ASSET_PROCESSED',
    -- User events
    'USER_LOGIN',
    'USER_LOGOUT',
    'USER_SETTINGS_UPDATED',
    -- System events
    'BULK_OPERATION_STARTED',
    'BULK_OPERATION_COMPLETED',
    'BULK_OPERATION_FAILED',
    'EXPORT_COMPLETED',
    'IMPORT_COMPLETED'
);

-- Entity types for audit
CREATE TYPE entity_type AS ENUM ('PRODUCT', 'STORE', 'ASSET', 'USER', 'SYSTEM');

-- Event severity
CREATE TYPE event_severity AS ENUM ('INFO', 'WARNING', 'ERROR', 'SUCCESS');

-- User roles
CREATE TYPE user_role AS ENUM ('USER', 'ADMIN', 'SUPER_ADMIN');

-- ============================================
-- TABLES
-- ============================================

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role user_role DEFAULT 'USER',
    avatar_url TEXT,
    email_verified BOOLEAN DEFAULT FALSE,
    email_verified_at TIMESTAMP WITH TIME ZONE,
    last_login_at TIMESTAMP WITH TIME ZONE,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE -- Soft delete
);

-- Password reset tokens
CREATE TABLE password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email verification tokens
CREATE TABLE email_verification_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    verified_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Sessions table (for refresh tokens)
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_active_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Stores table
CREATE TABLE stores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type store_type NOT NULL,
    store_url VARCHAR(500),
    api_key_encrypted TEXT,
    api_secret_encrypted TEXT,
    access_token_encrypted TEXT,
    refresh_token_encrypted TEXT,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    sync_status sync_status DEFAULT 'PENDING',
    sync_error TEXT,
    product_count INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE, -- Soft delete

    CONSTRAINT unique_store_per_user UNIQUE (user_id, name)
);

-- Design assets table
CREATE TABLE assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    type asset_type NOT NULL,
    status asset_status DEFAULT 'UPLOADING',
    size_bytes BIGINT NOT NULL CHECK (size_bytes > 0),
    storage_url TEXT NOT NULL,
    storage_key TEXT NOT NULL, -- S3/R2 key for deletion
    thumbnail_url TEXT,
    width INTEGER CHECK (width > 0),
    height INTEGER CHECK (height > 0),
    dpi INTEGER CHECK (dpi > 0),
    color_space VARCHAR(50),
    tags TEXT[] DEFAULT '{}',
    usage_count INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE -- Soft delete
);

-- Products table
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    store_id UUID REFERENCES stores(id) ON DELETE SET NULL,
    design_asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type product_type NOT NULL,
    sku VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    cost DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (cost >= 0),
    status product_status DEFAULT 'DRAFT',
    tags TEXT[] DEFAULT '{}',
    external_id VARCHAR(255), -- ID in external store
    external_url TEXT,
    metadata JSONB DEFAULT '{}',
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE, -- Soft delete

    CONSTRAINT unique_sku_per_user UNIQUE (user_id, sku),
    CONSTRAINT valid_margin CHECK (price >= cost)
);

-- Product variants (sizes, colors, etc.)
CREATE TABLE product_variants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    price_modifier DECIMAL(10, 2) DEFAULT 0, -- Added to base price
    cost_modifier DECIMAL(10, 2) DEFAULT 0, -- Added to base cost
    attributes JSONB DEFAULT '{}', -- {size: "XL", color: "Blue"}
    external_id VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    CONSTRAINT unique_variant_sku UNIQUE (product_id, sku)
);

-- Events table (audit log)
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type entity_type NOT NULL,
    entity_id UUID NOT NULL,
    event_type event_type NOT NULL,
    severity event_severity DEFAULT 'INFO',
    message TEXT,
    payload JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bulk operations tracking
CREATE TABLE bulk_operations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    operation_type VARCHAR(50) NOT NULL, -- 'CREATE', 'UPDATE', 'DELETE', 'EXPORT', 'IMPORT'
    entity_type entity_type NOT NULL,
    status VARCHAR(50) DEFAULT 'PENDING', -- 'PENDING', 'PROCESSING', 'COMPLETED', 'FAILED'
    total_items INTEGER DEFAULT 0,
    processed_items INTEGER DEFAULT 0,
    failed_items INTEGER DEFAULT 0,
    errors JSONB DEFAULT '[]',
    result_url TEXT, -- For exports, URL to download
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- API rate limiting
CREATE TABLE rate_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    identifier VARCHAR(255) NOT NULL, -- User ID or IP
    endpoint VARCHAR(255) NOT NULL,
    request_count INTEGER DEFAULT 1,
    window_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    CONSTRAINT unique_rate_limit UNIQUE (identifier, endpoint)
);

-- ============================================
-- INDEXES
-- ============================================

-- Users indexes
CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_role ON users(role) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_created_at ON users(created_at DESC);

-- Sessions indexes
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token_hash ON sessions(token_hash);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);

-- Stores indexes
CREATE INDEX idx_stores_user_id ON stores(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_stores_type ON stores(type) WHERE deleted_at IS NULL;
CREATE INDEX idx_stores_sync_status ON stores(sync_status) WHERE deleted_at IS NULL;
CREATE INDEX idx_stores_created_at ON stores(created_at DESC);

-- Assets indexes
CREATE INDEX idx_assets_user_id ON assets(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_type ON assets(type) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_status ON assets(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_tags ON assets USING GIN(tags) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_created_at ON assets(created_at DESC);

-- Products indexes
CREATE INDEX idx_products_user_id ON products(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_store_id ON products(store_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_status ON products(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_type ON products(type) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_sku ON products(sku) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_tags ON products USING GIN(tags) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_created_at ON products(created_at DESC);
CREATE INDEX idx_products_published_at ON products(published_at DESC) WHERE published_at IS NOT NULL;

-- Full text search on products
CREATE INDEX idx_products_search ON products USING gin(
    to_tsvector('english', title || ' ' || COALESCE(description, ''))
) WHERE deleted_at IS NULL;

-- Product variants indexes
CREATE INDEX idx_product_variants_product_id ON product_variants(product_id);

-- Events indexes
CREATE INDEX idx_events_user_id ON events(user_id);
CREATE INDEX idx_events_entity ON events(entity_type, entity_id);
CREATE INDEX idx_events_event_type ON events(event_type);
CREATE INDEX idx_events_created_at ON events(created_at DESC);
CREATE INDEX idx_events_severity ON events(severity);

-- Bulk operations indexes
CREATE INDEX idx_bulk_operations_user_id ON bulk_operations(user_id);
CREATE INDEX idx_bulk_operations_status ON bulk_operations(status);

-- Rate limits indexes
CREATE INDEX idx_rate_limits_identifier ON rate_limits(identifier);
CREATE INDEX idx_rate_limits_window ON rate_limits(window_start);

-- ============================================
-- FUNCTIONS
-- ============================================

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Increment asset usage count
CREATE OR REPLACE FUNCTION increment_asset_usage()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.design_asset_id IS NOT NULL THEN
        UPDATE assets
        SET usage_count = usage_count + 1
        WHERE id = NEW.design_asset_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Decrement asset usage count
CREATE OR REPLACE FUNCTION decrement_asset_usage()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.design_asset_id IS NOT NULL THEN
        UPDATE assets
        SET usage_count = GREATEST(0, usage_count - 1)
        WHERE id = OLD.design_asset_id;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Update store product count
CREATE OR REPLACE FUNCTION update_store_product_count()
RETURNS TRIGGER AS $$
BEGIN
    -- Update old store count if changed
    IF TG_OP = 'UPDATE' AND OLD.store_id IS DISTINCT FROM NEW.store_id THEN
        IF OLD.store_id IS NOT NULL THEN
            UPDATE stores
            SET product_count = (
                SELECT COUNT(*) FROM products
                WHERE store_id = OLD.store_id AND deleted_at IS NULL
            )
            WHERE id = OLD.store_id;
        END IF;
    END IF;

    -- Update new/current store count
    IF TG_OP IN ('INSERT', 'UPDATE') AND NEW.store_id IS NOT NULL THEN
        UPDATE stores
        SET product_count = (
            SELECT COUNT(*) FROM products
            WHERE store_id = NEW.store_id AND deleted_at IS NULL
        )
        WHERE id = NEW.store_id;
    END IF;

    -- Handle delete
    IF TG_OP = 'DELETE' AND OLD.store_id IS NOT NULL THEN
        UPDATE stores
        SET product_count = (
            SELECT COUNT(*) FROM products
            WHERE store_id = OLD.store_id AND deleted_at IS NULL
        )
        WHERE id = OLD.store_id;
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Clean expired sessions
CREATE OR REPLACE FUNCTION clean_expired_sessions()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Clean old rate limit records
CREATE OR REPLACE FUNCTION clean_old_rate_limits()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM rate_limits WHERE window_start < NOW() - INTERVAL '1 hour';
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- TRIGGERS
-- ============================================

-- Updated_at triggers
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_stores_updated_at
    BEFORE UPDATE ON stores
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_assets_updated_at
    BEFORE UPDATE ON assets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_products_updated_at
    BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_product_variants_updated_at
    BEFORE UPDATE ON product_variants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Asset usage tracking triggers
CREATE TRIGGER increment_asset_usage_on_product_insert
    AFTER INSERT ON products
    FOR EACH ROW EXECUTE FUNCTION increment_asset_usage();

CREATE TRIGGER update_asset_usage_on_product_update
    AFTER UPDATE OF design_asset_id ON products
    FOR EACH ROW
    WHEN (OLD.design_asset_id IS DISTINCT FROM NEW.design_asset_id)
    EXECUTE FUNCTION increment_asset_usage();

CREATE TRIGGER decrement_asset_usage_on_product_delete
    AFTER DELETE ON products
    FOR EACH ROW EXECUTE FUNCTION decrement_asset_usage();

-- Store product count triggers
CREATE TRIGGER update_store_count_on_product_change
    AFTER INSERT OR UPDATE OF store_id, deleted_at OR DELETE ON products
    FOR EACH ROW EXECUTE FUNCTION update_store_product_count();

-- ============================================
-- VIEWS
-- ============================================

-- Active products with store info
CREATE VIEW v_products_with_store AS
SELECT
    p.*,
    s.name as store_name,
    s.type as store_type,
    a.storage_url as design_url,
    a.thumbnail_url as design_thumbnail,
    (p.price - p.cost) as profit,
    CASE WHEN p.price > 0 THEN ROUND(((p.price - p.cost) / p.price * 100)::numeric, 2) ELSE 0 END as margin_percent
FROM products p
LEFT JOIN stores s ON p.store_id = s.id AND s.deleted_at IS NULL
LEFT JOIN assets a ON p.design_asset_id = a.id AND a.deleted_at IS NULL
WHERE p.deleted_at IS NULL;

-- Store statistics
CREATE VIEW v_store_stats AS
SELECT
    s.id,
    s.name,
    s.type,
    s.sync_status,
    s.last_sync_at,
    s.product_count,
    COUNT(DISTINCT CASE WHEN p.status = 'PUBLISHED' THEN p.id END) as published_count,
    COUNT(DISTINCT CASE WHEN p.status = 'DRAFT' THEN p.id END) as draft_count,
    COALESCE(SUM(p.price), 0) as total_catalog_value
FROM stores s
LEFT JOIN products p ON s.id = p.store_id AND p.deleted_at IS NULL
WHERE s.deleted_at IS NULL
GROUP BY s.id;

-- Recent activity feed
CREATE VIEW v_recent_activity AS
SELECT
    e.id,
    e.user_id,
    e.entity_type,
    e.entity_id,
    e.event_type,
    e.severity,
    e.message,
    e.created_at,
    u.name as user_name,
    CASE
        WHEN e.entity_type = 'PRODUCT' THEN (SELECT title FROM products WHERE id = e.entity_id)
        WHEN e.entity_type = 'STORE' THEN (SELECT name FROM stores WHERE id = e.entity_id)
        WHEN e.entity_type = 'ASSET' THEN (SELECT original_filename FROM assets WHERE id = e.entity_id)
        ELSE NULL
    END as entity_name
FROM events e
JOIN users u ON e.user_id = u.id
ORDER BY e.created_at DESC;

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

-- Enable RLS on all user-owned tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE bulk_operations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

-- Note: RLS policies should be created based on your auth setup
-- Example policies (using JWT claims):
/*
CREATE POLICY users_self_access ON users
    FOR ALL
    USING (id = current_setting('app.current_user_id')::uuid);

CREATE POLICY stores_owner_access ON stores
    FOR ALL
    USING (user_id = current_setting('app.current_user_id')::uuid);

CREATE POLICY products_owner_access ON products
    FOR ALL
    USING (user_id = current_setting('app.current_user_id')::uuid);

CREATE POLICY assets_owner_access ON assets
    FOR ALL
    USING (user_id = current_setting('app.current_user_id')::uuid);

CREATE POLICY events_owner_access ON events
    FOR ALL
    USING (user_id = current_setting('app.current_user_id')::uuid);
*/

-- ============================================
-- SEED DATA (Development Only)
-- ============================================

-- Uncomment for development seed data
/*
INSERT INTO users (id, email, password_hash, name, role, email_verified) VALUES
    ('00000000-0000-0000-0000-000000000001', 'admin@example.com', '$argon2id$v=19$m=65536,t=3,p=4$...', 'Admin User', 'ADMIN', true),
    ('00000000-0000-0000-0000-000000000002', 'user@example.com', '$argon2id$v=19$m=65536,t=3,p=4$...', 'Test User', 'USER', true);
*/

-- ============================================
-- MAINTENANCE QUERIES
-- ============================================

-- Query to check table sizes
-- SELECT
--     relname as table_name,
--     pg_size_pretty(pg_total_relation_size(relid)) as total_size
-- FROM pg_catalog.pg_statio_user_tables
-- ORDER BY pg_total_relation_size(relid) DESC;

-- Query to check index usage
-- SELECT
--     schemaname || '.' || relname as table,
--     indexrelname as index,
--     pg_size_pretty(pg_relation_size(indexrelid)) as size,
--     idx_scan as scans
-- FROM pg_stat_user_indexes
-- ORDER BY pg_relation_size(indexrelid) DESC;
