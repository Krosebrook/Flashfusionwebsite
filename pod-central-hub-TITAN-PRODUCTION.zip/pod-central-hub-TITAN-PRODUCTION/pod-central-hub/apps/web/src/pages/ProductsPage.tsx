import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Filter, Trash2, Download, Search } from 'lucide-react';
import {
  useProductStore,
  selectFilteredProducts,
  selectSelectedProducts,
  selectProductSelectedCount,
} from '../shared/store/productStore';
import {
  PageContainer,
  PageHeader,
  Button,
  Input,
  DataTable,
  Pagination,
  EmptyState,
  ConfirmModal,
  StatusBadge,
  Badge,
  type Column,
} from '../shared/ui';
import { useToast } from '../shared/hooks/useToast';
import { formatCurrency } from '../shared/lib/utils';
import type { Product } from '../entities/product/model/types';
import { ProductTypeLabels } from '../entities/product/model/types';

// ============================================
// TABLE COLUMNS
// ============================================

const productColumns: Column<Product>[] = [
  {
    id: 'title',
    header: 'Product',
    accessor: (row) => (
      <div>
        <p className="font-medium text-slate-900">{row.title}</p>
        <p className="text-sm text-slate-500">{row.sku}</p>
      </div>
    ),
    sortable: true,
  },
  {
    id: 'type',
    header: 'Type',
    accessor: (row) => (
      <Badge variant="outline">{ProductTypeLabels[row.type]}</Badge>
    ),
    sortable: true,
  },
  {
    id: 'price',
    header: 'Price',
    accessor: (row) => (
      <div>
        <p className="font-medium">{formatCurrency(row.price)}</p>
        {row.cost > 0 && (
          <p className="text-xs text-slate-500">Cost: {formatCurrency(row.cost)}</p>
        )}
      </div>
    ),
    sortable: true,
    align: 'right',
  },
  {
    id: 'status',
    header: 'Status',
    accessor: (row) => (
      <StatusBadge
        status={row.status.toLowerCase() as 'draft' | 'active' | 'published' | 'archived'}
      />
    ),
    sortable: true,
  },
];

// ============================================
// PRODUCTS PAGE
// ============================================

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { toast } = useToast();

  // Store state
  const {
    fetchProducts,
    bulkDelete,
    setFilters,
    clearSelection,
    isLoading,
    error,
    pagination,
  } = useProductStore();

  const products = useProductStore(selectFilteredProducts);
  const selectedProducts = useProductStore(selectSelectedProducts);
  const selectedCount = useProductStore(selectProductSelectedCount);

  // Local UI state
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Initial data fetch
  useEffect(() => {
    fetchProducts().catch((err) => {
      toast.error('Failed to load products', err.message);
    });
  }, [fetchProducts, toast]);

  // Sync search to URL and filters
  useEffect(() => {
    const debounce = setTimeout(() => {
      if (searchQuery) {
        setSearchParams({ q: searchQuery });
        setFilters({ search: searchQuery });
      } else {
        setSearchParams({});
        setFilters({ search: undefined });
      }
    }, 300);

    return () => clearTimeout(debounce);
  }, [searchQuery, setSearchParams, setFilters]);

  // Handlers
  const handleSearch = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  }, []);

  const handleDeleteClick = useCallback(() => {
    if (selectedCount > 0) {
      setIsDeleteModalOpen(true);
    }
  }, [selectedCount]);

  const handleConfirmDelete = useCallback(async () => {
    setIsDeleting(true);
    try {
      const ids = selectedProducts.map((p) => p.id);
      await bulkDelete(ids);
      clearSelection();
      setIsDeleteModalOpen(false);
      toast.success('Products deleted', `${ids.length} product(s) deleted successfully.`);
    } catch (err) {
      toast.error('Delete failed', (err as Error).message);
    } finally {
      setIsDeleting(false);
    }
  }, [selectedProducts, bulkDelete, clearSelection, toast]);

  const handleExport = useCallback(() => {
    // Convert products to CSV
    const headers = ['Title', 'SKU', 'Type', 'Price', 'Cost', 'Status'];
    const rows = products.map((p) => [
      p.title,
      p.sku,
      p.type,
      p.price.toString(),
      p.cost.toString(),
      p.status,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'products.csv';
    a.click();
    URL.revokeObjectURL(url);

    toast.success('Export complete');
  }, [products, toast]);

  // Render
  return (
    <PageContainer>
      <PageHeader
        title="Products"
        description="Manage your print-on-demand product catalog"
      >
        <div className="flex gap-2">
          {selectedCount > 0 && (
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDeleteClick}
              leftIcon={<Trash2 className="h-4 w-4" />}
            >
              Delete ({selectedCount})
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={handleExport}
            leftIcon={<Download className="h-4 w-4" />}
          >
            Export
          </Button>

          <Button
            size="sm"
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add Product
          </Button>
        </div>
      </PageHeader>

      {/* Search */}
      <div className="flex gap-4">
        <Input
          placeholder="Search products..."
          value={searchQuery}
          onChange={handleSearch}
          leftIcon={<Search className="h-4 w-4" />}
          className="max-w-sm"
        />
      </div>

      {/* Data Table or Empty State */}
      {products.length === 0 && !isLoading ? (
        <EmptyState
          icon="package"
          title="No products yet"
          description="Create your first product to start selling"
          action={
            <Button leftIcon={<Plus className="h-4 w-4" />}>
              Create Product
            </Button>
          }
        />
      ) : (
        <>
          <DataTable
            columns={productColumns}
            data={products}
            getRowId={(row) => row.id}
            isLoading={isLoading}
            selectable
            selectedIds={useProductStore.getState().selectedIds}
            onSelectionChange={(ids) => {
              useProductStore.setState({ selectedIds: ids });
            }}
            emptyMessage="No products match your search"
          />

          {pagination.totalPages > 1 && (
            <Pagination
              page={pagination.page}
              pageSize={pagination.pageSize}
              total={pagination.total}
              onPageChange={(page) => {
                // Would trigger a new fetch with pagination
              }}
            />
          )}
        </>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Products"
        description={`Are you sure you want to delete ${selectedCount} product(s)? This action cannot be undone.`}
        confirmText="Delete"
        variant="danger"
        isLoading={isDeleting}
      />
    </PageContainer>
  );
}
