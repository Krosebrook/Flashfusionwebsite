import React, { useEffect, useState, useCallback } from 'react';
import {
  Plus,
  RefreshCw,
  Store,
  ExternalLink,
  MoreHorizontal,
  Trash2,
  Settings,
} from 'lucide-react';
import { useStoreStore, selectStores, selectIsStoreSyncing } from '../shared/store/storeStore';
import {
  PageContainer,
  PageHeader,
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Button,
  EmptyState,
  StatusBadge,
  Skeleton,
  ConfirmModal,
} from '../shared/ui';
import { useToast } from '../shared/hooks/useToast';
import { formatRelativeTime } from '../shared/lib/utils';
import { StoreTypeLabels, StoreTypeIcons, SyncStatus } from '../entities/store/model/types';
import type { Store as StoreType } from '../entities/store/model/types';

// ============================================
// STORE CARD
// ============================================

interface StoreCardProps {
  store: StoreType;
  onSync: () => void;
  onDelete: () => void;
  isSyncing: boolean;
}

function StoreCard({ store, onSync, onDelete, isSyncing }: StoreCardProps) {
  const syncStatusMap: Record<string, 'pending' | 'syncing' | 'synced' | 'error' | 'disconnected'> = {
    PENDING: 'pending',
    SYNCING: 'syncing',
    SYNCED: 'synced',
    ERROR: 'error',
    DISCONNECTED: 'disconnected',
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
              <Store className="h-6 w-6 text-slate-600" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">{store.name}</h3>
              <p className="text-sm text-slate-500">{StoreTypeLabels[store.type]}</p>
            </div>
          </div>
          <StatusBadge status={syncStatusMap[store.syncStatus]} />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-2xl font-bold text-slate-900">{store.productCount}</p>
            <p className="text-xs text-slate-500">Products</p>
          </div>
          <div>
            <p className="text-sm font-medium text-slate-700">
              {store.lastSyncAt ? formatRelativeTime(store.lastSyncAt) : 'Never synced'}
            </p>
            <p className="text-xs text-slate-500">Last sync</p>
          </div>
        </div>

        {/* Error message */}
        {store.syncError && (
          <div className="p-2 bg-red-50 rounded-md">
            <p className="text-sm text-red-700">{store.syncError}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
          <Button
            variant="outline"
            size="sm"
            onClick={onSync}
            isLoading={isSyncing}
            leftIcon={<RefreshCw className="h-4 w-4" />}
            disabled={store.syncStatus === SyncStatus.DISCONNECTED || isSyncing}
          >
            Sync
          </Button>

          {store.storeUrl && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(store.storeUrl!, '_blank')}
              leftIcon={<ExternalLink className="h-4 w-4" />}
            >
              Open
            </Button>
          )}

          <div className="ml-auto flex gap-1">
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label="Settings"
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={onDelete}
              aria-label="Delete store"
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================
// STORES PAGE
// ============================================

export default function StoresPage() {
  const { toast } = useToast();

  // Store state
  const { fetchStores, syncStore, deleteStore, isLoading } = useStoreStore();
  const stores = useStoreStore(selectStores);

  // Local UI state
  const [deleteModalStore, setDeleteModalStore] = useState<StoreType | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Initial data fetch
  useEffect(() => {
    fetchStores().catch((err) => {
      toast.error('Failed to load stores', err.message);
    });
  }, [fetchStores, toast]);

  // Handlers
  const handleSync = useCallback(
    async (store: StoreType) => {
      try {
        const result = await syncStore(store.id);
        toast.success(
          'Sync complete',
          `${result.productsCreated} created, ${result.productsUpdated} updated`
        );
      } catch (err) {
        toast.error('Sync failed', (err as Error).message);
      }
    },
    [syncStore, toast]
  );

  const handleDeleteClick = useCallback((store: StoreType) => {
    setDeleteModalStore(store);
  }, []);

  const handleConfirmDelete = useCallback(async () => {
    if (!deleteModalStore) return;

    setIsDeleting(true);
    try {
      await deleteStore(deleteModalStore.id);
      setDeleteModalStore(null);
      toast.success('Store deleted', `${deleteModalStore.name} has been removed.`);
    } catch (err) {
      toast.error('Delete failed', (err as Error).message);
    } finally {
      setIsDeleting(false);
    }
  }, [deleteModalStore, deleteStore, toast]);

  // Loading state
  if (isLoading && stores.length === 0) {
    return (
      <PageContainer>
        <PageHeader title="Stores" description="Manage your connected store integrations" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Skeleton width={48} height={48} rounded="lg" />
                  <div>
                    <Skeleton width={120} height={20} />
                    <Skeleton width={80} height={16} className="mt-1" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Skeleton width="100%" height={40} />
                  <Skeleton width="100%" height={40} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader title="Stores" description="Manage your connected store integrations">
        <Button size="sm" leftIcon={<Plus className="h-4 w-4" />}>
          Connect Store
        </Button>
      </PageHeader>

      {stores.length === 0 ? (
        <EmptyState
          icon="store"
          title="No stores connected"
          description="Connect your first store to start syncing products"
          action={
            <Button leftIcon={<Plus className="h-4 w-4" />}>Connect Store</Button>
          }
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {stores.map((store) => (
            <StoreCard
              key={store.id}
              store={store}
              onSync={() => handleSync(store)}
              onDelete={() => handleDeleteClick(store)}
              isSyncing={useStoreStore.getState().syncingStoreIds.has(store.id)}
            />
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteModalStore}
        onClose={() => setDeleteModalStore(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Store"
        description={`Are you sure you want to delete "${deleteModalStore?.name}"? This will not affect products already synced to this store.`}
        confirmText="Delete"
        variant="danger"
        isLoading={isDeleting}
      />
    </PageContainer>
  );
}
