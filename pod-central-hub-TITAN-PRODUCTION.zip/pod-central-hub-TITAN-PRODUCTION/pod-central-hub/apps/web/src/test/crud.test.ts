// ============================================
// CRUD OPERATIONS - INTEGRATION TESTS
// ============================================

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { localDb, generateId, seedDemoData } from '@/shared/lib/localDb';
import type { Product } from '@/entities/product/model/types';
import type { Store } from '@/entities/store/model/types';

describe('Local Database CRUD Operations', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  describe('Basic Operations', () => {
    it('stores and retrieves data', () => {
      const testData = [{ id: '1', name: 'Test' }];
      localDb.set('test', testData);

      const retrieved = localDb.get<{ id: string; name: string }>('test');
      expect(retrieved).toEqual(testData);
    });

    it('returns empty array for non-existent key', () => {
      const result = localDb.get<unknown>('nonexistent');
      expect(result).toEqual([]);
    });

    it('gets single item by id', () => {
      const testData = [
        { id: '1', name: 'First' },
        { id: '2', name: 'Second' },
      ];
      localDb.set('test', testData);

      const item = localDb.getItem<{ id: string; name: string }>('test', '2');
      expect(item).toEqual({ id: '2', name: 'Second' });
    });

    it('returns null for non-existent item', () => {
      localDb.set('test', [{ id: '1', name: 'Test' }]);
      const item = localDb.getItem<{ id: string; name: string }>('test', '999');
      expect(item).toBeNull();
    });

    it('sets single item (create)', () => {
      const newItem = { id: '1', name: 'New Item' };
      localDb.setItem('test', newItem);

      const items = localDb.get<{ id: string; name: string }>('test');
      expect(items).toContainEqual(newItem);
    });

    it('sets single item (update)', () => {
      localDb.set('test', [{ id: '1', name: 'Original' }]);

      localDb.setItem('test', { id: '1', name: 'Updated' });

      const items = localDb.get<{ id: string; name: string }>('test');
      expect(items).toHaveLength(1);
      expect(items[0].name).toBe('Updated');
    });

    it('deletes item by id', () => {
      localDb.set('test', [
        { id: '1', name: 'Keep' },
        { id: '2', name: 'Delete' },
      ]);

      const result = localDb.deleteItem('test', '2');

      expect(result).toBe(true);
      const items = localDb.get<{ id: string; name: string }>('test');
      expect(items).toHaveLength(1);
      expect(items[0].id).toBe('1');
    });

    it('returns false when deleting non-existent item', () => {
      localDb.set('test', [{ id: '1', name: 'Test' }]);
      const result = localDb.deleteItem('test', '999');
      expect(result).toBe(false);
    });

    it('clears specific key', () => {
      localDb.set('test1', [{ id: '1' }]);
      localDb.set('test2', [{ id: '2' }]);

      localDb.clear('test1');

      expect(localDb.get('test1')).toEqual([]);
      expect(localDb.get('test2')).toHaveLength(1);
    });
  });

  describe('UUID Generation', () => {
    it('generates valid UUID v4 format', () => {
      const id = generateId();
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      expect(id).toMatch(uuidRegex);
    });

    it('generates unique IDs', () => {
      const ids = new Set<string>();
      for (let i = 0; i < 100; i++) {
        ids.add(generateId());
      }
      expect(ids.size).toBe(100);
    });
  });

  describe('Demo Data Seeding', () => {
    it('seeds demo data when empty', () => {
      seedDemoData();

      const products = localDb.get<Product>('products');
      const stores = localDb.get<Store>('stores');

      expect(products.length).toBeGreaterThan(0);
      expect(stores.length).toBeGreaterThan(0);
    });

    it('does not reseed if data exists', () => {
      localDb.set('products', [{ id: 'existing' }]);

      seedDemoData();

      const products = localDb.get<{ id: string }>('products');
      expect(products).toHaveLength(1);
      expect(products[0].id).toBe('existing');
    });

    it('seeds products with required fields', () => {
      seedDemoData();

      const products = localDb.get<Product>('products');
      products.forEach((product) => {
        expect(product.id).toBeDefined();
        expect(product.title).toBeDefined();
        expect(product.sku).toBeDefined();
        expect(product.price).toBeGreaterThan(0);
        expect(product.type).toBeDefined();
        expect(product.status).toBeDefined();
      });
    });

    it('seeds stores with required fields', () => {
      seedDemoData();

      const stores = localDb.get<Store>('stores');
      stores.forEach((store) => {
        expect(store.id).toBeDefined();
        expect(store.name).toBeDefined();
        expect(store.type).toBeDefined();
        expect(store.syncStatus).toBeDefined();
      });
    });
  });

  describe('Product CRUD', () => {
    beforeEach(() => {
      seedDemoData();
    });

    it('lists all products', () => {
      const products = localDb.get<Product>('products');
      expect(products.length).toBeGreaterThan(0);
    });

    it('creates a new product', () => {
      const initialCount = localDb.get<Product>('products').length;

      const newProduct: Product = {
        id: generateId(),
        userId: generateId(),
        title: 'New Test Product',
        description: 'Test description',
        type: 'MUG',
        sku: 'TEST-NEW-001',
        price: 19.99,
        cost: 8.00,
        status: 'DRAFT',
        storeId: null,
        designAssetId: null,
        tags: ['test', 'new'],
        externalId: null,
        externalUrl: null,
        metadata: {},
        publishedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      localDb.setItem('products', newProduct);

      const products = localDb.get<Product>('products');
      expect(products.length).toBe(initialCount + 1);
      expect(products.find((p) => p.sku === 'TEST-NEW-001')).toBeDefined();
    });

    it('updates an existing product', () => {
      const products = localDb.get<Product>('products');
      const productToUpdate = products[0];

      const updatedProduct = {
        ...productToUpdate,
        title: 'Updated Title',
        price: 99.99,
        updatedAt: new Date(),
      };

      localDb.setItem('products', updatedProduct);

      const retrieved = localDb.getItem<Product>('products', productToUpdate.id);
      expect(retrieved?.title).toBe('Updated Title');
      expect(retrieved?.price).toBe(99.99);
    });

    it('deletes a product', () => {
      const products = localDb.get<Product>('products');
      const initialCount = products.length;
      const productToDelete = products[0];

      localDb.deleteItem('products', productToDelete.id);

      const remainingProducts = localDb.get<Product>('products');
      expect(remainingProducts.length).toBe(initialCount - 1);
      expect(remainingProducts.find((p) => p.id === productToDelete.id)).toBeUndefined();
    });
  });

  describe('Store CRUD', () => {
    beforeEach(() => {
      seedDemoData();
    });

    it('lists all stores', () => {
      const stores = localDb.get<Store>('stores');
      expect(stores.length).toBeGreaterThan(0);
    });

    it('creates a new store', () => {
      const initialCount = localDb.get<Store>('stores').length;

      const newStore: Store = {
        id: generateId(),
        userId: generateId(),
        name: 'New Test Store',
        type: 'WOOCOMMERCE',
        storeUrl: 'https://newstore.example.com',
        apiKeyEncrypted: null,
        apiSecretEncrypted: null,
        isActive: true,
        lastSyncAt: null,
        syncStatus: 'PENDING',
        syncError: null,
        productCount: 0,
        metadata: {},
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      localDb.setItem('stores', newStore);

      const stores = localDb.get<Store>('stores');
      expect(stores.length).toBe(initialCount + 1);
    });

    it('updates store sync status', () => {
      const stores = localDb.get<Store>('stores');
      const storeToUpdate = stores[0];

      const updatedStore = {
        ...storeToUpdate,
        syncStatus: 'SYNCED' as const,
        lastSyncAt: new Date(),
        productCount: 100,
        updatedAt: new Date(),
      };

      localDb.setItem('stores', updatedStore);

      const retrieved = localDb.getItem<Store>('stores', storeToUpdate.id);
      expect(retrieved?.syncStatus).toBe('SYNCED');
      expect(retrieved?.productCount).toBe(100);
    });
  });

  describe('Error Handling', () => {
    it('handles JSON parse errors gracefully', () => {
      // Force invalid JSON in localStorage
      (localStorage.getItem as ReturnType<typeof vi.fn>).mockReturnValueOnce('invalid json');

      const result = localDb.get('test');
      expect(result).toEqual([]);
    });

    it('handles storage quota errors', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      (localStorage.setItem as ReturnType<typeof vi.fn>).mockImplementationOnce(() => {
        throw new Error('QuotaExceededError');
      });

      // Should not throw
      expect(() => localDb.set('test', [{ id: '1' }])).not.toThrow();
      consoleSpy.mockRestore();
    });
  });
});
