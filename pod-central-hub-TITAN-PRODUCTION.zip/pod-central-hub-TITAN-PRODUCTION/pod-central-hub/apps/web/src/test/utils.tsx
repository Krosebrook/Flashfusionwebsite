// ============================================
// TEST UTILITIES
// ============================================

import React, { ReactElement, ReactNode } from 'react';
import { render, RenderOptions, RenderResult } from '@testing-library/react';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from '@/features/auth';
import type { Product, ProductStatus, ProductType } from '@/entities/product/model/types';
import type { Store, StoreType, SyncStatus } from '@/entities/store/model/types';
import type { Asset, AssetType, AssetStatus } from '@/entities/asset/model/types';
import type { Event, EntityType, EventType, EventSeverity } from '@/entities/event/model/types';

// ============================================
// QUERY CLIENT FOR TESTS
// ============================================

export function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
        staleTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });
}

// ============================================
// WRAPPER COMPONENTS
// ============================================

interface WrapperProps {
  children: ReactNode;
}

export function AllProviders({ children }: WrapperProps) {
  const queryClient = createTestQueryClient();

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider>{children}</AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export function RouterWrapper({ children }: WrapperProps) {
  return <BrowserRouter>{children}</BrowserRouter>;
}

export function MemoryRouterWrapper({
  children,
  initialEntries = ['/'],
}: WrapperProps & { initialEntries?: string[] }) {
  return <MemoryRouter initialEntries={initialEntries}>{children}</MemoryRouter>;
}

export function QueryWrapper({ children }: WrapperProps) {
  const queryClient = createTestQueryClient();
  return (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
}

// ============================================
// CUSTOM RENDER
// ============================================

interface CustomRenderOptions extends Omit<RenderOptions, 'wrapper'> {
  route?: string;
  initialEntries?: string[];
}

export function renderWithProviders(
  ui: ReactElement,
  options?: CustomRenderOptions
): RenderResult {
  const { initialEntries, ...renderOptions } = options || {};

  if (initialEntries) {
    return render(ui, {
      wrapper: ({ children }) => (
        <MemoryRouterWrapper initialEntries={initialEntries}>
          <QueryWrapper>{children}</QueryWrapper>
        </MemoryRouterWrapper>
      ),
      ...renderOptions,
    });
  }

  return render(ui, {
    wrapper: AllProviders,
    ...renderOptions,
  });
}

export function renderWithRouter(
  ui: ReactElement,
  options?: CustomRenderOptions
): RenderResult {
  return render(ui, {
    wrapper: RouterWrapper,
    ...options,
  });
}

export function renderWithQuery(
  ui: ReactElement,
  options?: RenderOptions
): RenderResult {
  return render(ui, {
    wrapper: QueryWrapper,
    ...options,
  });
}

// ============================================
// MOCK DATA FACTORIES
// ============================================

let idCounter = 0;

export function generateMockId(): string {
  idCounter += 1;
  return `mock-uuid-${idCounter.toString().padStart(8, '0')}`;
}

export function resetMockIdCounter(): void {
  idCounter = 0;
}

// Product factory
export function createMockProduct(overrides: Partial<Product> = {}): Product {
  const now = new Date();
  return {
    id: generateMockId(),
    userId: generateMockId(),
    title: 'Test Product',
    description: 'Test product description',
    type: 'T_SHIRT' as ProductType,
    sku: `TST-${Date.now()}`,
    price: 29.99,
    cost: 12.50,
    status: 'DRAFT' as ProductStatus,
    storeId: null,
    designAssetId: null,
    tags: ['test'],
    externalId: null,
    externalUrl: null,
    metadata: {},
    publishedAt: null,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

// Store factory
export function createMockStore(overrides: Partial<Store> = {}): Store {
  const now = new Date();
  return {
    id: generateMockId(),
    userId: generateMockId(),
    name: 'Test Store',
    type: 'SHOPIFY' as StoreType,
    storeUrl: 'https://test.myshopify.com',
    apiKeyEncrypted: null,
    apiSecretEncrypted: null,
    isActive: true,
    lastSyncAt: null,
    syncStatus: 'PENDING' as SyncStatus,
    syncError: null,
    productCount: 0,
    metadata: {},
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

// Asset factory
export function createMockAsset(overrides: Partial<Asset> = {}): Asset {
  const now = new Date();
  return {
    id: generateMockId(),
    userId: generateMockId(),
    filename: 'test-asset.png',
    originalFilename: 'test-asset.png',
    mimeType: 'image/png',
    type: 'IMAGE' as AssetType,
    status: 'READY' as AssetStatus,
    sizeBytes: 1024000,
    storageUrl: 'https://storage.example.com/test-asset.png',
    thumbnailUrl: 'https://storage.example.com/thumb/test-asset.png',
    width: 2000,
    height: 2000,
    dpi: 300,
    colorSpace: 'sRGB',
    tags: ['test'],
    metadata: {},
    usageCount: 0,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

// Event factory
export function createMockEvent(overrides: Partial<Event> = {}): Event {
  const now = new Date();
  return {
    id: generateMockId(),
    userId: generateMockId(),
    entityType: 'PRODUCT' as EntityType,
    entityId: generateMockId(),
    eventType: 'PRODUCT_CREATED' as EventType,
    severity: 'SUCCESS' as EventSeverity,
    message: 'Test event',
    payload: {},
    ipAddress: null,
    userAgent: null,
    createdAt: now,
    ...overrides,
  };
}

// ============================================
// MOCK API RESPONSES
// ============================================

export function createPaginatedResponse<T>(
  data: T[],
  page = 1,
  pageSize = 20
) {
  const total = data.length;
  const totalPages = Math.ceil(total / pageSize);
  return {
    data,
    meta: {
      total,
      page,
      pageSize,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
    },
  };
}

export function createApiError(
  message: string,
  status = 400,
  code = 'ERROR'
) {
  return {
    message,
    status,
    code,
  };
}

// ============================================
// WAIT UTILITIES
// ============================================

export function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function waitForCondition(
  condition: () => boolean,
  timeout = 5000,
  interval = 100
): Promise<void> {
  const startTime = Date.now();
  while (!condition()) {
    if (Date.now() - startTime > timeout) {
      throw new Error('Timeout waiting for condition');
    }
    await wait(interval);
  }
}

// ============================================
// MOCK FETCH HELPERS
// ============================================

export function mockFetchSuccess<T>(data: T) {
  return vi.fn().mockResolvedValue({
    ok: true,
    status: 200,
    json: () => Promise.resolve(data),
  });
}

export function mockFetchError(status: number, message: string) {
  return vi.fn().mockResolvedValue({
    ok: false,
    status,
    json: () => Promise.resolve({ error: message }),
  });
}

export function mockFetchNetworkError() {
  return vi.fn().mockRejectedValue(new TypeError('Failed to fetch'));
}

// Re-export testing library utilities
export * from '@testing-library/react';
export { default as userEvent } from '@testing-library/user-event';
