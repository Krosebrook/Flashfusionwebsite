import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { ErrorBoundary, LoadingScreen } from './shared/ui/ErrorBoundary';
import { AppLayout } from './shared/ui/AppLayout';
import { AuthProvider, ProtectedRoute, PublicRoute } from './features/auth';

// ============================================
// LAZY LOADED PAGES
// ============================================

const DashboardPage = lazy(() => import('./pages/DashboardPage'));
const ProductsPage = lazy(() => import('./pages/ProductsPage'));
const StoresPage = lazy(() => import('./pages/StoresPage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));

// Placeholder pages (to be implemented)
const AssetsPage = lazy(() =>
  Promise.resolve({
    default: () => (
      <div className="p-6">
        <h1 className="text-2xl font-bold">Assets</h1>
        <p className="text-slate-500">Asset management page coming soon...</p>
      </div>
    ),
  })
);

const SettingsPage = lazy(() =>
  Promise.resolve({
    default: () => (
      <div className="p-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-slate-500">Settings page coming soon...</p>
      </div>
    ),
  })
);

const NotFoundPage = lazy(() =>
  Promise.resolve({
    default: () => (
      <div className="flex flex-col items-center justify-center min-h-screen p-6">
        <h1 className="text-6xl font-bold text-slate-200">404</h1>
        <h2 className="text-2xl font-bold text-slate-900 mt-4">Page not found</h2>
        <p className="text-slate-500 mt-2">The page you're looking for doesn't exist.</p>
        <a href="/dashboard" className="mt-6 text-blue-600 hover:text-blue-700">
          Go back home
        </a>
      </div>
    ),
  })
);

// ============================================
// QUERY CLIENT
// ============================================

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 3,
      refetchOnWindowFocus: false,
    },
    mutations: {
      retry: 1,
    },
  },
});

// ============================================
// APP COMPONENT
// ============================================

export default function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <BrowserRouter>
            <Suspense fallback={<LoadingScreen />}>
              <Routes>
                {/* Public routes */}
                <Route element={<PublicRoute />}>
                  <Route path="/login" element={<LoginPage />} />
                </Route>

                {/* Protected routes */}
                <Route element={<ProtectedRoute />}>
                  <Route element={<AppLayout />}>
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />
                    <Route path="/dashboard" element={<DashboardPage />} />
                    <Route path="/products" element={<ProductsPage />} />
                    <Route path="/products/:id" element={<ProductsPage />} />
                    <Route path="/stores" element={<StoresPage />} />
                    <Route path="/stores/:id" element={<StoresPage />} />
                    <Route path="/assets" element={<AssetsPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                  </Route>
                </Route>

                {/* 404 */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Suspense>
          </BrowserRouter>

          {/* Toast notifications */}
          <Toaster
            position="bottom-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#1e293b',
                color: '#fff',
                borderRadius: '8px',
              },
              success: {
                iconTheme: {
                  primary: '#22c55e',
                  secondary: '#fff',
                },
              },
              error: {
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#fff',
                },
              },
            }}
          />
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
