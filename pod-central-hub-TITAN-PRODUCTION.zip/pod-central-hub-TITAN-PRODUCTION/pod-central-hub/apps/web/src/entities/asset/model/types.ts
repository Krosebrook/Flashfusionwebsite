import { z } from 'zod';

// ============================================
// ASSET ENUMS
// ============================================

export const AssetType = {
  IMAGE: 'IMAGE',
  VECTOR: 'VECTOR',
  DOCUMENT: 'DOCUMENT',
} as const;
export type AssetType = (typeof AssetType)[keyof typeof AssetType];

export const AssetStatus = {
  UPLOADING: 'UPLOADING',
  PROCESSING: 'PROCESSING',
  READY: 'READY',
  ERROR: 'ERROR',
} as const;
export type AssetStatus = (typeof AssetStatus)[keyof typeof AssetStatus];

// Supported MIME types
export const SupportedMimeTypes = {
  'image/png': AssetType.IMAGE,
  'image/jpeg': AssetType.IMAGE,
  'image/jpg': AssetType.IMAGE,
  'image/webp': AssetType.IMAGE,
  'image/gif': AssetType.IMAGE,
  'image/svg+xml': AssetType.VECTOR,
  'application/pdf': AssetType.DOCUMENT,
  'application/postscript': AssetType.VECTOR,
} as const;

export const AcceptedFileTypes = Object.keys(SupportedMimeTypes);

// Max file sizes by type (in bytes)
export const MaxFileSizes: Record<AssetType, number> = {
  [AssetType.IMAGE]: 50 * 1024 * 1024, // 50MB
  [AssetType.VECTOR]: 25 * 1024 * 1024, // 25MB
  [AssetType.DOCUMENT]: 100 * 1024 * 1024, // 100MB
};

// ============================================
// ZOD SCHEMAS
// ============================================

export const AssetSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  filename: z.string().min(1, 'Filename is required').max(255),
  originalFilename: z.string().min(1).max(255),
  mimeType: z.string().min(1),
  type: z.nativeEnum(AssetType),
  status: z.nativeEnum(AssetStatus).default('UPLOADING'),
  sizeBytes: z.number().int().positive('File size must be positive'),
  storageUrl: z.string().url(),
  thumbnailUrl: z.string().url().nullable().optional(),
  width: z.number().int().positive().nullable().optional(),
  height: z.number().int().positive().nullable().optional(),
  dpi: z.number().int().positive().nullable().optional(),
  colorSpace: z.string().nullable().optional(),
  tags: z.array(z.string().max(50)).max(20).default([]),
  metadata: z.record(z.unknown()).optional().default({}),
  usageCount: z.number().int().nonnegative().default(0),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

export type Asset = z.infer<typeof AssetSchema>;

// Create Asset DTO (for upload)
export const CreateAssetSchema = z.object({
  originalFilename: z.string().min(1).max(255),
  mimeType: z.string().min(1),
  sizeBytes: z.number().int().positive(),
  tags: z.array(z.string().max(50)).max(20).default([]),
  metadata: z.record(z.unknown()).optional().default({}),
});
export type CreateAssetDto = z.infer<typeof CreateAssetSchema>;

// Update Asset DTO
export const UpdateAssetSchema = z.object({
  tags: z.array(z.string().max(50)).max(20).optional(),
  metadata: z.record(z.unknown()).optional(),
});
export type UpdateAssetDto = z.infer<typeof UpdateAssetSchema>;

// Upload request
export const UploadRequestSchema = z.object({
  filename: z.string().min(1).max(255),
  mimeType: z.enum(AcceptedFileTypes as [string, ...string[]]),
  sizeBytes: z.number().int().positive(),
});
export type UploadRequest = z.infer<typeof UploadRequestSchema>;

// Upload response (pre-signed URL)
export interface UploadResponse {
  assetId: string;
  uploadUrl: string;
  expiresAt: Date;
}

// ============================================
// QUERY & FILTER TYPES
// ============================================

export interface AssetFilters {
  type?: AssetType[];
  status?: AssetStatus[];
  search?: string;
  tags?: string[];
  minWidth?: number;
  minHeight?: number;
  minDpi?: number;
}

export interface AssetSortOptions {
  field: 'filename' | 'sizeBytes' | 'createdAt' | 'usageCount';
  order: 'asc' | 'desc';
}

// ============================================
// BUSINESS RULES & HELPERS
// ============================================

/**
 * Validate file for upload
 */
export function validateFile(file: File): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Check MIME type
  const mimeType = file.type as keyof typeof SupportedMimeTypes;
  if (!SupportedMimeTypes[mimeType]) {
    errors.push(`Unsupported file type: ${file.type}`);
    return { valid: false, errors };
  }

  // Get asset type from MIME
  const assetType = SupportedMimeTypes[mimeType];
  const maxSize = MaxFileSizes[assetType];

  // Check file size
  if (file.size > maxSize) {
    const maxSizeMB = Math.round(maxSize / (1024 * 1024));
    errors.push(`File too large. Maximum size is ${maxSizeMB}MB`);
  }

  // Check filename
  if (file.name.length > 255) {
    errors.push('Filename too long. Maximum 255 characters');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Format file size for display
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

/**
 * Get asset type from MIME type
 */
export function getAssetTypeFromMime(mimeType: string): AssetType | null {
  return SupportedMimeTypes[mimeType as keyof typeof SupportedMimeTypes] || null;
}

/**
 * Check if asset is ready for use
 */
export function isAssetReady(asset: Asset): boolean {
  return asset.status === AssetStatus.READY;
}

/**
 * Get dimensions string
 */
export function getDimensionsString(asset: Asset): string | null {
  if (!asset.width || !asset.height) return null;
  return `${asset.width} x ${asset.height}`;
}

/**
 * Check if asset meets minimum requirements for print
 */
export function meetsPrintRequirements(
  asset: Asset,
  minWidth = 2400,
  minHeight = 2400,
  minDpi = 300
): { valid: boolean; warnings: string[] } {
  const warnings: string[] = [];

  if (asset.width && asset.width < minWidth) {
    warnings.push(`Width (${asset.width}px) is below recommended minimum (${minWidth}px)`);
  }

  if (asset.height && asset.height < minHeight) {
    warnings.push(`Height (${asset.height}px) is below recommended minimum (${minHeight}px)`);
  }

  if (asset.dpi && asset.dpi < minDpi) {
    warnings.push(`DPI (${asset.dpi}) is below recommended minimum (${minDpi})`);
  }

  return {
    valid: warnings.length === 0,
    warnings,
  };
}
