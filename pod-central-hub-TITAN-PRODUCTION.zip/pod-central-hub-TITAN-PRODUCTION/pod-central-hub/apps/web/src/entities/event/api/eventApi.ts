// ============================================
// EVENT API - AUDIT LOG & ACTIVITY FEED
// ============================================

import { api } from '@/shared/api';
import type {
  Event,
  CreateEventDto,
  EventFilters,
  EventSortOptions,
  ActivityFeed,
  EntityType,
  EventType,
} from '../model/types';
import type { PaginatedResponse, PaginationParams } from '@/entities/product/model/types';

// ============================================
// API ENDPOINTS
// ============================================

const ENDPOINTS = {
  base: '/events',
  byId: (id: string) => `/events/${id}`,
  byEntity: (entityType: string, entityId: string) => `/events/entity/${entityType}/${entityId}`,
  activity: '/events/activity',
  stats: '/events/stats',
  export: '/events/export',
};

// ============================================
// QUERY PARAMS BUILDER
// ============================================

function buildQueryParams(
  filters?: EventFilters,
  sort?: EventSortOptions,
  pagination?: PaginationParams
): Record<string, string | number | boolean | undefined> {
  const params: Record<string, string | number | boolean | undefined> = {};

  if (pagination) {
    params.page = pagination.page;
    params.pageSize = pagination.pageSize;
  }

  if (sort) {
    params.sortBy = sort.field;
    params.sortOrder = sort.order;
  }

  if (filters) {
    if (filters.entityType?.length) params.entityType = filters.entityType.join(',');
    if (filters.entityId) params.entityId = filters.entityId;
    if (filters.eventType?.length) params.eventType = filters.eventType.join(',');
    if (filters.severity?.length) params.severity = filters.severity.join(',');
    if (filters.startDate) params.startDate = filters.startDate.toISOString();
    if (filters.endDate) params.endDate = filters.endDate.toISOString();
    if (filters.search) params.q = filters.search;
  }

  return params;
}

// ============================================
// API FUNCTIONS
// ============================================

export const eventApi = {
  /**
   * Get all events with optional filters, sorting, and pagination
   */
  async getAll(
    filters?: EventFilters,
    sort?: EventSortOptions,
    pagination: PaginationParams = { page: 1, pageSize: 50 }
  ): Promise<PaginatedResponse<Event>> {
    const params = buildQueryParams(filters, sort, pagination);
    return api.get<PaginatedResponse<Event>>(ENDPOINTS.base, { params });
  },

  /**
   * Get a single event by ID
   */
  async getById(id: string): Promise<Event> {
    const response = await api.get<{ data: Event }>(ENDPOINTS.byId(id));
    return response.data;
  },

  /**
   * Get events for a specific entity
   */
  async getByEntity(
    entityType: EntityType,
    entityId: string,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<Event>> {
    return api.get<PaginatedResponse<Event>>(ENDPOINTS.byEntity(entityType, entityId), {
      params: { page: pagination.page, pageSize: pagination.pageSize },
    });
  },

  /**
   * Create a new event (audit log entry)
   * Note: Most events are created server-side automatically
   */
  async create(data: CreateEventDto): Promise<Event> {
    const response = await api.post<{ data: Event }>(ENDPOINTS.base, data);
    return response.data;
  },

  // ============================================
  // ACTIVITY FEED
  // ============================================

  /**
   * Get activity feed with rich data
   */
  async getActivityFeed(
    options?: {
      limit?: number;
      cursor?: string;
      entityTypes?: EntityType[];
      eventTypes?: EventType[];
    }
  ): Promise<ActivityFeed> {
    const params: Record<string, string | number | undefined> = {};

    if (options?.limit) params.limit = options.limit;
    if (options?.cursor) params.cursor = options.cursor;
    if (options?.entityTypes?.length) params.entityTypes = options.entityTypes.join(',');
    if (options?.eventTypes?.length) params.eventTypes = options.eventTypes.join(',');

    return api.get(ENDPOINTS.activity, { params });
  },

  /**
   * Get recent activity (last 24 hours)
   */
  async getRecentActivity(limit = 10): Promise<Event[]> {
    const response = await api.get<{ data: Event[] }>('/events/recent', {
      params: { limit },
    });
    return response.data;
  },

  // ============================================
  // STATISTICS
  // ============================================

  /**
   * Get event statistics
   */
  async getStats(
    timeRange?: { startDate: Date; endDate: Date }
  ): Promise<{
    total: number;
    byEntityType: Record<string, number>;
    byEventType: Record<string, number>;
    bySeverity: Record<string, number>;
    byHour: Array<{ hour: string; count: number }>;
    byDay: Array<{ day: string; count: number }>;
  }> {
    const params: Record<string, string | undefined> = {};
    if (timeRange) {
      params.startDate = timeRange.startDate.toISOString();
      params.endDate = timeRange.endDate.toISOString();
    }
    return api.get(ENDPOINTS.stats, { params });
  },

  /**
   * Get error summary
   */
  async getErrorSummary(
    days = 7
  ): Promise<{
    totalErrors: number;
    byType: Record<string, number>;
    recentErrors: Event[];
    trend: Array<{ date: string; count: number }>;
  }> {
    return api.get('/events/errors/summary', { params: { days } });
  },

  // ============================================
  // EXPORT
  // ============================================

  /**
   * Export events to CSV
   */
  async exportCsv(filters?: EventFilters): Promise<Blob> {
    const params = buildQueryParams(filters);
    const response = await fetch(
      `${ENDPOINTS.export}?${new URLSearchParams(params as Record<string, string>).toString()}`,
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
          Accept: 'text/csv',
        },
      }
    );

    if (!response.ok) {
      throw new Error('Export failed');
    }

    return response.blob();
  },

  /**
   * Export events to JSON
   */
  async exportJson(filters?: EventFilters): Promise<Event[]> {
    const params = buildQueryParams(filters);
    params.format = 'json';
    const response = await api.get<{ data: Event[] }>(ENDPOINTS.export, { params });
    return response.data;
  },

  // ============================================
  // REAL-TIME SUBSCRIPTIONS
  // ============================================

  /**
   * Subscribe to real-time events via SSE
   */
  subscribeToEvents(
    options?: {
      entityTypes?: EntityType[];
      eventTypes?: EventType[];
      onEvent?: (event: Event) => void;
      onError?: (error: Error) => void;
    }
  ): () => void {
    const params = new URLSearchParams();
    if (options?.entityTypes?.length) {
      params.set('entityTypes', options.entityTypes.join(','));
    }
    if (options?.eventTypes?.length) {
      params.set('eventTypes', options.eventTypes.join(','));
    }

    const url = `/api/events/stream?${params.toString()}`;
    const eventSource = new EventSource(url);

    eventSource.onmessage = (e) => {
      try {
        const event = JSON.parse(e.data) as Event;
        options?.onEvent?.(event);
      } catch (error) {
        console.error('Failed to parse event:', error);
      }
    };

    eventSource.onerror = (e) => {
      options?.onError?.(new Error('Event stream error'));
    };

    // Return unsubscribe function
    return () => {
      eventSource.close();
    };
  },

  // ============================================
  // ENTITY-SPECIFIC HELPERS
  // ============================================

  /**
   * Get product activity
   */
  async getProductActivity(productId: string, limit = 20): Promise<Event[]> {
    const response = await eventApi.getByEntity('PRODUCT', productId, {
      page: 1,
      pageSize: limit,
    });
    return response.data;
  },

  /**
   * Get store activity
   */
  async getStoreActivity(storeId: string, limit = 20): Promise<Event[]> {
    const response = await eventApi.getByEntity('STORE', storeId, {
      page: 1,
      pageSize: limit,
    });
    return response.data;
  },

  /**
   * Get user activity
   */
  async getUserActivity(userId: string, limit = 20): Promise<Event[]> {
    const response = await eventApi.getByEntity('USER', userId, {
      page: 1,
      pageSize: limit,
    });
    return response.data;
  },

  // ============================================
  // SEARCH
  // ============================================

  /**
   * Search events by message content
   */
  async search(
    query: string,
    filters?: Omit<EventFilters, 'search'>,
    pagination: PaginationParams = { page: 1, pageSize: 50 }
  ): Promise<PaginatedResponse<Event>> {
    return eventApi.getAll({ ...filters, search: query }, undefined, pagination);
  },

  /**
   * Get events within a time range
   */
  async getByTimeRange(
    startDate: Date,
    endDate: Date,
    filters?: Omit<EventFilters, 'startDate' | 'endDate'>,
    pagination: PaginationParams = { page: 1, pageSize: 50 }
  ): Promise<PaginatedResponse<Event>> {
    return eventApi.getAll(
      { ...filters, startDate, endDate },
      { field: 'createdAt', order: 'desc' },
      pagination
    );
  },
};

export default eventApi;
