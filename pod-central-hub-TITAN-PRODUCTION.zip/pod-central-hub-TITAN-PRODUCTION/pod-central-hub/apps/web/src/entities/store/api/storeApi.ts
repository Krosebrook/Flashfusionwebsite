// ============================================
// STORE API - FULL CRUD OPERATIONS
// ============================================

import { api, withRetry, ApiError } from '@/shared/api';
import type {
  Store,
  CreateStoreDto,
  UpdateStoreDto,
  StoreFilters,
  StoreSortOptions,
  StoreCredentials,
  SyncResult,
} from '../model/types';
import type { PaginatedResponse, PaginationParams } from '@/entities/product/model/types';

// ============================================
// API ENDPOINTS
// ============================================

const ENDPOINTS = {
  base: '/stores',
  byId: (id: string) => `/stores/${id}`,
  sync: (id: string) => `/stores/${id}/sync`,
  testConnection: (id: string) => `/stores/${id}/test-connection`,
  disconnect: (id: string) => `/stores/${id}/disconnect`,
  reconnect: (id: string) => `/stores/${id}/reconnect`,
  products: (id: string) => `/stores/${id}/products`,
  stats: (id: string) => `/stores/${id}/stats`,
  syncHistory: (id: string) => `/stores/${id}/sync-history`,
  credentials: (id: string) => `/stores/${id}/credentials`,
};

// ============================================
// QUERY PARAMS BUILDER
// ============================================

function buildQueryParams(
  filters?: StoreFilters,
  sort?: StoreSortOptions,
  pagination?: PaginationParams
): Record<string, string | number | boolean | undefined> {
  const params: Record<string, string | number | boolean | undefined> = {};

  if (pagination) {
    params.page = pagination.page;
    params.pageSize = pagination.pageSize;
  }

  if (sort) {
    params.sortBy = sort.field;
    params.sortOrder = sort.order;
  }

  if (filters) {
    if (filters.type?.length) params.type = filters.type.join(',');
    if (filters.syncStatus?.length) params.syncStatus = filters.syncStatus.join(',');
    if (filters.isActive !== undefined) params.isActive = filters.isActive;
    if (filters.search) params.q = filters.search;
  }

  return params;
}

// ============================================
// API FUNCTIONS
// ============================================

export const storeApi = {
  /**
   * Get all stores with optional filters, sorting, and pagination
   */
  async getAll(
    filters?: StoreFilters,
    sort?: StoreSortOptions,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<Store>> {
    const params = buildQueryParams(filters, sort, pagination);
    return api.get<PaginatedResponse<Store>>(ENDPOINTS.base, { params });
  },

  /**
   * Get a single store by ID
   */
  async getById(id: string): Promise<Store> {
    const response = await api.get<{ data: Store }>(ENDPOINTS.byId(id));
    return response.data;
  },

  /**
   * Create/connect a new store
   */
  async create(data: CreateStoreDto): Promise<Store> {
    const response = await api.post<{ data: Store }>(ENDPOINTS.base, data);
    return response.data;
  },

  /**
   * Update store settings
   */
  async update(id: string, data: UpdateStoreDto): Promise<Store> {
    const response = await api.patch<{ data: Store }>(ENDPOINTS.byId(id), data);
    return response.data;
  },

  /**
   * Delete/remove a store connection
   */
  async delete(id: string): Promise<void> {
    await api.delete(ENDPOINTS.byId(id));
  },

  // ============================================
  // SYNC OPERATIONS
  // ============================================

  /**
   * Trigger a full sync with the store
   */
  async sync(id: string): Promise<SyncResult> {
    const response = await api.post<{ data: SyncResult }>(ENDPOINTS.sync(id));
    return response.data;
  },

  /**
   * Test store connection/credentials
   */
  async testConnection(id: string): Promise<{ success: boolean; message: string; latencyMs?: number }> {
    return api.post(ENDPOINTS.testConnection(id));
  },

  /**
   * Disconnect store (keep data but disable sync)
   */
  async disconnect(id: string): Promise<Store> {
    const response = await api.post<{ data: Store }>(ENDPOINTS.disconnect(id));
    return response.data;
  },

  /**
   * Reconnect a disconnected store
   */
  async reconnect(id: string, credentials?: StoreCredentials): Promise<Store> {
    const response = await api.post<{ data: Store }>(ENDPOINTS.reconnect(id), credentials);
    return response.data;
  },

  /**
   * Get sync history for a store
   */
  async getSyncHistory(
    id: string,
    pagination: PaginationParams = { page: 1, pageSize: 10 }
  ): Promise<PaginatedResponse<SyncResult>> {
    return api.get<PaginatedResponse<SyncResult>>(ENDPOINTS.syncHistory(id), {
      params: { page: pagination.page, pageSize: pagination.pageSize },
    });
  },

  // ============================================
  // STORE PRODUCTS
  // ============================================

  /**
   * Get products associated with a store
   */
  async getProducts(
    id: string,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<unknown>> {
    return api.get(ENDPOINTS.products(id), {
      params: { page: pagination.page, pageSize: pagination.pageSize },
    });
  },

  /**
   * Get store statistics
   */
  async getStats(id: string): Promise<{
    totalProducts: number;
    publishedProducts: number;
    lastSyncAt: Date | null;
    syncSuccessRate: number;
    averageSyncTime: number;
  }> {
    return api.get(ENDPOINTS.stats(id));
  },

  // ============================================
  // CREDENTIALS MANAGEMENT
  // ============================================

  /**
   * Update store credentials
   */
  async updateCredentials(id: string, credentials: StoreCredentials): Promise<Store> {
    const response = await api.put<{ data: Store }>(ENDPOINTS.credentials(id), credentials);
    return response.data;
  },

  /**
   * Validate credentials without saving
   */
  async validateCredentials(storeType: string, credentials: StoreCredentials): Promise<{ valid: boolean; errors?: string[] }> {
    return api.post('/stores/validate-credentials', { storeType, credentials });
  },

  // ============================================
  // BULK OPERATIONS
  // ============================================

  /**
   * Sync multiple stores
   */
  async bulkSync(ids: string[]): Promise<{ results: Array<{ id: string; result: SyncResult | { error: string } }> }> {
    return api.post('/stores/bulk/sync', { ids });
  },

  /**
   * Deactivate multiple stores
   */
  async bulkDeactivate(ids: string[]): Promise<{ deactivated: number; errors: Array<{ id: string; error: string }> }> {
    return api.post('/stores/bulk/deactivate', { ids });
  },

  // ============================================
  // PLATFORM-SPECIFIC HELPERS
  // ============================================

  /**
   * Get OAuth URL for store platforms that use OAuth
   */
  async getOAuthUrl(storeType: string, redirectUri: string): Promise<{ url: string; state: string }> {
    return api.post('/stores/oauth/url', { storeType, redirectUri });
  },

  /**
   * Exchange OAuth code for credentials
   */
  async exchangeOAuthCode(
    storeType: string,
    code: string,
    state: string
  ): Promise<{ credentials: StoreCredentials; storeName?: string }> {
    return api.post('/stores/oauth/exchange', { storeType, code, state });
  },

  // ============================================
  // UTILITY FUNCTIONS
  // ============================================

  /**
   * Retry sync with exponential backoff
   */
  async syncWithRetry(id: string, maxRetries = 3): Promise<SyncResult> {
    return withRetry(() => storeApi.sync(id), {
      maxRetries,
      retryCondition: (error) => {
        // Retry on network errors or 5xx server errors
        if (error instanceof ApiError) {
          return error.status >= 500;
        }
        return error.name === 'NetworkError';
      },
    });
  },

  /**
   * Get aggregated statistics across all stores
   */
  async getAggregatedStats(): Promise<{
    totalStores: number;
    activeStores: number;
    totalProducts: number;
    syncedToday: number;
    errorCount: number;
  }> {
    return api.get('/stores/stats/aggregated');
  },
};

export default storeApi;
