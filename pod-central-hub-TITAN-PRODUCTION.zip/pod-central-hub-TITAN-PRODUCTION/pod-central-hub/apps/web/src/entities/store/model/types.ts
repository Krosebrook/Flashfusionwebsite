import { z } from 'zod';

// ============================================
// STORE ENUMS
// ============================================

export const StoreType = {
  SHOPIFY: 'SHOPIFY',
  ETSY: 'ETSY',
  AMAZON: 'AMAZON',
  WOOCOMMERCE: 'WOOCOMMERCE',
  EBAY: 'EBAY',
  CUSTOM: 'CUSTOM',
} as const;
export type StoreType = (typeof StoreType)[keyof typeof StoreType];

export const SyncStatus = {
  PENDING: 'PENDING',
  SYNCING: 'SYNCING',
  SYNCED: 'SYNCED',
  ERROR: 'ERROR',
  DISCONNECTED: 'DISCONNECTED',
} as const;
export type SyncStatus = (typeof SyncStatus)[keyof typeof SyncStatus];

// Store type labels for UI
export const StoreTypeLabels: Record<StoreType, string> = {
  [StoreType.SHOPIFY]: 'Shopify',
  [StoreType.ETSY]: 'Etsy',
  [StoreType.AMAZON]: 'Amazon',
  [StoreType.WOOCOMMERCE]: 'WooCommerce',
  [StoreType.EBAY]: 'eBay',
  [StoreType.CUSTOM]: 'Custom Store',
};

// Sync status labels for UI
export const SyncStatusLabels: Record<SyncStatus, string> = {
  [SyncStatus.PENDING]: 'Pending',
  [SyncStatus.SYNCING]: 'Syncing...',
  [SyncStatus.SYNCED]: 'Synced',
  [SyncStatus.ERROR]: 'Error',
  [SyncStatus.DISCONNECTED]: 'Disconnected',
};

// Store type icons (for UI - using Lucide icon names)
export const StoreTypeIcons: Record<StoreType, string> = {
  [StoreType.SHOPIFY]: 'shopping-bag',
  [StoreType.ETSY]: 'palette',
  [StoreType.AMAZON]: 'package',
  [StoreType.WOOCOMMERCE]: 'shopping-cart',
  [StoreType.EBAY]: 'gavel',
  [StoreType.CUSTOM]: 'globe',
};

// ============================================
// ZOD SCHEMAS
// ============================================

export const StoreSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  name: z.string().min(1, 'Store name is required').max(255, 'Store name must be 255 characters or less'),
  type: z.nativeEnum(StoreType),
  storeUrl: z.string().url('Invalid store URL').nullable().optional(),
  apiKeyEncrypted: z.string().nullable().optional(),
  apiSecretEncrypted: z.string().nullable().optional(),
  isActive: z.boolean().default(true),
  lastSyncAt: z.coerce.date().nullable().optional(),
  syncStatus: z.nativeEnum(SyncStatus).default('PENDING'),
  syncError: z.string().nullable().optional(),
  productCount: z.number().int().nonnegative().default(0),
  metadata: z.record(z.unknown()).optional().default({}),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

export type Store = z.infer<typeof StoreSchema>;

// Create Store DTO
export const CreateStoreSchema = z.object({
  name: z.string().min(1, 'Store name is required').max(255),
  type: z.nativeEnum(StoreType),
  storeUrl: z.string().url().nullable().optional(),
  apiKey: z.string().min(1, 'API key is required').optional(),
  apiSecret: z.string().optional(),
  metadata: z.record(z.unknown()).optional().default({}),
});
export type CreateStoreDto = z.infer<typeof CreateStoreSchema>;

// Update Store DTO
export const UpdateStoreSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  storeUrl: z.string().url().nullable().optional(),
  apiKey: z.string().optional(),
  apiSecret: z.string().optional(),
  isActive: z.boolean().optional(),
  metadata: z.record(z.unknown()).optional(),
});
export type UpdateStoreDto = z.infer<typeof UpdateStoreSchema>;

// Store connection credentials
export const StoreCredentialsSchema = z.object({
  apiKey: z.string().min(1, 'API key is required'),
  apiSecret: z.string().optional(),
  accessToken: z.string().optional(),
  refreshToken: z.string().optional(),
  shopDomain: z.string().optional(),
});
export type StoreCredentials = z.infer<typeof StoreCredentialsSchema>;

// ============================================
// QUERY & FILTER TYPES
// ============================================

export interface StoreFilters {
  type?: StoreType[];
  syncStatus?: SyncStatus[];
  isActive?: boolean;
  search?: string;
}

export interface StoreSortOptions {
  field: 'name' | 'type' | 'lastSyncAt' | 'createdAt' | 'productCount';
  order: 'asc' | 'desc';
}

// ============================================
// SYNC TYPES
// ============================================

export interface SyncResult {
  storeId: string;
  success: boolean;
  productsCreated: number;
  productsUpdated: number;
  productsDeleted: number;
  errors: SyncError[];
  startedAt: Date;
  completedAt: Date;
}

export interface SyncError {
  productId?: string;
  sku?: string;
  message: string;
  code: string;
}

// ============================================
// BUSINESS RULES & HELPERS
// ============================================

/**
 * Check if store can be synced
 */
export function canSyncStore(store: Store): { valid: boolean; reason?: string } {
  if (!store.isActive) {
    return { valid: false, reason: 'Store is not active' };
  }

  if (store.syncStatus === SyncStatus.SYNCING) {
    return { valid: false, reason: 'Sync already in progress' };
  }

  if (store.syncStatus === SyncStatus.DISCONNECTED) {
    return { valid: false, reason: 'Store is disconnected. Please reconnect.' };
  }

  return { valid: true };
}

/**
 * Check if store has valid credentials
 */
export function hasValidCredentials(store: Store): boolean {
  return !!(store.apiKeyEncrypted || store.storeUrl);
}

/**
 * Get time since last sync
 */
export function getTimeSinceLastSync(store: Store): string | null {
  if (!store.lastSyncAt) return null;

  const now = new Date();
  const lastSync = new Date(store.lastSyncAt);
  const diffMs = now.getTime() - lastSync.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffMins > 0) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  return 'Just now';
}

/**
 * Get sync status color for UI
 */
export function getSyncStatusColor(status: SyncStatus): string {
  const colors: Record<SyncStatus, string> = {
    [SyncStatus.PENDING]: 'text-yellow-500',
    [SyncStatus.SYNCING]: 'text-blue-500',
    [SyncStatus.SYNCED]: 'text-green-500',
    [SyncStatus.ERROR]: 'text-red-500',
    [SyncStatus.DISCONNECTED]: 'text-gray-500',
  };
  return colors[status];
}
