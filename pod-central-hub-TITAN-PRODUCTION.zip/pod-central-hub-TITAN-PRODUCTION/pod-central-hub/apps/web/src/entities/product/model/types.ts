import { z } from 'zod';

// ============================================
// BRANDED ID TYPES FOR TYPE SAFETY
// ============================================

export type ProductId = string & { readonly __brand: 'ProductId' };
export type StoreId = string & { readonly __brand: 'StoreId' };
export type AssetId = string & { readonly __brand: 'AssetId' };
export type UserId = string & { readonly __brand: 'UserId' };

// Helper to create branded IDs
export const createProductId = (id: string): ProductId => id as ProductId;
export const createStoreId = (id: string): StoreId => id as StoreId;
export const createAssetId = (id: string): AssetId => id as AssetId;
export const createUserId = (id: string): UserId => id as UserId;

// ============================================
// PRODUCT ENUMS
// ============================================

export const ProductStatus = {
  DRAFT: 'DRAFT',
  ACTIVE: 'ACTIVE',
  PUBLISHED: 'PUBLISHED',
  ARCHIVED: 'ARCHIVED',
} as const;
export type ProductStatus = (typeof ProductStatus)[keyof typeof ProductStatus];

export const ProductType = {
  T_SHIRT: 'T_SHIRT',
  HOODIE: 'HOODIE',
  MUG: 'MUG',
  POSTER: 'POSTER',
  PHONE_CASE: 'PHONE_CASE',
  TOTE_BAG: 'TOTE_BAG',
  CANVAS: 'CANVAS',
  STICKER: 'STICKER',
  HAT: 'HAT',
  BLANKET: 'BLANKET',
} as const;
export type ProductType = (typeof ProductType)[keyof typeof ProductType];

// Status labels for UI
export const ProductStatusLabels: Record<ProductStatus, string> = {
  [ProductStatus.DRAFT]: 'Draft',
  [ProductStatus.ACTIVE]: 'Active',
  [ProductStatus.PUBLISHED]: 'Published',
  [ProductStatus.ARCHIVED]: 'Archived',
};

// Type labels for UI
export const ProductTypeLabels: Record<ProductType, string> = {
  [ProductType.T_SHIRT]: 'T-Shirt',
  [ProductType.HOODIE]: 'Hoodie',
  [ProductType.MUG]: 'Mug',
  [ProductType.POSTER]: 'Poster',
  [ProductType.PHONE_CASE]: 'Phone Case',
  [ProductType.TOTE_BAG]: 'Tote Bag',
  [ProductType.CANVAS]: 'Canvas',
  [ProductType.STICKER]: 'Sticker',
  [ProductType.HAT]: 'Hat',
  [ProductType.BLANKET]: 'Blanket',
};

// ============================================
// ZOD SCHEMAS
// ============================================

export const ProductSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  title: z.string().min(1, 'Title is required').max(200, 'Title must be 200 characters or less'),
  description: z.string().max(5000, 'Description must be 5000 characters or less').nullable().optional(),
  type: z.nativeEnum(ProductType),
  sku: z.string().min(1, 'SKU is required').regex(/^[A-Z0-9-]+$/, 'SKU must contain only uppercase letters, numbers, and hyphens'),
  price: z.number().positive('Price must be positive').multipleOf(0.01, 'Price must have at most 2 decimal places'),
  cost: z.number().nonnegative('Cost cannot be negative').multipleOf(0.01, 'Cost must have at most 2 decimal places').default(0),
  status: z.nativeEnum(ProductStatus).default('DRAFT'),
  storeId: z.string().uuid().nullable().optional(),
  designAssetId: z.string().uuid().nullable().optional(),
  tags: z.array(z.string().max(50, 'Tag must be 50 characters or less')).max(20, 'Maximum 20 tags allowed').default([]),
  externalId: z.string().max(255).nullable().optional(),
  externalUrl: z.string().url().nullable().optional(),
  metadata: z.record(z.unknown()).optional().default({}),
  publishedAt: z.coerce.date().nullable().optional(),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

export type Product = z.infer<typeof ProductSchema>;

// Create Product DTO
export const CreateProductSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().max(5000).nullable().optional(),
  type: z.nativeEnum(ProductType),
  sku: z.string().min(1, 'SKU is required').regex(/^[A-Z0-9-]+$/),
  price: z.number().positive().multipleOf(0.01),
  cost: z.number().nonnegative().multipleOf(0.01).default(0),
  status: z.nativeEnum(ProductStatus).default('DRAFT'),
  storeId: z.string().uuid().nullable().optional(),
  designAssetId: z.string().uuid().nullable().optional(),
  tags: z.array(z.string().max(50)).max(20).default([]),
  metadata: z.record(z.unknown()).optional().default({}),
});
export type CreateProductDto = z.infer<typeof CreateProductSchema>;

// Update Product DTO
export const UpdateProductSchema = CreateProductSchema.partial();
export type UpdateProductDto = z.infer<typeof UpdateProductSchema>;

// ============================================
// QUERY & FILTER TYPES
// ============================================

export interface ProductFilters {
  status?: ProductStatus[];
  type?: ProductType[];
  storeId?: string | null;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  tags?: string[];
  hasDesign?: boolean;
}

export interface ProductSortOptions {
  field: 'title' | 'price' | 'createdAt' | 'updatedAt' | 'status' | 'sku';
  order: 'asc' | 'desc';
}

// ============================================
// PAGINATION TYPES
// ============================================

export interface PaginationParams {
  page: number;
  pageSize: number;
}

export interface PaginationMeta {
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  meta: PaginationMeta;
}

// ============================================
// BUSINESS RULES & HELPERS
// ============================================

/**
 * Validates if a product can be published
 * Business Rule: Product cannot be PUBLISHED without storeId and designAssetId
 */
export function canPublishProduct(product: Product): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!product.storeId) {
    errors.push('Product must be assigned to a store before publishing');
  }

  if (!product.designAssetId) {
    errors.push('Product must have a design asset before publishing');
  }

  if (product.price <= 0) {
    errors.push('Product must have a valid price before publishing');
  }

  if (!product.title.trim()) {
    errors.push('Product must have a title before publishing');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Calculate profit margin percentage
 */
export function calculateMargin(product: Product): number {
  if (product.price === 0) return 0;
  if (product.cost === 0) return 100;
  return Math.round(((product.price - product.cost) / product.price) * 100 * 100) / 100;
}

/**
 * Calculate profit amount
 */
export function calculateProfit(product: Product): number {
  return Math.round((product.price - product.cost) * 100) / 100;
}

/**
 * Format price for display
 */
export function formatPrice(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
}

/**
 * Generate a unique SKU
 */
export function generateSku(type: ProductType, index: number): string {
  const prefix = type.slice(0, 3).toUpperCase();
  const timestamp = Date.now().toString(36).toUpperCase();
  return `${prefix}-${timestamp}-${String(index).padStart(4, '0')}`;
}
