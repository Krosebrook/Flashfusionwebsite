// ============================================
// PRODUCT TYPES - UNIT TESTS
// ============================================

import { describe, it, expect } from 'vitest';
import {
  ProductSchema,
  CreateProductSchema,
  UpdateProductSchema,
  ProductStatus,
  ProductType,
  canPublishProduct,
  calculateMargin,
  calculateProfit,
  formatPrice,
  generateSku,
} from './types';

describe('ProductSchema', () => {
  const validProduct = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    userId: '123e4567-e89b-12d3-a456-426614174001',
    title: 'Test Product',
    description: 'A test product description',
    type: 'T_SHIRT',
    sku: 'TST-001',
    price: 29.99,
    cost: 12.50,
    status: 'DRAFT',
    storeId: null,
    designAssetId: null,
    tags: ['test', 'sample'],
    externalId: null,
    externalUrl: null,
    metadata: {},
    publishedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  it('validates a complete valid product', () => {
    const result = ProductSchema.safeParse(validProduct);
    expect(result.success).toBe(true);
  });

  it('rejects product without required id', () => {
    const { id, ...productWithoutId } = validProduct;
    const result = ProductSchema.safeParse(productWithoutId);
    expect(result.success).toBe(false);
  });

  it('rejects product with invalid UUID for id', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      id: 'invalid-uuid',
    });
    expect(result.success).toBe(false);
  });

  it('rejects product with empty title', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      title: '',
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.errors[0].message).toContain('Title is required');
    }
  });

  it('rejects product with title over 200 characters', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      title: 'a'.repeat(201),
    });
    expect(result.success).toBe(false);
  });

  it('rejects product with invalid SKU format', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      sku: 'invalid sku with spaces',
    });
    expect(result.success).toBe(false);
  });

  it('accepts valid SKU formats', () => {
    const validSkus = ['TST-001', 'PRODUCT-123', 'ABC123', 'SKU-A-B-C'];
    validSkus.forEach((sku) => {
      const result = ProductSchema.safeParse({ ...validProduct, sku });
      expect(result.success).toBe(true);
    });
  });

  it('rejects negative price', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      price: -10,
    });
    expect(result.success).toBe(false);
  });

  it('rejects price with more than 2 decimal places', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      price: 29.999,
    });
    expect(result.success).toBe(false);
  });

  it('rejects negative cost', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      cost: -5,
    });
    expect(result.success).toBe(false);
  });

  it('rejects invalid product type', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      type: 'INVALID_TYPE',
    });
    expect(result.success).toBe(false);
  });

  it('accepts all valid product types', () => {
    Object.values(ProductType).forEach((type) => {
      const result = ProductSchema.safeParse({ ...validProduct, type });
      expect(result.success).toBe(true);
    });
  });

  it('accepts all valid product statuses', () => {
    Object.values(ProductStatus).forEach((status) => {
      const result = ProductSchema.safeParse({ ...validProduct, status });
      expect(result.success).toBe(true);
    });
  });

  it('rejects tags array with more than 20 items', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      tags: Array(21).fill('tag'),
    });
    expect(result.success).toBe(false);
  });

  it('rejects tag longer than 50 characters', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      tags: ['a'.repeat(51)],
    });
    expect(result.success).toBe(false);
  });

  it('coerces date strings to Date objects', () => {
    const result = ProductSchema.safeParse({
      ...validProduct,
      createdAt: '2024-01-01T00:00:00.000Z',
      updatedAt: '2024-01-01T00:00:00.000Z',
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.createdAt).toBeInstanceOf(Date);
      expect(result.data.updatedAt).toBeInstanceOf(Date);
    }
  });
});

describe('CreateProductSchema', () => {
  const validCreateData = {
    title: 'New Product',
    type: 'T_SHIRT',
    sku: 'NEW-001',
    price: 39.99,
  };

  it('validates minimal create data', () => {
    const result = CreateProductSchema.safeParse(validCreateData);
    expect(result.success).toBe(true);
  });

  it('applies default values', () => {
    const result = CreateProductSchema.safeParse(validCreateData);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.cost).toBe(0);
      expect(result.data.status).toBe('DRAFT');
      expect(result.data.tags).toEqual([]);
      expect(result.data.metadata).toEqual({});
    }
  });

  it('accepts optional fields', () => {
    const result = CreateProductSchema.safeParse({
      ...validCreateData,
      description: 'Product description',
      cost: 15.00,
      storeId: '123e4567-e89b-12d3-a456-426614174000',
      tags: ['new', 'featured'],
    });
    expect(result.success).toBe(true);
  });
});

describe('UpdateProductSchema', () => {
  it('allows partial updates', () => {
    const result = UpdateProductSchema.safeParse({
      title: 'Updated Title',
    });
    expect(result.success).toBe(true);
  });

  it('validates updated fields', () => {
    const result = UpdateProductSchema.safeParse({
      price: -10, // Invalid
    });
    expect(result.success).toBe(false);
  });

  it('allows empty object (no updates)', () => {
    const result = UpdateProductSchema.safeParse({});
    expect(result.success).toBe(true);
  });
});

describe('canPublishProduct', () => {
  const baseProduct = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    userId: '123e4567-e89b-12d3-a456-426614174001',
    title: 'Test Product',
    description: null,
    type: 'T_SHIRT' as const,
    sku: 'TST-001',
    price: 29.99,
    cost: 12.50,
    status: 'DRAFT' as const,
    storeId: '123e4567-e89b-12d3-a456-426614174002',
    designAssetId: '123e4567-e89b-12d3-a456-426614174003',
    tags: [],
    externalId: null,
    externalUrl: null,
    metadata: {},
    publishedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  it('returns valid for a complete product', () => {
    const result = canPublishProduct(baseProduct);
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('returns error for product without store', () => {
    const result = canPublishProduct({ ...baseProduct, storeId: null });
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Product must be assigned to a store before publishing');
  });

  it('returns error for product without design asset', () => {
    const result = canPublishProduct({ ...baseProduct, designAssetId: null });
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Product must have a design asset before publishing');
  });

  it('returns error for product with zero price', () => {
    const result = canPublishProduct({ ...baseProduct, price: 0 });
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Product must have a valid price before publishing');
  });

  it('returns error for product with empty title', () => {
    const result = canPublishProduct({ ...baseProduct, title: '   ' });
    expect(result.valid).toBe(false);
    expect(result.errors).toContain('Product must have a title before publishing');
  });

  it('returns multiple errors when multiple issues exist', () => {
    const result = canPublishProduct({
      ...baseProduct,
      storeId: null,
      designAssetId: null,
      price: 0,
    });
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(1);
  });
});

describe('calculateMargin', () => {
  const createProduct = (price: number, cost: number) => ({
    id: '',
    userId: '',
    title: '',
    description: null,
    type: 'T_SHIRT' as const,
    sku: '',
    price,
    cost,
    status: 'DRAFT' as const,
    storeId: null,
    designAssetId: null,
    tags: [],
    externalId: null,
    externalUrl: null,
    metadata: {},
    publishedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  it('calculates margin correctly', () => {
    const product = createProduct(100, 40);
    expect(calculateMargin(product)).toBe(60);
  });

  it('returns 0 for zero price', () => {
    const product = createProduct(0, 40);
    expect(calculateMargin(product)).toBe(0);
  });

  it('returns 100 for zero cost', () => {
    const product = createProduct(100, 0);
    expect(calculateMargin(product)).toBe(100);
  });

  it('handles decimal values correctly', () => {
    const product = createProduct(29.99, 12.50);
    const margin = calculateMargin(product);
    expect(margin).toBeCloseTo(58.32, 1);
  });
});

describe('calculateProfit', () => {
  const createProduct = (price: number, cost: number) => ({
    id: '',
    userId: '',
    title: '',
    description: null,
    type: 'T_SHIRT' as const,
    sku: '',
    price,
    cost,
    status: 'DRAFT' as const,
    storeId: null,
    designAssetId: null,
    tags: [],
    externalId: null,
    externalUrl: null,
    metadata: {},
    publishedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  it('calculates profit correctly', () => {
    const product = createProduct(100, 40);
    expect(calculateProfit(product)).toBe(60);
  });

  it('handles negative profit', () => {
    const product = createProduct(30, 50);
    expect(calculateProfit(product)).toBe(-20);
  });

  it('rounds to 2 decimal places', () => {
    const product = createProduct(29.99, 12.50);
    expect(calculateProfit(product)).toBe(17.49);
  });
});

describe('formatPrice', () => {
  it('formats price in USD by default', () => {
    expect(formatPrice(29.99)).toBe('$29.99');
  });

  it('formats price with different currency', () => {
    expect(formatPrice(29.99, 'EUR')).toContain('29.99');
  });

  it('handles zero', () => {
    expect(formatPrice(0)).toBe('$0.00');
  });

  it('handles large numbers', () => {
    const formatted = formatPrice(1234567.89);
    expect(formatted).toContain('1,234,567.89');
  });
});

describe('generateSku', () => {
  it('generates SKU with type prefix', () => {
    const sku = generateSku('T_SHIRT', 1);
    expect(sku).toMatch(/^T_S-[A-Z0-9]+-0001$/);
  });

  it('generates unique SKUs', () => {
    const sku1 = generateSku('T_SHIRT', 1);
    const sku2 = generateSku('T_SHIRT', 2);
    expect(sku1).not.toBe(sku2);
  });

  it('pads index correctly', () => {
    const sku = generateSku('MUG', 42);
    expect(sku).toMatch(/-0042$/);
  });

  it('uses first 3 characters of type', () => {
    expect(generateSku('HOODIE', 1)).toMatch(/^HOO-/);
    expect(generateSku('POSTER', 1)).toMatch(/^POS-/);
  });
});
