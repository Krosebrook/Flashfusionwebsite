// ============================================
// LOCAL DATABASE - MOCK PERSISTENCE LAYER
// ============================================
// Used for development/demo when backend is unavailable

import type { Product, ProductStatus, ProductType } from '@/entities/product/model/types';
import type { Store, StoreType, SyncStatus } from '@/entities/store/model/types';
import type { Asset, AssetType, AssetStatus } from '@/entities/asset/model/types';
import type { Event, EntityType, EventType, EventSeverity } from '@/entities/event/model/types';

// ============================================
// LOCAL STORAGE WRAPPER
// ============================================

const STORAGE_PREFIX = 'pod_central_';

export const localDb = {
  get<T>(key: string): T[] {
    try {
      const data = localStorage.getItem(STORAGE_PREFIX + key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  set<T>(key: string, value: T[]): void {
    try {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  },

  getItem<T>(key: string, id: string): T | null {
    const items = this.get<T & { id: string }>(key);
    return items.find((item) => item.id === id) || null;
  },

  setItem<T extends { id: string }>(key: string, item: T): T {
    const items = this.get<T>(key);
    const index = items.findIndex((i) => (i as T & { id: string }).id === item.id);
    if (index >= 0) {
      items[index] = item;
    } else {
      items.push(item);
    }
    this.set(key, items);
    return item;
  },

  deleteItem(key: string, id: string): boolean {
    const items = this.get<{ id: string }>(key);
    const filtered = items.filter((item) => item.id !== id);
    if (filtered.length < items.length) {
      this.set(key, filtered);
      return true;
    }
    return false;
  },

  clear(key?: string): void {
    if (key) {
      localStorage.removeItem(STORAGE_PREFIX + key);
    } else {
      Object.keys(localStorage)
        .filter((k) => k.startsWith(STORAGE_PREFIX))
        .forEach((k) => localStorage.removeItem(k));
    }
  },
};

// ============================================
// UUID GENERATOR
// ============================================

export function generateId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// ============================================
// DEMO DATA SEEDER
// ============================================

export function seedDemoData(): void {
  // Skip if data already exists
  if (localDb.get<Product>('products').length > 0) {
    return;
  }

  const now = new Date();
  const userId = generateId();

  // Seed Products
  const products: Product[] = [
    {
      id: generateId(),
      userId,
      title: 'Classic Cotton T-Shirt - Mountain Design',
      description: 'Premium 100% cotton t-shirt featuring a beautiful mountain landscape design. Perfect for outdoor enthusiasts.',
      type: 'T_SHIRT' as ProductType,
      sku: 'TSH-MTN-001',
      price: 29.99,
      cost: 12.50,
      status: 'PUBLISHED' as ProductStatus,
      storeId: null,
      designAssetId: null,
      tags: ['outdoor', 'nature', 'mountains', 'bestseller'],
      externalId: null,
      externalUrl: null,
      metadata: {},
      publishedAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
      createdAt: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      title: 'Premium Hoodie - Abstract Art',
      description: 'Cozy pullover hoodie with unique abstract art print. Soft fleece interior.',
      type: 'HOODIE' as ProductType,
      sku: 'HOD-ABS-002',
      price: 54.99,
      cost: 22.00,
      status: 'ACTIVE' as ProductStatus,
      storeId: null,
      designAssetId: null,
      tags: ['art', 'abstract', 'premium', 'winter'],
      externalId: null,
      externalUrl: null,
      metadata: {},
      publishedAt: null,
      createdAt: new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      title: 'Ceramic Coffee Mug - Motivational Quote',
      description: '11oz ceramic mug with inspirational quote. Dishwasher and microwave safe.',
      type: 'MUG' as ProductType,
      sku: 'MUG-MOT-003',
      price: 18.99,
      cost: 6.50,
      status: 'DRAFT' as ProductStatus,
      storeId: null,
      designAssetId: null,
      tags: ['motivation', 'office', 'gift'],
      externalId: null,
      externalUrl: null,
      metadata: {},
      publishedAt: null,
      createdAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      title: 'Canvas Print - Sunset Beach',
      description: 'Gallery-wrapped canvas print featuring a stunning sunset beach scene. Available in multiple sizes.',
      type: 'CANVAS' as ProductType,
      sku: 'CNV-BCH-004',
      price: 79.99,
      cost: 28.00,
      status: 'PUBLISHED' as ProductStatus,
      storeId: null,
      designAssetId: null,
      tags: ['beach', 'sunset', 'photography', 'home decor'],
      externalId: null,
      externalUrl: null,
      metadata: {},
      publishedAt: new Date(now.getTime() - 21 * 24 * 60 * 60 * 1000),
      createdAt: new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 21 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      title: 'Phone Case - Geometric Pattern',
      description: 'Slim protective phone case with geometric pattern design. Compatible with iPhone and Samsung models.',
      type: 'PHONE_CASE' as ProductType,
      sku: 'PHN-GEO-005',
      price: 24.99,
      cost: 8.00,
      status: 'ARCHIVED' as ProductStatus,
      storeId: null,
      designAssetId: null,
      tags: ['geometric', 'minimalist', 'tech'],
      externalId: null,
      externalUrl: null,
      metadata: {},
      publishedAt: null,
      createdAt: new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000),
    },
  ];

  // Seed Stores
  const stores: Store[] = [
    {
      id: generateId(),
      userId,
      name: 'Main Shopify Store',
      type: 'SHOPIFY' as StoreType,
      storeUrl: 'https://mystore.myshopify.com',
      apiKeyEncrypted: null,
      apiSecretEncrypted: null,
      isActive: true,
      lastSyncAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
      syncStatus: 'SYNCED' as SyncStatus,
      syncError: null,
      productCount: 45,
      metadata: {},
      createdAt: new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      name: 'Etsy Shop',
      type: 'ETSY' as StoreType,
      storeUrl: 'https://etsy.com/shop/myshop',
      apiKeyEncrypted: null,
      apiSecretEncrypted: null,
      isActive: true,
      lastSyncAt: new Date(now.getTime() - 24 * 60 * 60 * 1000),
      syncStatus: 'SYNCED' as SyncStatus,
      syncError: null,
      productCount: 28,
      metadata: {},
      createdAt: new Date(now.getTime() - 120 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      name: 'Amazon Seller',
      type: 'AMAZON' as StoreType,
      storeUrl: null,
      apiKeyEncrypted: null,
      apiSecretEncrypted: null,
      isActive: false,
      lastSyncAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
      syncStatus: 'DISCONNECTED' as SyncStatus,
      syncError: 'API credentials expired',
      productCount: 12,
      metadata: {},
      createdAt: new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
    },
  ];

  // Seed Assets
  const assets: Asset[] = [
    {
      id: generateId(),
      userId,
      filename: 'mountain-design-v2.png',
      originalFilename: 'mountain-design-v2.png',
      mimeType: 'image/png',
      type: 'IMAGE' as AssetType,
      status: 'READY' as AssetStatus,
      sizeBytes: 2456789,
      storageUrl: 'https://storage.example.com/assets/mountain-design-v2.png',
      thumbnailUrl: 'https://storage.example.com/thumbs/mountain-design-v2.png',
      width: 4000,
      height: 4000,
      dpi: 300,
      colorSpace: 'sRGB',
      tags: ['mountain', 'nature', 'landscape'],
      metadata: {},
      usageCount: 3,
      createdAt: new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      filename: 'abstract-art-blue.png',
      originalFilename: 'abstract-art-blue.png',
      mimeType: 'image/png',
      type: 'IMAGE' as AssetType,
      status: 'READY' as AssetStatus,
      sizeBytes: 3567890,
      storageUrl: 'https://storage.example.com/assets/abstract-art-blue.png',
      thumbnailUrl: 'https://storage.example.com/thumbs/abstract-art-blue.png',
      width: 5000,
      height: 5000,
      dpi: 300,
      colorSpace: 'sRGB',
      tags: ['abstract', 'art', 'blue'],
      metadata: {},
      usageCount: 1,
      createdAt: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      filename: 'logo-vector.svg',
      originalFilename: 'company-logo.svg',
      mimeType: 'image/svg+xml',
      type: 'VECTOR' as AssetType,
      status: 'READY' as AssetStatus,
      sizeBytes: 45678,
      storageUrl: 'https://storage.example.com/assets/logo-vector.svg',
      thumbnailUrl: 'https://storage.example.com/thumbs/logo-vector.png',
      width: null,
      height: null,
      dpi: null,
      colorSpace: null,
      tags: ['logo', 'brand', 'vector'],
      metadata: {},
      usageCount: 5,
      createdAt: new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000),
    },
  ];

  // Seed Events
  const events: Event[] = [
    {
      id: generateId(),
      userId,
      entityType: 'PRODUCT' as EntityType,
      entityId: products[0].id,
      eventType: 'PRODUCT_PUBLISHED' as EventType,
      severity: 'SUCCESS' as EventSeverity,
      message: 'Product "Classic Cotton T-Shirt" was published to Shopify',
      payload: { storeId: stores[0].id },
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      entityType: 'STORE' as EntityType,
      entityId: stores[0].id,
      eventType: 'STORE_SYNC_COMPLETED' as EventType,
      severity: 'SUCCESS' as EventSeverity,
      message: 'Sync completed for Main Shopify Store - 45 products synced',
      payload: { productsCreated: 0, productsUpdated: 45, productsDeleted: 0 },
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      entityType: 'ASSET' as EntityType,
      entityId: assets[1].id,
      eventType: 'ASSET_UPLOADED' as EventType,
      severity: 'SUCCESS' as EventSeverity,
      message: 'New asset uploaded: abstract-art-blue.png',
      payload: { sizeBytes: 3567890 },
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      entityType: 'STORE' as EntityType,
      entityId: stores[2].id,
      eventType: 'STORE_SYNC_FAILED' as EventType,
      severity: 'ERROR' as EventSeverity,
      message: 'Sync failed for Amazon Seller - API credentials expired',
      payload: { error: 'API_CREDENTIALS_EXPIRED' },
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
    },
    {
      id: generateId(),
      userId,
      entityType: 'PRODUCT' as EntityType,
      entityId: products[2].id,
      eventType: 'PRODUCT_CREATED' as EventType,
      severity: 'SUCCESS' as EventSeverity,
      message: 'New product created: Ceramic Coffee Mug - Motivational Quote',
      payload: {},
      ipAddress: null,
      userAgent: null,
      createdAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000),
    },
  ];

  // Save demo data
  localDb.set('products', products);
  localDb.set('stores', stores);
  localDb.set('assets', assets);
  localDb.set('events', events);

  console.log('Demo data seeded successfully');
}

// Auto-seed on import in development
if (import.meta.env.DEV) {
  seedDemoData();
}

export default localDb;
