import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type {
  Store,
  StoreFilters,
  CreateStoreDto,
  UpdateStoreDto,
  SyncResult,
} from '../../entities/store/model/types';

// ============================================
// API PLACEHOLDER
// ============================================

const storeApi = {
  async getAll(filters?: StoreFilters): Promise<Store[]> {
    return [];
  },
  async getById(id: string): Promise<Store> {
    throw new Error('Not implemented');
  },
  async create(dto: CreateStoreDto): Promise<Store> {
    throw new Error('Not implemented');
  },
  async update(id: string, dto: UpdateStoreDto): Promise<Store> {
    throw new Error('Not implemented');
  },
  async delete(id: string): Promise<void> {
    throw new Error('Not implemented');
  },
  async sync(id: string): Promise<SyncResult> {
    throw new Error('Not implemented');
  },
  async disconnect(id: string): Promise<void> {
    throw new Error('Not implemented');
  },
};

// ============================================
// STORE TYPES
// ============================================

interface StoreState {
  // Data
  stores: Map<string, Store>;
  filters: StoreFilters;
  syncingStoreIds: Set<string>;

  // UI State
  isLoading: boolean;
  error: Error | null;

  // Actions
  fetchStores: () => Promise<void>;
  fetchStoreById: (id: string) => Promise<Store>;
  createStore: (dto: CreateStoreDto) => Promise<Store>;
  updateStore: (id: string, dto: UpdateStoreDto) => Promise<Store>;
  deleteStore: (id: string) => Promise<void>;
  syncStore: (id: string) => Promise<SyncResult>;
  disconnectStore: (id: string) => Promise<void>;

  // Filters
  setFilters: (filters: Partial<StoreFilters>) => void;
  clearFilters: () => void;

  // Reset
  reset: () => void;
}

// ============================================
// INITIAL STATE
// ============================================

const initialState = {
  stores: new Map<string, Store>(),
  filters: {},
  syncingStoreIds: new Set<string>(),
  isLoading: false,
  error: null,
};

// ============================================
// STORE
// ============================================

export const useStoreStore = create<StoreState>()(
  devtools(
    persist(
      immer((set, get) => ({
        ...initialState,

        // Fetch all stores
        fetchStores: async () => {
          set({ isLoading: true, error: null });
          try {
            const stores = await storeApi.getAll(get().filters);
            set((state) => {
              state.stores.clear();
              stores.forEach((store) => {
                state.stores.set(store.id, store);
              });
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Fetch single store
        fetchStoreById: async (id) => {
          set({ isLoading: true, error: null });
          try {
            const store = await storeApi.getById(id);
            set((state) => {
              state.stores.set(id, store);
              state.isLoading = false;
            });
            return store;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Create store
        createStore: async (dto) => {
          set({ isLoading: true, error: null });
          try {
            const store = await storeApi.create(dto);
            set((state) => {
              state.stores.set(store.id, store);
              state.isLoading = false;
            });
            return store;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Update store
        updateStore: async (id, dto) => {
          set({ isLoading: true, error: null });
          try {
            const store = await storeApi.update(id, dto);
            set((state) => {
              state.stores.set(id, store);
              state.isLoading = false;
            });
            return store;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Delete store
        deleteStore: async (id) => {
          set({ isLoading: true, error: null });
          try {
            await storeApi.delete(id);
            set((state) => {
              state.stores.delete(id);
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Sync store
        syncStore: async (id) => {
          set((state) => {
            state.syncingStoreIds.add(id);
          });
          try {
            const result = await storeApi.sync(id);
            // Refresh store data after sync
            const store = await storeApi.getById(id);
            set((state) => {
              state.stores.set(id, store);
              state.syncingStoreIds.delete(id);
            });
            return result;
          } catch (error) {
            set((state) => {
              state.syncingStoreIds.delete(id);
            });
            throw error;
          }
        },

        // Disconnect store
        disconnectStore: async (id) => {
          set({ isLoading: true, error: null });
          try {
            await storeApi.disconnect(id);
            const store = await storeApi.getById(id);
            set((state) => {
              state.stores.set(id, store);
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Filter actions
        setFilters: (filters) =>
          set((state) => {
            state.filters = { ...state.filters, ...filters };
          }),

        clearFilters: () =>
          set((state) => {
            state.filters = {};
          }),

        // Reset
        reset: () => set(initialState),
      })),
      {
        name: 'store-store',
        partialize: (state) => ({ filters: state.filters }),
      }
    ),
    { name: 'StoreStore' }
  )
);

// ============================================
// SELECTORS
// ============================================

export const selectStores = (state: StoreState) =>
  Array.from(state.stores.values());

export const selectStoreById = (id: string) => (state: StoreState) =>
  state.stores.get(id);

export const selectActiveStores = (state: StoreState) =>
  Array.from(state.stores.values()).filter((store) => store.isActive);

export const selectSyncingStores = (state: StoreState) =>
  Array.from(state.syncingStoreIds);

export const selectIsStoreSyncing = (id: string) => (state: StoreState) =>
  state.syncingStoreIds.has(id);

export const selectFilteredStores = (state: StoreState) => {
  const stores = Array.from(state.stores.values());
  const { filters } = state;

  return stores.filter((store) => {
    if (filters.type?.length && !filters.type.includes(store.type)) {
      return false;
    }
    if (filters.syncStatus?.length && !filters.syncStatus.includes(store.syncStatus)) {
      return false;
    }
    if (filters.isActive !== undefined && store.isActive !== filters.isActive) {
      return false;
    }
    if (filters.search) {
      const search = filters.search.toLowerCase();
      if (!store.name.toLowerCase().includes(search)) {
        return false;
      }
    }
    return true;
  });
};

export default useStoreStore;
