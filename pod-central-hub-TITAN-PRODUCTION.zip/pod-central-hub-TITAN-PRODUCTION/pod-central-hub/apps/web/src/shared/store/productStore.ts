import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type {
  Product,
  ProductFilters,
  CreateProductDto,
  UpdateProductDto,
  PaginationMeta,
} from '../../entities/product/model/types';

// ============================================
// API PLACEHOLDER (will be replaced with actual API)
// ============================================

const productApi = {
  async getAll(filters?: ProductFilters): Promise<{ data: Product[]; meta: PaginationMeta }> {
    // Placeholder - will be replaced with actual API call
    return { data: [], meta: { total: 0, page: 1, pageSize: 20, totalPages: 0, hasNextPage: false, hasPrevPage: false } };
  },
  async getById(id: string): Promise<Product> {
    throw new Error('Not implemented');
  },
  async create(dto: CreateProductDto): Promise<Product> {
    throw new Error('Not implemented');
  },
  async update(id: string, dto: UpdateProductDto): Promise<Product> {
    throw new Error('Not implemented');
  },
  async delete(id: string): Promise<void> {
    throw new Error('Not implemented');
  },
  async bulkDelete(ids: string[]): Promise<void> {
    throw new Error('Not implemented');
  },
};

// ============================================
// STORE TYPES
// ============================================

interface ProductState {
  // Data
  products: Map<string, Product>;
  selectedIds: Set<string>;
  filters: ProductFilters;
  pagination: PaginationMeta;

  // UI State
  isLoading: boolean;
  error: Error | null;

  // Actions
  fetchProducts: () => Promise<void>;
  fetchProductById: (id: string) => Promise<Product>;
  createProduct: (dto: CreateProductDto) => Promise<Product>;
  updateProduct: (id: string, dto: UpdateProductDto) => Promise<Product>;
  deleteProduct: (id: string) => Promise<void>;
  bulkDelete: (ids: string[]) => Promise<void>;

  // Selection
  selectProduct: (id: string) => void;
  deselectProduct: (id: string) => void;
  toggleProductSelection: (id: string) => void;
  selectAll: () => void;
  clearSelection: () => void;

  // Filters
  setFilters: (filters: Partial<ProductFilters>) => void;
  clearFilters: () => void;

  // Reset
  reset: () => void;
}

// ============================================
// INITIAL STATE
// ============================================

const initialState = {
  products: new Map<string, Product>(),
  selectedIds: new Set<string>(),
  filters: {},
  pagination: {
    total: 0,
    page: 1,
    pageSize: 20,
    totalPages: 0,
    hasNextPage: false,
    hasPrevPage: false,
  },
  isLoading: false,
  error: null,
};

// ============================================
// STORE
// ============================================

export const useProductStore = create<ProductState>()(
  devtools(
    persist(
      immer((set, get) => ({
        ...initialState,

        // Fetch all products
        fetchProducts: async () => {
          set({ isLoading: true, error: null });
          try {
            const response = await productApi.getAll(get().filters);
            set((state) => {
              state.products.clear();
              response.data.forEach((product) => {
                state.products.set(product.id, product);
              });
              state.pagination = response.meta;
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Fetch single product
        fetchProductById: async (id) => {
          set({ isLoading: true, error: null });
          try {
            const product = await productApi.getById(id);
            set((state) => {
              state.products.set(id, product);
              state.isLoading = false;
            });
            return product;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Create product
        createProduct: async (dto) => {
          set({ isLoading: true, error: null });
          try {
            const product = await productApi.create(dto);
            set((state) => {
              state.products.set(product.id, product);
              state.isLoading = false;
            });
            return product;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Update product
        updateProduct: async (id, dto) => {
          set({ isLoading: true, error: null });
          try {
            const product = await productApi.update(id, dto);
            set((state) => {
              state.products.set(id, product);
              state.isLoading = false;
            });
            return product;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Delete product
        deleteProduct: async (id) => {
          set({ isLoading: true, error: null });
          try {
            await productApi.delete(id);
            set((state) => {
              state.products.delete(id);
              state.selectedIds.delete(id);
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Bulk delete
        bulkDelete: async (ids) => {
          set({ isLoading: true, error: null });
          try {
            await productApi.bulkDelete(ids);
            set((state) => {
              ids.forEach((id) => {
                state.products.delete(id);
                state.selectedIds.delete(id);
              });
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Selection actions
        selectProduct: (id) =>
          set((state) => {
            state.selectedIds.add(id);
          }),

        deselectProduct: (id) =>
          set((state) => {
            state.selectedIds.delete(id);
          }),

        toggleProductSelection: (id) =>
          set((state) => {
            if (state.selectedIds.has(id)) {
              state.selectedIds.delete(id);
            } else {
              state.selectedIds.add(id);
            }
          }),

        selectAll: () =>
          set((state) => {
            state.products.forEach((_, id) => state.selectedIds.add(id));
          }),

        clearSelection: () =>
          set((state) => {
            state.selectedIds.clear();
          }),

        // Filter actions
        setFilters: (filters) =>
          set((state) => {
            state.filters = { ...state.filters, ...filters };
          }),

        clearFilters: () =>
          set((state) => {
            state.filters = {};
          }),

        // Reset
        reset: () => set(initialState),
      })),
      {
        name: 'product-store',
        partialize: (state) => ({ filters: state.filters }),
      }
    ),
    { name: 'ProductStore' }
  )
);

// ============================================
// SELECTORS
// ============================================

export const selectProducts = (state: ProductState) =>
  Array.from(state.products.values());

export const selectProductById = (id: string) => (state: ProductState) =>
  state.products.get(id);

export const selectSelectedProducts = (state: ProductState) =>
  Array.from(state.selectedIds)
    .map((id) => state.products.get(id))
    .filter((p): p is Product => p !== undefined);

export const selectSelectedCount = (state: ProductState) =>
  state.selectedIds.size;

export const selectIsProductSelected = (id: string) => (state: ProductState) =>
  state.selectedIds.has(id);

export const selectFilteredProducts = (state: ProductState) => {
  const products = Array.from(state.products.values());
  const { filters } = state;

  return products.filter((product) => {
    if (filters.status?.length && !filters.status.includes(product.status)) {
      return false;
    }
    if (filters.type?.length && !filters.type.includes(product.type)) {
      return false;
    }
    if (filters.storeId !== undefined && product.storeId !== filters.storeId) {
      return false;
    }
    if (filters.minPrice && product.price < filters.minPrice) {
      return false;
    }
    if (filters.maxPrice && product.price > filters.maxPrice) {
      return false;
    }
    if (filters.search) {
      const search = filters.search.toLowerCase();
      if (
        !product.title.toLowerCase().includes(search) &&
        !product.sku.toLowerCase().includes(search)
      ) {
        return false;
      }
    }
    return true;
  });
};

export default useProductStore;
