// ============================================
// SHARED API EXPORTS
// ============================================

export {
  api,
  ApiError,
  NetworkError,
  ValidationError,
  setAuthToken,
  getAuthToken,
  clearAuthToken,
  addRequestInterceptor,
  addResponseInterceptor,
  addErrorInterceptor,
  withRetry,
  batchRequests,
} from './client';

export type {
  RequestConfig,
  ApiResponse,
  RetryConfig,
} from './client';
