// ============================================
// API CLIENT - HTTP REQUEST INFRASTRUCTURE
// ============================================

import type { PaginatedResponse, PaginationMeta } from '@/entities/product/model/types';

// ============================================
// CONFIGURATION
// ============================================

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';
const DEFAULT_TIMEOUT = 30000; // 30 seconds

// ============================================
// ERROR TYPES
// ============================================

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'ApiError';
  }

  static isApiError(error: unknown): error is ApiError {
    return error instanceof ApiError;
  }
}

export class NetworkError extends Error {
  constructor(message = 'Network error. Please check your connection.') {
    super(message);
    this.name = 'NetworkError';
  }
}

export class ValidationError extends ApiError {
  public fieldErrors: Record<string, string[]>;

  constructor(message: string, fieldErrors: Record<string, string[]>) {
    super(message, 400, 'VALIDATION_ERROR', { fieldErrors });
    this.name = 'ValidationError';
    this.fieldErrors = fieldErrors;
  }
}

// ============================================
// REQUEST/RESPONSE TYPES
// ============================================

export interface RequestConfig extends Omit<RequestInit, 'body'> {
  params?: Record<string, string | number | boolean | undefined | null>;
  data?: unknown;
  timeout?: number;
}

export interface ApiResponse<T = unknown> {
  data: T;
  meta?: PaginationMeta;
}

// ============================================
// TOKEN MANAGEMENT
// ============================================

let authToken: string | null = null;

export function setAuthToken(token: string | null): void {
  authToken = token;
  if (token) {
    localStorage.setItem('auth_token', token);
  } else {
    localStorage.removeItem('auth_token');
  }
}

export function getAuthToken(): string | null {
  if (!authToken) {
    authToken = localStorage.getItem('auth_token');
  }
  return authToken;
}

export function clearAuthToken(): void {
  authToken = null;
  localStorage.removeItem('auth_token');
}

// ============================================
// REQUEST INTERCEPTORS
// ============================================

type RequestInterceptor = (config: RequestConfig) => RequestConfig | Promise<RequestConfig>;
type ResponseInterceptor = (response: Response) => Response | Promise<Response>;
type ErrorInterceptor = (error: Error) => Error | Promise<Error>;

const requestInterceptors: RequestInterceptor[] = [];
const responseInterceptors: ResponseInterceptor[] = [];
const errorInterceptors: ErrorInterceptor[] = [];

export function addRequestInterceptor(interceptor: RequestInterceptor): () => void {
  requestInterceptors.push(interceptor);
  return () => {
    const index = requestInterceptors.indexOf(interceptor);
    if (index > -1) requestInterceptors.splice(index, 1);
  };
}

export function addResponseInterceptor(interceptor: ResponseInterceptor): () => void {
  responseInterceptors.push(interceptor);
  return () => {
    const index = responseInterceptors.indexOf(interceptor);
    if (index > -1) responseInterceptors.splice(index, 1);
  };
}

export function addErrorInterceptor(interceptor: ErrorInterceptor): () => void {
  errorInterceptors.push(interceptor);
  return () => {
    const index = errorInterceptors.indexOf(interceptor);
    if (index > -1) errorInterceptors.splice(index, 1);
  };
}

// ============================================
// URL BUILDER
// ============================================

function buildUrl(endpoint: string, params?: Record<string, string | number | boolean | undefined | null>): string {
  const url = new URL(endpoint, API_BASE_URL.startsWith('http') ? API_BASE_URL : window.location.origin + API_BASE_URL);

  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.append(key, String(value));
      }
    });
  }

  return url.toString();
}

// ============================================
// CORE REQUEST FUNCTION
// ============================================

async function request<T>(endpoint: string, config: RequestConfig = {}): Promise<T> {
  const { params, data, timeout = DEFAULT_TIMEOUT, ...fetchConfig } = config;

  // Apply request interceptors
  let processedConfig = { params, data, timeout, ...fetchConfig };
  for (const interceptor of requestInterceptors) {
    processedConfig = await interceptor(processedConfig);
  }

  // Build URL with query params
  const url = buildUrl(endpoint, processedConfig.params);

  // Build headers
  const headers = new Headers(processedConfig.headers);

  // Add auth token if available
  const token = getAuthToken();
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  // Add content type for JSON body
  if (processedConfig.data && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  // Add accept header
  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json');
  }

  // Create abort controller for timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    let response = await fetch(url, {
      ...fetchConfig,
      headers,
      body: processedConfig.data ? JSON.stringify(processedConfig.data) : undefined,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // Apply response interceptors
    for (const interceptor of responseInterceptors) {
      response = await interceptor(response);
    }

    // Handle non-OK responses
    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));

      // Handle validation errors
      if (response.status === 400 && errorBody.fieldErrors) {
        throw new ValidationError(
          errorBody.message || 'Validation failed',
          errorBody.fieldErrors
        );
      }

      // Handle unauthorized - clear token and redirect
      if (response.status === 401) {
        clearAuthToken();
        // Dispatch event for auth state management
        window.dispatchEvent(new CustomEvent('auth:unauthorized'));
      }

      throw new ApiError(
        errorBody.message || errorBody.error || `Request failed with status ${response.status}`,
        response.status,
        errorBody.code || 'UNKNOWN_ERROR',
        errorBody
      );
    }

    // Handle empty responses (204 No Content)
    if (response.status === 204) {
      return undefined as T;
    }

    // Parse JSON response
    const json = await response.json();
    return json as T;

  } catch (error) {
    clearTimeout(timeoutId);

    // Handle abort/timeout
    if (error instanceof Error && error.name === 'AbortError') {
      throw new NetworkError('Request timed out');
    }

    // Handle network errors
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new NetworkError();
    }

    // Apply error interceptors
    let processedError = error instanceof Error ? error : new Error(String(error));
    for (const interceptor of errorInterceptors) {
      processedError = await interceptor(processedError);
    }

    throw processedError;
  }
}

// ============================================
// HTTP METHOD HELPERS
// ============================================

export const api = {
  get<T>(endpoint: string, config?: Omit<RequestConfig, 'method' | 'data'>): Promise<T> {
    return request<T>(endpoint, { ...config, method: 'GET' });
  },

  post<T>(endpoint: string, data?: unknown, config?: Omit<RequestConfig, 'method' | 'data'>): Promise<T> {
    return request<T>(endpoint, { ...config, method: 'POST', data });
  },

  put<T>(endpoint: string, data?: unknown, config?: Omit<RequestConfig, 'method' | 'data'>): Promise<T> {
    return request<T>(endpoint, { ...config, method: 'PUT', data });
  },

  patch<T>(endpoint: string, data?: unknown, config?: Omit<RequestConfig, 'method' | 'data'>): Promise<T> {
    return request<T>(endpoint, { ...config, method: 'PATCH', data });
  },

  delete<T>(endpoint: string, config?: Omit<RequestConfig, 'method'>): Promise<T> {
    return request<T>(endpoint, { ...config, method: 'DELETE' });
  },
};

// ============================================
// RETRY UTILITY
// ============================================

export interface RetryConfig {
  maxRetries?: number;
  retryDelay?: number;
  retryCondition?: (error: Error) => boolean;
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  config: RetryConfig = {}
): Promise<T> {
  const {
    maxRetries = 3,
    retryDelay = 1000,
    retryCondition = (error) => error instanceof NetworkError,
  } = config;

  let lastError: Error;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      // Don't retry if condition not met or last attempt
      if (!retryCondition(lastError) || attempt === maxRetries) {
        throw lastError;
      }

      // Wait before retrying with exponential backoff
      await new Promise((resolve) => setTimeout(resolve, retryDelay * Math.pow(2, attempt)));
    }
  }

  throw lastError!;
}

// ============================================
// BATCH REQUEST UTILITY
// ============================================

export async function batchRequests<T>(
  requests: Array<() => Promise<T>>,
  concurrency = 5
): Promise<Array<{ status: 'fulfilled'; value: T } | { status: 'rejected'; reason: Error }>> {
  const results: Array<{ status: 'fulfilled'; value: T } | { status: 'rejected'; reason: Error }> = [];

  for (let i = 0; i < requests.length; i += concurrency) {
    const batch = requests.slice(i, i + concurrency);
    const batchResults = await Promise.allSettled(batch.map((fn) => fn()));

    results.push(...batchResults.map((result) => {
      if (result.status === 'fulfilled') {
        return { status: 'fulfilled' as const, value: result.value };
      }
      return {
        status: 'rejected' as const,
        reason: result.reason instanceof Error ? result.reason : new Error(String(result.reason))
      };
    }));
  }

  return results;
}

export default api;
