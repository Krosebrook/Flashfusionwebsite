import React, { type ReactNode } from 'react';
import { ArrowLeft } from 'lucide-react';
import { cn } from '../lib/utils';
import { Button } from './Button';

// ============================================
// PAGE HEADER
// ============================================

export interface PageHeaderProps {
  title: string;
  description?: string;
  children?: ReactNode;
  backHref?: string;
  onBack?: () => void;
  className?: string;
}

export function PageHeader({
  title,
  description,
  children,
  backHref,
  onBack,
  className,
}: PageHeaderProps) {
  const showBack = backHref || onBack;

  return (
    <div
      className={cn(
        'flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between',
        className
      )}
    >
      <div className="flex items-center gap-4">
        {showBack && (
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={onBack}
            asChild={!!backHref}
            aria-label="Go back"
          >
            {backHref ? (
              <a href={backHref}>
                <ArrowLeft className="h-5 w-5" />
              </a>
            ) : (
              <ArrowLeft className="h-5 w-5" />
            )}
          </Button>
        )}

        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {title}
          </h1>
          {description && (
            <p className="mt-1 text-sm text-slate-500">{description}</p>
          )}
        </div>
      </div>

      {children && (
        <div className="flex items-center gap-2">{children}</div>
      )}
    </div>
  );
}

// ============================================
// PAGE CONTAINER
// ============================================

export interface PageContainerProps {
  children: ReactNode;
  className?: string;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
}

export function PageContainer({
  children,
  className,
  maxWidth = 'full',
}: PageContainerProps) {
  const maxWidthStyles = {
    sm: 'max-w-screen-sm',
    md: 'max-w-screen-md',
    lg: 'max-w-screen-lg',
    xl: 'max-w-screen-xl',
    '2xl': 'max-w-screen-2xl',
    full: 'max-w-full',
  };

  return (
    <div
      className={cn(
        'flex flex-col gap-6 p-6',
        maxWidthStyles[maxWidth],
        'mx-auto w-full',
        className
      )}
    >
      {children}
    </div>
  );
}

// ============================================
// SECTION
// ============================================

export interface SectionProps {
  title?: string;
  description?: string;
  children: ReactNode;
  actions?: ReactNode;
  className?: string;
}

export function Section({
  title,
  description,
  children,
  actions,
  className,
}: SectionProps) {
  return (
    <section className={cn('space-y-4', className)}>
      {(title || description || actions) && (
        <div className="flex items-start justify-between">
          <div>
            {title && (
              <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
            )}
            {description && (
              <p className="mt-1 text-sm text-slate-500">{description}</p>
            )}
          </div>
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}
