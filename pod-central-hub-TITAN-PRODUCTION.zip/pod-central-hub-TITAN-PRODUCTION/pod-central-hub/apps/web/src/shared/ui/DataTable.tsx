import React, { useState, useCallback, type ReactNode } from 'react';
import {
  ChevronDown,
  ChevronUp,
  ChevronsUpDown,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Button } from './Button';
import { Checkbox } from './Select';
import { Skeleton } from './ErrorBoundary';

// ============================================
// TYPES
// ============================================

export interface Column<T> {
  id: string;
  header: string | ReactNode;
  accessor: keyof T | ((row: T) => ReactNode);
  sortable?: boolean;
  width?: string | number;
  align?: 'left' | 'center' | 'right';
  className?: string;
}

export interface SortState {
  column: string;
  direction: 'asc' | 'desc';
}

export interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  getRowId: (row: T) => string;
  isLoading?: boolean;
  onRowClick?: (row: T) => void;
  onSort?: (sort: SortState) => void;
  sortState?: SortState;
  selectable?: boolean;
  selectedIds?: Set<string>;
  onSelectionChange?: (selectedIds: Set<string>) => void;
  emptyMessage?: string;
  className?: string;
}

// ============================================
// DATA TABLE
// ============================================

export function DataTable<T>({
  columns,
  data,
  getRowId,
  isLoading = false,
  onRowClick,
  onSort,
  sortState,
  selectable = false,
  selectedIds = new Set(),
  onSelectionChange,
  emptyMessage = 'No data available',
  className,
}: DataTableProps<T>) {
  const allSelected = data.length > 0 && data.every((row) => selectedIds.has(getRowId(row)));
  const someSelected = data.some((row) => selectedIds.has(getRowId(row)));

  const handleSelectAll = useCallback(() => {
    if (!onSelectionChange) return;

    if (allSelected) {
      onSelectionChange(new Set());
    } else {
      const newSelected = new Set(data.map(getRowId));
      onSelectionChange(newSelected);
    }
  }, [allSelected, data, getRowId, onSelectionChange]);

  const handleSelectRow = useCallback(
    (id: string) => {
      if (!onSelectionChange) return;

      const newSelected = new Set(selectedIds);
      if (newSelected.has(id)) {
        newSelected.delete(id);
      } else {
        newSelected.add(id);
      }
      onSelectionChange(newSelected);
    },
    [selectedIds, onSelectionChange]
  );

  const handleSort = useCallback(
    (columnId: string) => {
      if (!onSort) return;

      const newDirection =
        sortState?.column === columnId && sortState.direction === 'asc'
          ? 'desc'
          : 'asc';

      onSort({ column: columnId, direction: newDirection });
    },
    [sortState, onSort]
  );

  const getCellValue = (row: T, accessor: Column<T>['accessor']): ReactNode => {
    if (typeof accessor === 'function') {
      return accessor(row);
    }
    return row[accessor] as ReactNode;
  };

  const getSortIcon = (columnId: string) => {
    if (sortState?.column !== columnId) {
      return <ChevronsUpDown className="h-4 w-4 text-slate-400" />;
    }
    return sortState.direction === 'asc' ? (
      <ChevronUp className="h-4 w-4" />
    ) : (
      <ChevronDown className="h-4 w-4" />
    );
  };

  const alignStyles = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };

  if (isLoading) {
    return (
      <div className={cn('overflow-hidden rounded-lg border border-slate-200', className)}>
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              {selectable && (
                <th className="w-12 px-4 py-3">
                  <Skeleton width={16} height={16} rounded="sm" />
                </th>
              )}
              {columns.map((column) => (
                <th key={column.id} className="px-4 py-3">
                  <Skeleton width="60%" height={16} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                {selectable && (
                  <td className="px-4 py-3">
                    <Skeleton width={16} height={16} rounded="sm" />
                  </td>
                )}
                {columns.map((column) => (
                  <td key={column.id} className="px-4 py-3">
                    <Skeleton width="80%" height={20} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className={cn('overflow-hidden rounded-lg border border-slate-200', className)}>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              {selectable && (
                <th className="w-12 px-4 py-3">
                  <Checkbox
                    checked={allSelected}
                    onChange={handleSelectAll}
                    aria-label="Select all rows"
                    ref={
                      someSelected && !allSelected
                        ? (el) => {
                            if (el) el.indeterminate = true;
                          }
                        : undefined
                    }
                  />
                </th>
              )}
              {columns.map((column) => (
                <th
                  key={column.id}
                  className={cn(
                    'px-4 py-3 text-xs font-medium uppercase tracking-wider text-slate-500',
                    alignStyles[column.align || 'left'],
                    column.sortable && 'cursor-pointer hover:bg-slate-100',
                    column.className
                  )}
                  style={{ width: column.width }}
                  onClick={column.sortable ? () => handleSort(column.id) : undefined}
                >
                  <div className="flex items-center gap-1">
                    {column.header}
                    {column.sortable && getSortIcon(column.id)}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {data.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (selectable ? 1 : 0)}
                  className="px-4 py-8 text-center text-sm text-slate-500"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              data.map((row) => {
                const rowId = getRowId(row);
                const isSelected = selectedIds.has(rowId);

                return (
                  <tr
                    key={rowId}
                    className={cn(
                      'transition-colors',
                      onRowClick && 'cursor-pointer hover:bg-slate-50',
                      isSelected && 'bg-blue-50'
                    )}
                    onClick={() => onRowClick?.(row)}
                  >
                    {selectable && (
                      <td
                        className="px-4 py-3"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Checkbox
                          checked={isSelected}
                          onChange={() => handleSelectRow(rowId)}
                          aria-label={`Select row ${rowId}`}
                        />
                      </td>
                    )}
                    {columns.map((column) => (
                      <td
                        key={column.id}
                        className={cn(
                          'px-4 py-3 text-sm text-slate-900',
                          alignStyles[column.align || 'left'],
                          column.className
                        )}
                      >
                        {getCellValue(row, column.accessor)}
                      </td>
                    ))}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================
// PAGINATION
// ============================================

export interface PaginationProps {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  pageSizeOptions?: number[];
  className?: string;
}

export function Pagination({
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 20, 50, 100],
  className,
}: PaginationProps) {
  const totalPages = Math.ceil(total / pageSize);
  const startItem = (page - 1) * pageSize + 1;
  const endItem = Math.min(page * pageSize, total);

  return (
    <div
      className={cn(
        'flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-white',
        className
      )}
    >
      <div className="flex items-center gap-4">
        <span className="text-sm text-slate-500">
          Showing {startItem} to {endItem} of {total} results
        </span>

        {onPageSizeChange && (
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="h-8 rounded-md border border-slate-300 bg-white px-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {pageSizeOptions.map((size) => (
              <option key={size} value={size}>
                {size} per page
              </option>
            ))}
          </select>
        )}
      </div>

      <div className="flex items-center gap-1">
        <Button
          variant="outline"
          size="icon-sm"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <span className="px-3 text-sm text-slate-600">
          Page {page} of {totalPages}
        </span>

        <Button
          variant="outline"
          size="icon-sm"
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
