// ============================================
// UI COMPONENT LIBRARY - BARREL EXPORTS
// ============================================

// Button
export { Button, buttonVariants, type ButtonProps } from './Button';

// Card
export {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  type CardProps,
  type CardHeaderProps,
  type CardTitleProps,
  type CardDescriptionProps,
  type CardContentProps,
  type CardFooterProps,
} from './Card';

// Input
export { Input, Textarea, type InputProps, type TextareaProps } from './Input';

// Select
export {
  Select,
  Checkbox,
  RadioGroup,
  type SelectProps,
  type SelectOption,
  type CheckboxProps,
  type RadioGroupProps,
  type RadioOption,
} from './Select';

// Badge
export {
  Badge,
  StatusBadge,
  CountBadge,
  type BadgeProps,
  type StatusBadgeProps,
  type StatusType,
  type CountBadgeProps,
} from './Badge';

// Modal
export {
  Modal,
  ConfirmModal,
  AlertDialog,
  type ModalProps,
  type ConfirmModalProps,
  type AlertDialogProps,
} from './Modal';

// Error Boundary & Loading States
export {
  ErrorBoundary,
  ErrorFallback,
  Skeleton,
  LoadingScreen,
  Spinner,
} from './ErrorBoundary';

// Empty State
export {
  EmptyState,
  NoResults,
  ErrorState,
  type EmptyStateProps,
  type NoResultsProps,
  type ErrorStateProps,
} from './EmptyState';

// Page Layout
export {
  PageHeader,
  PageContainer,
  Section,
  type PageHeaderProps,
  type PageContainerProps,
  type SectionProps,
} from './PageHeader';

// Data Table
export {
  DataTable,
  Pagination,
  type Column,
  type SortState,
  type DataTableProps,
  type PaginationProps,
} from './DataTable';
