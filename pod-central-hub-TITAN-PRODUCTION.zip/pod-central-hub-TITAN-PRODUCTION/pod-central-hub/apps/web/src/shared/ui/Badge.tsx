import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

// ============================================
// BADGE
// ============================================

const badgeVariants = cva(
  'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
  {
    variants: {
      variant: {
        default: 'bg-slate-100 text-slate-800',
        primary: 'bg-blue-100 text-blue-800',
        secondary: 'bg-slate-100 text-slate-600',
        success: 'bg-green-100 text-green-800',
        warning: 'bg-yellow-100 text-yellow-800',
        destructive: 'bg-red-100 text-red-800',
        outline: 'border border-slate-300 text-slate-700 bg-transparent',
      },
      size: {
        sm: 'px-2 py-0.5 text-xs',
        md: 'px-2.5 py-0.5 text-xs',
        lg: 'px-3 py-1 text-sm',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean;
  dotColor?: string;
}

export function Badge({
  className,
  variant,
  size,
  dot,
  dotColor,
  children,
  ...props
}: BadgeProps) {
  const dotColorStyles = {
    default: 'bg-slate-500',
    primary: 'bg-blue-500',
    secondary: 'bg-slate-400',
    success: 'bg-green-500',
    warning: 'bg-yellow-500',
    destructive: 'bg-red-500',
    outline: 'bg-slate-500',
  };

  return (
    <span
      className={cn(badgeVariants({ variant, size }), className)}
      {...props}
    >
      {dot && (
        <span
          className={cn(
            'mr-1.5 h-1.5 w-1.5 rounded-full',
            dotColor || dotColorStyles[variant || 'default']
          )}
        />
      )}
      {children}
    </span>
  );
}

// ============================================
// STATUS BADGE
// ============================================

export type StatusType =
  | 'draft'
  | 'active'
  | 'published'
  | 'archived'
  | 'pending'
  | 'syncing'
  | 'synced'
  | 'error'
  | 'disconnected';

const statusConfig: Record<
  StatusType,
  { variant: 'default' | 'primary' | 'success' | 'warning' | 'destructive'; label: string }
> = {
  draft: { variant: 'default', label: 'Draft' },
  active: { variant: 'primary', label: 'Active' },
  published: { variant: 'success', label: 'Published' },
  archived: { variant: 'default', label: 'Archived' },
  pending: { variant: 'warning', label: 'Pending' },
  syncing: { variant: 'primary', label: 'Syncing' },
  synced: { variant: 'success', label: 'Synced' },
  error: { variant: 'destructive', label: 'Error' },
  disconnected: { variant: 'default', label: 'Disconnected' },
};

export interface StatusBadgeProps {
  status: StatusType;
  showDot?: boolean;
  className?: string;
}

export function StatusBadge({ status, showDot = true, className }: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig.draft;

  return (
    <Badge variant={config.variant} dot={showDot} className={className}>
      {config.label}
    </Badge>
  );
}

// ============================================
// COUNT BADGE
// ============================================

export interface CountBadgeProps {
  count: number;
  max?: number;
  variant?: 'default' | 'primary' | 'destructive';
  className?: string;
}

export function CountBadge({
  count,
  max = 99,
  variant = 'default',
  className,
}: CountBadgeProps) {
  const displayCount = count > max ? `${max}+` : count.toString();

  return (
    <Badge
      variant={variant}
      size="sm"
      className={cn('min-w-[20px] justify-center', className)}
    >
      {displayCount}
    </Badge>
  );
}
