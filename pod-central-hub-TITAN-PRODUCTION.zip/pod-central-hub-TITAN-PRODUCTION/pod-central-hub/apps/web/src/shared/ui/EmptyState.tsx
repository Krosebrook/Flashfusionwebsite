import React, { type ReactNode } from 'react';
import {
  Package,
  Store,
  Image,
  FileText,
  Search,
  AlertCircle,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '../lib/utils';

// ============================================
// EMPTY STATE
// ============================================

const iconMap: Record<string, LucideIcon> = {
  package: Package,
  store: Store,
  image: Image,
  'file-text': FileText,
  search: Search,
  'alert-circle': AlertCircle,
};

export interface EmptyStateProps {
  icon?: keyof typeof iconMap | LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({
  icon = 'package',
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  const IconComponent = typeof icon === 'string' ? iconMap[icon] || Package : icon;

  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center py-12 px-4 text-center',
        className
      )}
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 mb-4">
        <IconComponent className="h-8 w-8 text-slate-400" />
      </div>

      <h3 className="text-lg font-medium text-slate-900 mb-1">{title}</h3>

      {description && (
        <p className="text-sm text-slate-500 max-w-md mb-4">{description}</p>
      )}

      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

// ============================================
// NO RESULTS
// ============================================

export interface NoResultsProps {
  searchQuery?: string;
  onClear?: () => void;
  className?: string;
}

export function NoResults({ searchQuery, onClear, className }: NoResultsProps) {
  return (
    <EmptyState
      icon="search"
      title="No results found"
      description={
        searchQuery
          ? `No results match "${searchQuery}". Try adjusting your search or filters.`
          : 'No results match your current filters. Try adjusting your criteria.'
      }
      action={
        onClear && (
          <button
            onClick={onClear}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Clear filters
          </button>
        )
      }
      className={className}
    />
  );
}

// ============================================
// ERROR STATE
// ============================================

export interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({
  title = 'Something went wrong',
  description = 'An error occurred while loading this content.',
  onRetry,
  className,
}: ErrorStateProps) {
  return (
    <EmptyState
      icon="alert-circle"
      title={title}
      description={description}
      action={
        onRetry && (
          <button
            onClick={onRetry}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Try again
          </button>
        )
      }
      className={className}
    />
  );
}
