import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';
import type {
  User,
  AuthContextValue,
  AuthStatus,
  LoginRequest,
  RegisterRequest,
  ResetPasswordRequest,
} from './types';
import { authApi, getStoredToken, clearStoredTokens } from './api';

// ============================================
// AUTH CONTEXT
// ============================================

const AuthContext = createContext<AuthContextValue | null>(null);

// ============================================
// AUTH PROVIDER
// ============================================

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [status, setStatus] = useState<AuthStatus>('idle');
  const [error, setError] = useState<Error | null>(null);

  // Initialize auth state on mount
  useEffect(() => {
    const initAuth = async () => {
      const token = getStoredToken();

      if (!token) {
        setStatus('unauthenticated');
        return;
      }

      setStatus('loading');

      try {
        const currentUser = await authApi.getCurrentUser();
        setUser(currentUser);
        setStatus('authenticated');
      } catch (err) {
        // Try to refresh token
        try {
          const response = await authApi.refreshToken();
          setUser(response.user);
          setStatus('authenticated');
        } catch {
          // Refresh failed, clear tokens
          clearStoredTokens();
          setStatus('unauthenticated');
        }
      }
    };

    initAuth();
  }, []);

  // Login
  const login = useCallback(async (request: LoginRequest) => {
    setStatus('loading');
    setError(null);

    try {
      const response = await authApi.login(request);
      setUser(response.user);
      setStatus('authenticated');
    } catch (err) {
      setError(err as Error);
      setStatus('unauthenticated');
      throw err;
    }
  }, []);

  // Register
  const register = useCallback(async (request: RegisterRequest) => {
    setStatus('loading');
    setError(null);

    try {
      const response = await authApi.register(request);
      setUser(response.user);
      setStatus('authenticated');
    } catch (err) {
      setError(err as Error);
      setStatus('unauthenticated');
      throw err;
    }
  }, []);

  // Logout
  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } finally {
      setUser(null);
      setStatus('unauthenticated');
      setError(null);
    }
  }, []);

  // Reset password
  const resetPassword = useCallback(async (request: ResetPasswordRequest) => {
    await authApi.requestPasswordReset(request);
  }, []);

  // Refresh token
  const refreshToken = useCallback(async () => {
    try {
      const response = await authApi.refreshToken();
      setUser(response.user);
      setStatus('authenticated');
    } catch (err) {
      setUser(null);
      setStatus('unauthenticated');
      throw err;
    }
  }, []);

  // Update user
  const updateUser = useCallback(async (updates: Partial<User>) => {
    const updatedUser = await authApi.updateUser(updates);
    setUser(updatedUser);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      status,
      error,
      login,
      register,
      logout,
      resetPassword,
      refreshToken,
      updateUser,
    }),
    [user, status, error, login, register, logout, resetPassword, refreshToken, updateUser]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ============================================
// AUTH HOOK
// ============================================

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
}

// ============================================
// CONVENIENCE HOOKS
// ============================================

/**
 * Get the current user (throws if not authenticated)
 */
export function useUser(): User {
  const { user, status } = useAuth();

  if (status !== 'authenticated' || !user) {
    throw new Error('User is not authenticated');
  }

  return user;
}

/**
 * Check if user is authenticated
 */
export function useIsAuthenticated(): boolean {
  const { status } = useAuth();
  return status === 'authenticated';
}

/**
 * Check if auth is loading
 */
export function useIsAuthLoading(): boolean {
  const { status } = useAuth();
  return status === 'loading' || status === 'idle';
}

export default AuthProvider;
