import type {
  LoginRequest,
  RegisterRequest,
  ResetPasswordRequest,
  NewPasswordRequest,
  AuthResponse,
  User,
} from './types';

// ============================================
// API BASE URL
// ============================================

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

// ============================================
// TOKEN STORAGE
// ============================================

const TOKEN_KEY = 'auth_token';
const REFRESH_TOKEN_KEY = 'refresh_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function getStoredRefreshToken(): string | null {
  return localStorage.getItem(REFRESH_TOKEN_KEY);
}

export function setStoredRefreshToken(token: string): void {
  localStorage.setItem(REFRESH_TOKEN_KEY, token);
}

export function clearStoredTokens(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(REFRESH_TOKEN_KEY);
}

// ============================================
// API CLIENT
// ============================================

class AuthApiError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public code?: string
  ) {
    super(message);
    this.name = 'AuthApiError';
  }
}

async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new AuthApiError(
      data.message || 'An error occurred',
      response.status,
      data.code
    );
  }

  return data;
}

// ============================================
// AUTH API
// ============================================

export const authApi = {
  /**
   * Login with email and password
   */
  async login(request: LoginRequest): Promise<AuthResponse> {
    const response = await apiRequest<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(request),
    });

    // Store tokens
    setStoredToken(response.tokens.accessToken);
    if (response.tokens.refreshToken) {
      setStoredRefreshToken(response.tokens.refreshToken);
    }

    return response;
  },

  /**
   * Register a new account
   */
  async register(request: RegisterRequest): Promise<AuthResponse> {
    const response = await apiRequest<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(request),
    });

    // Store tokens
    setStoredToken(response.tokens.accessToken);
    if (response.tokens.refreshToken) {
      setStoredRefreshToken(response.tokens.refreshToken);
    }

    return response;
  },

  /**
   * Logout and invalidate session
   */
  async logout(): Promise<void> {
    try {
      await apiRequest('/auth/logout', {
        method: 'POST',
      });
    } finally {
      clearStoredTokens();
    }
  },

  /**
   * Get current user
   */
  async getCurrentUser(): Promise<User> {
    return apiRequest<User>('/auth/me');
  },

  /**
   * Refresh access token
   */
  async refreshToken(): Promise<AuthResponse> {
    const refreshToken = getStoredRefreshToken();

    if (!refreshToken) {
      throw new AuthApiError('No refresh token', 401, 'NO_REFRESH_TOKEN');
    }

    const response = await apiRequest<AuthResponse>('/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refreshToken }),
    });

    // Update stored tokens
    setStoredToken(response.tokens.accessToken);
    if (response.tokens.refreshToken) {
      setStoredRefreshToken(response.tokens.refreshToken);
    }

    return response;
  },

  /**
   * Request password reset email
   */
  async requestPasswordReset(request: ResetPasswordRequest): Promise<void> {
    await apiRequest('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },

  /**
   * Reset password with token
   */
  async resetPassword(request: NewPasswordRequest): Promise<void> {
    await apiRequest('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },

  /**
   * Verify email with token
   */
  async verifyEmail(token: string): Promise<void> {
    await apiRequest('/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ token }),
    });
  },

  /**
   * Resend verification email
   */
  async resendVerificationEmail(): Promise<void> {
    await apiRequest('/auth/resend-verification', {
      method: 'POST',
    });
  },

  /**
   * Update current user
   */
  async updateUser(updates: Partial<User>): Promise<User> {
    return apiRequest<User>('/auth/me', {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  },

  /**
   * Change password
   */
  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    await apiRequest('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },
};

export default authApi;
