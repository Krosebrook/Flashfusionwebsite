import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth, useIsAuthLoading } from './AuthProvider';
import { LoadingScreen } from '../../shared/ui/ErrorBoundary';
import type { UserRole } from './types';
import { hasRole } from './types';

// ============================================
// PROTECTED ROUTE
// ============================================

interface ProtectedRouteProps {
  children?: React.ReactNode;
  redirectTo?: string;
  requiredRoles?: UserRole[];
}

export function ProtectedRoute({
  children,
  redirectTo = '/login',
  requiredRoles,
}: ProtectedRouteProps) {
  const { user, status } = useAuth();
  const isLoading = useIsAuthLoading();
  const location = useLocation();

  // Show loading while checking auth status
  if (isLoading) {
    return <LoadingScreen message="Checking authentication..." />;
  }

  // Redirect to login if not authenticated
  if (status === 'unauthenticated' || !user) {
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }

  // Check role-based access
  if (requiredRoles && !hasRole(user, requiredRoles)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // Render children or outlet
  return children ? <>{children}</> : <Outlet />;
}

// ============================================
// PUBLIC ROUTE (redirect if authenticated)
// ============================================

interface PublicRouteProps {
  children?: React.ReactNode;
  redirectTo?: string;
}

export function PublicRoute({ children, redirectTo = '/dashboard' }: PublicRouteProps) {
  const { status } = useAuth();
  const isLoading = useIsAuthLoading();
  const location = useLocation();

  // Show loading while checking auth status
  if (isLoading) {
    return <LoadingScreen message="Loading..." />;
  }

  // Redirect to dashboard if already authenticated
  if (status === 'authenticated') {
    // Check if there's a redirect location from login
    const from = (location.state as { from?: Location })?.from?.pathname || redirectTo;
    return <Navigate to={from} replace />;
  }

  return children ? <>{children}</> : <Outlet />;
}

// ============================================
// ROLE GUARD
// ============================================

interface RoleGuardProps {
  children: React.ReactNode;
  roles: UserRole[];
  fallback?: React.ReactNode;
}

export function RoleGuard({ children, roles, fallback = null }: RoleGuardProps) {
  const { user } = useAuth();

  if (!hasRole(user, roles)) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

// ============================================
// AUTH GUARD HOOK
// ============================================

export function useRequireAuth(redirectTo = '/login'): boolean {
  const { status } = useAuth();
  const location = useLocation();

  if (status === 'unauthenticated') {
    // This would trigger a navigation in the component
    return false;
  }

  return status === 'authenticated';
}

export default ProtectedRoute;
