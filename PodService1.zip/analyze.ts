#!/usr/bin/env node

/**
 * Deployment Analysis & Deprecation Recommendation Engine
 * 
 * Analyzes audit results and generates actionable recommendations:
 * - KEEP: Healthy, production-ready deployments
 * - MIGRATE: Personal account deployments (bus factor risk)
 * - DEPRECATE: Slow, degraded, or redundant instances
 * - REVIEW: Requires human decision (edge cases)
 */

import * as fs from 'fs';
import * as path from 'path';

interface Deployment {
  id: string;
  name: string;
  url: string;
  platform: string;
  purpose?: string;
  notes?: string;
}

interface AuditResult {
  id: string;
  url: string;
  status: 'alive' | 'slow' | 'degraded' | 'dead' | 'ssl-invalid' | 'error';
  responseTime: number;
  httpStatus: number | null;
  sslValid: boolean;
  error?: string;
  timestamp: string;
}

interface AnalysisReport {
  summary: {
    total: number;
    keep: number;
    migrate: number;
    deprecate: number;
    review: number;
  };
  recommendations: Recommendation[];
  platformBreakdown: Record<string, PlatformStats>;
  riskAssessment: RiskItem[];
  migrationPlan: MigrationStep[];
}

interface Recommendation {
  deployment: Deployment;
  auditResult: AuditResult;
  action: 'KEEP' | 'MIGRATE' | 'DEPRECATE' | 'REVIEW';
  reason: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  estimatedEffort: string;
  dependencies: string[];
}

interface PlatformStats {
  total: number;
  alive: number;
  slow: number;
  degraded: number;
  dead: number;
  recommendation: string;
}

interface RiskItem {
  type: 'bus-factor' | 'technical-debt' | 'security' | 'performance';
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  affectedDeployments: string[];
  mitigation: string;
}

interface MigrationStep {
  phase: number;
  name: string;
  deployments: string[];
  estimatedDuration: string;
  prerequisites: string[];
  rollbackPlan: string;
}

// Load deployments and audit results
const deploymentsPath = path.join(__dirname, '../data/deployments.json');
const auditResultsPath = path.join(__dirname, '../reports/audit-latest.json');

if (!fs.existsSync(deploymentsPath)) {
  console.error('❌ deployments.json not found. Run audit first.');
  process.exit(1);
}

if (!fs.existsSync(auditResultsPath)) {
  console.error('❌ Audit results not found. Run `npm run audit` first.');
  process.exit(1);
}

const deployments: Deployment[] = JSON.parse(fs.readFileSync(deploymentsPath, 'utf-8'));
const auditResults: AuditResult[] = JSON.parse(fs.readFileSync(auditResultsPath, 'utf-8'));

// Create lookup map for faster access
const auditMap = new Map<string, AuditResult>();
auditResults.forEach(result => auditMap.set(result.id, result));

// Analysis logic
function analyzeDeployment(deployment: Deployment): Recommendation {
  const audit = auditMap.get(deployment.id);
  
  if (!audit) {
    return {
      deployment,
      auditResult: {} as AuditResult,
      action: 'REVIEW',
      reason: 'No audit data available',
      priority: 'P2',
      estimatedEffort: '15 min',
      dependencies: []
    };
  }

  // Bus factor risk (personal accounts)
  const isPersonalAccount = deployment.notes?.includes('⚠️');
  
  // Dead or severely degraded
  if (audit.status === 'dead' || audit.status === 'error') {
    return {
      deployment,
      auditResult: audit,
      action: 'DEPRECATE',
      reason: `Deployment unreachable (${audit.status}). No active traffic.`,
      priority: 'P3',
      estimatedEffort: '5 min',
      dependencies: []
    };
  }

  // SSL invalid
  if (audit.status === 'ssl-invalid') {
    return {
      deployment,
      auditResult: audit,
      action: 'REVIEW',
      reason: 'SSL certificate invalid. May be intentional (test environment) or security issue.',
      priority: 'P1',
      estimatedEffort: '30 min',
      dependencies: ['Verify certificate provider', 'Check DNS settings']
    };
  }

  // Personal account + alive = MIGRATE
  if (isPersonalAccount && audit.status === 'alive') {
    return {
      deployment,
      auditResult: audit,
      action: 'MIGRATE',
      reason: 'Healthy deployment on personal account. Bus factor risk.',
      priority: 'P1',
      estimatedEffort: '2-4 hours',
      dependencies: ['Team account access', 'Deploy pipeline', 'DNS migration']
    };
  }

  // Degraded performance
  if (audit.status === 'degraded') {
    return {
      deployment,
      auditResult: audit,
      action: 'DEPRECATE',
      reason: `Slow response times (${audit.responseTime}ms). User impact likely.`,
      priority: 'P2',
      estimatedEffort: '1 hour',
      dependencies: ['Check for active users', 'Notify stakeholders']
    };
  }

  // Slow but functional
  if (audit.status === 'slow') {
    return {
      deployment,
      auditResult: audit,
      action: 'REVIEW',
      reason: `Slower than ideal (${audit.responseTime}ms). May need optimization or migration.`,
      priority: 'P2',
      estimatedEffort: '1-2 hours',
      dependencies: ['Performance profiling', 'Check platform limits']
    };
  }

  // Healthy deployment
  return {
    deployment,
    auditResult: audit,
    action: 'KEEP',
    reason: `Healthy deployment. Response time: ${audit.responseTime}ms. SSL valid.`,
    priority: 'P3',
    estimatedEffort: 'N/A',
    dependencies: []
  };
}

// Generate recommendations for all deployments
const recommendations = deployments.map(analyzeDeployment);

// Calculate summary statistics
const summary = {
  total: recommendations.length,
  keep: recommendations.filter(r => r.action === 'KEEP').length,
  migrate: recommendations.filter(r => r.action === 'MIGRATE').length,
  deprecate: recommendations.filter(r => r.action === 'DEPRECATE').length,
  review: recommendations.filter(r => r.action === 'REVIEW').length
};

// Platform breakdown
const platformBreakdown: Record<string, PlatformStats> = {};
deployments.forEach(deployment => {
  const platform = deployment.platform;
  if (!platformBreakdown[platform]) {
    platformBreakdown[platform] = {
      total: 0,
      alive: 0,
      slow: 0,
      degraded: 0,
      dead: 0,
      recommendation: ''
    };
  }
  
  const audit = auditMap.get(deployment.id);
  platformBreakdown[platform].total++;
  
  if (audit) {
    if (audit.status === 'alive') platformBreakdown[platform].alive++;
    if (audit.status === 'slow') platformBreakdown[platform].slow++;
    if (audit.status === 'degraded') platformBreakdown[platform].degraded++;
    if (audit.status === 'dead' || audit.status === 'error') platformBreakdown[platform].dead++;
  }
});

// Generate platform recommendations
Object.keys(platformBreakdown).forEach(platform => {
  const stats = platformBreakdown[platform];
  const healthyPercent = (stats.alive / stats.total) * 100;
  
  if (healthyPercent >= 80) {
    stats.recommendation = '✅ Stable platform. Continue using.';
  } else if (healthyPercent >= 50) {
    stats.recommendation = '⚠️ Mixed health. Review slow/degraded instances.';
  } else {
    stats.recommendation = '❌ Poor health. Consider migrating away.';
  }
});

// Risk assessment
const riskAssessment: RiskItem[] = [];

// Bus factor risk
const personalAccountDeployments = recommendations.filter(r => 
  r.deployment.notes?.includes('⚠️') && r.action === 'MIGRATE'
);

if (personalAccountDeployments.length > 0) {
  riskAssessment.push({
    type: 'bus-factor',
    severity: 'critical',
    description: `${personalAccountDeployments.length} production deployments on personal accounts. Single point of failure.`,
    affectedDeployments: personalAccountDeployments.map(r => r.deployment.name),
    mitigation: 'Migrate to team/organization accounts within 30 days.'
  });
}

// Technical debt
const slowDeployments = recommendations.filter(r => r.action === 'DEPRECATE' || r.auditResult.status === 'degraded');
if (slowDeployments.length > 5) {
  riskAssessment.push({
    type: 'technical-debt',
    severity: 'high',
    description: `${slowDeployments.length} underperforming or dead deployments. Operational overhead.`,
    affectedDeployments: slowDeployments.map(r => r.deployment.name),
    mitigation: 'Deprecate unused instances to reduce maintenance burden.'
  });
}

// Security risk (SSL issues)
const sslIssues = recommendations.filter(r => !r.auditResult.sslValid);
if (sslIssues.length > 0) {
  riskAssessment.push({
    type: 'security',
    severity: 'high',
    description: `${sslIssues.length} deployments with SSL certificate issues.`,
    affectedDeployments: sslIssues.map(r => r.deployment.name),
    mitigation: 'Fix SSL certificates or deprecate insecure deployments immediately.'
  });
}

// Migration plan
const migrationPlan: MigrationStep[] = [
  {
    phase: 1,
    name: 'Deprecate Dead Instances',
    deployments: recommendations.filter(r => r.action === 'DEPRECATE').map(r => r.deployment.name),
    estimatedDuration: '2 hours',
    prerequisites: ['Verify no active traffic', 'Export logs if needed'],
    rollbackPlan: 'N/A (read-only deprecation)'
  },
  {
    phase: 2,
    name: 'Migrate Personal Account Deployments',
    deployments: recommendations.filter(r => r.action === 'MIGRATE').map(r => r.deployment.name),
    estimatedDuration: '1-2 weeks',
    prerequisites: ['Team account setup', 'DNS control', 'Deploy pipeline'],
    rollbackPlan: 'Revert DNS to old deployment if migration fails'
  },
  {
    phase: 3,
    name: 'Review Edge Cases',
    deployments: recommendations.filter(r => r.action === 'REVIEW').map(r => r.deployment.name),
    estimatedDuration: '3-5 days',
    prerequisites: ['Stakeholder input', 'Performance profiling'],
    rollbackPlan: 'Maintain status quo if no clear decision'
  }
];

// Generate final report
const report: AnalysisReport = {
  summary,
  recommendations,
  platformBreakdown,
  riskAssessment,
  migrationPlan
};

// Save report
const reportsDir = path.join(__dirname, '../reports');
if (!fs.existsSync(reportsDir)) {
  fs.mkdirSync(reportsDir, { recursive: true });
}

const reportPath = path.join(reportsDir, `analysis-${new Date().toISOString().split('T')[0]}.json`);
fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));

// Console output
console.log('\n📊 Deployment Analysis Report\n');
console.log('Summary:');
console.log(`  Total Deployments: ${summary.total}`);
console.log(`  ✅ Keep: ${summary.keep}`);
console.log(`  🔄 Migrate: ${summary.migrate}`);
console.log(`  ❌ Deprecate: ${summary.deprecate}`);
console.log(`  👀 Review: ${summary.review}`);

console.log('\nPlatform Health:');
Object.entries(platformBreakdown).forEach(([platform, stats]) => {
  console.log(`  ${platform}: ${stats.alive}/${stats.total} healthy - ${stats.recommendation}`);
});

console.log('\nRisk Assessment:');
riskAssessment.forEach(risk => {
  const icon = risk.severity === 'critical' ? '🔴' : risk.severity === 'high' ? '🟠' : '🟡';
  console.log(`  ${icon} [${risk.severity.toUpperCase()}] ${risk.description}`);
});

console.log('\nMigration Plan:');
migrationPlan.forEach(step => {
  console.log(`  Phase ${step.phase}: ${step.name} (${step.deployments.length} deployments)`);
  console.log(`    Duration: ${step.estimatedDuration}`);
});

console.log(`\n✅ Full report saved: ${reportPath}`);
console.log('\nNext steps:');
console.log('  1. Review recommendations: npm run analyze');
console.log('  2. Export to CSV: npm run export:csv');
console.log('  3. Generate Markdown: npm run export:md');
