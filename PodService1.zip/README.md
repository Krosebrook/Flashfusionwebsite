# Deployment Health Audit System

**Purpose:** Automated testing of 40+ FlashFusion deployment URLs to determine live status, categorize by platform, and identify candidates for deprecation.

---

## Quick Start

```bash
# Install dependencies
npm install

# Run full audit
npm run audit

# Test specific platform
npm run audit:vercel
npm run audit:base44
npm run audit:replit

# Generate deprecation report
npm run deprecation-report

# Export to CSV
npm run audit:csv
```

---

## Features

- **Automated URL Testing:** Checks HTTP status, response time, SSL validity
- **Platform Categorization:** Groups by Vercel, Base44, Replit, Netlify, etc.
- **Smart Analysis:** Identifies duplicates, stale deployments, unique features
- **Deprecation Recommendations:** Suggests which URLs to keep/remove
- **Export Options:** JSON, CSV, Markdown reports

---

## Project Structure

```
deployment-audit/
├── README.md
├── package.json
├── tsconfig.json
├── data/
│   └── deployments.json          # 40+ deployment URLs
├── scripts/
│   ├── audit.ts                  # Main audit script
│   ├── analyze.ts                # Analysis and recommendations
│   └── export.ts                 # Report generation
└── reports/
    ├── audit-YYYYMMDD-HHMMSS.json
    ├── audit-YYYYMMDD-HHMMSS.csv
    └── deprecation-plan.md
```

---

## Deployment Data Format

The `data/deployments.json` file contains all known FlashFusion deployment URLs:

```json
{
  "deployments": [
    {
      "id": "vercel-genesis",
      "name": "FlashFusion Genesis",
      "url": "https://flashfusion-genesis.vercel.app",
      "platform": "vercel",
      "purpose": "primary",
      "notes": "Main production instance"
    },
    {
      "id": "base44-flash-fusion",
      "name": "Flash Fusion",
      "url": "https://flash-fusion-4e98fe60.base44.app",
      "platform": "base44",
      "purpose": "testing",
      "notes": "Base44 hosting experiment"
    }
  ]
}
```

---

## Audit Results

Each audit produces a structured report:

```json
{
  "timestamp": "2025-11-22T14:30:00Z",
  "summary": {
    "total": 42,
    "alive": 28,
    "dead": 14,
    "slow": 5,
    "platforms": {
      "vercel": 7,
      "base44": 7,
      "replit": 6,
      "netlify": 4
    }
  },
  "results": [
    {
      "id": "vercel-genesis",
      "url": "https://flashfusion-genesis.vercel.app",
      "status": "alive",
      "httpStatus": 200,
      "responseTime": 245,
      "sslValid": true,
      "lastModified": "2025-11-20T10:00:00Z",
      "recommendation": "KEEP - Primary instance"
    }
  ]
}
```

---

## Health Status Definitions

- **alive:** HTTP 200, response < 3s
- **slow:** HTTP 200, response 3-10s
- **degraded:** HTTP 200, response > 10s
- **dead:** HTTP 4xx/5xx or timeout
- **ssl-invalid:** Certificate expired or invalid

---

## Deprecation Criteria

**KEEP if:**
- Primary production instance
- Unique feature set not replicated elsewhere
- Recent deployment (< 30 days)
- Active user traffic detected

**DEPRECATE if:**
- Duplicate of another instance
- HTTP error status
- Not accessed in > 90 days
- Platform is sunset (e.g., discontinued service)

---

## Running the Audit

### Full Audit (All Platforms)

```bash
npm run audit
```

**Output:**
```
🔍 FlashFusion Deployment Health Audit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Testing 42 deployments...

Vercel (7)
  ✅ flashfusion-genesis.vercel.app (245ms)
  ✅ int-smart-triage-ai-2-0.vercel.app (312ms)
  ⚠️  v0-template-evaluation-academy.vercel.app (4.5s - SLOW)
  ❌ old-instance.vercel.app (404 Not Found)

Base44 (7)
  ✅ flash-fusion-4e98fe60.base44.app (198ms)
  ✅ archon-orchestrator.base44.app (221ms)
  ❌ deprecated-instance.base44.app (Connection timeout)

[... continues for all platforms ...]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total:     42 deployments
Alive:     28 (67%)
Dead:      14 (33%)
Slow:       5 (12%)
SSL Issues: 2 (5%)

Recommendation: Deprecate 31 deployments, keep 11
```

### Platform-Specific Audit

```bash
# Test only Vercel deployments
npm run audit:vercel

# Test only Base44 deployments
npm run audit:base44
```

### Generate Deprecation Plan

```bash
npm run deprecation-report
```

**Output:** `reports/deprecation-plan.md` with detailed recommendations

---

## Automation & CI/CD

Run audits automatically via GitHub Actions:

```yaml
# .github/workflows/deployment-audit.yml
name: Deployment Health Audit

on:
  schedule:
    - cron: '0 0 * * 0'  # Weekly on Sunday
  workflow_dispatch:

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm install
      - run: npm run audit
      - uses: actions/upload-artifact@v3
        with:
          name: audit-report
          path: reports/
```

---

## Next Steps

After audit is complete:

1. **Review deprecation plan** in `reports/deprecation-plan.md`
2. **Mark dead deployments** for removal
3. **Archive unique features** from specialized instances
4. **Consolidate to primary URL** (flashfusion.vercel.app)
5. **Update DNS records** if custom domains are affected
6. **Notify users** if public-facing URLs are changing

---

## Troubleshooting

### Error: "ETIMEDOUT"
**Cause:** Deployment is down or blocked by firewall  
**Fix:** Mark as dead, candidate for deprecation

### Error: "CERT_HAS_EXPIRED"
**Cause:** SSL certificate expired  
**Fix:** Renew certificate or mark for deprecation

### Error: "ENOTFOUND"
**Cause:** DNS record doesn't exist  
**Fix:** URL is stale, remove from tracking

---

## Support

For questions about specific deployments, check:
- Vercel Dashboard: https://vercel.com/dashboard
- Base44 Console: https://base44.io
- Replit Projects: https://replit.com/~

**Estimated Audit Time:** 5-10 minutes for 42 deployments
