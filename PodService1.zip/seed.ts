/**
 * Seed Script
 * Populates database with sample data for testing and demo purposes
 */

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

const adminClient = createClient(supabaseUrl, serviceRoleKey);

const SAMPLE_USERS = [
  {
    email: 'demo@flashfusion.dev',
    password: 'demo-password-123',
    display_name: 'Demo User',
    avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demo'
  },
  {
    email: 'sarah@indie.dev',
    password: 'sarah-password-456',
    display_name: 'Sarah Chen',
    avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah'
  },
  {
    email: 'alex@agency.com',
    password: 'alex-password-789',
    display_name: 'Alex Martinez',
    avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex'
  }
];

const SAMPLE_GENERATIONS = [
  {
    app_name: 'TaskMaster Pro',
    platform: 'web' as const,
    framework: 'nextjs' as const,
    config: {
      features: ['auth', 'database', 'realtime'],
      styling: 'tailwind',
      auth: 'supabase',
      database: 'supabase'
    },
    status: 'complete' as const,
    progress: 100,
    download_url: 'https://storage.example.com/taskmaster-pro.zip',
    cost_estimate: { vercel: 20, supabase: 25, total: 45 }
  },
  {
    app_name: 'Fitness Tracker',
    platform: 'mobile' as const,
    framework: 'react-native' as const,
    config: {
      features: ['auth', 'database', 'push-notifications'],
      styling: 'native',
      auth: 'firebase',
      database: 'firebase'
    },
    status: 'complete' as const,
    progress: 100,
    download_url: 'https://storage.example.com/fitness-tracker.zip',
    cost_estimate: { firebase: 30, total: 30 }
  },
  {
    app_name: 'Invoice Generator',
    platform: 'web' as const,
    framework: 'react' as const,
    config: {
      features: ['auth', 'database', 'pdf-export'],
      styling: 'mui',
      auth: 'auth0',
      database: 'postgres'
    },
    status: 'generating' as const,
    progress: 65,
    logs: [
      '[2025-11-22 10:15:30] Starting generation...',
      '[2025-11-22 10:15:45] Scaffold created',
      '[2025-11-22 10:16:20] Installing dependencies...'
    ]
  },
  {
    app_name: 'Chat App',
    platform: 'web' as const,
    framework: 'nextjs' as const,
    config: {
      features: ['auth', 'realtime', 'file-upload'],
      styling: 'shadcn',
      auth: 'supabase',
      database: 'supabase'
    },
    status: 'error' as const,
    progress: 45,
    error_message: 'Build failed: Missing environment variable SUPABASE_URL',
    logs: [
      '[2025-11-22 11:20:10] Starting generation...',
      '[2025-11-22 11:20:25] Scaffold created',
      '[2025-11-22 11:21:05] ERROR: Missing SUPABASE_URL'
    ]
  }
];

const PLATFORMS = ['vercel', 'base44', 'netlify', 'replit'] as const;

async function seed() {
  console.log('🌱 Starting database seeding...\n');

  try {
    // Create sample users
    console.log('👥 Creating sample users...');
    const userIds: string[] = [];

    for (const user of SAMPLE_USERS) {
      const { data, error } = await adminClient.auth.admin.createUser({
        email: user.email,
        password: user.password,
        email_confirm: true,
        user_metadata: {
          display_name: user.display_name,
          avatar_url: user.avatar_url
        }
      });

      if (error) {
        console.error(`   ❌ Failed to create ${user.email}:`, error.message);
      } else {
        userIds.push(data.user.id);
        console.log(`   ✅ Created ${user.email}`);
      }
    }

    console.log(`\n📱 Creating ${SAMPLE_GENERATIONS.length} sample app generations...\n`);

    for (let i = 0; i < SAMPLE_GENERATIONS.length; i++) {
      const gen = SAMPLE_GENERATIONS[i];
      const userId = userIds[i % userIds.length]; // Distribute across users

      const { data: generationData, error: genError } = await adminClient
        .from('app_generations')
        .insert({
          user_id: userId,
          ...gen
        })
        .select()
        .single();

      if (genError) {
        console.error(`   ❌ Failed to create "${gen.app_name}":`, genError.message);
        continue;
      }

      console.log(`   ✅ Created "${gen.app_name}" (${gen.status})`);

      // Add deployments for completed apps
      if (gen.status === 'complete' && generationData) {
        const platform = PLATFORMS[i % PLATFORMS.length];
        const url = `https://${gen.app_name.toLowerCase().replace(/\s+/g, '-')}.${platform}.app`;

        const { error: deployError } = await adminClient
          .from('deployments')
          .insert({
            app_generation_id: generationData.id,
            platform,
            url,
            status: 'active',
            last_verified: new Date().toISOString()
          });

        if (deployError) {
          console.error(`      ❌ Failed to create deployment:`, deployError.message);
        } else {
          console.log(`      📦 Deployed to ${platform}: ${url}`);
        }
      }
    }

    // Print summary
    console.log('\n═══════════════════════════════════════════════════');
    console.log('                  SEEDING COMPLETE                  ');
    console.log('═══════════════════════════════════════════════════\n');

    console.log('📊 Summary:');
    console.log(`   - ${userIds.length} users created`);
    console.log(`   - ${SAMPLE_GENERATIONS.length} app generations created`);
    console.log(`   - ${SAMPLE_GENERATIONS.filter(g => g.status === 'complete').length} deployments created`);

    console.log('\n🔑 Test Credentials:');
    SAMPLE_USERS.forEach(user => {
      console.log(`   - ${user.email} / ${user.password}`);
    });

    console.log('\n✨ You can now test the application with these accounts!\n');
    process.exit(0);

  } catch (error) {
    console.error('\n❌ Seeding failed:', error);
    process.exit(1);
  }
}

seed();
