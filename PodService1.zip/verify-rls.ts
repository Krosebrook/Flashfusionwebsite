/**
 * RLS Verification Script
 * Tests that Row Level Security policies are properly configured
 */

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Admin client (bypasses RLS)
const adminClient = createClient(supabaseUrl, serviceRoleKey);

interface TestResult {
  test: string;
  passed: boolean;
  message: string;
}

const results: TestResult[] = [];

async function runTest(test: string, fn: () => Promise<boolean>, expectedMessage: string) {
  try {
    const passed = await fn();
    results.push({ test, passed, message: passed ? '✓ PASS' : `✗ FAIL: ${expectedMessage}` });
  } catch (error) {
    results.push({ 
      test, 
      passed: false, 
      message: `✗ ERROR: ${error instanceof Error ? error.message : String(error)}` 
    });
  }
}

async function verifyRLS() {
  console.log('🔒 Starting RLS Verification...\n');

  // Create test users
  console.log('📝 Creating test users...');
  const { data: user1, error: user1Error } = await adminClient.auth.admin.createUser({
    email: 'test1@flashfusion.dev',
    password: 'test-password-123',
    email_confirm: true
  });

  const { data: user2, error: user2Error } = await adminClient.auth.admin.createUser({
    email: 'test2@flashfusion.dev',
    password: 'test-password-456',
    email_confirm: true
  });

  if (user1Error || user2Error || !user1?.user || !user2?.user) {
    console.error('❌ Failed to create test users');
    return;
  }

  console.log('✅ Test users created\n');

  // Get authenticated clients for each user
  const { data: session1 } = await adminClient.auth.signInWithPassword({
    email: 'test1@flashfusion.dev',
    password: 'test-password-123'
  });

  const { data: session2 } = await adminClient.auth.signInWithPassword({
    email: 'test2@flashfusion.dev',
    password: 'test-password-456'
  });

  if (!session1?.session || !session2?.session) {
    console.error('❌ Failed to authenticate test users');
    return;
  }

  const client1 = createClient(supabaseUrl, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    global: { headers: { Authorization: `Bearer ${session1.session.access_token}` } }
  });

  const client2 = createClient(supabaseUrl, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    global: { headers: { Authorization: `Bearer ${session2.session.access_token}` } }
  });

  // Test 1: Users can read their own profile
  await runTest(
    'User can read their own profile',
    async () => {
      const { data, error } = await client1
        .from('user_profiles')
        .select('*')
        .eq('id', user1.user.id)
        .single();
      return !error && data !== null;
    },
    'User should be able to read their own profile'
  );

  // Test 2: Users cannot read other users' profiles
  await runTest(
    'User cannot read other users profiles',
    async () => {
      const { data, error } = await client1
        .from('user_profiles')
        .select('*')
        .eq('id', user2.user.id)
        .single();
      return data === null || error !== null;
    },
    'User should NOT be able to read other profiles'
  );

  // Test 3: Users can create their own app_generations
  await runTest(
    'User can create their own generation',
    async () => {
      const { data, error } = await client1
        .from('app_generations')
        .insert({
          user_id: user1.user.id,
          app_name: 'Test App 1',
          platform: 'web',
          framework: 'nextjs',
          config: { features: ['auth', 'database'] }
        })
        .select()
        .single();
      return !error && data !== null;
    },
    'User should be able to create their own generation'
  );

  // Test 4: Users cannot create generations for other users
  await runTest(
    'User cannot create generation for other user',
    async () => {
      const { error } = await client1
        .from('app_generations')
        .insert({
          user_id: user2.user.id, // Trying to create for user2
          app_name: 'Malicious App',
          platform: 'web',
          framework: 'nextjs',
          config: { features: [] }
        });
      return error !== null;
    },
    'User should NOT be able to create generation for other users'
  );

  // Test 5: Users can only view their own generations
  await runTest(
    'User can only view their own generations',
    async () => {
      const { data, error } = await client1
        .from('app_generations')
        .select('*');
      
      if (error || !data) return false;
      
      // All returned generations should belong to user1
      return data.every(gen => gen.user_id === user1.user.id);
    },
    'User should only see their own generations'
  );

  // Test 6: Anonymous users cannot access any data
  const anonClient = createClient(supabaseUrl, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
  
  await runTest(
    'Anonymous user cannot read profiles',
    async () => {
      const { data, error } = await anonClient
        .from('user_profiles')
        .select('*');
      return error !== null || (data && data.length === 0);
    },
    'Anonymous users should NOT access profiles'
  );

  await runTest(
    'Anonymous user cannot read generations',
    async () => {
      const { data, error } = await anonClient
        .from('app_generations')
        .select('*');
      return error !== null || (data && data.length === 0);
    },
    'Anonymous users should NOT access generations'
  );

  // Cleanup
  console.log('\n🧹 Cleaning up test users...');
  await adminClient.auth.admin.deleteUser(user1.user.id);
  await adminClient.auth.admin.deleteUser(user2.user.id);
  console.log('✅ Cleanup complete\n');

  // Print results
  console.log('═══════════════════════════════════════════════════');
  console.log('                  RLS TEST RESULTS                  ');
  console.log('═══════════════════════════════════════════════════\n');

  results.forEach(({ test, passed, message }) => {
    console.log(`${passed ? '✅' : '❌'} ${test}`);
    console.log(`   ${message}\n`);
  });

  const passedTests = results.filter(r => r.passed).length;
  const totalTests = results.length;
  const passRate = Math.round((passedTests / totalTests) * 100);

  console.log('═══════════════════════════════════════════════════');
  console.log(`SUMMARY: ${passedTests}/${totalTests} tests passed (${passRate}%)`);
  console.log('═══════════════════════════════════════════════════\n');

  if (passedTests === totalTests) {
    console.log('🎉 All RLS policies are working correctly!');
    process.exit(0);
  } else {
    console.error('⚠️  Some RLS policies need attention');
    process.exit(1);
  }
}

verifyRLS().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});
