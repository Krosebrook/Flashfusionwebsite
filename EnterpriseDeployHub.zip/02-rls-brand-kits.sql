-- ============================================
-- RLS POLICIES FOR BRAND_KITS TABLE
-- ============================================
-- Purpose: Enforce creator_id isolation for brand kits
-- Run this in Supabase SQL Editor
-- Expected time: <1 second
-- ============================================

-- Step 1: Enable RLS on brand_kits table
ALTER TABLE brand_kits ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop existing policies (if any) to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own brand kits" ON brand_kits;
DROP POLICY IF EXISTS "Users can create their own brand kits" ON brand_kits;
DROP POLICY IF EXISTS "Users can update their own brand kits" ON brand_kits;
DROP POLICY IF EXISTS "Users can delete their own brand kits" ON brand_kits;

-- Step 3: Create SELECT policy (read own brand kits)
CREATE POLICY "Users can view their own brand kits"
  ON brand_kits
  FOR SELECT
  USING (auth.uid() = creator_id);

-- Step 4: Create INSERT policy (create own brand kits)
CREATE POLICY "Users can create their own brand kits"
  ON brand_kits
  FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

-- Step 5: Create UPDATE policy (modify own brand kits)
CREATE POLICY "Users can update their own brand kits"
  ON brand_kits
  FOR UPDATE
  USING (auth.uid() = creator_id)
  WITH CHECK (auth.uid() = creator_id);

-- Step 6: Create DELETE policy (delete own brand kits)
CREATE POLICY "Users can delete their own brand kits"
  ON brand_kits
  FOR DELETE
  USING (auth.uid() = creator_id);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Verify RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE tablename = 'brand_kits' AND schemaname = 'public';
-- Expected: rowsecurity = true

-- List all policies on brand_kits
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'brand_kits';
-- Expected: 4 policies (SELECT, INSERT, UPDATE, DELETE)

-- ============================================
-- CROSS-TENANT ISOLATION TEST
-- ============================================
-- WARNING: This test requires TWO real user accounts
-- Replace <user1_uuid> and <user2_uuid> with actual UUIDs
-- ============================================

-- As User 1: Create a brand kit
-- SET ROLE authenticated;
-- SET request.jwt.claims.sub = '<user1_uuid>';
-- INSERT INTO brand_kits (id, creator_id, name, colors, fonts, personality)
-- VALUES (
--   gen_random_uuid(),
--   '<user1_uuid>',
--   'Test Brand 1',
--   '{"primary": "#FF0000"}'::jsonb,
--   '{"heading": "Arial"}'::jsonb,
--   ARRAY['modern', 'bold', 'energetic']
-- );

-- As User 2: Try to read User 1's brand kit (should return 0 rows)
-- SET request.jwt.claims.sub = '<user2_uuid>';
-- SELECT * FROM brand_kits WHERE creator_id = '<user1_uuid>';
-- Expected: 0 rows (RLS blocks cross-tenant access)

-- As User 2: Try to update User 1's brand kit (should fail)
-- UPDATE brand_kits 
-- SET name = 'Hacked!' 
-- WHERE creator_id = '<user1_uuid>';
-- Expected: 0 rows updated (RLS blocks cross-tenant modification)

-- Cleanup
-- DELETE FROM brand_kits WHERE name = 'Test Brand 1';

-- ============================================
-- SUCCESS CRITERIA
-- ============================================
-- ✅ RLS enabled: rowsecurity = true
-- ✅ 4 policies created: SELECT, INSERT, UPDATE, DELETE
-- ✅ All policies enforce: auth.uid() = creator_id
-- ✅ Cross-tenant test: User 2 cannot access User 1's data
-- ============================================
