-- ============================================
-- RLS AUDIT SCRIPT
-- ============================================
-- Purpose: Check which tables have RLS enabled/disabled
-- Run this in Supabase SQL Editor
-- Expected time: <5 seconds
-- ============================================

-- Show all tables with their RLS status
SELECT 
  schemaname,
  tablename,
  rowsecurity AS rls_enabled,
  CASE 
    WHEN rowsecurity THEN '✅ RLS Enabled'
    ELSE '❌ RLS Disabled'
  END AS status
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY 
  rowsecurity DESC,
  tablename ASC;

-- ============================================
-- EXPECTED OUTPUT
-- ============================================
-- Tables WITH RLS: brand_kits, templates, orders, etc.
-- Tables WITHOUT RLS: Should be NONE (all public tables need RLS)
-- ============================================

-- Count summary
SELECT 
  COUNT(*) FILTER (WHERE rowsecurity = true) AS tables_with_rls,
  COUNT(*) FILTER (WHERE rowsecurity = false) AS tables_without_rls,
  COUNT(*) AS total_tables
FROM pg_tables
WHERE schemaname = 'public';

-- ============================================
-- ACTION ITEMS
-- ============================================
-- If tables_without_rls > 0:
-- 1. Review each table without RLS
-- 2. Determine if it contains user data
-- 3. If yes: Enable RLS + create policies (see other scripts)
-- 4. If no: Document why RLS is not needed
-- ============================================
