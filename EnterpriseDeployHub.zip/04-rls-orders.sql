-- ============================================
-- RLS POLICIES FOR ORDERS TABLE
-- ============================================
-- Purpose: Enforce creator_id isolation for orders
-- Run this in Supabase SQL Editor
-- Expected time: <1 second
-- ============================================

-- Step 1: Enable RLS on orders table
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop existing policies (if any) to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own orders" ON orders;
DROP POLICY IF EXISTS "Users can create their own orders" ON orders;
DROP POLICY IF EXISTS "Users can update their own orders" ON orders;
DROP POLICY IF EXISTS "Users can delete their own orders" ON orders;

-- Step 3: Create SELECT policy (read own orders)
CREATE POLICY "Users can view their own orders"
  ON orders
  FOR SELECT
  USING (auth.uid() = creator_id);

-- Step 4: Create INSERT policy (create own orders)
CREATE POLICY "Users can create their own orders"
  ON orders
  FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

-- Step 5: Create UPDATE policy (modify own orders)
-- NOTE: Consider restricting UPDATE to only certain columns (e.g., status)
-- or only allowing updates when status is 'draft' to prevent tampering
CREATE POLICY "Users can update their own orders"
  ON orders
  FOR UPDATE
  USING (auth.uid() = creator_id)
  WITH CHECK (auth.uid() = creator_id);

-- Step 6: Create DELETE policy (delete own orders)
-- NOTE: Consider restricting DELETE to only 'draft' orders
-- or disabling DELETE entirely (use soft delete instead)
CREATE POLICY "Users can delete their own orders"
  ON orders
  FOR DELETE
  USING (auth.uid() = creator_id);

-- ============================================
-- OPTIONAL: ADMIN POLICIES
-- ============================================
-- If you have admin users who need to view all orders:
-- Uncomment and adjust the following:

-- CREATE POLICY "Admins can view all orders"
--   ON orders
--   FOR SELECT
--   USING (
--     EXISTS (
--       SELECT 1 FROM user_roles 
--       WHERE user_id = auth.uid() 
--       AND role = 'admin'
--     )
--   );

-- ============================================
-- OPTIONAL: WEBHOOK POLICIES
-- ============================================
-- If Stripe/Printify webhooks need to update orders:
-- Create a service role key and use it for webhook handlers
-- DO NOT create permissive policies for webhooks
-- Instead, use service_role key which bypasses RLS

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Verify RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE tablename = 'orders' AND schemaname = 'public';
-- Expected: rowsecurity = true

-- List all policies on orders
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'orders';
-- Expected: 4 policies (SELECT, INSERT, UPDATE, DELETE)

-- ============================================
-- CROSS-TENANT ISOLATION TEST
-- ============================================
-- Same test pattern as brand_kits (see 02-rls-brand-kits.sql)
-- Replace <user1_uuid> and <user2_uuid> with actual UUIDs
-- ============================================

-- As User 1: Create an order
-- SET request.jwt.claims.sub = '<user1_uuid>';
-- INSERT INTO orders (id, creator_id, status, total_amount, stripe_payment_intent_id)
-- VALUES (
--   gen_random_uuid(),
--   '<user1_uuid>',
--   'pending',
--   2999, -- $29.99 in cents
--   'pi_test_12345'
-- );

-- As User 2: Try to read User 1's order (should return 0 rows)
-- SET request.jwt.claims.sub = '<user2_uuid>';
-- SELECT * FROM orders WHERE creator_id = '<user1_uuid>';
-- Expected: 0 rows (RLS blocks cross-tenant access)

-- As User 2: Try to update User 1's order (should fail)
-- UPDATE orders 
-- SET total_amount = 0 
-- WHERE creator_id = '<user1_uuid>';
-- Expected: 0 rows updated (RLS blocks cross-tenant modification)

-- ============================================
-- SUCCESS CRITERIA
-- ============================================
-- ✅ RLS enabled: rowsecurity = true
-- ✅ 4 policies created: SELECT, INSERT, UPDATE, DELETE
-- ✅ All policies enforce: auth.uid() = creator_id
-- ✅ Cross-tenant test: User 2 cannot access User 1's data
-- ============================================

-- ============================================
-- SECURITY CONSIDERATIONS
-- ============================================
-- 1. Consider restricting UPDATE to only draft orders:
--    USING (auth.uid() = creator_id AND status = 'draft')
--
-- 2. Consider soft deletes instead of hard deletes:
--    Add 'deleted_at' column, use UPDATE instead of DELETE
--
-- 3. Webhook handlers should use service_role key (bypasses RLS)
--    Never create permissive policies for webhooks
--
-- 4. Log all order modifications for audit trail:
--    Consider adding trigger to log changes to audit table
-- ============================================
