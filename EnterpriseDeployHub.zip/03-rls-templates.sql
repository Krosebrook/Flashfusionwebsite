-- ============================================
-- RLS POLICIES FOR TEMPLATES TABLE
-- ============================================
-- Purpose: Enforce creator_id isolation for templates
-- Run this in Supabase SQL Editor
-- Expected time: <1 second
-- ============================================

-- Step 1: Enable RLS on templates table
ALTER TABLE templates ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop existing policies (if any) to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own templates" ON templates;
DROP POLICY IF EXISTS "Users can create their own templates" ON templates;
DROP POLICY IF EXISTS "Users can update their own templates" ON templates;
DROP POLICY IF EXISTS "Users can delete their own templates" ON templates;

-- Step 3: Create SELECT policy (read own templates)
CREATE POLICY "Users can view their own templates"
  ON templates
  FOR SELECT
  USING (auth.uid() = creator_id);

-- Step 4: Create INSERT policy (create own templates)
CREATE POLICY "Users can create their own templates"
  ON templates
  FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

-- Step 5: Create UPDATE policy (modify own templates)
CREATE POLICY "Users can update their own templates"
  ON templates
  FOR UPDATE
  USING (auth.uid() = creator_id)
  WITH CHECK (auth.uid() = creator_id);

-- Step 6: Create DELETE policy (delete own templates)
CREATE POLICY "Users can delete their own templates"
  ON templates
  FOR DELETE
  USING (auth.uid() = creator_id);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Verify RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE tablename = 'templates' AND schemaname = 'public';
-- Expected: rowsecurity = true

-- List all policies on templates
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'templates';
-- Expected: 4 policies (SELECT, INSERT, UPDATE, DELETE)

-- ============================================
-- CROSS-TENANT ISOLATION TEST
-- ============================================
-- Same test pattern as brand_kits (see 02-rls-brand-kits.sql)
-- Replace <user1_uuid> and <user2_uuid> with actual UUIDs
-- ============================================

-- As User 1: Create a template
-- SET request.jwt.claims.sub = '<user1_uuid>';
-- INSERT INTO templates (id, creator_id, brand_kit_id, template_type, design_data)
-- VALUES (
--   gen_random_uuid(),
--   '<user1_uuid>',
--   '<existing_brand_kit_id>',
--   'social_media',
--   '{"width": 1080, "height": 1080}'::jsonb
-- );

-- As User 2: Try to read User 1's template (should return 0 rows)
-- SET request.jwt.claims.sub = '<user2_uuid>';
-- SELECT * FROM templates WHERE creator_id = '<user1_uuid>';
-- Expected: 0 rows (RLS blocks cross-tenant access)

-- ============================================
-- SUCCESS CRITERIA
-- ============================================
-- ✅ RLS enabled: rowsecurity = true
-- ✅ 4 policies created: SELECT, INSERT, UPDATE, DELETE
-- ✅ All policies enforce: auth.uid() = creator_id
-- ✅ Cross-tenant test: User 2 cannot access User 1's data
-- ============================================
