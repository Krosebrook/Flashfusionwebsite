import { z } from 'zod';

/**
 * FlashFusion AI Safety Layer
 * 
 * 6-Layer Defense Strategy:
 * 1. Input Validation (this file)
 * 2. Prompt Structure (separate instructions from data)
 * 3. Output Validation (this file)
 * 4. External Monitoring (Sentry + custom logging)
 * 5. Rate Limiting (per-user caps)
 * 6. Human Oversight (review queue for high-risk)
 * 
 * OWASP LLM01: Prompt Injection Defense
 */

// ============================================================================
// LAYER 1: INPUT VALIDATION
// ============================================================================

/**
 * Validates user input before sending to AI
 * Detects common prompt injection patterns
 * 
 * @param input - Raw user input for brand generation
 * @returns Validation result with sanitized output
 */
export function validateBrandInput(input: string): { 
  valid: boolean; 
  sanitized: string; 
  error?: string;
  risk_level?: 'low' | 'medium' | 'high';
} {
  // Length check (prevent DoS via massive inputs)
  if (input.length > 500) {
    return { 
      valid: false, 
      sanitized: '', 
      error: 'Input too long (max 500 chars)',
      risk_level: 'medium'
    };
  }

  // Minimum viable input
  if (input.trim().length < 3) {
    return {
      valid: false,
      sanitized: '',
      error: 'Input too short (min 3 chars)',
      risk_level: 'low'
    };
  }

  // Prompt injection patterns (OWASP LLM01)
  const injectionPatterns = [
    { pattern: /ignore previous instructions/i, severity: 'high' },
    { pattern: /system prompt/i, severity: 'high' },
    { pattern: /you are now/i, severity: 'high' },
    { pattern: /forget (all|everything)/i, severity: 'high' },
    { pattern: /disregard (all|previous)/i, severity: 'high' },
    { pattern: /<script[^>]*>/i, severity: 'high' },
    { pattern: /javascript:/i, severity: 'medium' },
    { pattern: /on(load|error|click)=/i, severity: 'medium' },
    { pattern: /exec\s*\(/i, severity: 'high' },
    { pattern: /eval\s*\(/i, severity: 'high' },
  ];

  for (const { pattern, severity } of injectionPatterns) {
    if (pattern.test(input)) {
      return { 
        valid: false, 
        sanitized: '', 
        error: `Disallowed pattern detected: ${pattern.source}`,
        risk_level: severity as 'high' | 'medium'
      };
    }
  }

  // Sanitize: Remove dangerous characters
  const sanitized = input
    .replace(/[<>{}]/g, '') // HTML/template injection
    .replace(/[\u0000-\u001F\u007F-\u009F]/g, '') // Control characters
    .trim();

  return { 
    valid: true, 
    sanitized,
    risk_level: 'low'
  };
}

// ============================================================================
// LAYER 3: OUTPUT VALIDATION
// ============================================================================

/**
 * Brand Kit Output Schema
 * Enforces strict structure on AI-generated brand kits
 */
const BrandKitSchema = z.object({
  colors: z.array(
    z.string()
      .regex(/^#[0-9A-Fa-f]{6}$/, 'Invalid hex color format')
  ).min(3, 'Minimum 3 colors required')
    .max(10, 'Maximum 10 colors allowed'),
  
  fonts: z.array(
    z.object({
      heading: z.string()
        .min(1, 'Heading font name required')
        .max(50, 'Font name too long')
        .regex(/^[a-zA-Z0-9\s\-]+$/, 'Invalid font name characters'),
      body: z.string()
        .min(1, 'Body font name required')
        .max(50, 'Font name too long')
        .regex(/^[a-zA-Z0-9\s\-]+$/, 'Invalid font name characters'),
    })
  ).min(1, 'At least one font pair required')
    .max(5, 'Maximum 5 font pairs allowed'),
  
  personality: z.array(
    z.string()
      .min(1, 'Personality trait required')
      .max(50, 'Personality trait too long')
      .regex(/^[a-zA-Z0-9\s\-]+$/, 'Invalid personality trait characters')
  ).min(3, 'Minimum 3 personality traits required')
    .max(10, 'Maximum 10 personality traits allowed'),
  
  // Optional fields
  logo_style: z.string()
    .max(100, 'Logo style description too long')
    .optional(),
  
  tone_of_voice: z.string()
    .max(200, 'Tone of voice description too long')
    .optional(),
});

export type BrandKit = z.infer<typeof BrandKitSchema>;

/**
 * Validates AI-generated brand kit output
 * Ensures output conforms to expected schema
 * 
 * @param output - Raw output from AI
 * @returns Validation result with parsed data
 */
export function validateBrandKitOutput(output: unknown): { 
  valid: boolean; 
  data?: BrandKit; 
  error?: string;
  errors?: z.ZodIssue[];
} {
  try {
    const parsed = BrandKitSchema.parse(output);
    return { valid: true, data: parsed };
  } catch (err) {
    if (err instanceof z.ZodError) {
      return { 
        valid: false, 
        error: 'Schema validation failed',
        errors: err.errors
      };
    }
    return { 
      valid: false, 
      error: err instanceof Error ? err.message : 'Unknown validation error'
    };
  }
}

// ============================================================================
// LAYER 4: RATE LIMITING (Per-User)
// ============================================================================

/**
 * Simple in-memory rate limiter
 * Production: Use Redis/Upstash for distributed rate limiting
 */
const requestCounts = new Map<string, { count: number; resetAt: number }>();

/**
 * Checks if user has exceeded rate limit
 * 
 * @param userId - User ID
 * @param limit - Maximum requests per window
 * @param windowMs - Time window in milliseconds
 * @returns Whether request is allowed
 */
export function checkRateLimit(
  userId: string, 
  limit: number = 10, 
  windowMs: number = 60000
): { allowed: boolean; remaining: number; resetIn: number } {
  const now = Date.now();
  const userLimit = requestCounts.get(userId);

  // First request or window expired
  if (!userLimit || now > userLimit.resetAt) {
    requestCounts.set(userId, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, resetIn: windowMs };
  }

  // Within window
  if (userLimit.count < limit) {
    userLimit.count++;
    return { 
      allowed: true, 
      remaining: limit - userLimit.count, 
      resetIn: userLimit.resetAt - now 
    };
  }

  // Exceeded limit
  return { 
    allowed: false, 
    remaining: 0, 
    resetIn: userLimit.resetAt - now 
  };
}

// ============================================================================
// LAYER 6: HUMAN OVERSIGHT FLAGS
// ============================================================================

/**
 * Determines if brand kit requires human review
 * 
 * @param brandKit - Generated brand kit
 * @param creatorMetadata - Creator account metadata
 * @returns Whether human review is required
 */
export function requiresHumanReview(
  brandKit: BrandKit,
  creatorMetadata: {
    publishCount: number;
    accountAgeInDays: number;
    previousReports: number;
  }
): { required: boolean; reason?: string } {
  // New creators (first 10 publishes)
  if (creatorMetadata.publishCount < 10) {
    return { required: true, reason: 'New creator (<10 publishes)' };
  }

  // Recently created accounts (< 7 days)
  if (creatorMetadata.accountAgeInDays < 7) {
    return { required: true, reason: 'New account (<7 days old)' };
  }

  // Creators with previous reports
  if (creatorMetadata.previousReports > 0) {
    return { required: true, reason: 'Previous reports on record' };
  }

  // Suspicious patterns in output
  const allText = [
    ...brandKit.personality,
    brandKit.logo_style,
    brandKit.tone_of_voice,
  ].filter(Boolean).join(' ').toLowerCase();

  const suspiciousTerms = [
    'illegal', 'weapon', 'drug', 'hack', 'crack', 
    'pirate', 'torrent', 'porn', 'xxx'
  ];

  for (const term of suspiciousTerms) {
    if (allText.includes(term)) {
      return { required: true, reason: `Suspicious term detected: ${term}` };
    }
  }

  return { required: false };
}

// ============================================================================
// EXPORTS
// ============================================================================

export default {
  validateBrandInput,
  validateBrandKitOutput,
  checkRateLimit,
  requiresHumanReview,
};
