import { Kysely, PostgresDialect } from 'kysely';
import { Pool } from 'pg';
import type { Database } from './types';

// Export all types
export * from './types';

// ============================================
// DATABASE CONNECTION
// ============================================

let db: Kysely<Database> | null = null;

export interface DatabaseConfig {
  connectionString?: string;
  host?: string;
  port?: number;
  database?: string;
  user?: string;
  password?: string;
  ssl?: boolean | { rejectUnauthorized: boolean };
  max?: number; // Max pool size
  idleTimeoutMillis?: number;
  connectionTimeoutMillis?: number;
}

/**
 * Create a new database connection
 */
export function createDatabase(config: DatabaseConfig): Kysely<Database> {
  const pool = new Pool({
    connectionString: config.connectionString,
    host: config.host,
    port: config.port,
    database: config.database,
    user: config.user,
    password: config.password,
    ssl: config.ssl,
    max: config.max ?? 10,
    idleTimeoutMillis: config.idleTimeoutMillis ?? 30000,
    connectionTimeoutMillis: config.connectionTimeoutMillis ?? 5000,
  });

  return new Kysely<Database>({
    dialect: new PostgresDialect({ pool }),
  });
}

/**
 * Get the singleton database instance
 */
export function getDatabase(): Kysely<Database> {
  if (!db) {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error('DATABASE_URL environment variable is not set');
    }

    db = createDatabase({
      connectionString,
      ssl: process.env.NODE_ENV === 'production'
        ? { rejectUnauthorized: false }
        : false,
    });
  }

  return db;
}

/**
 * Close the database connection
 */
export async function closeDatabase(): Promise<void> {
  if (db) {
    await db.destroy();
    db = null;
  }
}

// ============================================
// QUERY HELPERS
// ============================================

/**
 * Execute a transaction
 */
export async function transaction<T>(
  callback: (trx: Kysely<Database>) => Promise<T>
): Promise<T> {
  return getDatabase().transaction().execute(callback);
}

/**
 * Soft delete helper - sets deleted_at instead of hard delete
 */
export function softDelete() {
  return { deleted_at: new Date() };
}

/**
 * Exclude soft-deleted records from query
 */
export function notDeleted<T extends { deleted_at: Date | null }>(
  column: keyof T = 'deleted_at' as keyof T
) {
  return (eb: any) => eb.isNull(column);
}

// ============================================
// PAGINATION HELPERS
// ============================================

export interface PaginationParams {
  page?: number;
  pageSize?: number;
}

export interface PaginationMeta {
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface PaginatedResult<T> {
  data: T[];
  meta: PaginationMeta;
}

export function getPaginationParams(params: PaginationParams) {
  const page = Math.max(1, params.page ?? 1);
  const pageSize = Math.min(100, Math.max(1, params.pageSize ?? 20));
  const offset = (page - 1) * pageSize;

  return { page, pageSize, offset };
}

export function createPaginationMeta(
  total: number,
  page: number,
  pageSize: number
): PaginationMeta {
  const totalPages = Math.ceil(total / pageSize);

  return {
    total,
    page,
    pageSize,
    totalPages,
    hasNextPage: page < totalPages,
    hasPrevPage: page > 1,
  };
}

// ============================================
// SEARCH HELPERS
// ============================================

/**
 * Create a full-text search query for PostgreSQL
 */
export function toSearchQuery(searchTerm: string): string {
  // Escape special characters and create a tsquery
  return searchTerm
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((term) => `${term}:*`)
    .join(' & ');
}

/**
 * Create an ILIKE pattern for partial matching
 */
export function toILikePattern(searchTerm: string): string {
  return `%${searchTerm.replace(/%/g, '\\%').replace(/_/g, '\\_')}%`;
}
