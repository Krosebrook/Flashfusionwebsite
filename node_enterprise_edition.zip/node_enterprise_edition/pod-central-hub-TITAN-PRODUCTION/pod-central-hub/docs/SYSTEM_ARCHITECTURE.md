# Technical Architecture: Print-on-Demand Central Hub

## Overview
Namespace: com.pod.hub
Architecture: Feature Sliced Design (FSD)

### Stack
- Frontend: React 18 / Vite / TS
- State: React Context + LocalStorage Persistence
- Deployment: Vercel / Edge Ready
- Styling: Tailwind v3

### Reliability Layer
- Retry strategies on mock API failures.
- Deterministic hashing for ID generation.