## Mermaid Diagrams

### Entity Relationship
```mermaid
erDiagram
    PRODUCT ||--o| DESIGN_ASSET : "uses"
    PRODUCT ||--o| STORE_CONNECTION : "publishes_to"
    STORE_CONNECTION ||--o{ PUBLISH_EVENT : "logs"
```

### Flow
```mermaid
graph LR
    A[Design Studio] --> B[Asset Generator]
    B --> C[Product Creation]
    C --> D[Store Mapping]
    D --> E[Publishing Queue]
```