# Pod Central Hub

> Enterprise Print-on-Demand Product Management Platform

[![CI/CD](https://github.com/company/pod-central-hub/actions/workflows/ci.yml/badge.svg)](https://github.com/company/pod-central-hub/actions/workflows/ci.yml)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.2-blue)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-18.2-blue)](https://reactjs.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

## Overview

Pod Central Hub is a comprehensive platform for managing print-on-demand products, connecting multiple e-commerce stores, and streamlining the product publishing workflow.

### Key Features

- **Product Management** - Create, edit, and organize POD products with full CRUD operations
- **Multi-Store Integration** - Connect Shopify, Etsy, Amazon, WooCommerce, and more
- **Design Asset Library** - Upload and manage design files with print-ready validation
- **Bulk Operations** - Mass create, update, and publish products
- **Real-time Sync** - Automatic synchronization with connected stores
- **Analytics Dashboard** - Track performance across all stores

## Tech Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | React 18, TypeScript 5.2, Tailwind CSS |
| **State Management** | Zustand, React Query |
| **Build Tool** | Vite 5, Turborepo |
| **Backend** | Vercel Edge Functions |
| **Database** | PostgreSQL with Kysely |
| **Authentication** | JWT with Argon2 |
| **Testing** | Vitest, Playwright |
| **Deployment** | Vercel |

## Quick Start

### Prerequisites

- Node.js 20+
- npm 10+
- PostgreSQL 15+ (for production)

### Installation

```bash
# Clone the repository
git clone https://github.com/company/pod-central-hub.git
cd pod-central-hub

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Start development server
npm run dev
```

The application will be available at `http://localhost:5173`

### Environment Variables

Create a `.env` file with:

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/pod_central

# Authentication
JWT_SECRET=your-super-secret-jwt-key-min-32-chars

# API
VITE_API_URL=http://localhost:3001/api

# Optional
SENTRY_DSN=your-sentry-dsn
S3_BUCKET=your-s3-bucket
```

## Project Structure

```
pod-central-hub/
├── apps/
│   └── web/                    # React frontend application
│       ├── src/
│       │   ├── app/            # App-level configuration
│       │   ├── entities/       # Business entities (Product, Store, Asset, Event)
│       │   ├── features/       # Feature modules (auth, product-crud, etc.)
│       │   ├── pages/          # Page components
│       │   └── shared/         # Shared code (UI, hooks, utils, stores)
│       └── package.json
├── packages/
│   └── database/               # Database schema and types
│       ├── schema.sql          # PostgreSQL schema
│       └── src/
│           ├── index.ts        # Database connection
│           └── types.ts        # Kysely type definitions
├── docs/                       # Documentation
├── .github/
│   └── workflows/              # CI/CD pipelines
├── turbo.json                  # Turborepo configuration
└── package.json                # Root package.json
```

## Architecture

The project follows **Feature Sliced Design (FSD)** architecture:

- **Entities** - Business domain objects (Product, Store, Asset, Event)
- **Features** - User interactions and business logic
- **Shared** - Reusable code (UI components, hooks, utilities)
- **Pages** - Route-level components

### State Management

- **Zustand** - Client-side state for products, stores, and assets
- **React Query** - Server state caching and synchronization
- **Immer** - Immutable state updates

## Development

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Production build
npm run preview      # Preview production build
npm run test         # Run tests
npm run test:coverage # Run tests with coverage
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript type checking
```

### Code Style

- ESLint + Prettier for code formatting
- TypeScript strict mode enabled
- Conventional Commits for git messages

### Testing

```bash
# Unit tests
npm run test

# With coverage
npm run test:coverage

# E2E tests (when implemented)
npm run test:e2e
```

## Deployment

### Staging

Automatically deployed on push to `develop` branch via GitHub Actions.

### Production

Automatically deployed on push to `main` branch via GitHub Actions.

### Manual Deployment

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to preview
vercel

# Deploy to production
vercel --prod
```

## Database

### Running Migrations

```bash
# Apply schema
psql $DATABASE_URL < packages/database/schema.sql
```

### Schema Overview

- `users` - User accounts and authentication
- `stores` - Connected e-commerce stores
- `products` - POD product catalog
- `assets` - Design files and media
- `events` - Audit log and activity tracking

## API Documentation

API documentation is available at `/api/docs` when running in development mode.

### Authentication

All API endpoints (except `/auth/*`) require a valid JWT token:

```
Authorization: Bearer <token>
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/login` | User login |
| POST | `/auth/register` | User registration |
| GET | `/products` | List products |
| POST | `/products` | Create product |
| GET | `/products/:id` | Get product |
| PATCH | `/products/:id` | Update product |
| DELETE | `/products/:id` | Delete product |
| GET | `/stores` | List stores |
| POST | `/stores/:id/sync` | Sync store |

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'feat: add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see [LICENSE](LICENSE) for details.

## Support

- **Issues**: [GitHub Issues](https://github.com/company/pod-central-hub/issues)
- **Documentation**: [docs/](./docs)
