import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Package,
  Store,
  Image,
  TrendingUp,
  ArrowRight,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import { useProductStore, selectProducts } from '../shared/store/productStore';
import { useStoreStore, selectStores } from '../shared/store/storeStore';
import { useAssetStore, selectAssets } from '../shared/store/assetStore';
import {
  PageContainer,
  PageHeader,
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Button,
  Skeleton,
  StatusBadge,
} from '../shared/ui';
import { formatCurrency } from '../shared/lib/utils';
import { ProductStatus } from '../entities/product/model/types';
import { SyncStatus } from '../entities/store/model/types';

// ============================================
// STAT CARD
// ============================================

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  href?: string;
  isLoading?: boolean;
}

function StatCard({ title, value, icon, href, isLoading }: StatCardProps) {
  const content = (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          {isLoading ? (
            <Skeleton width={80} height={32} className="mt-1" />
          ) : (
            <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
          )}
        </div>
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
          {icon}
        </div>
      </CardContent>
    </Card>
  );

  if (href) {
    return <Link to={href}>{content}</Link>;
  }

  return content;
}

// ============================================
// RECENT PRODUCTS
// ============================================

function RecentProducts() {
  const products = useProductStore(selectProducts);
  const isLoading = useProductStore((state) => state.isLoading);

  const recentProducts = products
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle>Recent Products</CardTitle>
        <Link to="/products">
          <Button variant="ghost" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>
            View all
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Skeleton width={40} height={40} rounded="md" />
                  <div>
                    <Skeleton width={120} height={16} />
                    <Skeleton width={80} height={14} className="mt-1" />
                  </div>
                </div>
                <Skeleton width={60} height={24} rounded="full" />
              </div>
            ))}
          </div>
        ) : recentProducts.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Package className="h-12 w-12 mx-auto text-slate-300 mb-2" />
            <p>No products yet</p>
            <Link to="/products">
              <Button variant="link" size="sm">
                Create your first product
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {recentProducts.map((product) => (
              <Link
                key={product.id}
                to={`/products/${product.id}`}
                className="flex items-center justify-between p-2 rounded-md hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-slate-100">
                    <Package className="h-5 w-5 text-slate-500" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900">{product.title}</p>
                    <p className="text-sm text-slate-500">
                      {formatCurrency(product.price)} &bull; {product.sku}
                    </p>
                  </div>
                </div>
                <StatusBadge
                  status={product.status.toLowerCase() as 'draft' | 'active' | 'published' | 'archived'}
                />
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================
// STORE STATUS
// ============================================

function StoreStatus() {
  const stores = useStoreStore(selectStores);
  const isLoading = useStoreStore((state) => state.isLoading);

  const activeStores = stores.filter((s) => s.isActive);
  const syncedStores = stores.filter((s) => s.syncStatus === SyncStatus.SYNCED);
  const errorStores = stores.filter((s) => s.syncStatus === SyncStatus.ERROR);

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle>Store Connections</CardTitle>
        <Link to="/stores">
          <Button variant="ghost" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>
            Manage
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Skeleton width={40} height={40} rounded="md" />
                  <div>
                    <Skeleton width={100} height={16} />
                    <Skeleton width={60} height={14} className="mt-1" />
                  </div>
                </div>
                <Skeleton width={70} height={24} rounded="full" />
              </div>
            ))}
          </div>
        ) : stores.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Store className="h-12 w-12 mx-auto text-slate-300 mb-2" />
            <p>No stores connected</p>
            <Link to="/stores">
              <Button variant="link" size="sm">
                Connect a store
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center p-3 bg-slate-50 rounded-lg">
                <p className="text-2xl font-bold text-slate-900">{activeStores.length}</p>
                <p className="text-xs text-slate-500">Active</p>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{syncedStores.length}</p>
                <p className="text-xs text-slate-500">Synced</p>
              </div>
              <div className="text-center p-3 bg-red-50 rounded-lg">
                <p className="text-2xl font-bold text-red-600">{errorStores.length}</p>
                <p className="text-xs text-slate-500">Errors</p>
              </div>
            </div>
            <div className="space-y-2">
              {stores.slice(0, 3).map((store) => (
                <div
                  key={store.id}
                  className="flex items-center justify-between p-2 rounded-md hover:bg-slate-50"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-slate-100">
                      <Store className="h-4 w-4 text-slate-500" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 text-sm">{store.name}</p>
                      <p className="text-xs text-slate-500">
                        {store.productCount} products
                      </p>
                    </div>
                  </div>
                  {store.syncStatus === SyncStatus.SYNCED ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : store.syncStatus === SyncStatus.ERROR ? (
                    <AlertCircle className="h-5 w-5 text-red-500" />
                  ) : (
                    <StatusBadge
                      status={store.syncStatus.toLowerCase() as 'pending' | 'syncing' | 'synced' | 'error'}
                      showDot={false}
                    />
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================
// DASHBOARD PAGE
// ============================================

export default function DashboardPage() {
  const { fetchProducts, isLoading: productsLoading } = useProductStore();
  const { fetchStores, isLoading: storesLoading } = useStoreStore();
  const { fetchAssets, isLoading: assetsLoading } = useAssetStore();

  const products = useProductStore(selectProducts);
  const stores = useStoreStore(selectStores);
  const assets = useAssetStore(selectAssets);

  useEffect(() => {
    fetchProducts().catch(console.error);
    fetchStores().catch(console.error);
    fetchAssets().catch(console.error);
  }, [fetchProducts, fetchStores, fetchAssets]);

  const publishedProducts = products.filter((p) => p.status === ProductStatus.PUBLISHED);

  return (
    <PageContainer>
      <PageHeader
        title="Dashboard"
        description="Overview of your print-on-demand business"
      />

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Products"
          value={products.length}
          icon={<Package className="h-6 w-6 text-blue-600" />}
          href="/products"
          isLoading={productsLoading}
        />
        <StatCard
          title="Published"
          value={publishedProducts.length}
          icon={<CheckCircle className="h-6 w-6 text-green-600" />}
          href="/products?status=PUBLISHED"
          isLoading={productsLoading}
        />
        <StatCard
          title="Connected Stores"
          value={stores.filter((s) => s.isActive).length}
          icon={<Store className="h-6 w-6 text-purple-600" />}
          href="/stores"
          isLoading={storesLoading}
        />
        <StatCard
          title="Design Assets"
          value={assets.length}
          icon={<Image className="h-6 w-6 text-orange-600" />}
          href="/assets"
          isLoading={assetsLoading}
        />
      </div>

      {/* Content Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        <RecentProducts />
        <StoreStatus />
      </div>
    </PageContainer>
  );
}
