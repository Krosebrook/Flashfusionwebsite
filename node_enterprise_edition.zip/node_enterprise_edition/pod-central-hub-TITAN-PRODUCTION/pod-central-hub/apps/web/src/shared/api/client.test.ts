// ============================================
// API CLIENT - UNIT TESTS
// ============================================

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  api,
  ApiError,
  NetworkError,
  ValidationError,
  setAuthToken,
  getAuthToken,
  clearAuthToken,
  withRetry,
  batchRequests,
} from './client';

describe('API Client', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    clearAuthToken();
    localStorage.clear();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Token Management', () => {
    it('sets auth token', () => {
      setAuthToken('test-token');
      expect(getAuthToken()).toBe('test-token');
    });

    it('persists token to localStorage', () => {
      setAuthToken('test-token');
      expect(localStorage.setItem).toHaveBeenCalledWith('auth_token', 'test-token');
    });

    it('clears auth token', () => {
      setAuthToken('test-token');
      clearAuthToken();
      expect(getAuthToken()).toBeNull();
    });

    it('removes token from localStorage when cleared', () => {
      setAuthToken('test-token');
      clearAuthToken();
      expect(localStorage.removeItem).toHaveBeenCalledWith('auth_token');
    });

    it('retrieves token from localStorage if not in memory', () => {
      (localStorage.getItem as ReturnType<typeof vi.fn>).mockReturnValue('stored-token');
      clearAuthToken(); // Clear in-memory token
      expect(getAuthToken()).toBe('stored-token');
    });
  });

  describe('HTTP Methods', () => {
    beforeEach(() => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ data: 'test' }),
      });
    });

    it('makes GET requests', async () => {
      await api.get('/test');
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/test'),
        expect.objectContaining({ method: 'GET' })
      );
    });

    it('makes POST requests with data', async () => {
      await api.post('/test', { name: 'test' });
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/test'),
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({ name: 'test' }),
        })
      );
    });

    it('makes PUT requests', async () => {
      await api.put('/test', { name: 'updated' });
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/test'),
        expect.objectContaining({ method: 'PUT' })
      );
    });

    it('makes PATCH requests', async () => {
      await api.patch('/test', { name: 'patched' });
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/test'),
        expect.objectContaining({ method: 'PATCH' })
      );
    });

    it('makes DELETE requests', async () => {
      await api.delete('/test');
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/test'),
        expect.objectContaining({ method: 'DELETE' })
      );
    });
  });

  describe('Request Headers', () => {
    beforeEach(() => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ data: 'test' }),
      });
    });

    it('includes auth token in Authorization header', async () => {
      setAuthToken('test-token');
      await api.get('/test');

      const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
      const headers = call[1].headers as Headers;
      expect(headers.get('Authorization')).toBe('Bearer test-token');
    });

    it('sets Content-Type for POST requests', async () => {
      await api.post('/test', { data: 'test' });

      const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
      const headers = call[1].headers as Headers;
      expect(headers.get('Content-Type')).toBe('application/json');
    });

    it('sets Accept header', async () => {
      await api.get('/test');

      const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
      const headers = call[1].headers as Headers;
      expect(headers.get('Accept')).toBe('application/json');
    });
  });

  describe('Query Parameters', () => {
    beforeEach(() => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ data: 'test' }),
      });
    });

    it('includes query parameters in URL', async () => {
      await api.get('/test', { params: { page: 1, limit: 10 } });

      const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
      expect(call[0]).toContain('page=1');
      expect(call[0]).toContain('limit=10');
    });

    it('filters out null and undefined params', async () => {
      await api.get('/test', { params: { page: 1, filter: null, sort: undefined } });

      const call = (fetch as ReturnType<typeof vi.fn>).mock.calls[0];
      expect(call[0]).toContain('page=1');
      expect(call[0]).not.toContain('filter');
      expect(call[0]).not.toContain('sort');
    });
  });

  describe('Error Handling', () => {
    it('throws ApiError for non-OK responses', async () => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: false,
        status: 400,
        json: () => Promise.resolve({ message: 'Bad Request', code: 'BAD_REQUEST' }),
      });

      await expect(api.get('/test')).rejects.toThrow(ApiError);
    });

    it('includes error details in ApiError', async () => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: false,
        status: 404,
        json: () => Promise.resolve({ message: 'Not found', code: 'NOT_FOUND' }),
      });

      try {
        await api.get('/test');
      } catch (error) {
        expect(error).toBeInstanceOf(ApiError);
        expect((error as ApiError).status).toBe(404);
        expect((error as ApiError).code).toBe('NOT_FOUND');
        expect((error as ApiError).message).toBe('Not found');
      }
    });

    it('throws ValidationError for validation failures', async () => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: false,
        status: 400,
        json: () =>
          Promise.resolve({
            message: 'Validation failed',
            fieldErrors: { name: ['Name is required'] },
          }),
      });

      await expect(api.post('/test', {})).rejects.toThrow(ValidationError);
    });

    it('clears token on 401 response', async () => {
      setAuthToken('test-token');
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: false,
        status: 401,
        json: () => Promise.resolve({ message: 'Unauthorized' }),
      });

      await expect(api.get('/test')).rejects.toThrow(ApiError);
      expect(getAuthToken()).toBeNull();
    });

    it('handles network errors', async () => {
      (global.fetch as ReturnType<typeof vi.fn>).mockRejectedValue(
        new TypeError('Failed to fetch')
      );

      await expect(api.get('/test')).rejects.toThrow(NetworkError);
    });

    it('handles 204 No Content responses', async () => {
      (global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue({
        ok: true,
        status: 204,
        json: () => Promise.reject(new Error('No JSON')),
      });

      const result = await api.delete('/test');
      expect(result).toBeUndefined();
    });
  });

  describe('ApiError Class', () => {
    it('creates ApiError with all properties', () => {
      const error = new ApiError('Test error', 400, 'TEST_ERROR', { field: 'value' });
      expect(error.message).toBe('Test error');
      expect(error.status).toBe(400);
      expect(error.code).toBe('TEST_ERROR');
      expect(error.details).toEqual({ field: 'value' });
      expect(error.name).toBe('ApiError');
    });

    it('isApiError returns true for ApiError instances', () => {
      const error = new ApiError('Test', 400, 'TEST');
      expect(ApiError.isApiError(error)).toBe(true);
    });

    it('isApiError returns false for regular errors', () => {
      expect(ApiError.isApiError(new Error('Test'))).toBe(false);
    });
  });

  describe('ValidationError Class', () => {
    it('creates ValidationError with field errors', () => {
      const fieldErrors = { name: ['Required'], email: ['Invalid format'] };
      const error = new ValidationError('Validation failed', fieldErrors);

      expect(error.message).toBe('Validation failed');
      expect(error.status).toBe(400);
      expect(error.code).toBe('VALIDATION_ERROR');
      expect(error.fieldErrors).toEqual(fieldErrors);
    });
  });

  describe('NetworkError Class', () => {
    it('creates NetworkError with default message', () => {
      const error = new NetworkError();
      expect(error.message).toBe('Network error. Please check your connection.');
      expect(error.name).toBe('NetworkError');
    });

    it('creates NetworkError with custom message', () => {
      const error = new NetworkError('Custom message');
      expect(error.message).toBe('Custom message');
    });
  });
});

describe('withRetry', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('returns result on success', async () => {
    const fn = vi.fn().mockResolvedValue('success');
    const promise = withRetry(fn);
    await vi.runAllTimersAsync();
    const result = await promise;
    expect(result).toBe('success');
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('retries on failure', async () => {
    const fn = vi
      .fn()
      .mockRejectedValueOnce(new NetworkError())
      .mockResolvedValueOnce('success');

    const promise = withRetry(fn, { maxRetries: 3, retryDelay: 100 });
    await vi.runAllTimersAsync();
    const result = await promise;

    expect(result).toBe('success');
    expect(fn).toHaveBeenCalledTimes(2);
  });

  it('throws after max retries', async () => {
    const fn = vi.fn().mockRejectedValue(new NetworkError());

    const promise = withRetry(fn, { maxRetries: 2, retryDelay: 100 });

    await vi.runAllTimersAsync();
    await expect(promise).rejects.toThrow(NetworkError);
    expect(fn).toHaveBeenCalledTimes(3); // Initial + 2 retries
  });

  it('does not retry when condition is false', async () => {
    const fn = vi.fn().mockRejectedValue(new ApiError('Bad Request', 400, 'BAD_REQUEST'));

    const promise = withRetry(fn, {
      maxRetries: 3,
      retryCondition: (error) => error instanceof NetworkError,
    });

    await expect(promise).rejects.toThrow(ApiError);
    expect(fn).toHaveBeenCalledTimes(1);
  });
});

describe('batchRequests', () => {
  it('executes all requests', async () => {
    const requests = [
      vi.fn().mockResolvedValue(1),
      vi.fn().mockResolvedValue(2),
      vi.fn().mockResolvedValue(3),
    ];

    const results = await batchRequests(requests);

    expect(results).toHaveLength(3);
    expect(results.map((r) => r.status)).toEqual(['fulfilled', 'fulfilled', 'fulfilled']);
    expect(results.map((r) => (r as { status: 'fulfilled'; value: number }).value)).toEqual([1, 2, 3]);
  });

  it('handles mixed success and failure', async () => {
    const requests = [
      vi.fn().mockResolvedValue(1),
      vi.fn().mockRejectedValue(new Error('Failed')),
      vi.fn().mockResolvedValue(3),
    ];

    const results = await batchRequests(requests);

    expect(results[0]).toEqual({ status: 'fulfilled', value: 1 });
    expect(results[1].status).toBe('rejected');
    expect(results[2]).toEqual({ status: 'fulfilled', value: 3 });
  });

  it('respects concurrency limit', async () => {
    let concurrent = 0;
    let maxConcurrent = 0;

    const createRequest = () =>
      vi.fn().mockImplementation(async () => {
        concurrent++;
        maxConcurrent = Math.max(maxConcurrent, concurrent);
        await new Promise((resolve) => setTimeout(resolve, 10));
        concurrent--;
        return 'done';
      });

    const requests = Array(10).fill(null).map(createRequest);
    await batchRequests(requests, 3);

    expect(maxConcurrent).toBeLessThanOrEqual(3);
  });
});
