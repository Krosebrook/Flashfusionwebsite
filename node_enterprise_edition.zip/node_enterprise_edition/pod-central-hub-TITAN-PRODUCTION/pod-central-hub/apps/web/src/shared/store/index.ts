// ============================================
// STATE MANAGEMENT - BARREL EXPORTS
// ============================================

// Product Store
export {
  useProductStore,
  selectProducts,
  selectProductById,
  selectSelectedProducts,
  selectSelectedCount as selectProductSelectedCount,
  selectIsProductSelected,
  selectFilteredProducts,
} from './productStore';

// Store Store (for store integrations)
export {
  useStoreStore,
  selectStores,
  selectStoreById,
  selectActiveStores,
  selectSyncingStores,
  selectIsStoreSyncing,
  selectFilteredStores,
} from './storeStore';

// Asset Store
export {
  useAssetStore,
  selectAssets,
  selectAssetById,
  selectSelectedAssets,
  selectSelectedCount as selectAssetSelectedCount,
  selectIsAssetSelected,
  selectUploads,
  selectActiveUploads,
  selectFilteredAssets,
} from './assetStore';
