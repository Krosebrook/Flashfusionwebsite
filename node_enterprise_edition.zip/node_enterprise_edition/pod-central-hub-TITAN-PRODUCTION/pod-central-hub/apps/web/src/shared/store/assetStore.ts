import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type {
  Asset,
  AssetFilters,
  CreateAssetDto,
  UpdateAssetDto,
  UploadRequest,
  UploadResponse,
} from '../../entities/asset/model/types';

// ============================================
// API PLACEHOLDER
// ============================================

const assetApi = {
  async getAll(filters?: AssetFilters): Promise<Asset[]> {
    return [];
  },
  async getById(id: string): Promise<Asset> {
    throw new Error('Not implemented');
  },
  async requestUpload(request: UploadRequest): Promise<UploadResponse> {
    throw new Error('Not implemented');
  },
  async confirmUpload(id: string): Promise<Asset> {
    throw new Error('Not implemented');
  },
  async update(id: string, dto: UpdateAssetDto): Promise<Asset> {
    throw new Error('Not implemented');
  },
  async delete(id: string): Promise<void> {
    throw new Error('Not implemented');
  },
  async bulkDelete(ids: string[]): Promise<void> {
    throw new Error('Not implemented');
  },
};

// ============================================
// UPLOAD TYPES
// ============================================

interface UploadProgress {
  id: string;
  filename: string;
  progress: number;
  status: 'pending' | 'uploading' | 'processing' | 'complete' | 'error';
  error?: string;
}

// ============================================
// STORE TYPES
// ============================================

interface AssetState {
  // Data
  assets: Map<string, Asset>;
  selectedIds: Set<string>;
  filters: AssetFilters;
  uploads: Map<string, UploadProgress>;

  // UI State
  isLoading: boolean;
  error: Error | null;

  // Actions
  fetchAssets: () => Promise<void>;
  fetchAssetById: (id: string) => Promise<Asset>;
  uploadAsset: (file: File, tags?: string[]) => Promise<Asset>;
  updateAsset: (id: string, dto: UpdateAssetDto) => Promise<Asset>;
  deleteAsset: (id: string) => Promise<void>;
  bulkDelete: (ids: string[]) => Promise<void>;

  // Selection
  selectAsset: (id: string) => void;
  deselectAsset: (id: string) => void;
  toggleAssetSelection: (id: string) => void;
  selectAll: () => void;
  clearSelection: () => void;

  // Upload tracking
  updateUploadProgress: (id: string, progress: Partial<UploadProgress>) => void;
  removeUpload: (id: string) => void;
  clearCompletedUploads: () => void;

  // Filters
  setFilters: (filters: Partial<AssetFilters>) => void;
  clearFilters: () => void;

  // Reset
  reset: () => void;
}

// ============================================
// INITIAL STATE
// ============================================

const initialState = {
  assets: new Map<string, Asset>(),
  selectedIds: new Set<string>(),
  filters: {},
  uploads: new Map<string, UploadProgress>(),
  isLoading: false,
  error: null,
};

// ============================================
// STORE
// ============================================

export const useAssetStore = create<AssetState>()(
  devtools(
    persist(
      immer((set, get) => ({
        ...initialState,

        // Fetch all assets
        fetchAssets: async () => {
          set({ isLoading: true, error: null });
          try {
            const assets = await assetApi.getAll(get().filters);
            set((state) => {
              state.assets.clear();
              assets.forEach((asset) => {
                state.assets.set(asset.id, asset);
              });
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Fetch single asset
        fetchAssetById: async (id) => {
          set({ isLoading: true, error: null });
          try {
            const asset = await assetApi.getById(id);
            set((state) => {
              state.assets.set(id, asset);
              state.isLoading = false;
            });
            return asset;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Upload asset
        uploadAsset: async (file, tags = []) => {
          const uploadId = crypto.randomUUID();

          // Initialize upload tracking
          set((state) => {
            state.uploads.set(uploadId, {
              id: uploadId,
              filename: file.name,
              progress: 0,
              status: 'pending',
            });
          });

          try {
            // Request pre-signed upload URL
            set((state) => {
              const upload = state.uploads.get(uploadId);
              if (upload) upload.status = 'uploading';
            });

            const uploadResponse = await assetApi.requestUpload({
              filename: file.name,
              mimeType: file.type,
              sizeBytes: file.size,
            });

            // Upload file to pre-signed URL
            const xhr = new XMLHttpRequest();

            await new Promise<void>((resolve, reject) => {
              xhr.upload.onprogress = (event) => {
                if (event.lengthComputable) {
                  const progress = Math.round((event.loaded / event.total) * 100);
                  set((state) => {
                    const upload = state.uploads.get(uploadId);
                    if (upload) upload.progress = progress;
                  });
                }
              };

              xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                  resolve();
                } else {
                  reject(new Error(`Upload failed: ${xhr.statusText}`));
                }
              };

              xhr.onerror = () => reject(new Error('Upload failed'));

              xhr.open('PUT', uploadResponse.uploadUrl);
              xhr.setRequestHeader('Content-Type', file.type);
              xhr.send(file);
            });

            // Confirm upload and get processed asset
            set((state) => {
              const upload = state.uploads.get(uploadId);
              if (upload) upload.status = 'processing';
            });

            const asset = await assetApi.confirmUpload(uploadResponse.assetId);

            // Update with tags if provided
            let finalAsset = asset;
            if (tags.length > 0) {
              finalAsset = await assetApi.update(asset.id, { tags });
            }

            // Add to store and mark complete
            set((state) => {
              state.assets.set(finalAsset.id, finalAsset);
              const upload = state.uploads.get(uploadId);
              if (upload) upload.status = 'complete';
            });

            return finalAsset;
          } catch (error) {
            set((state) => {
              const upload = state.uploads.get(uploadId);
              if (upload) {
                upload.status = 'error';
                upload.error = (error as Error).message;
              }
            });
            throw error;
          }
        },

        // Update asset
        updateAsset: async (id, dto) => {
          set({ isLoading: true, error: null });
          try {
            const asset = await assetApi.update(id, dto);
            set((state) => {
              state.assets.set(id, asset);
              state.isLoading = false;
            });
            return asset;
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Delete asset
        deleteAsset: async (id) => {
          set({ isLoading: true, error: null });
          try {
            await assetApi.delete(id);
            set((state) => {
              state.assets.delete(id);
              state.selectedIds.delete(id);
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Bulk delete
        bulkDelete: async (ids) => {
          set({ isLoading: true, error: null });
          try {
            await assetApi.bulkDelete(ids);
            set((state) => {
              ids.forEach((id) => {
                state.assets.delete(id);
                state.selectedIds.delete(id);
              });
              state.isLoading = false;
            });
          } catch (error) {
            set({ error: error as Error, isLoading: false });
            throw error;
          }
        },

        // Selection actions
        selectAsset: (id) =>
          set((state) => {
            state.selectedIds.add(id);
          }),

        deselectAsset: (id) =>
          set((state) => {
            state.selectedIds.delete(id);
          }),

        toggleAssetSelection: (id) =>
          set((state) => {
            if (state.selectedIds.has(id)) {
              state.selectedIds.delete(id);
            } else {
              state.selectedIds.add(id);
            }
          }),

        selectAll: () =>
          set((state) => {
            state.assets.forEach((_, id) => state.selectedIds.add(id));
          }),

        clearSelection: () =>
          set((state) => {
            state.selectedIds.clear();
          }),

        // Upload tracking
        updateUploadProgress: (id, progress) =>
          set((state) => {
            const upload = state.uploads.get(id);
            if (upload) {
              Object.assign(upload, progress);
            }
          }),

        removeUpload: (id) =>
          set((state) => {
            state.uploads.delete(id);
          }),

        clearCompletedUploads: () =>
          set((state) => {
            state.uploads.forEach((upload, id) => {
              if (upload.status === 'complete' || upload.status === 'error') {
                state.uploads.delete(id);
              }
            });
          }),

        // Filter actions
        setFilters: (filters) =>
          set((state) => {
            state.filters = { ...state.filters, ...filters };
          }),

        clearFilters: () =>
          set((state) => {
            state.filters = {};
          }),

        // Reset
        reset: () => set(initialState),
      })),
      {
        name: 'asset-store',
        partialize: (state) => ({ filters: state.filters }),
      }
    ),
    { name: 'AssetStore' }
  )
);

// ============================================
// SELECTORS
// ============================================

export const selectAssets = (state: AssetState) =>
  Array.from(state.assets.values());

export const selectAssetById = (id: string) => (state: AssetState) =>
  state.assets.get(id);

export const selectSelectedAssets = (state: AssetState) =>
  Array.from(state.selectedIds)
    .map((id) => state.assets.get(id))
    .filter((a): a is Asset => a !== undefined);

export const selectSelectedCount = (state: AssetState) =>
  state.selectedIds.size;

export const selectIsAssetSelected = (id: string) => (state: AssetState) =>
  state.selectedIds.has(id);

export const selectUploads = (state: AssetState) =>
  Array.from(state.uploads.values());

export const selectActiveUploads = (state: AssetState) =>
  Array.from(state.uploads.values()).filter(
    (u) => u.status === 'pending' || u.status === 'uploading' || u.status === 'processing'
  );

export const selectFilteredAssets = (state: AssetState) => {
  const assets = Array.from(state.assets.values());
  const { filters } = state;

  return assets.filter((asset) => {
    if (filters.type?.length && !filters.type.includes(asset.type)) {
      return false;
    }
    if (filters.status?.length && !filters.status.includes(asset.status)) {
      return false;
    }
    if (filters.tags?.length) {
      const hasMatchingTag = filters.tags.some((tag) => asset.tags.includes(tag));
      if (!hasMatchingTag) return false;
    }
    if (filters.minWidth && (!asset.width || asset.width < filters.minWidth)) {
      return false;
    }
    if (filters.minHeight && (!asset.height || asset.height < filters.minHeight)) {
      return false;
    }
    if (filters.minDpi && (!asset.dpi || asset.dpi < filters.minDpi)) {
      return false;
    }
    if (filters.search) {
      const search = filters.search.toLowerCase();
      if (
        !asset.filename.toLowerCase().includes(search) &&
        !asset.originalFilename.toLowerCase().includes(search)
      ) {
        return false;
      }
    }
    return true;
  });
};

export default useAssetStore;
