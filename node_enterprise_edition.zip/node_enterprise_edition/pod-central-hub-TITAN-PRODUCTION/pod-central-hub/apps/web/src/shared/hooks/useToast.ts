import { useCallback } from 'react';
import toast, { type ToastOptions } from 'react-hot-toast';

// ============================================
// TOAST HOOK
// ============================================

export type ToastType = 'success' | 'error' | 'warning' | 'info' | 'loading';

export interface ToastParams {
  title: string;
  description?: string;
  variant?: ToastType;
  duration?: number;
}

const defaultDurations: Record<ToastType, number> = {
  success: 3000,
  error: 5000,
  warning: 4000,
  info: 3000,
  loading: Infinity,
};

export function useToast() {
  const showToast = useCallback(
    ({ title, description, variant = 'info', duration }: ToastParams) => {
      const finalDuration = duration ?? defaultDurations[variant];

      const content = description ? (
        <div>
          <p className="font-medium">{title}</p>
          <p className="text-sm text-slate-500 mt-1">{description}</p>
        </div>
      ) : (
        title
      );

      const options: ToastOptions = {
        duration: finalDuration,
      };

      switch (variant) {
        case 'success':
          return toast.success(content, options);
        case 'error':
          return toast.error(content, options);
        case 'loading':
          return toast.loading(content, options);
        default:
          return toast(content, options);
      }
    },
    []
  );

  const dismiss = useCallback((toastId?: string) => {
    if (toastId) {
      toast.dismiss(toastId);
    } else {
      toast.dismiss();
    }
  }, []);

  const promise = useCallback(
    <T,>(
      promise: Promise<T>,
      messages: {
        loading: string;
        success: string | ((data: T) => string);
        error: string | ((err: Error) => string);
      }
    ) => {
      return toast.promise(promise, messages);
    },
    []
  );

  return {
    toast: showToast,
    dismiss,
    promise,
    // Convenience methods
    success: (title: string, description?: string) =>
      showToast({ title, description, variant: 'success' }),
    error: (title: string, description?: string) =>
      showToast({ title, description, variant: 'error' }),
    warning: (title: string, description?: string) =>
      showToast({ title, description, variant: 'warning' }),
    info: (title: string, description?: string) =>
      showToast({ title, description, variant: 'info' }),
    loading: (title: string, description?: string) =>
      showToast({ title, description, variant: 'loading' }),
  };
}

export default useToast;
