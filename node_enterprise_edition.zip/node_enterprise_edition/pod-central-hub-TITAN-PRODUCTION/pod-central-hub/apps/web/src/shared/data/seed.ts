import { v4 as uuidv4 } from 'uuid';
export const SEED_DATA = Array.from({length: 55}).map((_, i) => ({ id: uuidv4(), title: 'Seed Product ' + i }));