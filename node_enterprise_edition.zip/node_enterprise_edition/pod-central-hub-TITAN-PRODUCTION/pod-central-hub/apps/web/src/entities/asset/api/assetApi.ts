// ============================================
// ASSET API - FULL CRUD OPERATIONS WITH FILE UPLOAD
// ============================================

import { api, ApiError } from '@/shared/api';
import type {
  Asset,
  CreateAssetDto,
  UpdateAssetDto,
  AssetFilters,
  AssetSortOptions,
  UploadRequest,
  UploadResponse,
} from '../model/types';
import type { PaginatedResponse, PaginationParams } from '@/entities/product/model/types';

// ============================================
// API ENDPOINTS
// ============================================

const ENDPOINTS = {
  base: '/assets',
  byId: (id: string) => `/assets/${id}`,
  upload: '/assets/upload',
  uploadComplete: (id: string) => `/assets/${id}/upload-complete`,
  thumbnail: (id: string) => `/assets/${id}/thumbnail`,
  download: (id: string) => `/assets/${id}/download`,
  duplicate: (id: string) => `/assets/${id}/duplicate`,
  bulk: '/assets/bulk',
  bulkDelete: '/assets/bulk/delete',
  search: '/assets/search',
  tags: '/assets/tags',
};

// ============================================
// QUERY PARAMS BUILDER
// ============================================

function buildQueryParams(
  filters?: AssetFilters,
  sort?: AssetSortOptions,
  pagination?: PaginationParams
): Record<string, string | number | boolean | undefined> {
  const params: Record<string, string | number | boolean | undefined> = {};

  if (pagination) {
    params.page = pagination.page;
    params.pageSize = pagination.pageSize;
  }

  if (sort) {
    params.sortBy = sort.field;
    params.sortOrder = sort.order;
  }

  if (filters) {
    if (filters.type?.length) params.type = filters.type.join(',');
    if (filters.status?.length) params.status = filters.status.join(',');
    if (filters.search) params.q = filters.search;
    if (filters.tags?.length) params.tags = filters.tags.join(',');
    if (filters.minWidth !== undefined) params.minWidth = filters.minWidth;
    if (filters.minHeight !== undefined) params.minHeight = filters.minHeight;
    if (filters.minDpi !== undefined) params.minDpi = filters.minDpi;
  }

  return params;
}

// ============================================
// UPLOAD HELPERS
// ============================================

interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

type ProgressCallback = (progress: UploadProgress) => void;

/**
 * Upload file directly to storage (S3/R2)
 */
async function uploadToStorage(
  uploadUrl: string,
  file: File,
  onProgress?: ProgressCallback
): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable && onProgress) {
        onProgress({
          loaded: event.loaded,
          total: event.total,
          percentage: Math.round((event.loaded / event.total) * 100),
        });
      }
    });

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
      } else {
        reject(new ApiError('Upload failed', xhr.status, 'UPLOAD_FAILED'));
      }
    });

    xhr.addEventListener('error', () => {
      reject(new ApiError('Upload failed', 0, 'NETWORK_ERROR'));
    });

    xhr.addEventListener('abort', () => {
      reject(new ApiError('Upload cancelled', 0, 'UPLOAD_CANCELLED'));
    });

    xhr.open('PUT', uploadUrl);
    xhr.setRequestHeader('Content-Type', file.type);
    xhr.send(file);
  });
}

// ============================================
// API FUNCTIONS
// ============================================

export const assetApi = {
  /**
   * Get all assets with optional filters, sorting, and pagination
   */
  async getAll(
    filters?: AssetFilters,
    sort?: AssetSortOptions,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<Asset>> {
    const params = buildQueryParams(filters, sort, pagination);
    return api.get<PaginatedResponse<Asset>>(ENDPOINTS.base, { params });
  },

  /**
   * Get a single asset by ID
   */
  async getById(id: string): Promise<Asset> {
    const response = await api.get<{ data: Asset }>(ENDPOINTS.byId(id));
    return response.data;
  },

  /**
   * Delete an asset
   */
  async delete(id: string): Promise<void> {
    await api.delete(ENDPOINTS.byId(id));
  },

  /**
   * Update asset metadata
   */
  async update(id: string, data: UpdateAssetDto): Promise<Asset> {
    const response = await api.patch<{ data: Asset }>(ENDPOINTS.byId(id), data);
    return response.data;
  },

  /**
   * Duplicate an asset
   */
  async duplicate(id: string): Promise<Asset> {
    const response = await api.post<{ data: Asset }>(ENDPOINTS.duplicate(id));
    return response.data;
  },

  // ============================================
  // UPLOAD OPERATIONS
  // ============================================

  /**
   * Request a pre-signed upload URL
   */
  async requestUploadUrl(request: UploadRequest): Promise<UploadResponse> {
    return api.post(ENDPOINTS.upload, request);
  },

  /**
   * Mark upload as complete and trigger processing
   */
  async completeUpload(assetId: string): Promise<Asset> {
    const response = await api.post<{ data: Asset }>(ENDPOINTS.uploadComplete(assetId));
    return response.data;
  },

  /**
   * Full upload flow: request URL -> upload file -> complete
   */
  async upload(
    file: File,
    options?: {
      tags?: string[];
      metadata?: Record<string, unknown>;
      onProgress?: ProgressCallback;
    }
  ): Promise<Asset> {
    // Step 1: Request upload URL
    const uploadResponse = await assetApi.requestUploadUrl({
      filename: file.name,
      mimeType: file.type,
      sizeBytes: file.size,
    });

    // Step 2: Upload to storage
    await uploadToStorage(uploadResponse.uploadUrl, file, options?.onProgress);

    // Step 3: Complete upload and start processing
    const asset = await assetApi.completeUpload(uploadResponse.assetId);

    // Step 4: Update with tags/metadata if provided
    if (options?.tags?.length || options?.metadata) {
      return assetApi.update(asset.id, {
        tags: options.tags,
        metadata: options.metadata,
      });
    }

    return asset;
  },

  /**
   * Upload multiple files
   */
  async uploadMultiple(
    files: File[],
    options?: {
      tags?: string[];
      onProgress?: (file: File, progress: UploadProgress) => void;
      onComplete?: (file: File, asset: Asset) => void;
      onError?: (file: File, error: Error) => void;
    }
  ): Promise<{ uploaded: Asset[]; errors: Array<{ file: File; error: Error }> }> {
    const uploaded: Asset[] = [];
    const errors: Array<{ file: File; error: Error }> = [];

    for (const file of files) {
      try {
        const asset = await assetApi.upload(file, {
          tags: options?.tags,
          onProgress: (progress) => options?.onProgress?.(file, progress),
        });
        uploaded.push(asset);
        options?.onComplete?.(file, asset);
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error));
        errors.push({ file, error: err });
        options?.onError?.(file, err);
      }
    }

    return { uploaded, errors };
  },

  // ============================================
  // DOWNLOAD OPERATIONS
  // ============================================

  /**
   * Get download URL for an asset
   */
  async getDownloadUrl(id: string): Promise<{ url: string; expiresAt: Date }> {
    return api.get(ENDPOINTS.download(id));
  },

  /**
   * Download an asset file
   */
  async download(id: string): Promise<Blob> {
    const { url } = await assetApi.getDownloadUrl(id);
    const response = await fetch(url);
    if (!response.ok) {
      throw new ApiError('Download failed', response.status, 'DOWNLOAD_ERROR');
    }
    return response.blob();
  },

  // ============================================
  // THUMBNAIL OPERATIONS
  // ============================================

  /**
   * Get thumbnail URL
   */
  async getThumbnailUrl(id: string, size?: 'small' | 'medium' | 'large'): Promise<string> {
    const params = size ? { size } : undefined;
    const response = await api.get<{ url: string }>(ENDPOINTS.thumbnail(id), { params });
    return response.url;
  },

  /**
   * Regenerate thumbnail
   */
  async regenerateThumbnail(id: string): Promise<Asset> {
    const response = await api.post<{ data: Asset }>(`${ENDPOINTS.thumbnail(id)}/regenerate`);
    return response.data;
  },

  // ============================================
  // BULK OPERATIONS
  // ============================================

  /**
   * Bulk delete assets
   */
  async bulkDelete(ids: string[]): Promise<{ deleted: number; errors: Array<{ id: string; error: string }> }> {
    return api.post(ENDPOINTS.bulkDelete, { ids });
  },

  /**
   * Bulk update tags
   */
  async bulkUpdateTags(
    ids: string[],
    operation: 'add' | 'remove' | 'replace',
    tags: string[]
  ): Promise<{ updated: number; errors: Array<{ id: string; error: string }> }> {
    return api.post('/assets/bulk/tags', { ids, operation, tags });
  },

  // ============================================
  // SEARCH & DISCOVERY
  // ============================================

  /**
   * Full-text search assets
   */
  async search(
    query: string,
    filters?: Omit<AssetFilters, 'search'>,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<Asset>> {
    const params = buildQueryParams({ ...filters, search: query }, undefined, pagination);
    return api.get<PaginatedResponse<Asset>>(ENDPOINTS.search, { params });
  },

  /**
   * Get all unique tags with counts
   */
  async getTags(): Promise<Array<{ tag: string; count: number }>> {
    return api.get(ENDPOINTS.tags);
  },

  /**
   * Get similar assets based on visual similarity
   */
  async getSimilar(id: string, limit = 10): Promise<Asset[]> {
    const response = await api.get<{ data: Asset[] }>(`/assets/${id}/similar`, {
      params: { limit },
    });
    return response.data;
  },

  // ============================================
  // STATISTICS
  // ============================================

  /**
   * Get asset statistics
   */
  async getStats(): Promise<{
    total: number;
    byType: Record<string, number>;
    byStatus: Record<string, number>;
    totalSizeBytes: number;
    recentlyUploaded: number;
  }> {
    return api.get('/assets/stats');
  },

  /**
   * Get storage usage
   */
  async getStorageUsage(): Promise<{
    used: number;
    limit: number;
    percentage: number;
  }> {
    return api.get('/assets/storage');
  },
};

export default assetApi;
