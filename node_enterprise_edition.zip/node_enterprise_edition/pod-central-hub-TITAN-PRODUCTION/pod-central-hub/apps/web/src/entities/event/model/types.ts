import { z } from 'zod';

// ============================================
// EVENT ENUMS
// ============================================

export const EventType = {
  // Product events
  PRODUCT_CREATED: 'PRODUCT_CREATED',
  PRODUCT_UPDATED: 'PRODUCT_UPDATED',
  PRODUCT_DELETED: 'PRODUCT_DELETED',
  PRODUCT_PUBLISHED: 'PRODUCT_PUBLISHED',
  PRODUCT_UNPUBLISHED: 'PRODUCT_UNPUBLISHED',
  PRODUCT_ARCHIVED: 'PRODUCT_ARCHIVED',

  // Store events
  STORE_CONNECTED: 'STORE_CONNECTED',
  STORE_DISCONNECTED: 'STORE_DISCONNECTED',
  STORE_SYNC_STARTED: 'STORE_SYNC_STARTED',
  STORE_SYNC_COMPLETED: 'STORE_SYNC_COMPLETED',
  STORE_SYNC_FAILED: 'STORE_SYNC_FAILED',

  // Asset events
  ASSET_UPLOADED: 'ASSET_UPLOADED',
  ASSET_DELETED: 'ASSET_DELETED',
  ASSET_PROCESSED: 'ASSET_PROCESSED',

  // User events
  USER_LOGIN: 'USER_LOGIN',
  USER_LOGOUT: 'USER_LOGOUT',
  USER_SETTINGS_UPDATED: 'USER_SETTINGS_UPDATED',

  // System events
  BULK_OPERATION_STARTED: 'BULK_OPERATION_STARTED',
  BULK_OPERATION_COMPLETED: 'BULK_OPERATION_COMPLETED',
  BULK_OPERATION_FAILED: 'BULK_OPERATION_FAILED',
  EXPORT_COMPLETED: 'EXPORT_COMPLETED',
  IMPORT_COMPLETED: 'IMPORT_COMPLETED',
} as const;
export type EventType = (typeof EventType)[keyof typeof EventType];

export const EntityType = {
  PRODUCT: 'PRODUCT',
  STORE: 'STORE',
  ASSET: 'ASSET',
  USER: 'USER',
  SYSTEM: 'SYSTEM',
} as const;
export type EntityType = (typeof EntityType)[keyof typeof EntityType];

export const EventSeverity = {
  INFO: 'INFO',
  WARNING: 'WARNING',
  ERROR: 'ERROR',
  SUCCESS: 'SUCCESS',
} as const;
export type EventSeverity = (typeof EventSeverity)[keyof typeof EventSeverity];

// Event type to severity mapping
export const EventTypeSeverity: Record<EventType, EventSeverity> = {
  [EventType.PRODUCT_CREATED]: EventSeverity.SUCCESS,
  [EventType.PRODUCT_UPDATED]: EventSeverity.INFO,
  [EventType.PRODUCT_DELETED]: EventSeverity.WARNING,
  [EventType.PRODUCT_PUBLISHED]: EventSeverity.SUCCESS,
  [EventType.PRODUCT_UNPUBLISHED]: EventSeverity.INFO,
  [EventType.PRODUCT_ARCHIVED]: EventSeverity.INFO,
  [EventType.STORE_CONNECTED]: EventSeverity.SUCCESS,
  [EventType.STORE_DISCONNECTED]: EventSeverity.WARNING,
  [EventType.STORE_SYNC_STARTED]: EventSeverity.INFO,
  [EventType.STORE_SYNC_COMPLETED]: EventSeverity.SUCCESS,
  [EventType.STORE_SYNC_FAILED]: EventSeverity.ERROR,
  [EventType.ASSET_UPLOADED]: EventSeverity.SUCCESS,
  [EventType.ASSET_DELETED]: EventSeverity.INFO,
  [EventType.ASSET_PROCESSED]: EventSeverity.INFO,
  [EventType.USER_LOGIN]: EventSeverity.INFO,
  [EventType.USER_LOGOUT]: EventSeverity.INFO,
  [EventType.USER_SETTINGS_UPDATED]: EventSeverity.INFO,
  [EventType.BULK_OPERATION_STARTED]: EventSeverity.INFO,
  [EventType.BULK_OPERATION_COMPLETED]: EventSeverity.SUCCESS,
  [EventType.BULK_OPERATION_FAILED]: EventSeverity.ERROR,
  [EventType.EXPORT_COMPLETED]: EventSeverity.SUCCESS,
  [EventType.IMPORT_COMPLETED]: EventSeverity.SUCCESS,
};

// Event labels for UI
export const EventTypeLabels: Record<EventType, string> = {
  [EventType.PRODUCT_CREATED]: 'Product Created',
  [EventType.PRODUCT_UPDATED]: 'Product Updated',
  [EventType.PRODUCT_DELETED]: 'Product Deleted',
  [EventType.PRODUCT_PUBLISHED]: 'Product Published',
  [EventType.PRODUCT_UNPUBLISHED]: 'Product Unpublished',
  [EventType.PRODUCT_ARCHIVED]: 'Product Archived',
  [EventType.STORE_CONNECTED]: 'Store Connected',
  [EventType.STORE_DISCONNECTED]: 'Store Disconnected',
  [EventType.STORE_SYNC_STARTED]: 'Sync Started',
  [EventType.STORE_SYNC_COMPLETED]: 'Sync Completed',
  [EventType.STORE_SYNC_FAILED]: 'Sync Failed',
  [EventType.ASSET_UPLOADED]: 'Asset Uploaded',
  [EventType.ASSET_DELETED]: 'Asset Deleted',
  [EventType.ASSET_PROCESSED]: 'Asset Processed',
  [EventType.USER_LOGIN]: 'User Login',
  [EventType.USER_LOGOUT]: 'User Logout',
  [EventType.USER_SETTINGS_UPDATED]: 'Settings Updated',
  [EventType.BULK_OPERATION_STARTED]: 'Bulk Operation Started',
  [EventType.BULK_OPERATION_COMPLETED]: 'Bulk Operation Completed',
  [EventType.BULK_OPERATION_FAILED]: 'Bulk Operation Failed',
  [EventType.EXPORT_COMPLETED]: 'Export Completed',
  [EventType.IMPORT_COMPLETED]: 'Import Completed',
};

// ============================================
// ZOD SCHEMAS
// ============================================

export const EventSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  entityType: z.nativeEnum(EntityType),
  entityId: z.string().uuid(),
  eventType: z.nativeEnum(EventType),
  severity: z.nativeEnum(EventSeverity),
  message: z.string().max(1000).optional(),
  payload: z.record(z.unknown()).optional().default({}),
  ipAddress: z.string().ip().nullable().optional(),
  userAgent: z.string().max(500).nullable().optional(),
  createdAt: z.coerce.date(),
});

export type Event = z.infer<typeof EventSchema>;

// Create Event DTO
export const CreateEventSchema = z.object({
  entityType: z.nativeEnum(EntityType),
  entityId: z.string().uuid(),
  eventType: z.nativeEnum(EventType),
  message: z.string().max(1000).optional(),
  payload: z.record(z.unknown()).optional().default({}),
});
export type CreateEventDto = z.infer<typeof CreateEventSchema>;

// ============================================
// QUERY & FILTER TYPES
// ============================================

export interface EventFilters {
  entityType?: EntityType[];
  entityId?: string;
  eventType?: EventType[];
  severity?: EventSeverity[];
  startDate?: Date;
  endDate?: Date;
  search?: string;
}

export interface EventSortOptions {
  field: 'createdAt' | 'eventType' | 'severity';
  order: 'asc' | 'desc';
}

// ============================================
// ACTIVITY FEED TYPES
// ============================================

export interface ActivityItem {
  id: string;
  event: Event;
  entityName?: string;
  actorName?: string;
  formattedTime: string;
  relativeTime: string;
}

export interface ActivityFeed {
  items: ActivityItem[];
  hasMore: boolean;
  nextCursor?: string;
}

// ============================================
// BUSINESS RULES & HELPERS
// ============================================

/**
 * Get entity type from event type
 */
export function getEntityTypeFromEvent(eventType: EventType): EntityType {
  if (eventType.startsWith('PRODUCT_')) return EntityType.PRODUCT;
  if (eventType.startsWith('STORE_')) return EntityType.STORE;
  if (eventType.startsWith('ASSET_')) return EntityType.ASSET;
  if (eventType.startsWith('USER_')) return EntityType.USER;
  return EntityType.SYSTEM;
}

/**
 * Format event message
 */
export function formatEventMessage(event: Event): string {
  if (event.message) return event.message;
  return EventTypeLabels[event.eventType] || event.eventType;
}

/**
 * Get severity color for UI
 */
export function getSeverityColor(severity: EventSeverity): string {
  const colors: Record<EventSeverity, string> = {
    [EventSeverity.INFO]: 'text-blue-500',
    [EventSeverity.WARNING]: 'text-yellow-500',
    [EventSeverity.ERROR]: 'text-red-500',
    [EventSeverity.SUCCESS]: 'text-green-500',
  };
  return colors[severity];
}

/**
 * Get severity icon name for UI
 */
export function getSeverityIcon(severity: EventSeverity): string {
  const icons: Record<EventSeverity, string> = {
    [EventSeverity.INFO]: 'info',
    [EventSeverity.WARNING]: 'alert-triangle',
    [EventSeverity.ERROR]: 'x-circle',
    [EventSeverity.SUCCESS]: 'check-circle',
  };
  return icons[severity];
}

/**
 * Format relative time
 */
export function formatRelativeTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - new Date(date).getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;

  return new Date(date).toLocaleDateString();
}

/**
 * Group events by date
 */
export function groupEventsByDate(events: Event[]): Map<string, Event[]> {
  const groups = new Map<string, Event[]>();

  events.forEach((event) => {
    const dateKey = new Date(event.createdAt).toLocaleDateString();
    const existing = groups.get(dateKey) || [];
    groups.set(dateKey, [...existing, event]);
  });

  return groups;
}

/**
 * Check if event is recent (within last 24 hours)
 */
export function isRecentEvent(event: Event): boolean {
  const now = new Date();
  const eventTime = new Date(event.createdAt);
  const diffMs = now.getTime() - eventTime.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);
  return diffHours < 24;
}
