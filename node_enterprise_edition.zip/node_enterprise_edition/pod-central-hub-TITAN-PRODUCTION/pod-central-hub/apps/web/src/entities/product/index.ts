// ============================================
// PRODUCT ENTITY - BARREL EXPORTS
// ============================================

// Types
export * from './model/types';

// API
export { productApi, default as productApiDefault } from './api/productApi';
