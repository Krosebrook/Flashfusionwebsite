// ============================================
// PRODUCT API - FULL CRUD OPERATIONS
// ============================================

import { api, withRetry, batchRequests, ApiError } from '@/shared/api';
import type {
  Product,
  CreateProductDto,
  UpdateProductDto,
  ProductFilters,
  ProductSortOptions,
  PaginatedResponse,
  PaginationParams,
} from '../model/types';

// ============================================
// API ENDPOINTS
// ============================================

const ENDPOINTS = {
  base: '/products',
  byId: (id: string) => `/products/${id}`,
  publish: (id: string) => `/products/${id}/publish`,
  unpublish: (id: string) => `/products/${id}/unpublish`,
  archive: (id: string) => `/products/${id}/archive`,
  duplicate: (id: string) => `/products/${id}/duplicate`,
  bulk: '/products/bulk',
  bulkDelete: '/products/bulk/delete',
  bulkUpdate: '/products/bulk/update',
  bulkPublish: '/products/bulk/publish',
  export: '/products/export',
  import: '/products/import',
};

// ============================================
// QUERY PARAMS BUILDER
// ============================================

function buildQueryParams(
  filters?: ProductFilters,
  sort?: ProductSortOptions,
  pagination?: PaginationParams
): Record<string, string | number | boolean | undefined> {
  const params: Record<string, string | number | boolean | undefined> = {};

  if (pagination) {
    params.page = pagination.page;
    params.pageSize = pagination.pageSize;
  }

  if (sort) {
    params.sortBy = sort.field;
    params.sortOrder = sort.order;
  }

  if (filters) {
    if (filters.status?.length) params.status = filters.status.join(',');
    if (filters.type?.length) params.type = filters.type.join(',');
    if (filters.storeId !== undefined) params.storeId = filters.storeId || 'null';
    if (filters.search) params.q = filters.search;
    if (filters.minPrice !== undefined) params.minPrice = filters.minPrice;
    if (filters.maxPrice !== undefined) params.maxPrice = filters.maxPrice;
    if (filters.tags?.length) params.tags = filters.tags.join(',');
    if (filters.hasDesign !== undefined) params.hasDesign = filters.hasDesign;
  }

  return params;
}

// ============================================
// API FUNCTIONS
// ============================================

export const productApi = {
  /**
   * Get all products with optional filters, sorting, and pagination
   */
  async getAll(
    filters?: ProductFilters,
    sort?: ProductSortOptions,
    pagination: PaginationParams = { page: 1, pageSize: 20 }
  ): Promise<PaginatedResponse<Product>> {
    const params = buildQueryParams(filters, sort, pagination);
    return api.get<PaginatedResponse<Product>>(ENDPOINTS.base, { params });
  },

  /**
   * Get a single product by ID
   */
  async getById(id: string): Promise<Product> {
    const response = await api.get<{ data: Product }>(ENDPOINTS.byId(id));
    return response.data;
  },

  /**
   * Create a new product
   */
  async create(data: CreateProductDto): Promise<Product> {
    const response = await api.post<{ data: Product }>(ENDPOINTS.base, data);
    return response.data;
  },

  /**
   * Update an existing product
   */
  async update(id: string, data: UpdateProductDto): Promise<Product> {
    const response = await api.patch<{ data: Product }>(ENDPOINTS.byId(id), data);
    return response.data;
  },

  /**
   * Delete a product
   */
  async delete(id: string): Promise<void> {
    await api.delete(ENDPOINTS.byId(id));
  },

  /**
   * Publish a product to its connected store
   */
  async publish(id: string): Promise<Product> {
    const response = await api.post<{ data: Product }>(ENDPOINTS.publish(id));
    return response.data;
  },

  /**
   * Unpublish a product (remove from store)
   */
  async unpublish(id: string): Promise<Product> {
    const response = await api.post<{ data: Product }>(ENDPOINTS.unpublish(id));
    return response.data;
  },

  /**
   * Archive a product
   */
  async archive(id: string): Promise<Product> {
    const response = await api.post<{ data: Product }>(ENDPOINTS.archive(id));
    return response.data;
  },

  /**
   * Duplicate a product
   */
  async duplicate(id: string, overrides?: Partial<CreateProductDto>): Promise<Product> {
    const response = await api.post<{ data: Product }>(ENDPOINTS.duplicate(id), overrides);
    return response.data;
  },

  // ============================================
  // BULK OPERATIONS
  // ============================================

  /**
   * Bulk create products
   */
  async bulkCreate(products: CreateProductDto[]): Promise<{ created: Product[]; errors: Array<{ index: number; error: string }> }> {
    return api.post(ENDPOINTS.bulk, { products });
  },

  /**
   * Bulk delete products
   */
  async bulkDelete(ids: string[]): Promise<{ deleted: number; errors: Array<{ id: string; error: string }> }> {
    return api.post(ENDPOINTS.bulkDelete, { ids });
  },

  /**
   * Bulk update products
   */
  async bulkUpdate(
    updates: Array<{ id: string; data: UpdateProductDto }>
  ): Promise<{ updated: Product[]; errors: Array<{ id: string; error: string }> }> {
    return api.post(ENDPOINTS.bulkUpdate, { updates });
  },

  /**
   * Bulk publish products
   */
  async bulkPublish(ids: string[]): Promise<{ published: Product[]; errors: Array<{ id: string; error: string }> }> {
    return api.post(ENDPOINTS.bulkPublish, { ids });
  },

  // ============================================
  // EXPORT/IMPORT
  // ============================================

  /**
   * Export products to CSV
   */
  async exportCsv(filters?: ProductFilters): Promise<Blob> {
    const params = buildQueryParams(filters);
    const response = await fetch(`${ENDPOINTS.export}?${new URLSearchParams(params as Record<string, string>).toString()}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
        Accept: 'text/csv',
      },
    });

    if (!response.ok) {
      throw new ApiError('Export failed', response.status, 'EXPORT_ERROR');
    }

    return response.blob();
  },

  /**
   * Import products from CSV
   */
  async importCsv(file: File): Promise<{ imported: number; errors: Array<{ row: number; error: string }> }> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(ENDPOINTS.import, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('auth_token')}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new ApiError(error.message || 'Import failed', response.status, 'IMPORT_ERROR');
    }

    return response.json();
  },

  // ============================================
  // UTILITY FUNCTIONS
  // ============================================

  /**
   * Check if SKU is available
   */
  async checkSkuAvailability(sku: string, excludeId?: string): Promise<boolean> {
    const params: Record<string, string> = { sku };
    if (excludeId) params.excludeId = excludeId;

    const response = await api.get<{ available: boolean }>('/products/check-sku', { params });
    return response.available;
  },

  /**
   * Get product statistics
   */
  async getStats(): Promise<{
    total: number;
    byStatus: Record<string, number>;
    byType: Record<string, number>;
    publishedCount: number;
    recentlyCreated: number;
  }> {
    return api.get('/products/stats');
  },

  /**
   * Retry failed operation with exponential backoff
   */
  async withRetry<T>(fn: () => Promise<T>, maxRetries = 3): Promise<T> {
    return withRetry(fn, { maxRetries });
  },

  /**
   * Execute multiple operations in parallel with concurrency control
   */
  async batch<T>(
    operations: Array<() => Promise<T>>,
    concurrency = 5
  ): Promise<Array<{ status: 'fulfilled'; value: T } | { status: 'rejected'; reason: Error }>> {
    return batchRequests(operations, concurrency);
  },
};

export default productApi;
