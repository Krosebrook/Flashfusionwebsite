/* eslint-disable no-console */
export type LogLevel = "debug" | "info" | "warn" | "error";

const levelRank: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};

function currentLevel(): LogLevel {
  const env = (process.env.LOG_LEVEL || "").toLowerCase();
  if (env === "debug" || env === "info" || env === "warn" || env === "error") return env;
  return process.env.NODE_ENV === "production" ? "info" : "debug";
}

function canLog(level: LogLevel): boolean {
  return levelRank[level] >= levelRank[currentLevel()];
}

const warned = new Set<string>();

export const logger = {
  debug: (...args: unknown[]) => { if (canLog("debug")) console.debug("[debug]", ...args); },
  info: (...args: unknown[]) => { if (canLog("info")) console.info("[info]", ...args); },
  warn: (...args: unknown[]) => { if (canLog("warn")) console.warn("[warn]", ...args); },
  error: (...args: unknown[]) => { if (canLog("error")) console.error("[error]", ...args); },
  warnOnce: (key: string, message: string) => {
    if (warned.has(key)) return;
    warned.add(key);
    if (canLog("warn")) console.warn("[warn]", message);
  }
};
