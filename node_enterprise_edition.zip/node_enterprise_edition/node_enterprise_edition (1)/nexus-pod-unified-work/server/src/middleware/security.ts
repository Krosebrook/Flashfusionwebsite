import type { Express } from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { randomUUID } from "node:crypto";
import { readEnv } from "../utils/env.js";

export function applySecurityMiddleware(app: Express): void {
  app.set("trust proxy", 1);

  app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }
  }));

  const corsOrigin = readEnv("CORS_ORIGIN", { warnIfMissing: false });
  app.use(cors({
    origin: corsOrigin ? corsOrigin.split(",").map(s => s.trim()) : true,
    credentials: true
  }));

  app.use(rateLimit({
    windowMs: 60_000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false
  }));

  app.use((req, _res, next) => {
    // Basic request id propagation
    const incoming = req.header("x-request-id");
    (req as any).requestId = incoming || randomUUID();
    next();
  });
}
