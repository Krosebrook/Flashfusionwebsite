import { logger } from "../utils/logger.js";

export type StoreKind = "shopify" | "etsy" | "printify" | "woocommerce";

export type PublishProductPayload = {
  title: string;
  description?: string;
  price?: number; // store currency units (e.g., USD dollars)
  currency?: string;
  images?: string[]; // data URLs or remote URLs
  tags?: string[];
};

export type PublishProductResult = {
  demoMode: boolean;
  store: StoreKind;
  externalId: string;
  url?: string;
  warning?: string;
  raw?: unknown;
};

function normalizeHttpsUrl(url: string | undefined): string | undefined {
  if (!url) return undefined;
  const trimmed = url.trim().replace(/\/$/, "");
  if (!trimmed) return undefined;
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
  return `https://${trimmed}`;
}

function parseDataUrl(dataUrl: string): { mime: string; base64: string } | null {
  const m = dataUrl.match(/^data:([^;]+);base64,(.+)$/i);
  if (!m) return null;
  return { mime: m[1], base64: m[2] };
}

function demoResult(store: StoreKind, warning: string): PublishProductResult {
  return {
    demoMode: true,
    store,
    externalId: "demo",
    warning
  };
}

type FetchJsonInit = Omit<RequestInit, "signal"> & { timeoutMs?: number };

async function fetchJson(url: string, init: FetchJsonInit): Promise<any> {
  const timeoutMs = init.timeoutMs ?? 10_000;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const contentType = res.headers.get("content-type") || "";
    const text = await res.text();

    if (!res.ok) {
      throw Object.assign(
        new Error(`HTTP ${res.status} ${res.statusText}: ${text.slice(0, 500)}`),
        { status: res.status, body: text }
      );
    }

    if (contentType.includes("application/json")) return JSON.parse(text);
    // Some APIs return JSON with a different content-type; try parse.
    try {
      return JSON.parse(text);
    } catch {
      return { raw: text };
    }
  } finally {
    clearTimeout(timeout);
  }
}

export class StoreConnector {
  private apiKey?: string;
  private storeUrl?: string;
  private kind: StoreKind;
  private extra?: Record<string, string | undefined>;

  constructor(args: { apiKey?: string; storeUrl?: string; kind: StoreKind; extra?: Record<string, string | undefined> }) {
    this.apiKey = args.apiKey;
    this.storeUrl = args.storeUrl;
    this.kind = args.kind;
    this.extra = args.extra;
  }

  async publishProduct(payload: PublishProductPayload): Promise<PublishProductResult> {
    if (this.kind === "shopify") return this.publishShopify(payload);
    if (this.kind === "etsy") return this.publishEtsy(payload);
    if (this.kind === "printify") return this.publishPrintify(payload);
    if (this.kind === "woocommerce") return this.publishWooCommerce(payload);

    // Exhaustive guard
    const neverKind: never = this.kind;
    throw new Error(`Unsupported store kind: ${neverKind}`);
  }

  private async publishShopify(payload: PublishProductPayload): Promise<PublishProductResult> {
    const token = this.apiKey;
    const storeUrl = normalizeHttpsUrl(this.storeUrl);

    if (!token) return demoResult("shopify", "Missing Env Var: SHOPIFY_ACCESS_TOKEN");
    if (!storeUrl) return demoResult("shopify", "Missing Env Var: SHOPIFY_STORE_URL");

    const apiVersion = (this.extra?.SHOPIFY_API_VERSION || "2025-10").trim();
    const mode = (this.extra?.SHOPIFY_API_MODE || "graphql").trim().toLowerCase();

    // Best practice (Shopify): GraphQL is the primary Admin API; REST is legacy.
    // Keep REST for compatibility as a fallback.
    if (mode === "rest") {
      return this.publishShopifyRest(storeUrl, token, apiVersion, payload);
    }

    try {
      return await this.publishShopifyGraphql(storeUrl, token, apiVersion, payload);
    } catch (e) {
      logger.warn("Shopify GraphQL publish failed; attempting REST fallback.", String(e));
      try {
        return await this.publishShopifyRest(storeUrl, token, apiVersion, payload);
      } catch (e2) {
        return demoResult("shopify", `Shopify publish failed (GraphQL + REST). ${String(e2).slice(0, 180)}`);
      }
    }
  }

  private async publishShopifyGraphql(storeUrl: string, token: string, apiVersion: string, payload: PublishProductPayload): Promise<PublishProductResult> {
    const endpoint = `${storeUrl}/admin/api/${apiVersion}/graphql.json`;

    const price = typeof payload.price === "number" ? payload.price : 19.99;
    const tags = (payload.tags || []).filter(Boolean);

    // Media: GraphQL expects URLs for originalSource. Data URLs are not supported directly.
    const media = (payload.images || [])
      .filter((u) => u.startsWith("https://") || u.startsWith("http://"))
      .map((u) => ({
        mediaContentType: "IMAGE",
        originalSource: u,
        alt: payload.title
      }));

    const mutation = `
      mutation productCreate($input: ProductInput!, $media: [CreateMediaInput!]) {
        productCreate(input: $input, media: $media) {
          product { id legacyResourceId title }
          userErrors { field message }
        }
      }
    `;

    const variables = {
      input: {
        title: payload.title,
        descriptionHtml: payload.description || "Generated with Nexus POD",
        tags,
        status: "DRAFT"
      },
      media: media.length ? media : null
    };

    const res = await fetchJson(endpoint, {
      method: "POST",
      timeoutMs: 15_000,
      headers: {
        "X-Shopify-Access-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({ query: mutation, variables })
    });

    const userErrors = res?.data?.productCreate?.userErrors || [];
    if (userErrors.length) {
      const msg = String(userErrors[0]?.message || "Unknown Shopify user error");
      throw new Error(`Shopify user error: ${msg}`);
    }

    const product = res?.data?.productCreate?.product;
    const legacyId = product?.legacyResourceId ? String(product.legacyResourceId) : undefined;
    const externalId = legacyId || String(product?.id || "unknown");
    const url = legacyId ? `${storeUrl}/admin/products/${legacyId}` : undefined;

    // Warning if caller passed data URLs (ignored in GraphQL mode)
    const passedDataUrls = (payload.images || []).some((u) => u.startsWith("data:"));
    const warning = passedDataUrls ? "Some images were data URLs and were not uploaded in GraphQL mode. Use remote URLs or upload media separately." : undefined;

    return { demoMode: false, store: "shopify", externalId, url, warning, raw: res };
  }

  private async publishShopifyRest(storeUrl: string, token: string, apiVersion: string, payload: PublishProductPayload): Promise<PublishProductResult> {
    const endpoint = `${storeUrl}/admin/api/${apiVersion}/products.json`;

    const images = (payload.images || []).map((img) => {
      const data = parseDataUrl(img);
      if (data?.mime?.startsWith("image/") && data.base64) {
        // REST supports base64 attachments
        return { attachment: data.base64, filename: "nexus-pod.png" };
      }
      if (img.startsWith("http://") || img.startsWith("https://")) return { src: img };
      return undefined;
    }).filter(Boolean) as any[];

    const bodyHtml = payload.description || "Generated with Nexus POD";
    const price = typeof payload.price === "number" ? payload.price.toFixed(2) : "19.99";

    const product = {
      product: {
        title: payload.title,
        body_html: bodyHtml,
        vendor: "Nexus POD",
        product_type: "Print-on-Demand",
        tags: (payload.tags || []).join(", "),
        variants: [{ price }],
        images
      }
    };

    const res = await fetchJson(endpoint, {
      method: "POST",
      headers: {
        "X-Shopify-Access-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(product)
    });

    const externalId = String(res?.product?.id ?? "unknown");
    const url = `${storeUrl}/admin/products/${externalId}`;
    return { demoMode: false, store: "shopify", externalId, url, raw: res };
  }

  private async publishEtsy(_payload: PublishProductPayload): Promise<PublishProductResult> {
    // Etsy publishing requires OAuth2 and listing-specific required fields that vary by category.
    // This starter focuses on orchestration + readiness. Implement a dedicated Etsy module for real production publishing.
    const accessToken = this.extra?.ETSY_ACCESS_TOKEN || this.apiKey;
    const clientKey = this.extra?.ETSY_API_KEY;
    const shopId = this.extra?.ETSY_SHOP_ID;

    if (!clientKey) return demoResult("etsy", "Missing Env Var: ETSY_API_KEY");
    if (!accessToken) return demoResult("etsy", "Missing Env Var: ETSY_ACCESS_TOKEN");
    if (!shopId) return demoResult("etsy", "Missing Env Var: ETSY_SHOP_ID");

    return demoResult("etsy", "Etsy publishing not implemented in this starter (OAuth2 + listing schema required).");
  }

  private async publishPrintify(_payload: PublishProductPayload): Promise<PublishProductResult> {
    // Printify product creation requires blueprint + provider + variants; keep demo in this starter.
    const token = this.apiKey;
    if (!token) return demoResult("printify", "Missing Env Var: PRINTIFY_API_TOKEN");
    return demoResult("printify", "Printify publishing not implemented in this starter (requires blueprint/provider selection).");
  }

  private async publishWooCommerce(payload: PublishProductPayload): Promise<PublishProductResult> {
    const storeUrl = normalizeHttpsUrl(this.storeUrl);
    const key = this.extra?.WOOCOMMERCE_CONSUMER_KEY;
    const secret = this.extra?.WOOCOMMERCE_CONSUMER_SECRET;

    if (!storeUrl) return demoResult("woocommerce", "Missing Env Var: WOOCOMMERCE_STORE_URL");
    if (!key) return demoResult("woocommerce", "Missing Env Var: WOOCOMMERCE_CONSUMER_KEY");
    if (!secret) return demoResult("woocommerce", "Missing Env Var: WOOCOMMERCE_CONSUMER_SECRET");

    const endpoint = `${storeUrl}/wp-json/wc/v3/products`;
    const basic = Buffer.from(`${key}:${secret}`).toString("base64");

    const regular_price = typeof payload.price === "number" ? payload.price.toFixed(2) : undefined;

    const images = (payload.images || [])
      .filter((u) => u.startsWith("https://") || u.startsWith("http://"))
      .map((src) => ({ src }));

    const body = {
      name: payload.title,
      type: "simple",
      regular_price,
      description: payload.description || "",
      short_description: payload.description || "",
      tags: (payload.tags || []).filter(Boolean).map((name) => ({ name })),
      images
    };

    const res = await fetchJson(endpoint, {
      method: "POST",
      timeoutMs: 12_000,
      headers: {
        "Authorization": `Basic ${basic}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(body)
    });

    const externalId = String(res?.id ?? "unknown");
    const url = String(res?.permalink || "");
    const warning = (payload.images || []).some((u) => u.startsWith("data:"))
      ? "Some images were data URLs and were not uploaded to WooCommerce (remote URLs only in this starter)."
      : undefined;

    return { demoMode: false, store: "woocommerce", externalId, url, warning, raw: res };
  }
}
