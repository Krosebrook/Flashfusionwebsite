import type { SeedPayload, SeedSource, SeedBenchmarks, SeedTimeseriesPoint, Product, ProductTemplate, Order, StoreConnection } from "@/types";

/**
 * Offline fallback seed generator.
 *
 * This mirrors the backend's seeded, web-grounded dataset without relying on
 * any runtime network calls. The goal is to keep Demo Mode realistic while
 * remaining deterministic enough for dashboards/tests.
 */

function isoDateOnly(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function hashStringToInt(input: string): number {
  // DJB2-ish
  let h = 5381;
  for (let i = 0; i < input.length; i++) {
    h = ((h << 5) + h) ^ input.charCodeAt(i);
  }
  // Convert to positive 32-bit
  return h >>> 0;
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function idFor(prefix: string, seed: string): string {
  const h = hashStringToInt(`${prefix}:${seed}`).toString(16).slice(0, 12);
  return `${prefix}_${h.padStart(12, "0")}`;
}

export function createGroundedFallbackSeed(now = new Date()): SeedPayload {
  const asOf = isoDateOnly(now);

  const sources: SeedSource[] = [
    { name: "Shopify – conversion rate benchmarks", url: "https://www.shopify.com/blog/ecommerce-conversion-rate", asOf },
    { name: "Printify – production times", url: "https://help.printify.com/hc/en-us/articles/4483629751825-What-are-Printify-s-production-times-like", asOf },
    { name: "Printful – fulfillment times", url: "https://help.printful.com/hc/en-us/articles/360014007980-How-long-does-fulfillment-take", asOf },
    { name: "Printify – tee example cost", url: "https://printify.com/app/products/6/gildan/unisex-heavy-cotton-tee", asOf, note: "Example baseline cost only." },
    { name: "Printify – hoodies list", url: "https://printify.com/app/products/mens-clothing/hoodies", asOf, note: "Example baseline cost only." },
    { name: "Printify – mugs list", url: "https://printify.com/app/products/home-and-living/mugs", asOf, note: "Example baseline cost only." }
  ];

  const benchmarks: SeedBenchmarks = {
    conversionRateTypical: 0.025,
    conversionRateShopifyAvg: 0.014,
    conversionRateGood: 0.032,
    printifyProductionDays: { min: 2, max: 7 },
    printfulFulfillmentDays: { min: 2, max: 5 },
    baselineCostsUsd: { tee: 9.5, hoodie: 21.58, mug: 4.93 }
  };

  const templates: ProductTemplate[] = [
    {
      id: idFor("tpl", "classic-tee"),
      name: "Classic Tee (DTG front)",
      baseProductType: "T_SHIRT",
      defaultPrice: 24.99,
      defaultCost: benchmarks.baselineCostsUsd.tee,
      defaultTags: ["tee", "classic", "dtg"],
      createdAt: now.toISOString()
    },
    {
      id: idFor("tpl", "hoodie-core"),
      name: "Core Hoodie (front)",
      baseProductType: "HOODIE",
      defaultPrice: 49.99,
      defaultCost: benchmarks.baselineCostsUsd.hoodie,
      defaultTags: ["hoodie", "core"],
      createdAt: now.toISOString()
    },
    {
      id: idFor("tpl", "mug-ceramic"),
      name: "Ceramic Mug (11oz)",
      baseProductType: "MUG",
      defaultPrice: 19.99,
      defaultCost: benchmarks.baselineCostsUsd.mug,
      defaultTags: ["mug", "ceramic"],
      createdAt: now.toISOString()
    }
  ];

  const products: Product[] = [
    {
      id: idFor("prod", "midwest-minimal-tee"),
      title: "Midwest Minimal Tee",
      description: "Clean typographic print. Designed for high legibility and low ink coverage.",
      productType: "T_SHIRT",
      price: 24.99,
      cost: benchmarks.baselineCostsUsd.tee,
      status: "READY",
      designAssetId: null,
      storeId: null,
      tags: ["minimal", "typography", "tee"],
      variants: [],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    },
    {
      id: idFor("prod", "dad-joke-hoodie"),
      title: "Dad Joke Hoodie (Deluxe)",
      description: "A hoodie for people who believe puns are a human right.",
      productType: "HOODIE",
      price: 54.99,
      cost: benchmarks.baselineCostsUsd.hoodie,
      status: "DRAFT",
      designAssetId: null,
      storeId: null,
      tags: ["hoodie", "funny"],
      variants: [],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    },
    {
      id: idFor("prod", "cosmic-mug"),
      title: "Cosmic Gradient Mug",
      description: "A simple, high-contrast gradient that survives tiny thumbnails.",
      productType: "MUG",
      price: 19.99,
      cost: benchmarks.baselineCostsUsd.mug,
      status: "PUBLISHED",
      designAssetId: null,
      storeId: null,
      tags: ["mug", "cosmic"],
      variants: [],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    }
  ];

  const days = 14;
  const timeseries: SeedTimeseriesPoint[] = [];
  const orders: Order[] = [];

  const baseSessions = 1100;
  const baseAov = 38.5;
  const baseCvr = benchmarks.conversionRateTypical;

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const date = isoDateOnly(d);

    const drift = hashStringToInt(date) % 120; // 0..119
    const sessions = baseSessions + (days - i) * 25 + drift;
    const cvr = clamp(baseCvr + ((drift - 60) / 10000), 0.01, 0.05);
    const ordersCount = Math.max(1, Math.round(sessions * cvr));
    const aov = round2(baseAov + ((drift - 60) / 10));
    const revenue = round2(ordersCount * aov);
    const adSpend = round2(sessions * 0.18);

    timeseries.push({
      date,
      sessions,
      orders: ordersCount,
      revenue,
      adSpend,
      conversionRate: round2(ordersCount / sessions),
      aov
    });

    for (let j = 0; j < ordersCount; j++) {
      const orderId = idFor("ord", `${date}:${j}`).toUpperCase();
      const total = round2(aov + ((j % 5) - 2) * 1.75);
      const status = j % 7 === 0 ? "PENDING" : j % 5 === 0 ? "SHIPPED" : "DELIVERED";
      orders.push({
        id: orderId,
        customerName: `Customer ${String((days - i) * 10 + j + 1).padStart(3, "0")}`,
        total,
        status,
        items: [{ productId: products[j % products.length].id, quantity: 1 }],
        createdAt: new Date(d.getTime() + j * 60 * 60 * 1000).toISOString()
      });
    }
  }

  const stores: StoreConnection[] = [
    { id: idFor("store", "shopify"), platform: "Shopify", kind: "shopify", storeName: "Demo Shopify Store", apiKeyMasked: "••••••••", connectedAt: now.toISOString(), status: "DISCONNECTED" },
    { id: idFor("store", "etsy"), platform: "Etsy", kind: "etsy", storeName: "Demo Etsy Shop", apiKeyMasked: "••••••••", connectedAt: now.toISOString(), status: "DISCONNECTED" },
    { id: idFor("store", "printify"), platform: "Printify", kind: "printify", storeName: "Demo Printify", apiKeyMasked: "••••••••", connectedAt: now.toISOString(), status: "DISCONNECTED" },
    { id: idFor("store", "woocommerce"), platform: "WooCommerce", kind: "woocommerce", storeName: "Demo Woo Store", apiKeyMasked: "••••••••", connectedAt: now.toISOString(), status: "DISCONNECTED" }
  ];

  return {
    generatedAt: now.toISOString(),
    sources,
    benchmarks,
    timeseries,
    products,
    templates,
    orders,
    stores
  };
}
