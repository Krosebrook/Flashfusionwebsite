import * as React from "react";
import { Search, Trash2 } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export default function Products() {
  const { products, deleteProduct } = useAppData();
  const [query, setQuery] = React.useState("");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) => p.title.toLowerCase().includes(q) || p.productType.toLowerCase().includes(q));
  }, [products, query]);

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Products</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Manage your catalog and prep items for publishing.</p>
        </div>
        <Button
          variant="secondary"
          onClick={() => alert("Create flow: use Bulk Generator / Design Studio for now.")}
        >
          New product
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex items-center gap-3">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title or type…"
            className="w-full bg-transparent outline-none text-sm"
            aria-label="Search products"
          />
        </div>
      </Card>

      <div className="grid gap-3">
        {filtered.map((p) => (
          <Card key={p.id} className="p-4">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold truncate">{p.title}</h3>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                    {p.productType}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-200">
                    {p.status}
                  </span>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  Price: ${p.price} • Cost: ${p.cost} • Variants: {p.variants?.length ?? 0}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Button variant="ghost" onClick={() => deleteProduct(p.id)} aria-label={`Delete ${p.title}`}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {filtered.length === 0 && (
          <Card className="p-10">
            <div className="text-center text-slate-500 dark:text-slate-400">No products match your search.</div>
          </Card>
        )}
      </div>
    </div>
  );
}
