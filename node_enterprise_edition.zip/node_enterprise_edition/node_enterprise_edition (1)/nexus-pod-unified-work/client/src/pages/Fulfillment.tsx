import * as React from "react";
import { Clock, PackageCheck, Truck } from "lucide-react";
import { useAppData } from "@/context/AppDataContext";
import { KpiCard } from "@/components/charts/KpiCard";
import { BarChartCard } from "@/components/charts/BarChartCard";
import { Card } from "@/components/ui/Card";

function addDays(iso: string, days: number): Date {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d;
}

export default function Fulfillment() {
  const { orders, seed } = useAppData();
  const b = seed?.benchmarks;
  const production = b?.printifyProductionDays ?? { min: 2, max: 7 };
  const fulfillment = b?.printfulFulfillmentDays ?? { min: 2, max: 5 };

  const counts = React.useMemo(() => {
    return orders.reduce(
      (acc, o) => {
        acc[o.status] += 1;
        return acc;
      },
      { PENDING: 0, SHIPPED: 0, DELIVERED: 0 }
    );
  }, [orders]);

  const openOrders = orders.filter((o) => o.status !== "DELIVERED").slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const chartData = [
    { status: "PENDING", count: counts.PENDING },
    { status: "SHIPPED", count: counts.SHIPPED },
    { status: "DELIVERED", count: counts.DELIVERED }
  ];

  const avgAgeDays = React.useMemo(() => {
    if (!openOrders.length) return 0;
    const now = Date.now();
    const total = openOrders.reduce((acc, o) => acc + Math.max(0, now - Date.parse(o.createdAt)), 0);
    return total / openOrders.length / (1000 * 60 * 60 * 24);
  }, [openOrders]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Fulfillment</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Production + fulfillment windows are shown using web-grounded benchmarks from the seed. Replace these with real carrier + provider data once connected.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KpiCard icon={PackageCheck} label="Delivered" value={String(counts.DELIVERED)} subtext="Completed orders" />
        <KpiCard icon={Truck} label="In-flight" value={String(counts.SHIPPED)} subtext="Shipped" />
        <KpiCard icon={Clock} label="Open order age" value={`${avgAgeDays.toFixed(1)} days`} subtext={`Pending: ${counts.PENDING}`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BarChartCard
          title="Order Status"
          data={chartData}
          xKey="status"
          barKey="count"
          barLabel="Count"
          yFormatter={(v) => String(v)}
          height={360}
        />

        <Card className="p-4">
          <h3 className="text-lg font-semibold">Benchmark windows</h3>
          <div className="mt-3 text-sm text-slate-600 dark:text-slate-300 space-y-2">
            <div>
              <div className="font-medium">Production time</div>
              <div className="text-slate-500 dark:text-slate-400">{production.min}–{production.max} business days (seed benchmark)</div>
            </div>
            <div>
              <div className="font-medium">Fulfillment time</div>
              <div className="text-slate-500 dark:text-slate-400">{fulfillment.min}–{fulfillment.max} business days (seed benchmark)</div>
            </div>
            <div>
              <div className="font-medium">Estimated delivery range</div>
              <div className="text-slate-500 dark:text-slate-400">
                {production.min + fulfillment.min}–{production.max + fulfillment.max} business days from order creation.
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold">Open orders</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Uses benchmark windows to estimate ship + delivery dates.
            </p>
          </div>
        </div>

        <div className="mt-4 overflow-auto">
          <table className="min-w-full text-sm">
            <thead className="text-left text-slate-600 dark:text-slate-300">
              <tr className="border-b border-slate-200 dark:border-slate-800">
                <th className="py-2 pr-4">Order</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2 pr-4">Created</th>
                <th className="py-2 pr-4">Est. ship</th>
                <th className="py-2 pr-4">Est. deliver</th>
              </tr>
            </thead>
            <tbody>
              {openOrders.slice(0, 20).map((o) => {
                const created = o.createdAt;
                const shipMin = addDays(created, production.min);
                const shipMax = addDays(created, production.max);
                const delMin = addDays(created, production.min + fulfillment.min);
                const delMax = addDays(created, production.max + fulfillment.max);
                return (
                  <tr key={o.id} className="border-b border-slate-100 dark:border-slate-900">
                    <td className="py-2 pr-4 font-mono text-xs whitespace-nowrap">{o.id}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{o.status}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{new Date(created).toLocaleString()}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{shipMin.toLocaleDateString()}–{shipMax.toLocaleDateString()}</td>
                    <td className="py-2 pr-4 whitespace-nowrap">{delMin.toLocaleDateString()}–{delMax.toLocaleDateString()}</td>
                  </tr>
                );
              })}
              {openOrders.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-slate-500 dark:text-slate-400">No open orders.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
