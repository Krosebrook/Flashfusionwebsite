import * as React from "react";
import { Link } from "react-router-dom";
import type { StatusResponse } from "@/lib/api";

export function DemoModeBanner(props: { status: StatusResponse | null; error?: string | null }) {
  const { status, error } = props;

  if (error) {
    return (
      <div className="w-full rounded-xl border border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-100 px-4 py-3 text-sm">
        <strong>API not reachable.</strong> {error}{" "}
        <span className="opacity-80">
          Start the server with <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">npm run dev</code> or{" "}
          <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">npm start</code>.
        </span>
      </div>
    );
  }

  if (!status) return null;

  if (!status.demoMode) {
    return (
      <div className="w-full rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-900 dark:border-indigo-900/40 dark:bg-indigo-950/30 dark:text-indigo-100 px-4 py-3 text-sm">
        <div className="flex items-start justify-between gap-4">
          <div>
            <strong>LIVE.</strong> All critical integrations configured. Score: <strong>{status.score}/100</strong>.
            {status.warnings?.length ? (
              <div className="mt-1 text-xs opacity-80">Warnings: {status.warnings.slice(0, 2).join(" • ")}{status.warnings.length > 2 ? " …" : ""}</div>
            ) : null}
          </div>
          <Link to="/readiness" className="text-xs underline opacity-90 hover:opacity-100">View readiness</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full rounded-xl border border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-100 px-4 py-3 text-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <strong>{status.mode === "PARTIAL" ? "PARTIAL" : "DEMO"} Mode.</strong>{" "}
          Score: <strong>{status.score}/100</strong>.{" "}
          {status.missing?.length ? (
            <>
              Missing env vars:{" "}
              <code className="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10">{status.missing.join(", ")}</code>.
            </>
          ) : null}
          {status.warnings?.length ? (
            <div className="mt-1 text-xs opacity-80">Warnings: {status.warnings.slice(0, 2).join(" • ")}{status.warnings.length > 2 ? " …" : ""}</div>
          ) : null}
        </div>
        <Link to="/readiness" className="text-xs underline opacity-90 hover:opacity-100">Fix readiness</Link>
      </div>
    </div>
  );
}
