import { localDb, KEYS } from "@/storage/localDb";
import type { SeedPayload, AutomationRule } from "@/types";
import { fetchSeed } from "@/lib/api";
import { createGroundedFallbackSeed } from "@/data/groundedFallback";

const SCHEMA_VERSION = 2;

function safeNow(): Date {
  try { return new Date(); } catch { return new Date(0); }
}

function hasNonEmptyArray<T>(value: unknown): value is T[] {
  return Array.isArray(value) && value.length > 0;
}

function defaultAutomations(now = safeNow()): AutomationRule[] {
  const iso = now.toISOString();
  return [
    {
      id: "aut_publish_ready_shopify",
      name: "Publish READY products → Shopify (manual run)",
      enabled: true,
      trigger: { type: "MANUAL" },
      action: { type: "PUBLISH_READY_PRODUCTS", store: "shopify" },
      createdAt: iso
    },
    {
      id: "aut_export_kpi",
      name: "Export KPI CSV (manual run)",
      enabled: true,
      trigger: { type: "MANUAL" },
      action: { type: "EXPORT_KPI_CSV" },
      createdAt: iso
    },
    {
      id: "aut_export_orders",
      name: "Export Orders CSV (manual run)",
      enabled: false,
      trigger: { type: "MANUAL" },
      action: { type: "EXPORT_ORDERS_CSV" },
      createdAt: iso
    }
  ];
}

export type BootstrapResult = {
  seed: SeedPayload;
  usedNetworkSeed: boolean;
};

/**
 * Ensures local storage contains the minimum datasets required for the app.
 *
 * Behavior:
 * - If schema matches and core arrays exist, returns stored seed.
 * - Otherwise attempts GET /api/seed; if that fails (offline/API down), falls back.
 */
export async function ensureBootstrapped(): Promise<BootstrapResult> {
  const version = localDb.get<number>(KEYS.SCHEMA, 0);
  const products = localDb.get(KEYS.PRODUCTS, null as unknown);
  const orders = localDb.get(KEYS.ORDERS, null as unknown);
  const templates = localDb.get(KEYS.TEMPLATES, null as unknown);
  const stores = localDb.get(KEYS.STORES, null as unknown);

  const seedInStorage = localDb.get<SeedPayload | null>(KEYS.SEED, null);

  const looksInitialized =
    version === SCHEMA_VERSION &&
    hasNonEmptyArray(products) &&
    hasNonEmptyArray(orders) &&
    hasNonEmptyArray(templates) &&
    Array.isArray(stores);

  if (looksInitialized && seedInStorage) {
    // Automations are optional; seed them if missing.
    const autos = localDb.get(KEYS.AUTOMATIONS, null as unknown);
    if (!Array.isArray(autos)) localDb.set(KEYS.AUTOMATIONS, defaultAutomations());
    return { seed: seedInStorage, usedNetworkSeed: false };
  }

  // Attempt network seed first.
  let seed: SeedPayload | null = null;
  let usedNetworkSeed = false;
  try {
    const res = await fetchSeed();
    seed = res;
    usedNetworkSeed = true;
  } catch {
    // Offline/API down: fall back.
    seed = createGroundedFallbackSeed(safeNow());
    usedNetworkSeed = false;
  }

  // Persist scoped keys (never wipe whole origin).
  localDb.set(KEYS.PRODUCTS, seed.products);
  localDb.set(KEYS.TEMPLATES, seed.templates);
  localDb.set(KEYS.ORDERS, seed.orders);
  localDb.set(KEYS.STORES, seed.stores);
  localDb.set(KEYS.SEED, seed);

  // Always ensure these exist.
  const designs = localDb.get(KEYS.DESIGNS, null as unknown);
  if (!Array.isArray(designs)) localDb.set(KEYS.DESIGNS, []);
  const events = localDb.get(KEYS.EVENTS, null as unknown);
  if (!Array.isArray(events)) localDb.set(KEYS.EVENTS, []);
  const autos = localDb.get(KEYS.AUTOMATIONS, null as unknown);
  if (!Array.isArray(autos)) localDb.set(KEYS.AUTOMATIONS, defaultAutomations());

  localDb.set(KEYS.SCHEMA, SCHEMA_VERSION);

  return { seed, usedNetworkSeed };
}

export function removeAppKeys(): void {
  const keysToRemove = new Set<string>(Object.values(KEYS));
  // Ensure legacy schema key is removed too.
  keysToRemove.add(KEYS.SCHEMA_V1);
  for (const k of keysToRemove) {
    try { localStorage.removeItem(k); } catch { /* noop */ }
  }
}
