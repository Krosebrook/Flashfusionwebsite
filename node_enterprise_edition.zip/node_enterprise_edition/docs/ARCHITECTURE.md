# System Architecture

## Overview
This system has been modernized to follow the **Twelve-Factor App** methodology. It utilizes containerization for consistent environments and orchestration for high availability.

## Component Diagram
```mermaid
graph TD
    Client -->|HTTPS| CDN
    CDN -->|TLS| LB[Load Balancer]
    LB -->|Routing| API[API Gateway]
    API -->|gRPC| Core[Core Service]
    Core -->|Read/Write| DB[(Primary Database)]
    Core -->|Cache| Redis[Redis Cluster]
    
    subgraph Observability
        Prometheus --> Core
        Grafana --> Prometheus
    end
```

## Technology Stack
- **Runtime**: Node.js 18 (LTS)
- **Infrastructure**: Terraform / Docker / Kubernetes
- **Observability**: Prometheus / Grafana / ELK Stack